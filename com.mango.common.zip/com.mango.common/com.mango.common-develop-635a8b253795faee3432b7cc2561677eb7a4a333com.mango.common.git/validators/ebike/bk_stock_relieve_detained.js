const Joi = require('poolishark').Joi;
const validators = require('../../settings/validators');

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  detainedArea: Joi.string().description('扣押点'),
  stock: Joi.array().items(Joi.string()).description('车辆'),
  reportTime: Joi.date().description('上报时间'),
  handler: Joi.string().description('处理人'),
  penalty: Joi.number().description('罚款金额'),
  parkingFee: Joi.number().description('停车费'),
}).unknown().empty(null);