const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  dataSource: Joi.number().description('数据源'),
  deviceType: Joi.string().description('设备型号'),
  appVersion: Joi.string().description('软件版本号'),
  sim: Joi.object({
    imsi: Joi.string().description('IMSI'),
    powerOn: Joi.boolean().description('是否开机'),
    expiryDate: Joi.date().description('有效期'),
    dataUsage: Joi.number().description('数据源'),
    dataBalance: Joi.number().description('剩余流量'),
    invalid: Joi.boolean().description('是否有效'),
  }).unknown().description('sim'),
  isOnline: Joi.boolean().description('当前是否在线'),
  latestOnlineAt: Joi.date().description('最近上线时间'),
  mode: Joi.number().description('模式'),
  signal: Joi.number().description('信号'),
  voltage: Joi.number().description('电压'),
  gpsLocation: Joi.object({
    gpsLngLat: Joi.array().items(Joi.number()).description('gps经纬度'),
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    time: Joi.date().description('定位时间'),
    speed: Joi.number().description('速度'),
    direction: Joi.number().description('相位角')
  }).unknown().description('GPS 信息'),
  cellLocation: Joi.object({
    mcc: Joi.number().description('移动国家代码'),
    mnc: Joi.number().description('移动网络号码'),
    cells: Joi.array().items({
      lac: Joi.number().description('本地区域识别码'),
      cellid: Joi.number().description('基站编号'),
      rxl: Joi.number().description('信号接收强度')
    }).description('基站信息'),
    time: Joi.date().description('基站定位时间')
  }).unknown(),
}).unknown().empty(null);