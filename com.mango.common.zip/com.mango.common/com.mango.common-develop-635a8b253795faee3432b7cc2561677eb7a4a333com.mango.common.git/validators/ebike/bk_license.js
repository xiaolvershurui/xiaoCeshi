const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  bikeNo: Joi.string().description('车牌号'),
  photo: Joi.string().description('照片'),
  bikeColor: Joi.string().description('车辆颜色'),
  owner: Joi.string().description('所有人'),
  address: Joi.string().description('住址'),
  vin: Joi.string().description('车架号'),
  model: Joi.string().description('品牌型号'),
  registeredAt: Joi.date().description('登记日期'),
  issuedAt: Joi.date().description('发证日期'),
  expiredAt: Joi.date().description('有效期'),
  number: Joi.string().description('证件号'),
  issuer: Joi.string().description('发证机构'),
  isChecked: Joi.boolean().description('是否已通过人工审核'),
  stock: Joi.string().description('车辆 ref'),
}).unknown().empty(null);