const Joi = require('poolishark').Joi;
const validators = require('../../settings/validators');

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  group: Joi.number().description('组别'),
  code: Joi.string().description('类型二维码'),
  region: Joi.string().description('大区'),
  station: Joi.string().description('站点'),
  asset: Joi.string().description('配件种类'),
  totalCount: Joi.number().description('总数'),
  intactCount: Joi.number().description('完好数量'),
  damageCount: Joi.number().description('损坏数量'),
  repairCount: Joi.number().description('返修数量'),
  scrapCount: Joi.number().description('报废数量')
}).unknown().empty(null);