const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  code: Joi.string().description('编码'),
  count: Joi.number().description('物资总数量'),
  region: Joi.string().description('物资所属大区'),
  name: Joi.string().description('名称'),
  remark: Joi.string().description('备注'),
  station: Joi.string().description('运营站'),
  unit: Joi.string().description('单位'),
  intactCount: Joi.number().description('完好物资数量'),
  damageCount: Joi.number().description('损坏物资数量'),
  scrapCount: Joi.number().description('报废物资数量'),
}).unknown().empty(null);