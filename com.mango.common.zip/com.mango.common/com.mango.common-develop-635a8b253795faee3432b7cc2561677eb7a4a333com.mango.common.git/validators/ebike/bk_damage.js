const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  description: Joi.string().description('损坏描述'),
  mountings: Joi.array().items(Joi.number()).description('损坏配件'),
  photo: Joi.string().description('照片'),
  repairPhoto: Joi.string().description('修复照片'),
  state: Joi.number().description('修复状态'),
  recordedAt: Joi.date().description('录损时间'),
  notifiedAt: Joi.date().description('通知时间'),
  repairedAt: Joi.date().description('修复时间'),
  repairRemark: Joi.string().description('修复备注'),
  submitter: Joi.string().description('提交人账户 ref'),
  repairer: Joi.string().description('修复人账户 ref'),
  stockState: Joi.number().description('导致库存变更为'),
}).unknown().empty(null);