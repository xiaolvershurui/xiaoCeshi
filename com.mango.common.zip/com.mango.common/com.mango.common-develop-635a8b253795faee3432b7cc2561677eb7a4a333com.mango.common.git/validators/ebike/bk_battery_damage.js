const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  battery: Joi.string().description('电池 ref'),
  description: Joi.string().description('损坏描述'),
  photo: Joi.string().description('照片'),
  state: Joi.number().description('修复状态'),
  recordedAt: Joi.date().description('录入时间'),
  notifiedAt: Joi.date().description('通知时间'),
  repairedAt: Joi.date().description('修复时间'),
  remark: Joi.string().description('备注'),
  repairer: Joi.string().description('维护人 ref'),
}).unknown().empty(null);