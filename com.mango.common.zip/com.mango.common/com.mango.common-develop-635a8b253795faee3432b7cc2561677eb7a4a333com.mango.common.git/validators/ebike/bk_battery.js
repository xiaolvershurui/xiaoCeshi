const Joi = require('poolishark').Joi;
const validators = require('../../settings/validators');

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  QRCode: Joi.string().description('二维码'),
  mark: Joi.string().description('标记'),
  enable: Joi.boolean().description('启用状态'),
  region: Joi.string().description('大区 ref'),
  state: Joi.number().description('损坏状态'),
  locate: Joi.number().description('去向'),
  gps: Joi.string().description('GPS绑定'),
  location: Joi.object({
    lngLat: validators.location.description('电池经纬度'),
    time: Joi.date().description('定位时间'),
    speed: Joi.number().description('速度'),
    direction: Joi.number().description('相位角')
  }).unknown().description('位置'),
  charge: Joi.boolean().description('充电状态'),
  underVoltage: Joi.boolean().description('是否馈电'),
  inspector: Joi.string().description('维护人 ref'),
  station: Joi.string().description('所在电站 ref'),
  fromStation: Joi.string().description('由某电站出发 ref'),
  stock: Joi.string().description('所在车辆 ref'),
  lastUpdatedPowerAt: Joi.date().description('最近一次更新电量时间'),
  useRecord: Joi.object({
    rechargeCount: Joi.number().description('充电次数'),
    useCount: Joi.number().description('使用次数')
  }).unknown().description('使用历史记录'),
  isSuspectedLost: Joi.boolean().description('疑似丢失标记'),
}).unknown().empty(null);