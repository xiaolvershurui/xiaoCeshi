const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  type: Joi.number().description('类型'),
  region: Joi.string().description('大区'),
  style: Joi.string().description('车型'),
  signal: Joi.number().description('标记'),
  order: Joi.string().description('订单 ref'),
  ticket: Joi.string().description('第三方支付凭据 ref'),
  amount: Joi.number().description('账单总额'),
}).unknown().empty(null);