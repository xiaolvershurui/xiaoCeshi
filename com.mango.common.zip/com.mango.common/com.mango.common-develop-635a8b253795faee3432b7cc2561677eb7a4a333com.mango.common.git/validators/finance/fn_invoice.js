const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  state: Joi.number().description('支付状态'),
  amount: Joi.number().description('支付金额'),
  link: Joi.string().description('发票链接'),
  passedAt: Joi.date().description('通过时间'),
  rejectedAt: Joi.date().description('驳回时间'),
  rejectReason: Joi.string().description('驳回理由'),
  checker: Joi.date().description('审核人'),
}).unknown().empty(null);