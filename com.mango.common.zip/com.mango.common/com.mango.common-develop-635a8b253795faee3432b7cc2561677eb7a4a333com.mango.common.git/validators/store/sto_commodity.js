const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  name: Joi.string().description('商品名称'),
  image: Joi.string().description('图片'),
  description: Joi.string().description('商品描述'),
  type: Joi.number().description('商品类型'),
  exchangeNotice: Joi.string().description('兑换须知'),
  points: Joi.number().description('所需积分'),
  money: Joi.number().description('所需金额'),
  tag: Joi.string().description('描述'),
  littleMango: Joi.number().description('小芒果'),
  coupon: Joi.object({
    name: Joi.string().description('优惠券名称'),
    amount: Joi.number().description('优惠券金额'),
    expires: Joi.number().description('过期天数')
  }).description('优惠券信息')
}).unknown().empty(null);