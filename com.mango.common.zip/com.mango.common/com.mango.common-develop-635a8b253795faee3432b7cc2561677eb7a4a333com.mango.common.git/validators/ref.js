require('xx-utils');
module.exports = (srcSchema, key, refSchema) => {
  try {
    if (!srcSchema.isJoi || srcSchema._type !== 'object') return;
    const keys = key.split('.');
    keys.reduce((memo, item, index) => {
      if (memo._type === 'object') {
        const children = memo._inner.children;
        const ref = children.search({ key: item });
        if(!ref) throw new Error(`schema don't has key [${key}]`);
        if (ref.schema._type === 'array') {
          if (index < keys.length - 1) {
            return ref.schema._inner.inclusions[0];
          } else {
            ref.schema._inner.inclusions[0] = refSchema;
          }
        } else {
          if (index < keys.length - 1) {
            return children.search({ key: item }).schema;
          } else {
            ref.schema = refSchema;
          }
        }
      } else {
        throw new Error('No deeper search.');
      }
    }, srcSchema);
  } catch (err) {
    console.warn(err.message);
  }
};