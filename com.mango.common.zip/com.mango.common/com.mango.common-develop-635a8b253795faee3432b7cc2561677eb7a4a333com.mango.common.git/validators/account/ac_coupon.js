const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  state: Joi.number().description("状态"),
  name: Joi.string().description("名称"),
  amount: Joi.number().description("面额"),
  user: Joi.string().description('User ref'),
  expires: Joi.date().description("过期时间"),
  type: Joi.number().description("类型"),
  usedAt: Joi.date().description("使用时间"),
  couponCode: Joi.string().description("优惠券Code"),
}).unknown().empty(null);


