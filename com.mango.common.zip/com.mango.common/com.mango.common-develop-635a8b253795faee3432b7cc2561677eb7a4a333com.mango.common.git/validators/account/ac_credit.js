const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('User ref'),
  name: Joi.string().description('名称项目'),
  type: Joi.number().description('类型'),
  order: Joi.string().description('Order ref'),
  point: Joi.number().description('分额'),
  appeal: Joi.object({
    appealed: Joi.boolean().description('是否已经申诉'),
    appealedAt: Joi.date().description('申诉时间'),
    result: Joi.number().description('申诉结果'),
    passedAt: Joi.date().description('通过时间'),
    rejectedAt: Joi.date().description('驳回时间'),
    rejectReason: Joi.string().description('驳回原因')
  }).description('申诉信息'),
}).unknown().empty(null);