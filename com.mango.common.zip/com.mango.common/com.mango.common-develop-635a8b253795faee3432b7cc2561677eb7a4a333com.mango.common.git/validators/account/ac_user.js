const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('userId'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  auth: Joi.object({
    bddId: Joi.string().description('八点到Id'),
    tel: Joi.string().description('用户电话'),
    wxOpenId: Joi.string().description('微信openid'),
    alipayOpenId: Joi.string().description('阿里openid'),
    roles: Joi.array().items(Joi.string()).description('角色'),
    permissions: Joi.array().items(Joi.string()).description('额外权限'),
    primaryUser: Joi.string().description('主账号 ref'),
    verifyTel: Joi.string().description('接受验证码手机号'),
    password: Joi.string().description('密码-用于管理端登陆'),
    fromBaojia: Joi.boolean().description('从宝驾注册')
  }).unknown().description('用户认证信息'),
  profile: Joi.object({
    nickname: Joi.string().description('昵称'),
    avator: Joi.string().description('头像'),
    gender: Joi.string().description('性别')
  }).unknown().description('用户侧写'),
  invite: Joi.object({
    code: Joi.string().description('邀请码'),
    codeHasChanged: Joi.boolean().description('是否更改过邀请码'),
    invitedBy: Joi.string().description('被邀请人 ref')
  }).description('邀请'),
  credit: Joi.number().description('信用分'),
  cert: Joi.object({
    hasVerified: Joi.boolean().description('是否通过实名认证'),
    triedAt: Joi.array().items(Joi.date()).description('实名重试时间'),
    certType: Joi.string().description('证件类型'),
    certNo: Joi.string().description('证件号码'),
    certInfo: Joi.object({
      hometown: Joi.string().description('户籍地'),
      birthday: Joi.date().description('生日'),
      gender: Joi.string().description('性别')
    }).description('验证信息'),
    name: Joi.string().description('姓名')
  }).unknown().description('验证信息'),
  location: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址'),
    accuracy: Joi.number().description('精确度'),
  }).unknown().description('快照位置'),
  destroyed: Joi.boolean().description('账号是否注销'),
}).unknown().empty(null);