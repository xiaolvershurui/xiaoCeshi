const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('operatorId'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enableOffDuty: Joi.boolean().description('可否自行下班'),
  user: Joi.string().description('用户 ref'),
  enable: Joi.boolean().description('是否启用'),
  isWorking: Joi.boolean().description('是否当班'),
  workEmail: Joi.string().description('工作邮箱'),
  color: Joi.string().description('巡检区颜色'),
  type: Joi.number().description('司机类型'),
  regions: Joi.array().items(Joi.string()).description('大区 ref'),
  lastCheckInAt: Joi.date().description('上次上班时间'),
  inspectionAreas: Joi.array().items(Joi.string()).description('巡检区 ref'),
  location: Joi.object({
    address: Joi.string().description('地址'),
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    snappedAt: Joi.date().description('快照时间')
  }).unknown().description('位置'),
  batteryBag: Joi.object({
    enable: Joi.boolean().description('是否能够携带'),
    batteries: Joi.array().items(Joi.string()).description('携带电池列表'),
    total: Joi.number().description('出发总数'),
    available: Joi.number().description('可用数量'),
    unavailable: Joi.number().description('更换后电池数量'),
  }).unknown().description('携带电池状况'),
  acceptTaskGroups: Joi.array().items(Joi.number()).description('可接受任务组'),
  isDriver: Joi.boolean().description('是否为巡检司机'),
  checkStatus: Joi.number().description('巡检类型'),
  accountInfo: Joi.object({
    idCard: Joi.object({
      positivePhoto: Joi.string().description('正面照片'),
      negativePhoto: Joi.string().description('背面照片'),
    }).description('身份证照片'),
    license: Joi.object({
      positivePhoto: Joi.string().description('正面照片'),
      negativePhoto: Joi.string().description('背面照片'),
    }).description('驾驶证照片'),
    cardWithHand: Joi.object({
      positivePhoto: Joi.string().description('正面照片'),
      negativePhoto: Joi.string().description('背面照片'),
    }).description('手持身份证照片'),
    bankCard: Joi.object({
      positivePhoto: Joi.string().description('正面照片'),
      negativePhoto: Joi.string().description('背面照片'),
    }).description('银行卡照片'),
    bank: Joi.string().description('开户行'),
    accountNumber: Joi.string().description('开户行账户'),
    accountName: Joi.string().description('开户行名'),
    avator: Joi.string().description('头像'),
    gender: Joi.string().description('性别'),
    hasMarried: Joi.boolean().description('婚否'),
    address: Joi.string().description('住址')
  }).unknown().description('账户验证信息'),
  stockInfo: Joi.object({
    type: Joi.number().description('车辆类型'),
    stockPhoto: Joi.string().description('车辆照片'),
    stockLicense: Joi.object({
      positivePhoto: Joi.string().description('正面照片'),
      negativePhoto: Joi.string().description('背面照片')
    }).unknown().description('行驶证照片'),
    driverAvailable: Joi.date().description('驾驶证有效期'),
    stockAvailable: Joi.date().description('行驶证有效期'),
    number: Joi.string().description('车牌号'),
    enableTime: Joi.string().description('可出车时间'),
    outCount: Joi.number().description('周出车天数'),
    limit: Joi.boolean().description('限行日是否出车'),
    enableToSecondRing: Joi.boolean().description('是否进入二环以内'),
    source: Joi.number().description('来源类型')
  }).unknown().description('车辆信息'),
  inspectionArea: Joi.object({
    id: Joi.string(),
    state: Joi.number(),
  }).unknown().description('巡检订单冗余信息'),
  inspectionPrice: Joi.string().description('计价规则'),
  missCount: Joi.number().description('多余电池'),
  wrongCount: Joi.number().description('错误换电'),
  wrongStock: Joi.array().items(Joi.object({
    stock: Joi.string().description('车辆编号'),
    number: Joi.string().description('车牌号'),
    battery: Joi.string().description('电池编号')
  })).description('错误换电设备'),
  showAmount: Joi.boolean().description('是否可见巡检金额'),
  needCast: Joi.boolean().description('是否需要结算')
}).unknown().empty(null);