const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  repairMembers: Joi.array().items(Joi.string()).description('维修成员'),
  team: Joi.object({
    id: Joi.string().description('小组 id'),
    name: Joi.string().description('小组名称')
  }).unknown().description('维修小组'),
  region: Joi.string().description('大区'),
  station: Joi.string().description('站点'),
  status: Joi.number().description('维修工作订单状态'),
  repairStocks: Joi.array().items(Joi.object({
    id: Joi.string().description('车辆 id'),
    isDetainedAndPullBack: Joi.boolean().description('是否是扣押拖回车辆'),
    isValid: Joi.boolean().description('是否有效'),
  }).unknown()).description('维修成员'),
}).unknown().empty(null);
