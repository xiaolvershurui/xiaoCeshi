const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  credit: Joi.string().description('信用记录 ref'),
  reason: Joi.string().description('申诉缘由'),
  user: Joi.string().description('账户 ref'),
  photos: Joi.array().items(Joi.string()).description('图片'),
  order: Joi.string().description('订单'),
  state: Joi.number().description('处理状态'),
  appealedAt: Joi.date().description('申诉时间'),
  result: Joi.number().description('申诉结果'),
  processor: Joi.string().description('处理人'),
  passedAt: Joi.date().description('通过时间'),
  passRemark: Joi.string().description('通过时间'),
  rejectedAt: Joi.date().description('驳回时间'),
  rejectReason: Joi.string().description('驳回原因'),
}).unknown().empty(null);