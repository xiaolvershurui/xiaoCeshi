const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  name: Joi.string().description('大区名'),
  city: Joi.string().description('所属城市'),
  path: Joi.object().unknown().description('大区围栏'),
  owner: Joi.string().description('大区拥有者 ref'),
  managers: Joi.array().items(Joi.string()),
  isFactory: Joi.boolean().description('是否是工厂'),
  prices: Joi.array().items(Joi.object({
    timeUnit: Joi.number().description('时间单价'),
    mileageUnit: Joi.number().description('里程单价'),
    floorCost: Joi.number().description('最低消费'),
    enableInsurance: Joi.boolean().description('是否开通保险服务'),
    insurance: Joi.number().description('保费'),
    parkingRate: Joi.number().description('停车区费率'),
    dayCeilingCost: Joi.number().description('日封顶'),
    nightCeilingCost: Joi.number().description('夜封顶')
  }).unknown()).description('定价'),
  isDefault: Joi.boolean().description('录入车辆时默认选项'),
}).unknown().empty(null);