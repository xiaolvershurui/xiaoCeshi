const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  name: Joi.string().description('名称'),
  enable: Joi.boolean().description('启用状态'),
  location: Joi.object({
    city: Joi.string().description('城市名'),
    area: Joi.string().description('行政区'),
    address: Joi.string().description('街道地址'),
    lngLat: Joi.array().items(Joi.number()).description('经纬度')
  }).unknown().description('地理位置'),
  capacity: Joi.object({
    totalChargePort: Joi.number().description('充电口总数量'),
    totalBatteryStorage: Joi.number().description('可存放电池数量'),
    totalBikeStorage: Joi.number().description('可存放车辆数量'),
    usingChargePort: Joi.number().description('占用电池口数量'),
    usingBatteryStorage: Joi.number().description('占用电池存放空间数量'),
    usingBikeStorage: Joi.number().description('占用车辆存放空间数量'),
    remainChargePort: Joi.number().description('剩余电池口数量'),
    remainBatteryStorage: Joi.number().description('剩余电池存放空间'),
    remainBikeStorage: Joi.number().description('剩余车辆存放空间数量'),
  }).unknown().description('容量'),
  batteryBag: Joi.object({
    batteries: Joi.array().items(Joi.string()).description('电池列表'),
    total: Joi.number().description('总数'),
    available: Joi.number().description('可用数量'),
    unavailable: Joi.number().description('不可用数量')
  }).unknown().description('携带电池情况'),
  bikeBag: Joi.object({
    bikes: Joi.array().items(Joi.string()).description('存放车辆列表')
  }).unknown().description('存放车辆情况'),
}).unknown().empty(null);
