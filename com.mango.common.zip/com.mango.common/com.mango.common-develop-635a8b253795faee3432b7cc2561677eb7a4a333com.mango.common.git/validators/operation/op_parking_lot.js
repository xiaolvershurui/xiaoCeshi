const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  name: Joi.string().description('名称'),
  enable: Joi.boolean().description('启用状态'),
  creator: Joi.string().description('创建人'),
  polygon: Joi.object().description('多边形区域'),
  pathLine: Joi.object().description('路径线'),
  navigationPoints: Joi.object().description('导航点'),
  popPoint: Joi.object().description('气泡框点'),
  pathLineLength: Joi.number().description('路径线长度'),
  ratedCapacity: Joi.number().description('额定停车容量'),
  restCapacity: Joi.number().description('剩余停车容量'),
  storedStocks: Joi.string().description('在停车区的车辆列表'),
  reviewState: Joi.number().description('审核状态'),
  reviewRemark: Joi.string().description('审核意见'),
  reviewer: Joi.string().description('审核人'),
  reviewedAt: Joi.string().description('审核日期'),
  removed: Joi.string().description('是否被删除'),
  photo: Joi.string().description('绑定的停车区照片')
}).unknown().empty(null);
