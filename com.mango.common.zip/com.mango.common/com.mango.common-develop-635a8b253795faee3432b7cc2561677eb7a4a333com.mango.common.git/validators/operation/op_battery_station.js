const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区 ref'),
  name: Joi.string().description('名称'),
  outCount: Joi.number().description('在外电池数'),
  outStockCount: Joi.number().description('发出车辆数'),
  enable: Joi.boolean().description('启用状态'),
  director: Joi.string().description('负责人 ref'),
  storeManagers: Joi.array().items(Joi.string()).description('可用库管'),
  type: Joi.number().description('类型'),
  location: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址')
  }).unknown().description('地址'),
}).unknown().empty(null);