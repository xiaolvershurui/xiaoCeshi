const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  bikeNo: Joi.string().description('车辆编号'),
  bike: Joi.string().description('车辆ref'),
  type: Joi.number().description('举报类型'),
  abuseLocation: Joi.object({
    lngLat: Joi.array().items(Joi.number()),
    address: Joi.string()
  }).description('举报地点'),
  userLocation: Joi.object({
    lngLat: Joi.array().items(Joi.number()),
    address: Joi.string()
  }).description('用户定位位置'),
  photos: Joi.array().items(Joi.number()).description('照片'),
  description: Joi.string().description('详细描述'),
  reporter: Joi.string().description('上报人'),
  state: Joi.number().description('状态'),
  reportedAt: Joi.date().description('上报时间'),
  processor: Joi.string().description('处理人'),
  processedAt: Joi.date().description('处理时间'),
  result: Joi.number().description('处理结果'),
  remark: Joi.string().description('处理结果备注')
}).unknown().empty(null);