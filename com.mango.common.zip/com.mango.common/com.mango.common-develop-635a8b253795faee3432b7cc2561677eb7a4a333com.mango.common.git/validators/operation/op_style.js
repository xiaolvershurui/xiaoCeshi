const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  name: Joi.string().description('名称'),
  number: Joi.string().description('车型编号'),
  thumbnail: Joi.string().description('缩略图'),
  level: Joi.number().description('分级'),
  maxMileage: Joi.number().description('最大续航里程'),
  ratedVoltage: Joi.number().description('电池额定电压'),
  isDefault: Joi.boolean().description('录入车辆时默认选项'),
}).unknown().empty(null);