const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  region: Joi.string().description('大区 ref'),
  type: Joi.number().description('任务类型'),
  processed: Joi.boolean().description('是否完成'),
  processor: Joi.string().description('处理人'),
  processedAt: Joi.date().description('处理时间'),
  rate: Joi.number().description('任务权值'),
}).unknown().empty(null);