const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('所属大区 ref'),
  regionName: Joi.string().description('所属大区名称'),
  polygon: Joi.string().description('所属巡检区'),
  name: Joi.string().description('打卡点'),
  creator: Joi.string().description('创建人'),
  location: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
  }).unknown(),
  needPunch: Joi.boolean().description('是否需要打卡'),
  punchedAt: Joi.date().description('打卡时间')
}).unknown().empty(null);