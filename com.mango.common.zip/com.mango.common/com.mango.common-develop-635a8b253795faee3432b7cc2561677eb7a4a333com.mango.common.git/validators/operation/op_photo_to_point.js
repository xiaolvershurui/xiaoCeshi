const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  creator: Joi.string().description('创建人'),
  location: Joi.object().unknown().description('位置信息'),
  photo: Joi.string().description('图片'),
  removed: Joi.boolean().description('是否删除'),
  parkingLot: Joi.string().description('照片绑定的停车区')
}).unknown().empty(null);
