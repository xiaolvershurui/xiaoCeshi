const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  name: Joi.string().description('大区名'),
  enable: Joi.boolean().description('启用状态'),
  creator: Joi.string().description('创建人'),
  type: Joi.number().description('类型'),
  neighborhood: Joi.number().description('社区类型'),
  location: Joi.object({
    city: Joi.string().description('城市名'),
    area: Joi.string().description('行政区'),
    address: Joi.string().description('街道地址'),
    lngLat: Joi.array().items(Joi.number()).description('经纬度')
  }).unknown().description('位置'),
  path: Joi.object().unknown().description('大区围栏'),
  extraPoints: Joi.array().items({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('位置')
  }).description('额外点'),
  state: Joi.number().description('大区状态'),
  reworkReasons: Joi.array().items(Joi.number()).description('返工原因'),
  proposedChanges: Joi.string().description('修改建议'),
  reviewer: Joi.string().description('审核人'),
  directionLine: Joi.object().description('方向线'),
  matchCount: Joi.number().description('禁停区订单经过次数'),
  lastCleanAt: Joi.date().description('最后清零时间')
}).unknown().empty(null);