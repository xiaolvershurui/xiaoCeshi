const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  photos: Joi.array().items(Joi.string()).description('图片'),
  description: Joi.string().description('反馈内容'),
  state: Joi.number().description('处理状态 '),
  feedbackAt: Joi.date().description('反馈时间'),
  processor: Joi.string().description('处理人'),
  processedAt: Joi.date().description('处理时间'),
  result: Joi.string().description('处理结果( 内部使用的备注信息 )'),
  reply: Joi.string().description('回复用户的内容'),
}).unknown().empty(null);