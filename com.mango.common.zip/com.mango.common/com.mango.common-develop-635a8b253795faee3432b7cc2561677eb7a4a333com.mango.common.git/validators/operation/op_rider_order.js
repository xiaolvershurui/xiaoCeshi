const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  region: Joi.string().description('_id'),
  user: Joi.object({
    id: Joi.string().description('Id'),
    name: Joi.string().description('姓名'),
    tel: Joi.string().description('电话'),
    avator: Joi.string().description('头像'),
    operator: Joi.string().description('运营账户'),
    type: Joi.number(),
    dispatchAbility: Joi.number().description('调度能力')
  }).unknown().description('账户信息'),
  state: Joi.number(),
  inspectedStocks: Joi.array().items(
    Joi.object({
      id: Joi.string().description('Id'),
      bikeNo: Joi.string().description('车牌号'),
      box: Joi.string().description('box Id'),
      prevTaskList: Joi.array().items(Joi.object()).description('开始巡检任务快照'),
      startedAt: Joi.date().description('巡检开始时间'),
      lastTaskList: Joi.array().items(Joi.object()).description('最终任务快照'),
      hasFound: Joi.boolean().description('是否找到'),
      isReturnedBack: Joi.boolean().description('是否拖回'),
      isExchangedBattery: Joi.boolean().description('是否换电'),
      isBackIntoRegion: Joi.boolean().description('是否回栏'),
      isHardToFindButFound: Joi.boolean().description('是否难寻找到'),
      isPutOn: Joi.boolean().description('是否投放'),
      finishedAt: Joi.date().description('结束巡检时间'),
      isNormal: Joi.boolean().description('是否普通任务'),
      isValidTask: Joi.boolean().description('是否有效任务'),
      lastLocate: Joi.number().description('最后位置'),
      perLocate: Joi.number().description('车辆上一次位置'),
      isSelfTask: Joi.boolean().description('是否是自己任务'),
    }).unknown()
  ).description('已巡检车辆链表'),
  path: Joi.string().description('巡检轨迹'),
  statistic: Joi.object({
    total: Joi.number().description('巡检总数'),
    found: Joi.number().description('找到数'),
    returnBack: Joi.number().description('拖回数量'),
    exchangeBattery: Joi.number().description('是否换电'),
    backIntoRegion: Joi.number().description('回栏数'),
    hardToFindButFound: Joi.number().description('难寻找到数量'),
    putOn: Joi.number().description('投放数'),
    normal: Joi.number().description('完成普通任务数'),
    returnBackUnfinished: Joi.number().description('未完成任务数'),
    mileage: Joi.number().description('巡检距离'),
    unfinished: Joi.object().description('未完成任务任务组分布')
  }).unknown().description('统计巡检数据'),
  times: Joi.object({
    startedAt: Joi.date().description('订单开始时间'),
    finishedAt: Joi.date().description('订单结束时间'),
    auditedAt: Joi.date().description('订单审核时间'),
    firstInspectionStartedAt: Joi.date().description('首次巡检开始时间'),
    lastInspectionFinishedAt: Joi.date().description('最后一次巡检结束时间'),
  }).unknown(),
  auditor: Joi.string().description('审核人'),
  createdAt: Joi.date().description("创建时间"),
  updatedAt: Joi.date().description("更新时间")
}).unknown().empty(null);