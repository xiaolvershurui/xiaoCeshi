const clone = require('clone');
const _ref = require('./ref');
// Account
const _ac_coupon = require('./account/ac_coupon');
const _ac_credit = require('./account/ac_credit');
const _ac_user = require('./account/ac_user');
const _ac_operator = require('./account/ac_operator');
const _ac_wallet = require('./account/ac_wallet');
// Bike
const _bk_battery = require('./ebike/bk_battery');
const _bk_box = require('./ebike/bk_box');
const _bk_bt_box = require('./ebike/bk_bt_box');
const _bk_damage = require('./ebike/bk_damage');
const _bk_mounting = require('./ebike/bk_mounting');
const _bk_stock = require('./ebike/bk_stock');
const _bk_asset = require('./ebike/bk_asset');
const _bk_stock_detained = require('./ebike/bk_stock_detained');
const _bk_stock_relieve_detained = require('./ebike/bk_stock_relieve_detained');

// Finance
const _fn_balance_bill = require('./finance/fn_balance_bill');
const _fn_deposit_bill = require('./finance/fn_deposit_bill');
const _fn_ticket = require('./finance/fn_ticket');
const _fn_invoice = require('./finance/fn_invoice');
// Operation
const _op_battery_station = require('./operation/op_battery_station');
const _op_polygon = require('./operation/op_polygon');
const _op_style = require('./operation/op_style');
const _op_work_order = require('./operation/op_work_order');
const _op_region = require('./operation/op_region');
const _op_feedback = require('./operation/op_feedback');
const _op_credit_appeal = require('./operation/op_credit_appeal');
const _op_inspection_order = require('./operation/op_inspection_order');
const _op_rider_order = require('./operation/op_rider_order');
const _op_reported_abuse = require('./operation/op_reported_abuse');
const _op_reported_damage = require('./operation/op_reported_damage');
const _op_punch_area = require('./operation/op_punch_area');
const _op_photo_to_point = require('./operation/op_photo_to_point');
const _op_parking_lot = require('./operation/op_parking_lot');
const _op_repair_work_order = require('./operation/op_repair_work_order');

// Order
const _od_order = require('./order/od_order');
const _od_illegal = require('./order/od_illegal');
const _od_reservation = require('./order/od_reservation');
const _od_asset_receive = require('./order/assetReceipt/od_asset_receive');
const _od_asset_dispatch = require('./order/assetReceipt/od_asset_dispatch');
const _od_asset_check = require('./order/assetReceipt/od_asset_check');
const _od_asset_purchase = require('./order/assetReceipt/od_asset_purchase');
const _od_asset_repair = require('./order/assetReceipt/od_asset_repair');
const _od_asset_scrap = require('./order/assetReceipt/od_asset_scrap');
const _od_asset_inbound = require('./order/assetReceipt/od_asset_inbound');
const _od_stock_pull_back = require('./order/stockReceipt/od_stock_pull_back');
const _od_stock_put_on = require('./order/stockReceipt/od_stock_put_on');
const _od_stock_in_factory = require('./order/stockReceipt/od_stock_in_factory');
const _od_stock_damage = require('./order/stockReceipt/od_stock_damage');
const _od_stock_repair = require('./order/stockReceipt/od_stock_repair');

const _od_battery_inbound = require('./order/batteryReceipt/od_battery_inbound');
const _od_battery_scrap = require('./order/batteryReceipt/od_battery_scrap');
const _od_battery_check = require('./order/batteryReceipt/od_battery_check');
const _od_battery_start_repair = require('./order/batteryReceipt/od_battery_start_repair');
const _od_battery_end_repair = require('./order/batteryReceipt/od_battery_end_repair');
const _od_battery_damage = require('./order/batteryReceipt/od_battery_damage');
const _od_battery_repair = require('./order/batteryReceipt/od_battery_repair');
const _od_battery_maintain = require('./order/batteryReceipt/od_battery_maintain');
const _od_battery_number_check = require('./order/batteryReceipt/od_battery_number_check');
const _od_battery_dispatch = require('./order/batteryReceipt/od_battery_dispatch');
const _od_battery_start_charge = require('./order/batteryReceipt/od_battery_start_charge');
const _od_battery_end_charge = require('./order/batteryReceipt/od_battery_end_charge');
const _od_battery_update = require('./order/batteryReceipt/od_battery_update');
const _od_battery_inspect = require('./order/batteryReceipt/od_battery_inspect');
const _od_battery_receive = require('./order/batteryReceipt/od_battery_receive');

// Record
const _rc_battery_op = require('./record/rc_battery_op');
const _rc_check_in = require('./record/rc_check_in');
const _rc_id_card_verify = require('./record/rc_id_card_verify');
const _rc_invite = require('./record/rc_invite');
const _rc_login = require('./record/rc_login');
const _rc_mounting_op = require('./record/rc_mounting_op');
const _rc_notification = require('./record/rc_notification');
const _rc_operator_capture = require('./record/rc_operator_capture');
const _rc_oplog = require('./record/rc_oplog');
const _rc_scan_qr = require('./record/rc_scan_qr');
const _rc_share = require('./record/rc_share');
const _rc_stock_op = require('./record/rc_stock_op');
const _rc_stock_point = require('./record/rc_stock_point');
const _rc_user_capture = require('./record/rc_user_capture');
const _rc_polygon_op = require('./record/rc_polygon_op');
const _rc_stock_alarm = require('./record/rc_stock_alarm');
const _rc_deposit_refund = require('./record/rc_deposit_refund');
const _rc_message = require('./record/rc_message');
const _rc_point = require('./record/rc_point');
const _rc_commodity_exchange = require('./record/rc_commodity_exchange');
const _rc_detained_area_log = require('./record/rc_detained_area_log');
const _rc_user_experience = require('./record/rc_user_experience');
const _rc_power_unlink = require('./record/rc_power_unlink');
const _rc_punch_area = require('./record/rc_punch_area');
const _rc_electric = require('./record/rc_electric');
const _rc_stock_repair = require('./record/rc_stock_repair');

// Setting
const _st_ad = require('./setting/st_ad');
const _st_config = require('./setting/st_config');
const _st_coupon_code = require('./setting/st_coupon_code');
const _st_event = require('./setting/st_event');
const _st_launch = require('./setting/st_launch');
const _st_reply = require('./setting/st_reply');
const _st_inspection_price = require('./setting/st_inspection_price');
const _st_asset = require('./setting/st_asset');
const _st_supplier = require('./setting/st_supplier');
const _st_detained_area = require('./setting/st_detained_area');
const _st_commodity = require('./setting/st_commodity');
const _st_repair_project = require('./setting/st_repair_project');
const _st_repair_project_group = require('./setting/st_repair_project_group');
const _st_repair_team = require('./setting/st_repair_team');

// Store
const _sto_commodity = require('./store/sto_commodity');
// Statistic
const _ss_balance_in_day = require('./statistic/ss_balance_in_day');
const _ss_battery_op_in_day = require('./statistic/ss_battery_op_in_day');
const _ss_day_found = require('./statistic/ss_day_found');
const _ss_deposit_in_day = require('./statistic/ss_deposit_in_day');
const _ss_error_in_day = require('./statistic/ss_error_in_day');
const _ss_flow_in_hour = require('./statistic/ss_flow_in_hour');
const _ss_inspect_in_day = require('./statistic/ss_inspect_in_day');
const _ss_no_power_stock = require('./statistic/ss_no_power_stock');
const _ss_offline_in_day = require('./statistic/ss_offline_in_day');
const _ss_offline_time = require('./statistic/ss_offline_time');
const _ss_offline_stock = require('./statistic/ss_offline_stock');
const _ss_order_count_in_minute = require('./statistic/ss_order_count_in_minute');
const _ss_park_in_day = require('./statistic/ss_park_in_day');
const _ss_rent_detail_in_day = require('./statistic/ss_rent_detail_in_day');
const _ss_rent_in_day = require('./statistic/ss_rent_in_day');
const _ss_reservation_in_day = require('./statistic/ss_reservation_in_day');
const _ss_snap_in_minute = require('./statistic/ss_snap_in_minute');
const _ss_stock_in_day = require('./statistic/ss_stock_in_day');
const _ss_task_increase_in_day = require('./statistic/ss_task_increase_in_day');
const _ss_user_in_day = require('./statistic/ss_user_in_day');
const _ss_work_order_in_day = require('./statistic/ss_work_order_in_day');
const _ss_polygon_op_in_day = require('./statistic/ss_polygon_op_in_day');
const _ss_dashboard = require('./statistic/ss_dashboard');
const _ss_deposit_refund_in_day = require('./statistic/ss_deposit_refund_in_day');
const _ss_deposit_city_administrativeAreas_in_day = require('./statistic/ss_deposit_city_administrativeAreas_in_day');
const _ss_task_monitor = require('./statistic/ss_task_monitor');
const _ss_final_stock_state = require('./statistic/ss_final_stock_state');
const _ss_user_experience = require('./statistic/ss_user_experience_in_day');
const _ss_retention_in_week = require('./statistic/ss_retention_in_week');
const _ss_liveness_in_day = require('./statistic/ss_retention_in_week');
const _ss_inspect_cost_in_day = require('./statistic/ss_inspect_cost_in_day');
const _ss_order_discount_in_day = require('./statistic/ss_order_discount_in_day');
const _ss_background_finish_order_reason_in_day = require('./statistic/ss_background_finish_order_reason_in_day');
const _ss_user_experience_monitor_in_day = require('./statistic/ss_user_experience_monitor_in_day');

const _tf_history_video = require('./traffic/tf_history_video');
const _tf_training_base = require('./traffic/tf_training_base');
const _tf_video = require('./traffic/tf_video');

exports.ac_operator = (function () {
  const operator = clone(_ac_operator);
  _ref(operator, 'user', _ac_user);
  _ref(operator, 'regions', _op_region);
  _ref(operator, 'inspectionAreas', _op_polygon);
  return operator;
})();

exports.ac_credit = (function () {
  const credit = clone(_ac_credit);
  _ref(credit, 'user', _ac_user);
  _ref(credit, 'order', _od_order);
  return credit;
})();

exports.ac_user = (function () {
  const user = clone(_ac_user);
  _ref(user, 'invite.invitedBy', _ac_user);
  _ref(user, 'auth.primaryUser', _ac_user);
  return user;
})();

exports.ac_coupon = (function () {
  const coupon = clone(_ac_coupon);
  _ref(coupon, 'user', _ac_user);
  return coupon;
})();

exports.ac_wallet = (function () {
  const wallet = clone(_ac_wallet);
  _ref(wallet, 'user', _ac_user);
  _ref(wallet, 'deposit.ticket', _fn_ticket);
  return wallet;
})();

exports.bk_battery = (function () {
  const battery = clone(_bk_battery);
  _ref(battery, 'region', _op_region);
  _ref(battery, 'inspector', _ac_operator);
  _ref(battery, 'station', _op_battery_station);
  _ref(battery, 'fromStation', _op_battery_station);
  _ref(battery, 'stock', _bk_stock);
  return battery;
})();

exports.bk_asset = (function () {
  const asset = clone(_bk_asset);
  _ref(asset, 'region', _op_region);
  _ref(asset, 'station', _op_battery_station);
  _ref(asset, 'asset', _st_asset);
  return asset;
})();

exports.bk_bt_box = (function () {
  return clone(_bk_bt_box);
})();

exports.bk_box = (function () {
  return clone(_bk_box);
})();

exports.bk_stock = (function () {
  const stock = clone(_bk_stock);
  _ref(stock, 'region', _op_region);
  _ref(stock, 'style', _op_style);
  _ref(stock, 'box', _bk_box);
  _ref(stock, 'battery.id', _bk_battery);
  _ref(stock, 'station', _op_battery_station);
  _ref(stock, 'lockVin.operator', _ac_user);
  return stock;
})();

exports.bk_damage = (function () {
  const damage = clone(_bk_damage);
  _ref(damage, 'stock', _bk_stock);
  _ref(damage, 'submitter', _ac_user);
  _ref(damage, 'repairer', _ac_user);
  return damage;
})();

exports.bk_mounting = (function () {
  const mounting = clone(_bk_mounting);
  _ref(mounting, 'region', _op_region);
  _ref(mounting, 'station', _op_battery_station);
  return mounting;
})();

exports.bk_stock_detained = (function () {
  const bk_stock_detained = clone(_bk_stock_detained);
  _ref(bk_stock_detained, 'detainedArea', _st_detained_area);
  _ref(bk_stock_detained, 'stock', _bk_stock);
  _ref(bk_stock_detained, 'reporter', _ac_user);
  return bk_stock_detained;
})();

exports.bk_stock_relieve_detained = (function () {
  const bk_stock_relieve_detained = clone(_bk_stock_relieve_detained);
  _ref(bk_stock_relieve_detained, 'detainedArea', _st_detained_area);
  _ref(bk_stock_relieve_detained, 'stock', _bk_stock);
  _ref(bk_stock_relieve_detained, 'handler', _ac_user);
  return bk_stock_relieve_detained;
})();

exports.fn_balance_bill = (function () {
  const balance_bill = clone(_fn_balance_bill);
  _ref(balance_bill, 'user', _ac_user);
  _ref(balance_bill, 'region', _op_region);
  _ref(balance_bill, 'style', _op_style);
  _ref(balance_bill, 'order', _od_order);
  _ref(balance_bill, 'ticket', _fn_ticket);
  return balance_bill;
})();

exports.fn_ticket = (function () {
  const fn_ticket = clone(_fn_ticket);
  _ref(fn_ticket, 'user', _ac_user);
  return fn_ticket;
})();

exports.fn_deposit_bill = (function () {
  const deposit_bill = clone(_fn_deposit_bill);
  _ref(deposit_bill, 'user', _ac_user);
  _ref(deposit_bill, 'ticket', _fn_ticket);
  return deposit_bill;
})();

exports.fn_invoice = (function () {
  const fn_invoice = clone(_fn_invoice);
  _ref(fn_invoice, 'user', _ac_user);
  _ref(fn_invoice, 'checker', _ac_user);
  return fn_invoice;
})();

exports.op_region = (function () {
  const op_region = clone(_op_region);
  _ref(op_region, 'owner', _ac_user);
  _ref(op_region, 'managers', _ac_user);
  return op_region;
})();

exports.op_style = (function () {
  return clone(_op_style);
})();

exports.op_battery_station = function () {
  const battery_station = clone(_op_battery_station);
  _ref(battery_station, 'region', _op_region);
  _ref(battery_station, 'director', _ac_user);
  return battery_station;
}();

exports.op_credit_appeal = function () {
  const credit_appeal = clone(_op_credit_appeal);
  _ref(credit_appeal, 'credit', _ac_credit);
  _ref(credit_appeal, 'user', _ac_user);
  _ref(credit_appeal, 'order', _od_order);
  _ref(credit_appeal, 'processor', _ac_user);
  return credit_appeal;
}();

exports.op_inspection_order = function () {
  const op_inspection_order = clone(_op_inspection_order);
  _ref(op_inspection_order, 'user.operator', _ac_operator);
  _ref(op_inspection_order, 'region', _op_region);
  return op_inspection_order;
}();

exports.op_rider_order = function () {
  const op_rider_order = clone(_op_rider_order);
  _ref(op_rider_order, 'user.operator', _ac_operator);
  _ref(op_rider_order, 'region', _op_region);
  _ref(op_rider_order, 'auditor', _ac_user);
  return op_rider_order;
}();

exports.op_polygon = function () {
  const op_polygon = clone(_op_polygon);
  _ref(op_polygon, 'creator', _ac_user);
  _ref(op_polygon, 'reviewer', _ac_user);
  return op_polygon;
}();

exports.op_reported_abuse = function () {
  const op_reported_abuse = clone(_op_reported_abuse);
  _ref(op_reported_abuse, 'bike', _bk_stock);
  _ref(op_reported_abuse, 'reporter', _ac_user);
  _ref(op_reported_abuse, 'processor', _ac_user);
  return op_reported_abuse;
}();

exports.op_reported_damage = function () {
  const op_reported_damage = clone(_op_reported_damage);
  _ref(op_reported_damage, 'bike', _bk_stock);
  _ref(op_reported_damage, 'reporter', _ac_user);
  _ref(op_reported_damage, 'processor', _ac_user);
  return op_reported_damage;
}();

exports.op_punch_area = function () {
  const op_punch_area = clone(_op_punch_area);
  _ref(op_punch_area, 'region', _op_region);
  _ref(op_punch_area, 'polygon', _op_polygon);
  _ref(op_punch_area, 'creator', _ac_user);
  return op_punch_area;
}();

exports.op_photo_to_point = function () {
  const op_photo_to_point = clone(_op_photo_to_point);
  _ref(op_photo_to_point, 'creator', _ac_user);
  _ref(op_photo_to_point, 'parkingLot', _op_parking_lot);
  return op_photo_to_point;
}();

exports.op_repair_work_order = function () {
  const op_repair_work_order = clone(_op_repair_work_order);
  _ref(op_repair_work_order, 'repairMembers', _ac_user);
  _ref(op_repair_work_order, 'team.id', _st_repair_team);
  _ref(op_repair_work_order, 'region', _op_region);
  _ref(op_repair_work_order, 'station', _op_battery_station);
  _ref(op_repair_work_order, 'repairStocks.id', _bk_stock);
  return op_repair_work_order;
}();

exports.rc_stock_point = function () {
  const rc_stock_point = clone(_rc_stock_point);
  _ref(rc_stock_point, 'region', _op_region);
  _ref(rc_stock_point, 'stock', _bk_stock);
  _ref(rc_stock_point, 'style', _op_style);
  _ref(rc_stock_point, 'box', _bk_box);
  return clone(rc_stock_point);
}();

exports.rc_stock_op = function () {
  return clone(_rc_stock_op);
}();

exports.rc_electric = function () {
  const rc_electric = clone(_rc_electric);
  _ref(rc_electric, 'station', _op_battery_station);
  _ref(rc_electric, 'operator', _ac_user);
  return rc_electric;
}();

exports.rc_stock_repair = function () {
  const rc_stock_repair = clone(_rc_stock_repair);
  _ref(rc_stock_repair, 'stock', _bk_stock);
  _ref(rc_stock_repair, 'user', _ac_user);
  _ref(rc_stock_repair, 'station', _op_battery_station);
  _ref(rc_stock_repair, 'repairProject.projectId', _st_repair_project);
  _ref(rc_stock_repair, 'repairProject.projectGroupId', _st_repair_project_group);
  return rc_stock_repair;
}();

exports.rc_detained_area_log = function () {
  const rc_detained_area_log = clone(_rc_detained_area_log);
  _ref(rc_detained_area_log, 'detainedArea', _st_detained_area);
  _ref(rc_detained_area_log, 'stock', _bk_stock);
  return clone(rc_detained_area_log);
}();

exports.rc_user_experience = function () {
  const rc_user_experience = clone(_rc_user_experience);
  _ref(rc_user_experience, 'user', _ac_user);
  _ref(rc_user_experience, 'region', _op_region);
  _ref(rc_user_experience, 'order', _od_order);
  _ref(rc_user_experience, 'stock', _bk_stock);
  return clone(rc_user_experience);
}();

exports.rc_power_unlink = function () {
  const rc_power_unlink = clone(_rc_power_unlink);
  _ref(rc_power_unlink, 'region', _op_region);
  _ref(rc_power_unlink, 'order', _od_order);
  _ref(rc_power_unlink, 'stock', _bk_stock);
  return clone(rc_power_unlink);
}();

exports.rc_punch_area = function () {
  const rc_punch_area = clone(_rc_punch_area);
  _ref(rc_punch_area, 'polygon', _op_polygon);
  _ref(rc_punch_area, 'punchArea', _op_punch_area);
  _ref(rc_punch_area, 'puncher', _ac_user);
  return clone(rc_punch_area);
}();

exports.op_feedback = function () {
  const op_feedback = _op_feedback;
  _ref(op_feedback, 'user', _ac_user);
  _ref(op_feedback, 'processor', _ac_user);
  return op_feedback;
}();

exports.op_work_order = function () {
  const op_work_order = clone(_op_work_order);
  _ref(op_work_order, 'user', _ac_user);
  _ref(op_work_order, 'processor', _ac_user);
  return op_work_order;
}();

exports.od_order = function () {
  const od_order = clone(_od_order);
  _ref(od_order, 'user', _ac_user);
  _ref(od_order, 'stock', _bk_stock);
  _ref(od_order, 'box', _bk_box);
  _ref(od_order, 'region', _op_region);
  _ref(od_order, 'style', _op_style);
  _ref(od_order, 'reservation', _od_reservation);
  _ref(od_order, 'payInfo.coupon.ref', _ac_coupon);
  return od_order;
}();

exports.od_illegal = function () {
  const od_illegal = clone(_od_illegal);
  _ref(od_illegal, 'user', _ac_user);
  _ref(od_illegal, 'region', _op_region);
  _ref(od_illegal, 'order', _od_order);
  return od_illegal;
}();

exports.od_reservation = function () {
  const od_reservation = clone(_od_reservation);
  _ref(od_reservation, 'user', _ac_user);
  _ref(od_reservation, 'stock', _bk_stock);
  _ref(od_reservation, 'box', _bk_box);
  _ref(od_reservation, 'region', _op_region);
  _ref(od_reservation, 'style', _op_style);
  return od_reservation;
}();

exports.od_asset_receive = function () {
  const od_asset_receive = clone(_od_asset_receive);
  _ref(od_asset_receive, 'user', _ac_user);
  _ref(od_asset_receive, 'dispenser', _ac_user);
  _ref(od_asset_receive, 'assets.id', _st_asset);
  _ref(od_asset_receive, 'region', _op_region);
  _ref(od_asset_receive, 'station', _op_battery_station);
  return od_asset_receive;
}();

exports.od_asset_scrap = function () {
  const od_asset_scrap = clone(_od_asset_scrap);
  _ref(od_asset_scrap, 'dispenser', _ac_user);
  _ref(od_asset_scrap, 'region', _op_region);
  _ref(od_asset_scrap, 'station', _op_battery_station);
  _ref(od_asset_scrap, 'assets.id', _st_asset);
  return od_asset_scrap;
}();

exports.od_asset_inbound = function () {
  const od_asset_inbound = clone(_od_asset_inbound);
  _ref(od_asset_inbound, 'user', _ac_user);
  _ref(od_asset_inbound, 'region', _op_region);
  _ref(od_asset_inbound, 'station', _op_battery_station);
  _ref(od_asset_inbound, 'assets.id', _st_asset);
  return od_asset_inbound;
}();

exports.od_asset_purchase = function () {
  const od_asset_purchase = clone(_od_asset_purchase);
  _ref(od_asset_purchase, 'user', _ac_user);
  _ref(od_asset_purchase, 'auditor', _ac_user);
  _ref(od_asset_purchase, 'supplier', _st_supplier);
  _ref(od_asset_purchase, 'assets.id', _st_asset);
  _ref(od_asset_purchase, 'purchaseSuccess.id', _st_asset);
  _ref(od_asset_purchase, 'purchaseFailed.id', _st_asset);
  _ref(od_asset_purchase, 'purchaseSuccess.style', _op_style);
  _ref(od_asset_purchase, 'purchaseFailed.style', _op_style);
  return od_asset_purchase;
}();

exports.od_asset_dispatch = function () {
  const od_asset_dispatch = clone(_od_asset_dispatch);
  _ref(od_asset_dispatch, 'user', _ac_user);
  _ref(od_asset_dispatch, 'dispenser', _ac_user);
  _ref(od_asset_dispatch, 'receiver', _ac_user);
  _ref(od_asset_dispatch, 'assets.id', _st_asset);
  _ref(od_asset_dispatch, 'region', _op_region);
  _ref(od_asset_dispatch, 'startStation', _op_battery_station);
  _ref(od_asset_dispatch, 'endStation', _op_battery_station);
  return od_asset_dispatch;
}();

exports.od_asset_check = function () {
  const od_asset_check = clone(_od_asset_check);
  _ref(od_asset_check, 'submitter', _ac_user);
  _ref(od_asset_check, 'user', _ac_user);
  _ref(od_asset_check, 'fixedUser', _ac_user);
  _ref(od_asset_check, 'region', _op_region);
  _ref(od_asset_check, 'station', _op_battery_station);
  _ref(od_asset_check, 'assets.id', _st_asset);
  return od_asset_check;
}();

exports.od_asset_repair = function () {
  const od_asset_repair = clone(_od_asset_repair);
  _ref(od_asset_repair, 'dispenser', _ac_user);
  _ref(od_asset_repair, 'region', _op_region);
  _ref(od_asset_repair, 'station', _op_battery_station);
  _ref(od_asset_repair, 'assets.id', _st_asset);
  _ref(od_asset_repair, 'records.id', _st_asset);
  return od_asset_repair;
}();

exports.od_battery_inbound = function () {
  const od_battery_inbound = clone(_od_battery_inbound);
  _ref(od_battery_inbound, 'user', _ac_user);
  _ref(od_battery_inbound, 'region', _op_region);
  _ref(od_battery_inbound, 'station', _op_battery_station);
  _ref(od_battery_inbound, 'inboundBatteries.battery', _bk_battery);
  return od_battery_inbound;
}();

exports.od_battery_scrap = function () {
  const od_battery_scrap = clone(_od_battery_scrap);
  _ref(od_battery_scrap, 'user', _ac_user);
  _ref(od_battery_scrap, 'region', _op_region);
  _ref(od_battery_scrap, 'station', _op_battery_station);
  _ref(od_battery_scrap, 'scrapSuccess.id', _bk_battery);
  _ref(od_battery_scrap, 'scrapFailed.id', _bk_battery);
  _ref(od_battery_scrap, 'nextTryRecords.operator', _ac_user);
  _ref(od_battery_scrap, 'auditor', _ac_operator);
  return od_battery_scrap;
}();

exports.od_battery_check = function () {
  const od_battery_check = clone(_od_battery_check);
  _ref(od_battery_check, 'storeManager', _ac_user);
  _ref(od_battery_check, 'region', _op_region);
  _ref(od_battery_check, 'station', _op_battery_station);
  _ref(od_battery_check, 'auditor', _ac_user);
  return od_battery_check;
}();

exports.od_battery_start_repair = function () {
  const od_battery_start_repair = clone(_od_battery_start_repair);
  _ref(od_battery_start_repair, 'user', _ac_user);
  _ref(od_battery_start_repair, 'region', _op_region);
  _ref(od_battery_start_repair, 'station', _op_battery_station);
  _ref(od_battery_start_repair, 'outboundSuccess.id', _bk_battery);
  _ref(od_battery_start_repair, 'outboundFailed.id', _bk_battery);
  _ref(od_battery_start_repair, 'nextTryRecords.operator', _ac_user);
  return od_battery_start_repair;
}();

exports.od_battery_end_repair = function () {
  const od_battery_end_repair = clone(_od_battery_end_repair);
  _ref(od_battery_end_repair, 'user', _ac_user);
  _ref(od_battery_end_repair, 'region', _op_region);
  _ref(od_battery_end_repair, 'station', _op_battery_station);
  _ref(od_battery_end_repair, 'inboundSuccess.id', _bk_battery);
  _ref(od_battery_end_repair, 'inboundFailed.id', _bk_battery);
  _ref(od_battery_end_repair, 'nextTryRecords.operator', _ac_user);
  return od_battery_end_repair;
}();

exports.od_battery_damage = function () {
  const od_battery_damage = clone(_od_battery_damage);
  _ref(od_battery_damage, 'user', _ac_user);
  _ref(od_battery_damage, 'region', _op_region);
  _ref(od_battery_damage, 'station', _op_battery_station);
  _ref(od_battery_damage, 'damageSuccess.id', _bk_battery);
  _ref(od_battery_damage, 'damageFailed.id', _bk_battery);
  _ref(od_battery_damage, 'nextTryRecords.operator', _ac_user);
  return od_battery_damage;
}();

exports.od_battery_repair = function () {
  const od_battery_repair = clone(_od_battery_repair);
  _ref(od_battery_repair, 'user', _ac_user);
  _ref(od_battery_repair, 'region', _op_region);
  _ref(od_battery_repair, 'station', _op_battery_station);
  _ref(od_battery_repair, 'repairSuccess.id', _bk_battery);
  _ref(od_battery_repair, 'repairFailed.id', _bk_battery);
  _ref(od_battery_repair, 'nextTryRecords.operator', _ac_user);
  return od_battery_repair;
}();

exports.od_battery_maintain = function () {
  const od_battery_maintain = clone(_od_battery_maintain);
  _ref(od_battery_maintain, 'user', _ac_user);
  _ref(od_battery_maintain, 'region', _op_region);
  _ref(od_battery_maintain, 'station', _op_battery_station);
  _ref(od_battery_maintain, 'maintainSuccess.id', _bk_battery);
  _ref(od_battery_maintain, 'maintainFailed.id', _bk_battery);
  _ref(od_battery_maintain, 'nextTryRecords.operator', _ac_user);
  return od_battery_maintain;
}();

exports.od_battery_number_check = function () {
  const od_battery_number_check = clone(_od_battery_number_check);
  _ref(od_battery_number_check, 'user', _ac_user);
  _ref(od_battery_number_check, 'region', _op_region);
  _ref(od_battery_number_check, 'station', _op_battery_station);
  _ref(od_battery_number_check, 'onlineBatteryIds', _bk_battery);
  return od_battery_number_check;
}();


exports.od_battery_dispatch = function () {
  const od_battery_dispatch = clone(_od_battery_dispatch);
  _ref(od_battery_dispatch, 'dispenser', _ac_user);
  _ref(od_battery_dispatch, 'receiver', _ac_user);
  _ref(od_battery_dispatch, 'region', _op_region);
  _ref(od_battery_dispatch, 'startStation', _op_battery_station);
  _ref(od_battery_dispatch, 'endStation', _op_battery_station);
  _ref(od_battery_dispatch, 'outboundSuccess.id', _bk_battery);
  _ref(od_battery_dispatch, 'outboundFailed.id', _bk_battery);
  _ref(od_battery_dispatch, 'inboundSuccess.id', _bk_battery);
  _ref(od_battery_dispatch, 'inboundFailed.id', _bk_battery);
  _ref(od_battery_dispatch, 'nextTryRecords.operator', _ac_user);
  return od_battery_dispatch;
}();

exports.od_battery_start_charge = function () {
  const od_battery_start_charge = clone(_od_battery_start_charge);
  _ref(od_battery_start_charge, 'user', _ac_user);
  _ref(od_battery_start_charge, 'region', _op_region);
  _ref(od_battery_start_charge, 'station', _op_battery_station);
  _ref(od_battery_start_charge, 'startChargeSuccess.id', _bk_battery);
  _ref(od_battery_start_charge, 'startChargeFailed.id', _bk_battery);
  _ref(od_battery_start_charge, 'nextTryRecords.operator', _ac_user);
  return od_battery_start_charge;
}();

exports.od_battery_end_charge = function () {
  const od_battery_end_charge = clone(_od_battery_end_charge);
  _ref(od_battery_end_charge, 'user', _ac_user);
  _ref(od_battery_end_charge, 'region', _op_region);
  _ref(od_battery_end_charge, 'station', _op_battery_station);
  _ref(od_battery_end_charge, 'endChargeSuccess.id', _bk_battery);
  _ref(od_battery_end_charge, 'endChargeFailed.id', _bk_battery);
  _ref(od_battery_end_charge, 'nextTryRecords.operator', _ac_user);
  return od_battery_end_charge;
}();

exports.od_battery_update = function () {
  const od_battery_update = clone(_od_battery_update);
  _ref(od_battery_update, 'user', _ac_user);
  _ref(od_battery_update, 'region', _op_region);
  _ref(od_battery_update, 'station', _op_battery_station);
  _ref(od_battery_update, 'battery', _bk_battery);
  return od_battery_update;
}();

exports.od_battery_receive = function () {
  const od_battery_receive = clone(_od_battery_receive);
  _ref(od_battery_receive, 'user', _ac_user);
  _ref(od_battery_receive, 'region', _op_region);
  _ref(od_battery_receive, 'receiveSuccess.station', _op_battery_station);
  _ref(od_battery_receive, 'receiveSuccess.dispenser', _ac_user);
  _ref(od_battery_receive, 'returnSuccess.station', _op_battery_station);
  _ref(od_battery_receive, 'returnSuccess.receiver', _ac_user);
  return od_battery_receive;
}();

exports.od_battery_inspect = function () {
  const od_battery_inspect = clone(_od_battery_inspect);
  _ref(od_battery_inspect, 'user', _ac_user);
  _ref(od_battery_inspect, 'region', _op_region);
  _ref(od_battery_inspect, 'receiveSuccess.station', _op_battery_station);
  _ref(od_battery_inspect, 'receiveSuccess.dispenser', _ac_user);
  _ref(od_battery_inspect, 'returnSuccess.station', _op_battery_station);
  _ref(od_battery_inspect, 'returnSuccess.receiver', _ac_user);
  return od_battery_inspect;
}();

exports.od_stock_pull_back = function () {
  const od_stock_pull_back = clone(_od_stock_pull_back);
  _ref(od_stock_pull_back, 'storeManager', _ac_user);
  _ref(od_stock_pull_back, 'driver', _ac_user);
  _ref(od_stock_pull_back, 'region', _op_region);
  _ref(od_stock_pull_back, 'station', _op_battery_station);
  _ref(od_stock_pull_back, 'stocks', _bk_stock);
  _ref(od_stock_pull_back, 'pullBackSuccess', _bk_stock);
  _ref(od_stock_pull_back, 'pullBackFailed', _bk_stock);
  return od_stock_pull_back;
}();

exports.od_stock_put_on = function () {
  const od_stock_put_on = clone(_od_stock_put_on);
  _ref(od_stock_put_on, 'storeManager', _ac_user);
  _ref(od_stock_put_on, 'driver', _ac_user);
  _ref(od_stock_put_on, 'region', _op_region);
  _ref(od_stock_put_on, 'station', _op_battery_station);
  _ref(od_stock_put_on, 'stocks', _bk_stock);
  _ref(od_stock_put_on, 'putOnSuccess', _bk_stock);
  _ref(od_stock_put_on, 'putOnFailed', _bk_stock);
  return od_stock_put_on;
}();

exports.od_stock_in_factory = function () {
  const od_stock_in_factory = clone(_od_stock_in_factory);
  _ref(od_stock_in_factory, 'storeManager', _ac_user);
  _ref(od_stock_in_factory, 'region', _op_region);
  _ref(od_stock_in_factory, 'station', _op_battery_station);
  _ref(od_stock_in_factory, 'stocks.id', _bk_stock);
  return od_stock_in_factory;
}();

exports.od_stock_damage = function () {
  const od_stock_damage = clone(_od_stock_damage);
  _ref(od_stock_damage, 'storeManager', _ac_user);
  _ref(od_stock_damage, 'region', _op_region);
  _ref(od_stock_damage, 'station', _op_battery_station);
  _ref(od_stock_damage, 'stocks', _bk_stock);
  _ref(od_stock_damage, 'damageSuccess', _bk_stock);
  _ref(od_stock_damage, 'damageFailed', _bk_stock);
  return od_stock_damage;
}();

exports.od_stock_repair = function () {
  const od_stock_repair = clone(_od_stock_repair);
  _ref(od_stock_repair, 'storeManager', _ac_user);
  _ref(od_stock_repair, 'region', _op_region);
  _ref(od_stock_repair, 'station', _op_battery_station);
  _ref(od_stock_repair, 'stocks', _bk_stock);
  _ref(od_stock_repair, 'repairSuccess', _bk_stock);
  _ref(od_stock_repair, 'repairFailed', _bk_stock);
  return od_stock_repair;
}();

exports.rc_battery_op = function () {
  const rc_battery_op = clone(_rc_battery_op);
  _ref(rc_battery_op, 'battery', _bk_battery);
  _ref(rc_battery_op, 'inStation', _op_battery_station);
  _ref(rc_battery_op, 'fromAccount', _bk_box);
  return rc_battery_op;
}();

exports.rc_deposit_refund = function () {
  const rc_deposit_refund = clone(_rc_deposit_refund);
  _ref(rc_deposit_refund, 'user', _ac_user);
  _ref(rc_deposit_refund, 'region', _op_region);
  return _rc_deposit_refund;
}();

exports.rc_check_in = function () {
  const rc_check_in = clone(_rc_check_in);
  _ref(rc_check_in, 'user', _ac_user);
  _ref(rc_check_in, 'operator', _ac_operator);
  return rc_check_in;
}();

exports.rc_id_card_verify = function () {
  return clone(_rc_id_card_verify);
}();

exports.rc_polygon_op = function () {
  const rc_polygon_op = clone(_rc_polygon_op);
  _ref(rc_polygon_op, 'user', _ac_user);
  _ref(rc_polygon_op, 'polygon', _op_polygon);
  return rc_polygon_op;
}();

exports.rc_invite = function () {
  const invite = clone(_rc_invite);
  _ref(invite, 'user', _ac_user);
  _ref(invite, 'invitedUser', _ac_user);
  return invite;
}();

exports.rc_login = function () {
  const login = clone(_rc_login);
  _ref(login, 'user', _ac_user);
  return login;
}();

exports.rc_mounting_op = function () {
  const mounting_op = clone(_rc_mounting_op);
  _ref(mounting_op, 'mounting', _bk_mounting);
  _ref(mounting_op, 'operator', _ac_user);
  return mounting_op;
}();

exports.rc_stock_alarm = function () {
  const rc_stock_alarm = clone(_rc_stock_alarm);
  _ref(rc_stock_alarm, 'region', _op_region);
  _ref(rc_stock_alarm, 'stock', _bk_stock);
  _ref(rc_stock_alarm, 'style', _op_style);
  _ref(rc_stock_alarm, 'box', _bk_box);
  _ref(rc_stock_alarm, 'point', _rc_stock_point);
  _ref(rc_stock_alarm, 'order', _od_order);
  return rc_stock_alarm;
}();

exports.rc_notification = function () {
  return clone(_rc_notification);
}();

exports.rc_operator_capture = function () {
  const operator_capture = clone(_rc_operator_capture);
  _ref(operator_capture, 'user', _ac_user);
  _ref(operator_capture, 'regions', _op_region);
  return operator_capture;
}();

exports.rc_oplog = function () {
  const oplog = clone(_rc_oplog);
  _ref(oplog, 'entities.box', _bk_box);
  _ref(oplog, 'entities.style', _op_style);
  _ref(oplog, 'entities.region', _op_region);
  _ref(oplog, 'entities.user', _ac_user);
  _ref(oplog, 'entities.order', _od_order);
  _ref(oplog, 'entities.reservation', _od_reservation);
  _ref(oplog, 'entities.btBox', _bk_bt_box);
  return oplog;
}();

exports.rc_scan_qr = function () {
  return clone(_rc_scan_qr);
}();

exports.rc_share = function () {
  const share = clone(_rc_share);
  _ref(share, 'user', _ac_user);
  return share;
}();

exports.rc_user_capture = function () {
  const user_capture = clone(_rc_user_capture);
  _ref(user_capture, 'user', _ac_user);
  return user_capture;
}();

exports.rc_message = function () {
  const rc_message = clone(_rc_message);
  _ref(rc_message, 'user', _ac_user);
  return rc_message;
}();

exports.rc_point = function () {
  const rc_point = clone(_rc_point);
  _ref(rc_point, 'user', _ac_user);
  return rc_point;
}();

exports.rc_commodity_exchange = function () {
  const rc_commodity_exchange = clone(_rc_commodity_exchange);
  _ref(rc_commodity_exchange, 'user', _rc_commodity_exchange);
  return rc_commodity_exchange;
}();

exports.st_ad = function () {
  return clone(_st_ad);
}();

exports.st_asset = function () {
  return clone(_st_asset);
}();

exports.st_supplier = function () {
  return clone(_st_supplier);
}();

exports.st_commodity = function () {
  const st_commodity = clone(_st_commodity);
  _ref(st_commodity, 'user', _ac_user);
  _ref(st_commodity, 'commodity', _sto_commodity);
  return st_commodity;
}();

exports.st_repair_project = function () {
  const st_repair_project = clone(_st_repair_project);
  _ref(st_repair_project, 'group', _st_repair_project_group);
  _ref(st_repair_project, 'creator', _ac_user);
  _ref(st_repair_project, 'lastEditor', _ac_user);
  return st_repair_project;
}();

exports.st_repair_project_group = function () {
  const st_repair_project_group = clone(_st_repair_project_group);
  _ref(st_repair_project_group, 'creator', _ac_user);
  _ref(st_repair_project_group, 'lastEditor', _ac_user);
  return st_repair_project_group;
}();

exports.st_repair_team = function () {
  const st_repair_team = clone(_st_repair_team);
  _ref(st_repair_team, 'region', _op_region);
  _ref(st_repair_team, 'groupLeader', _ac_user);
  _ref(st_repair_team, 'groupMembers', _ac_user);
  _ref(st_repair_team, 'creator', _ac_user);
  _ref(st_repair_team, 'lastEditor', _ac_user);
  return st_repair_team;
}();

exports.st_inspection_price = function () {
  return clone(_st_inspection_price);
}();

exports.st_config = function () {
  return clone(_st_config);
}();

exports.st_coupon_code = function () {
  return clone(_st_coupon_code);
}();

exports.st_event = function () {
  return clone(_st_event);
}();

exports.st_launch = function () {
  return clone(_st_launch);
}();

exports.st_reply = function () {
  return clone(_st_reply);
}();

exports.st_asset = function () {
  return clone(_st_asset);
}();

exports.st_detained_area = function () {
  return clone(_st_detained_area);
}();

exports.sto_commodity = function () {
  return clone(_sto_commodity);
}();

exports.ss_balance_in_day = function () {
  return clone(_ss_balance_in_day);
}();

exports.ss_retention_in_week = function () {
  return clone(_ss_retention_in_week);
}();

exports.ss_liveness_in_day = function () {
  return clone(_ss_liveness_in_day);
}();

exports.ss_deposit_city_administrativeAreas_in_day = function () {
  return clone(_ss_deposit_city_administrativeAreas_in_day);
}();

exports.ss_deposit_refund_in_day = function () {
  const ss_deposit_refund_in_day = clone(_ss_deposit_refund_in_day);
  _ref(ss_deposit_refund_in_day, 'region', _op_region);
  return ss_deposit_refund_in_day;
}();

exports.ss_battery_op_in_day = function () {
  return clone(_ss_battery_op_in_day);
}();

exports.ss_offline_time = function () {
  const ss_offline_time = clone(_ss_offline_time);
  _ref(ss_offline_time, 'stock', _bk_stock);
  return ss_offline_time;
}();

exports.ss_order_discount_in_day = function () {
  return clone(_ss_order_discount_in_day);
}();

exports.ss_day_found = function () {
  return clone(_ss_day_found);
}();

exports.ss_task_monitor = function () {
  const ss_task_monitor = clone(_ss_task_monitor);
  _ref(ss_task_monitor, 'region', _op_region);
  return ss_task_monitor;
}();

exports.ss_deposit_in_day = function () {
  return clone(_ss_deposit_in_day);
}();

exports.ss_error_in_day = function () {
  return clone(_ss_error_in_day);
}();

exports.ss_flow_in_hour = function () {
  return clone(_ss_flow_in_hour);
}();

exports.ss_polygon_op_in_day = function () {
  return (_ss_polygon_op_in_day);
}();

exports.ss_inspect_in_day = function () {
  return clone(_ss_inspect_in_day);
}();

exports.ss_inspect_cost_in_day = function () {
  const ss_inspect_cost_in_day = clone(_ss_inspect_cost_in_day);
  _ref(ss_inspect_cost_in_day, 'region', _op_region);
  return ss_inspect_cost_in_day;
}();

exports.ss_no_power_stock = function () {
  return clone(_ss_no_power_stock);
}();

exports.ss_offline_in_day = function () {
  return clone(_ss_offline_in_day);
}();

exports.ss_offline_stock = function () {
  return clone(_ss_offline_stock);
}();

exports.ss_order_count_in_minute = function () {
  return clone(_ss_order_count_in_minute);
}();

exports.ss_park_in_day = function () {
  return clone(_ss_park_in_day);
}();

exports.ss_rent_detail_in_day = function () {
  return clone(_ss_rent_detail_in_day);
}();

exports.ss_stock_in_day = function () {
  return clone(_ss_stock_in_day);
}();

exports.ss_task_increase_in_day = function () {
  return clone(_ss_task_increase_in_day);
}();

exports.ss_user_in_day = function () {
  return clone(_ss_user_in_day);
}();

exports.ss_work_order_in_day = function () {
  return clone(_ss_work_order_in_day);
}();

exports.ss_rent_in_day = function () {
  return clone(_ss_rent_in_day);
}();

exports.ss_reservation_in_day = function () {
  return clone(_ss_reservation_in_day);
}();

exports.ss_snap_in_minute = function () {
  return clone(_ss_snap_in_minute);
}();

exports.ss_dashboard = function () {
  const ss_dashboard = clone(_ss_dashboard);
  _ref(ss_dashboard, 'region', _op_region);
  return ss_dashboard;
}();

exports.ss_background_finish_order_reason_in_day = function () {
  return clone(_ss_background_finish_order_reason_in_day);
}();

exports.ss_final_stock_state = function () {
  return clone(_ss_final_stock_state);
}();

exports.ss_user_experience = function () {
  const ss_user_experience = clone(_ss_user_experience);
  _ref(ss_user_experience, 'region', _op_region);
  return ss_user_experience;
}();

exports.ss_user_experience_monitor_in_day= function () {
  const ss_user_experience_monitor_in_day = clone(_ss_user_experience_monitor_in_day);
  _ref(ss_user_experience_monitor_in_day,'region',_op_region);
  return ss_user_experience_monitor_in_day;
}();

exports.tf_history_video = function () {
  const tf_history_video = clone(_tf_history_video);
  _ref(tf_history_video, 'user', _ac_user);
  _ref(tf_history_video, 'video', _tf_video);
  return tf_history_video;
}();

exports.tf_training_base = function () {
  return clone(_tf_training_base);
}();

exports.tf_video = function () {
  return clone(_tf_video);
}();
