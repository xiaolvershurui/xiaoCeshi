const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  city: Joi.string().description('城市'),
  name: Joi.string().description('培训地点名称'),
  lngLat: Joi.array().items(Joi.number()).description('经纬度'),
  address: Joi.string().description('详细地址'),
  image: Joi.string().description('缩略图'),
}).unknown().empty(null);