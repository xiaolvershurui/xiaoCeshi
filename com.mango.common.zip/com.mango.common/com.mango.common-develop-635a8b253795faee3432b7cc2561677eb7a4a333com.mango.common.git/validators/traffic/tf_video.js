const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  image: Joi.string().description('视频缩略图'),
  name: Joi.string().description('视频名称'),
  src: Joi.string().description('视频地址'),
  enable: Joi.boolean().description('视频是否可用'),
  additionPeriod: Joi.number().description('视频观看加分周期'),
  size: Joi.string().description('视频大小')
}).unknown().empty(null);