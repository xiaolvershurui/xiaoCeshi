const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户'),
  video: Joi.string().description('视频'),
  expiryTime: Joi.date().description('视频过期时间'),
}).unknown().empty(null);