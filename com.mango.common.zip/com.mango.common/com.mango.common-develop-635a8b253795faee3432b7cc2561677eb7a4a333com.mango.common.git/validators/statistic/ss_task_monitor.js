const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('日期'),
  hour: Joi.number().description('小时'),
  taskCount: Joi.number().description('任务车'),
  perfect: Joi.number().description('完美'),
  total: Joi.number().description('投放中'),
  locateType: Joi.object({
    isRent: Joi.number().description('是否在租'),
    inStorage: Joi.number().description('在库'),
    interiorUse: Joi.number().description('内部使用'),
    lost: Joi.number().description('丢失'),
    dispatch: Joi.number().description('调度'),
    otherUse: Joi.number().description('其他占用'),
    detained: Joi.number().description('被扣押'),
    backHaul: Joi.number().description('被拖回'),
    suspectedLost: Joi.number().description('疑似丢失'),
  }),
  lostScanAfterDays: Joi.number().description('超一天丢失扫码'),
  lostScanAfterOneDay: Joi.number().description('一天内丢失扫码'),
  taskType: Joi.object({
    offlineScanAfterDays: Joi.number().description('超一天丢失扫码'),
    noLocationScanAfterDays: Joi.number().description('超一天无定位扫码车'),
    offlineScanAfterOneDay: Joi.number().description('一天内离线扫码'),
    noLocationScanAfterOneDay: Joi.number().description('一天内无定位扫码车'),
    realOfflineAfterDays: Joi.number().description('超一天真离线'),
    suspectedOfflineAfterDays: Joi.number().description('超一天疑似离线'),
    realOfflineAfterOneDay: Joi.number().description('一天内真离线'),
    suspectedOfflineAfterOneDay: Joi.number().description('一天内疑似离线'),
    powerOffByStolen: Joi.number().description('被盗断电'),
    powerOffByNoVoltage: Joi.number().description('零电断电'),
    noVoltage: Joi.number().description('零电'),
    difficultExchange: Joi.number().description('困难换电'),
    noLocation: Joi.object({
      damage: Joi.number().description('故障无定位'),
      dormancy: Joi.number().description('休眠无定位')
    }).description('无定位'),
    lowPower: Joi.number().description('低电'),
    outSideRegionNoFree: Joi.number().description('围栏外非免单'),
    lowPowerWarn: Joi.number().description('低压预警'),
    highPowerWarn: Joi.number().description('高压预警'),
    highPowerOffline: Joi.number().description('高压离线'),
    outSideRegionFree: Joi.number().description('围栏外免单车'),
    other: Joi.array().items(Joi.object({
      _id: Joi.string(),
      isOnline: Joi.boolean(),
      noGpsLocation: Joi.boolean(),
      voltage: Joi.number(),
      outsideRegion: Joi.boolean(),
      taskList: Joi.array().items(Joi.number()),
      locate: Joi.number(),
      stockNo: Joi.string()
    }))
  })
}).unknown().empty(null);