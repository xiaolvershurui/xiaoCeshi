const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  type: Joi.number().description('错误类型'),
  code: Joi.string().description('报错的错误码'),
  description: Joi.string().description('错误描述'),
  method: Joi.string().description('请求方法'),
  totalCount: Joi.number().description('总共报错次数'),
  actualCount: Joi.number().description('实际报错人数'),
  users: Joi.array().items(Joi.object({
    id: Joi.string(),
    tel: Joi.string(),
    ver: Joi.string(),
    appv: Joi.string(),
    plat: Joi.string(),
    mdl: Joi.string(),
    order: Joi.string()
  }).unknown()).description('报错用户'),
}).unknown().empty(null);
