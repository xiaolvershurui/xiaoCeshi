const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  offline: Joi.number().description('离线总数'),
  offlineStocks: Joi.array().items(Joi.string()).description('离线'),
  increased: Joi.number().description('当日净增'),
  lastDayToPutIn: Joi.number().description('上日残留变投放'),
  lastDayToStore: Joi.number().description('上日残留变在库'),
  toDayToPutIn: Joi.number().description('新增变投放'),
  toDayToStore: Joi.number().description('新增变在库'),
}).unknown().empty(null);