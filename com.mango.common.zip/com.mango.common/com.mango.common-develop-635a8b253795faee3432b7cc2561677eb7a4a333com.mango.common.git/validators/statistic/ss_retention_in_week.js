const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  depositCount: Joi.number().description('当周押金量'),
  orderCount: Joi.number().description('当周订单量'),
  depositRetentionInterval: Joi.object().unknown().description('押金周留存量'),
  orderRetentionInterval: Joi.object().unknown().description('订单N周留存量'),
}).unknown().empty(null);