const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  date: Joi.date().description('离线日期'),
  findDate: Joi.date().description('离线后首次找车日期'),
  offlineCount: Joi.number().description('离线任务产生次数'),
  findCount: Joi.number().description('离线后找车次数'),
  simPowerOn: Joi.boolean().description('sim卡开关机'),
  isOnline: Joi.boolean().description('是否在线'),
  isNoPower: Joi.boolean().description('是否低压'),
  clear: Joi.boolean().description('是否清除'),
  locate: Joi.number().description('车辆去向')
}).unknown().empty(null);