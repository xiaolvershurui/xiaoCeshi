const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  stock: Joi.string().description('车辆'),
  noFoundOperator: Joi.array().items(Joi.string()).description('未找到人员'),
  operator: Joi.string().description('找到人员'),
  taskGroup: Joi.number().description('任务组类型'),
  highestTask: Joi.number().description('最高任务类型'),
  description: Joi.string().description('找到描述'),
}).unknown().empty(null);