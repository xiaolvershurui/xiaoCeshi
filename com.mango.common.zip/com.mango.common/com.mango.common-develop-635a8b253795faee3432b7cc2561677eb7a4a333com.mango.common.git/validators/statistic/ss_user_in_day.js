const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  registerCount: Joi.number().description('新用户'),
  authorizationCount: Joi.number().description('新增实名认证用户'),
  chargeCount: Joi.number().description('当天充押金人数'),
  payUser: Joi.object({
    newUserCount: Joi.number().description('新用户下单人数'),
    oldUserCount: Joi.number().description('老用户下单人数'),
    orderOnce: Joi.number().description('下单一次用户数'),
    orderTwice: Joi.number().description('下单二次用户数'),
    orderThrice: Joi.number().description('下单三次用户数'),
    orderQuartic: Joi.number().description('下单四次用户数'),
    orderMoreThenQuintic: Joi.number().description('下单五次及以上用户数'),
  }).unknown().description('付费用户'),
  vitality: Joi.object({
    loginCount: Joi.number().description('登陆用户数'),
    stayOneDay: Joi.number().description('一天留存'),
    stayTwoDay: Joi.number().description('两天留存'),
    stayThreeDay: Joi.number().description('三天留存'),
    stayFourDay: Joi.number().description('四天留存'),
    stayFiveDay: Joi.number().description('五天留存'),
    staySixDay: Joi.number().description('六天留存'),
    staySevenDay: Joi.number().description('七天留存'),
    stayThirtyDay: Joi.number().description('三十天留存'),
    stayNinetyDay: Joi.number().description('九十天留存'),
    stayThreeSixtyDay: Joi.number().description('三百六十天留存'),
  }).unknown().description('活跃度'),
}).unknown().empty(null);