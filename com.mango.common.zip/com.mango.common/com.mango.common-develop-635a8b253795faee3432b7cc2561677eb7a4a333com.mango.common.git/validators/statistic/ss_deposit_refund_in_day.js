const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  region: Joi.string().description('大区Id'),
  totalAmount: Joi.number().description('当天退押金总人数'),
  historySucceedOrderCount: Joi.object().unknown().description('历史成功订单数'),
  registerRefundDays: Joi.object().unknown().description('注册到退款日期'),
  refundIntervalDays: Joi.object().unknown().description('最近退款天数'),
  refundCount: Joi.object().unknown().description('退款次数')
}).unknown().empty(null);