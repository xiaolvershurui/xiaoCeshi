const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  stockNo: Joi.string().description('车辆No'),
  type: Joi.number().description('离线类型'),
  location: Joi.object({
    lanLat: Joi.array().items(Joi.number()),
    address: String()
  }).description('位置'),
  locate: Joi.number().description('去向'),
  voltage: Joi.number().description('电压'),
  time: Joi.date().description('离线日期'),
}).unknown().empty(null);