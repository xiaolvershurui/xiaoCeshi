const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区'),
  date: Joi.date().description('日期'),
  forbiddenPark: Joi.number().description('禁停区车辆数'),
  outFenceUser: Joi.number().description('骑出围栏用户数'),
  outFenceStock: Joi.number().description('出围栏车辆数'),
  outFenceOrder: Joi.number().description('出围栏订单数'),
  totalCount: Joi.number().description('出围栏次数'),
  unMoveEnd: Joi.number().description('长时间未移动结束订单'),
  forbiddenMove: Joi.number().description('禁行区车辆数'),
  unMoveEndInForbiddenPark: Joi.number().description('未移动结束且在禁停区车辆数'),
  unMoveEndInForbiddenMove: Joi.number().description('未移动结束且在禁行区车辆数'),
}).unknown().empty(null);