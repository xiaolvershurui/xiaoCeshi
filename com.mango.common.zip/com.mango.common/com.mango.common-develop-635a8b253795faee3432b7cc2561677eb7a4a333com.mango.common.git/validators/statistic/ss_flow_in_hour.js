const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  hour: Joi.number().description('当天小时'),
  depositCount: Joi.number().description('支付押金笔数'),
  depositAmount: Joi.number().description('支付押金总额'),
  refundDepositCount: Joi.number().description('退款押金笔数'),
  refundDepositAmount: Joi.number().description('退款押金总额'),
  rechargeCount: Joi.number().description('充值笔数'),
  rechargeAmount: Joi.number().description('充值总额'),
  refundBalanceCount: Joi.number().description('余额退款笔数'),
  refundBalanceAmount: Joi.number().description('余额退款总额'),
  totalIncome: Joi.number().description('总收入流水'),
  totalOutcome: Joi.number().description('总支出流水'),
  checked: Joi.boolean().description('是否已经检查过'),
}).unknown().empty(null);