const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  region: Joi.string().description('地区'),
  foundSuccessRate: Joi.number().description('找车成功率'),
  scanSuccessRate: Joi.number().description('扫码成功率'),
  orderSuccessRate: Joi.number().description('下单成功率'),
  orderPowerOffRate: Joi.number().description('骑行断电率'),
  userFinishedOrderRate: Joi.date().description('用户主动结束订单率')
}).unknown().empty(null);