const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('Region ref'),
  date: Joi.date().description('日期'),
  totalInAmount: Joi.number().description('租金收入'),
  inspectOutAmount: Joi.number().description('巡检支出'),
  inspectCostPercent: Joi.number().description('巡检支出占比'),
  putOn: Joi.number().description('在外投放数量'),
  inspect: Joi.number().description('巡检车辆数'),
  inspectPercent: Joi.number().description('巡检车辆数'),
  averageIn: Joi.number().description('单车租金收入'),
  averageUpkeepAmount: Joi.number().description('单车维护费用'),
  upkeepPercent: Joi.number().description('维护费用支出占比'),
  exchange: Joi.number().description('换电数量'),
  exchangeOutAmount: Joi.number().description('换电支出'),
  returnBack: Joi.number().description('拖回数量'),
  returnBackAmount: Joi.number().description('拖回支出'),
  backIntoRegion: Joi.number().description('回栏数量'),
  backIntoRegionOutAmount: Joi.number().description('回栏支出'),
}).unknown().empty(null);