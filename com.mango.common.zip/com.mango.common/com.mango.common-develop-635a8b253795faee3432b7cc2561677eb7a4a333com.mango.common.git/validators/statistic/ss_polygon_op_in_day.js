const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date(),
  type: Joi.number(),
  matchCount: Joi.array().items(Joi.object({
    city: Joi.string(),
    unCleanCount: Joi.number(),
    unCleanPercent: Joi.number(),
    unCleanBefore: Joi.number(),
    residual: Joi.number()
  }).unknown().description('禁停区清零记录')),
}).unknown().empty(null);