const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  startCharge: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('开始充电操作'),
  endCharge: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('结束充电操作'),
  outbound: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('分配电池到站'),
  // 分发电池到巡检
  dispense: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('分发电池到巡检'),
  inbound: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('接收电池到站'),
  changeToStock: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('电池更换到车'),
  changeOutStock: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('电池更换下车'),
  damage: Joi.array().items(Joi.object({
    operator: Joi.string(),
    operatorName: Joi.string(),
    count: Joi.number(),
  }).unknown()).description('电池报损'),
}).unknown().empty(null);