const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  totalCount: Joi.number().description('当日活跃总人数'),
  freshInterval: Joi.object().unknown().description('活跃天数分布'),
  registerInterval: Joi.object().unknown().description('注册时间分布'),
  lastLoginInterval: Joi.object().unknown().description('N天后在此登陆分布'),
  reservationCount: Joi.number().description('当日交付押金数量'),
  depositCount: Joi.number().description('当日交付押金数量'),
  orderCount: Joi.number().description('当日下达订单数量'),
  orderRetentionInterval: Joi.object().unknown().description('订单N天留存分布'),
  depositRetentionInterval:Joi.Object().unknown().description('押金N天留存分布'),
  reservationRetentionInterval: Joi.Object().unknown().description('预约N天留存分布')
}).unknown().empty(null);