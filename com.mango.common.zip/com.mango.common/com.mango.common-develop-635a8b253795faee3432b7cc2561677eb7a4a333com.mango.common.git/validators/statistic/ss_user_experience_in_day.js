const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  // 日期
  date: Joi.date(),
  // 大区
  region: Joi.string(),
  // 扫码次数
  scanCount: Joi.number(),
  // 扫码成功次数
  scanSuccess: Joi.number(),
  // 下单成功（有订单）
  rentSuccess: Joi.number(),
  // 下单完成（订单有消费）
  finishSuccess: Joi.number(),
  // 围栏外导致的断电订单
  outsideRegion: {
    totalCount: Joi.number(),
    fiveSecondsCount: Joi.number()
  },
  // 禁行区断电
  prohibitionArea: {
    totalCount: Joi.number(),
    fiveSecondsCount: Joi.number()
  },
  // 正常骑行断电
  normalRideCount: {
    totalCount: Joi.number(),
    fiveSecondsCount: Joi.number()
  },
  // 禁行禁停区导致还车失败
  returnFailedByAreaCount: Joi.number(),
  // 离线导致换车失败
  returnFailedByOfflineCount: Joi.number()
}).unknown().empty(null);