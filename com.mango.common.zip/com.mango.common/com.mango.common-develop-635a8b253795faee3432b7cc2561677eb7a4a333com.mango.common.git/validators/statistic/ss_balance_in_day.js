const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  count: Joi.number().description('充值笔数'),
  amount: Joi.number().description('充值金额'),
  alipayCount: Joi.number().description('支付宝充值笔数'),
  alipayAmount: Joi.number().description('支付宝充值金额'),
  wxCount: Joi.number().description('微信充值笔数'),
  wxAmount: Joi.number().description('微信充值金额'),
  consumeCount: Joi.number().description('消费笔数'),
  consumeAmount: Joi.number().description('消费金额'),
  freeCount: Joi.number().description('免单笔数'),
  freeAmount: Joi.number().description('免单金额'),
  residueAmount: Joi.number().description('今日余额沉淀'),
  totalResidueAmount: Joi.number().description('累计余额沉淀'),
}).unknown().empty(null);