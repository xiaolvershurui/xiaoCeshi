const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  taskCountLastDay: Joi.number().description('头天二十一点任务量'),
  taskCountToDay: Joi.number().description('今天早上八点任务量'),
  handleTaskCount: Joi.number().description('处理任务量'),
  taskIncrease: Joi.number().description('任务增长比例'),
}).unknown().empty(null);