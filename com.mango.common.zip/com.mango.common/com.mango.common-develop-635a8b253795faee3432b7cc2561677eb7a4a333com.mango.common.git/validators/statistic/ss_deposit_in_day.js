const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  newChargeCount: Joi.number().description('新充值押金笔数'),
  newChargeAmount: Joi.number().description('新充值押金金额'),
  newWithdrawCount: Joi.number().description('新提交提现押金笔数'),
  newWithdrawAmount: Joi.number().description('新提交提现金额'),
  refundCount: Joi.number().description('执行退款笔数'),
  refundAmount: Joi.number().description('执行退款金额'),
  withdrawCount: Joi.number().description('提现中笔数'),
  withdrawAmount: Joi.number().description('提现中金额'),
  remainCount: Joi.number().description('未提交提现押金池笔数'),
  remainAmount: Joi.number().description('未提交提现押金沉淀金额'),
  residueCount: Joi.number().description('剩余押金笔数'),
  residueAmount: Joi.number().description('剩余押金金额'),
  totalPayCount: Joi.number().description('累计支付押金池笔数'),
  totalPayAmount: Joi.number().description('累计支付押金金额'),
  totalRefundCount: Joi.number().description('累计退还押金笔数'),
  totalRefundAmount: Joi.number().description('累计退还押金金额'),
}).unknown().empty(null);