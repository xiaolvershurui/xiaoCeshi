const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  orderCount: Joi.number().description('订单数量'),
  orderCountTotalAmount: Joi.number().description('订单总额'),
  orderAmount: Joi.object({
    stockAndCouponAndPark: Joi.number().description('骑行优惠券停车区金额'),
    couponAndPark: Joi.number().description('优惠券停车订单金额'),
    stockAndCoupon: Joi.number().description('骑行优惠券订单金额'),
    stockAndPark: Joi.number().description('骑行停车订单金额'),
    coupon: Joi.number().description('优惠券订单金额'),
    park: Joi.number().description('停车区订单金额'),
    stock: Joi.number().description('骑行优惠订单金额'),
    normal: Joi.number().description('正常订单金额'),
  }).unknown().description('各组订单金额'),
  discountCount: Joi.object({
    stockAndCouponAndPark: Joi.number().description('骑行优惠券停车区订单数量'),
    couponAndPark: Joi.number().description('优惠券停车订单数'),
    stockAndCoupon: Joi.number().description('骑行优惠券订单数'),
    stockAndPark: Joi.number().description('骑行停车订单数'),
    coupon: Joi.number().description('优惠券订单数'),
    park: Joi.number().description('停车区订单数'),
    stock: Joi.number().description('骑行优惠订单数'),
    normal: Joi.number().description('正常订订单数'),
  }).unknown().description('各组数量'),
  discountAmount:Joi.object({
    coupon: Joi.number().description('优惠券优惠金额'),
    park: Joi.number().description('停车优惠金额'),
    stock: Joi.number().description('骑行优惠金额')
  }).unknown().description('优惠金额')
}).unknown().empty(null);
