const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  stock: Joi.string().description('车辆'),
  stockNo: Joi.string().description('车牌号'),
  orderCount: Joi.number().description('下单次数'),
  totalAmount: Joi.number().description('总租金'),
  validTime: Joi.number().description('车辆可用时长'),
  orderDuration: Joi.number().description('订单时长'),
  scanCount: Joi.number().description('扫码次数'),
  scanErrorCount: Joi.number().description('扫码错误次数'),
}).unknown().empty(null);