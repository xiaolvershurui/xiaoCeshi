const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('库存 ref'),
  stockNo: Joi.string().description('车牌号'),
  region: Joi.string().description('大区 ref'),
  style: Joi.string().description('车型 ref'),
  date: Joi.date().description('日期'),
  validTime: Joi.number().description('累计可用时长'),
  latestSetInvalidAt: Joi.date().description('最近转换为不可用时间'),
  latestSetValidAt: Joi.date().description('最近转换为可用的时间'),
  usingTime: Joi.number().description('累计租用时长'),
  usingMileage: Joi.number().description('累计租用里程'),
  latestSetUsingAt: Joi.date().description('最近转为在租的时间'),
  latestSetNotUsingAt: Joi.date().description('最近转为不在租的时间'),
  latestSetUsingMileage: Joi.number().description('最近转为在租时记录的总里程'),
  latestSetOnlineAt: Joi.date().description('最近转为在线的时间'),
  latestSetOfflineAt: Joi.date().description('最近转为离线的时间'),
  onlineTime: Joi.number().description('累计在线时长'),
  setOfflineTimes: Joi.number().description('累计离线次数'),
}).unknown().empty(null);