const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  noPowerDate: Joi.date().description('零电日期'),
  stock: Joi.string().description('车辆'),
  offlineDate: Joi.date().description('首次离线日期'),
  findDate: Joi.date().description('零电后首次找车日期'),
  findCount: Joi.number().description('离线后找车次数'),
  powerOffDate: Joi.date().description('断电警报日期'),
  clear: Joi.boolean().description('是否清除'),
  locate: Joi.number().description('车辆去向')
}).unknown().empty(null);