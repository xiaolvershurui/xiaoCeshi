const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  city: Joi.string().description('城市'),
  totalUser: Joi.number().description('城市用户量'),
  keepDepositCount: Joi.number().description('押金留存量'),
  administrativeAreas: Joi.array().items(Joi.object({
    area: Joi.string().description('区域名称'),
    totalUser: Joi.number().description('总用户量'),
    keepDepositCount: Joi.number().description('总用押金留存户量'),
  }).unknown())
}).unknown().empty(null);