const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  totalOrderCount: Joi.number().description('总订单数'),
  finishCount: Joi.number().description('正常完成订单数'),
  abnormalCount: Joi.number().description('异常结束订单数'),
  overTimeCount: Joi.number().description('超时结束'),
  unMoveCount: Joi.number().description('无移动结束'),
  backEndCount: Joi.number().description('后台结束'),
  systemEndCount: Joi.number().description('系统结束'),
  forbiddenCount: Joi.number().description('禁停区结束'),
  totalCount: Joi.number().description('总预约订单数'),
  finishWithReservation: Joi.number().description('预约完成订单数'),
  reservationTimeOut: Joi.number().description('预约超时数'),
  reservationCancel: Joi.number().description('预约取消'),
  useOtherStock: Joi.number().description('用其他车'),
  reservationFailed: Joi.number().description('被预约导致预约失败'),
  rentFailed: Joi.number().description('被预约导致下单失败'),
}).unknown().empty(null);