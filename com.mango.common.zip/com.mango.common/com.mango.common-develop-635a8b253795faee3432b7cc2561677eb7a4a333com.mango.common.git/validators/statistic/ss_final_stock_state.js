const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区'),
  regionName: Joi.string().description('大区名'),
  date: Joi.date().description('日期'),
  totalCount: Joi.number().description('总数'),
  putOn: Joi.number().description('投放数'),
  lostControl: Joi.number().description('失控车辆数'),
  lostControlIncreased: Joi.number().description('新增失控数'),
  enableRent: Joi.number().description('投放可租数'),
  forbiddenRent: Joi.number().description('投放禁租数'),
  inStation: Joi.number().description('在库车辆数'),
  inTransport: Joi.number().description('运输车辆数'),
  inDetain: Joi.number().description("扣押车辆数"),
  inDetainIncreased: Joi.number().description("在库扣押数"),
  inSuspectedLost: Joi.number().description("疑似丢失"),
  inLost: Joi.number().description("丢失"),
  scrap: Joi.number().description("报废车辆"),
  rentAmount: Joi.number().description("车辆租金"),
  batteryLostAndDamageIncreased: Joi.number().description("新增丢失报废"),
  batteryLostRecordCount: Joi.number().description("巡检上班丢失"),
  batteryLostWithStockRecordCount: Joi.number().description("随车丢失"),
  batteryLostAndDamage: Joi.number().description("电池丢失报废"),
  batteryNeedRepaired: Joi.number().description("电池维修数"),
  batteryTotalCount: Joi.number().description("电池总数"),
  batteryIntactCount: Joi.number().description("完好电池数"),
  other: Joi.object({
    internalUsing: Joi.number().description("内部使用"),
    otherUsing: Joi.number().description("其他占用"),
    pullBack: Joi.number().description("待拖回")
  }).unknown().description("其他"),
  highVoltageButOffline: Joi.number().description("高压离线"),
  difficultFind: Joi.array().description("司机难寻车辆"),
  difficultFindButFound: Joi.array().description("难寻找到"),
  offlineBeforeHours: Joi.array().description("12小时未上线车辆"),
  offlineButFound: Joi.array().description("找到离线车辆"),
  invalidReason: Joi.object({
    offline: Joi.number().description("离线"),
    lowPower: Joi.number().description("低电"),
    noGpsLocation: Joi.number().description("无定位"),
    outSideRegionNoFree: Joi.number().description("围栏外非免单")
  }).unknown().description("各个类型不可租原因")
}).unknown().empty(null);