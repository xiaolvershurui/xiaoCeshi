const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区'),
  date: Joi.date().description('日期'),
  particles: Joi.array().items(Joi.string()).description('粒度'),
  hour: Joi.number().description('小时'),
  minute: Joi.number().description('分钟'),
  second: Joi.number().description('秒'),
  orderCount: Joi.number().description('订单总数'),
  illegalOrderCount: Joi.number().description('违规订单数'),
  standardOrderCount: Joi.number().description('规范订单数'),
  putOnStockCount: Joi.number().description('投放车辆数'),
  administrativeAreas: Joi.array().items(Joi.object({
    id: Joi.string().description('行政区编号'),
    name: Joi.string().description('行政区名称'),
    stockCount: Joi.number().description('行政区车辆数'),
  }).unknown()),
  ticketCount: Joi.number().description('罚单数'),
  historyTicketCount: Joi.number().description('历史罚单数'),
}).unknown().empty(null);