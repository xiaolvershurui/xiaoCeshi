const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  newChargeCount: Joi.number().description('新充值押金笔数'),
  city: Joi.string().description('城市名'),
  totalUser: Joi.number().description('城市用户量'),
  keepDepositCount: Joi.number().description('押金存留量'),
  administrativeAreas: Joi.array().items(Joi.object({
    name: Joi.string().description('地区名'),
    totalUser: Joi.number().description('地区总人数'),
    keepDepositCount: Joi.number().description('押金存留人数')
  })).description('行政区信息')
}).unknown().allow(null);