const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('日期'),
  hour: Joi.number().description('当天小时'),
  minute: Joi.number().description('当天分钟'),
  stock: Joi.object().description('当前车辆'),
}).unknown().empty(null);