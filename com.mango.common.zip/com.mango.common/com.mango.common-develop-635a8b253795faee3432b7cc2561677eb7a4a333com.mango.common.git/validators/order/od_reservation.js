const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户 ref'),
  stock: Joi.string().description('预约车辆 车辆ref'),
  box: Joi.string().description('盒子 ref'),
  boxDataSource: Joi.number().description('盒子数据源'),
  region: Joi.string().description('大区 ref'),
  style: Joi.string().description('车型 ref'),
  styleLevel: Joi.number().description('车型level'),
  state: Joi.number().description('预约状态'),
  reservedAt: Joi.date().description('开始预约时间'),
  expires: Joi.date().description('预约过期时间'),
  cancelledAt: Joi.date().description('取消预约时间'),
  cancelReason: Joi.number().description('取消原因'),
  finishedAt: Joi.date().description('结束预约时间'),
  baojia: Joi.object({
    isBaojia: Joi.boolean().description('是否是宝驾用户'),
    id: Joi.string().description('宝驾订单号'),
  }).unknown().description('宝驾订单信息'),
}).unknown().empty(null);