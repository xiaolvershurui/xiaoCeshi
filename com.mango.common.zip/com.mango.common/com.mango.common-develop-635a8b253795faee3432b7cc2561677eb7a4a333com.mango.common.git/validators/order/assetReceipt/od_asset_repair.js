const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区 ref'),
  dispenser: Joi.string().description('签发者 ref'),
  station: Joi.string().description('站点 ref'),
  createFailed: Joi.array().items(Joi.object()),
  returnBackFailed: Joi.array().items(Joi.object()),
  records: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    receiver: Joi.string(),
    returnedAt: Joi.date(),
  }).unknown()),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    outboundCount: Joi.number(),
    damageCount: Joi.number(),
    intactCount: Joi.number()
  }).unknown()).description('物件信息')
}).unknown().empty(null);