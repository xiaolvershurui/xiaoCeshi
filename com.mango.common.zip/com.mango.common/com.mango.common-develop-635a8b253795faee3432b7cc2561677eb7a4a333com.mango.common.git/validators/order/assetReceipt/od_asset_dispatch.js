const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户 ref'),
  region: Joi.string().description('大区'),
  dispenser: Joi.string().description('签发者 ref'),
  receiver: Joi.string().description('接收人 ref'),
  status: Joi.number().description('调度单状态'),
  startStation: Joi.string().description('出发站点'),
  endStation: Joi.string().description('目的站点'),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    startIntactCount: Joi.number(),
    startBadCount: Joi.number(),
    endIntactCount: Joi.number(),
    endBadCount: Joi.number(),
  }).unknown())
}).unknown().empty(null);