const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区 ref'),
  dispenser: Joi.string().description('签发者 ref'),
  station: Joi.string().description('站点 ref'),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    count: Joi.number()
  }).unknown()).description('物件信息')
}).unknown().empty(null);