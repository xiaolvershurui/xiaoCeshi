const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('采购人'),
  supplier: Joi.string().description('供应商'),
  contractFile: Joi.string().description('合同文件'),
  status: Joi.number().description('状态'),
  total: Joi.number().description('采购总额'),
  assets: Joi.array().items(Joi.object({
    id: Joi.string().description('物料 ref'),
    count: Joi.number().description('物料二维码'),
  }).unknown()).description("配件信息"),
  purchaseSuccess: Joi.array().items(Joi.object({
    id: Joi.string().description('配件 ref'),
    specification: Joi.string().description('配件规格'),
    count: Joi.number().description('配件数量'),
    price: Joi.number().description('配件价格'),
    style: Joi.string().description('适用车型'),
    time: Joi.date().description('采购成功时间'),
  }).unknown()).description("采购成功的配件信息"),
  purchaseFailed: Joi.array().items(Joi.object({
    id: Joi.string().description('配件 ref'),
    specification: Joi.string().description('配件规格'),
    count: Joi.number().description('配件数量'),
    price: Joi.number().description('配件价格'),
    style: Joi.string().description('适用车型'),
    time: Joi.date().description('采购失败时间'),
    errMessage: Joi.date().description('采购失败原因'),
  }).unknown()).description("采购成功的配件信息"),
  auditor: Joi.string().description('审核人'),
  auditAt: Joi.date().description('审核时间'),
  nextTry: Joi.date().description('下一次重试时间'),
  finishedAt: Joi.date().description('结束时间'),
}).unknown().empty(null);