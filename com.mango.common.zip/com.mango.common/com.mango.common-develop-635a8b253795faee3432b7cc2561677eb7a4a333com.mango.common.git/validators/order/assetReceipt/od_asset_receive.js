const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户 ref'),
  station: Joi.string().description('站点'),
  status: Joi.number().description('领用单状态'),
  region: Joi.string().description('大区'),
  dispenser: Joi.string().description('签发者 ref'),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    receiveCount: Joi.number(),
    backIntactCount: Joi.number(),
    backBadCount: Joi.number(),
    lostCount: Joi.number(),
  }).unknown())
}).unknown().empty(null);