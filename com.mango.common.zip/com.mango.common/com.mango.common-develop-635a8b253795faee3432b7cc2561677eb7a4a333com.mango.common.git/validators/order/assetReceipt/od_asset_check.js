const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  submitter: Joi.string().description('提交人 User ref'),
  user:  Joi.string().description('盘点人 User ref'),
  fixedUser: Joi.string().description('修正人 User ref'),
  station: Joi.string().description('站点'),
  region: Joi.string().description('大区 ref'),
  assets: Joi.array().items(Joi.object({
    id: Joi.string().description('物料 ref'),
    code: Joi.string().description('物料二维码'),
    intactCount: Joi.number().description('盘点完好数量'),
    actualDamageCount: Joi.number().description('实际损坏数量'),
    actualIntactCount: Joi.number().description('实际完好数量'),
    fixedTotalCount: Joi.number().description('修正总数量'),
    fixedlIntactCount: Joi.number().description('修正损坏数量'),
    fixedDamageCount: Joi.number().description('修正完好数量')
  }).unknown()),
  nextTry: Joi.date().description('下次尝试时间')
}).unknown().empty(null);

