const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户 ref'),
  productNo: Joi.string().description('保险产品号'),
  info: Joi.object({
    order: Joi.string().description('订单 ref'),
    name: Joi.string().description('姓名'),
    idCardNo: Joi.string().description('身份证号'),
    tel: Joi.string().description('手机号'),
    stock: Joi.string().description('车辆 ref'),
    vin: Joi.string().description('车架号'),
    bikeNo: Joi.string().description('车牌号')
  }).unknown().description('投保信息'),
  policy: Joi.object({
    no: Joi.string().description('保单号'),
    startTime: Joi.date().description('起保时间'),
    endTime: Joi.date().description('结保时间'),
    duration: Joi.string().description('保期时长'),
    state: Joi.number().description('保险状态'),
    cost: Joi.number().description('保费'),
    amount: Joi.number().description('保额'),
    insuredTime: Joi.date().description('投保时间')
  }).unknown().description('保单信息'),
}).unknown().empty(null);