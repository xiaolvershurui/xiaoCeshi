const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  storeManager: Joi.string(),
  driver: Joi.string(),
  region: Joi.string(),
  station: Joi.string(),
  status: Joi.number(),
  stocks: Joi.array().items(Joi.string().empty(null)),
  pullBackSuccess: Joi.array().items(Joi.string().empty(null)),
  pullBackFailed: Joi.array().items(Joi.string().empty(null)),
  nextTry: Joi.date(),
  finishedAt: Joi.date()
}).unknown().empty(null);