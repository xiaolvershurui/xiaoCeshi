const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('用户'),
  region: Joi.string().description('大区'),
  order: Joi.string().description('订单'),
  points: Joi.array().items(Joi.object({
      ts: Joi.date().description('时间'),
      lngLat: Joi.array().items(Joi.number()).description('经纬度'),
      illegals: Joi.object({
        // 逆行
        wrongDirection: Joi.object({
          name: Joi.string(),
          type: Joi.number(),
          _id: Joi.string()
        }).unknown(),
        // 横跨机动车道
        acrossMotorway: Joi.object({
          name: Joi.string(),
          type: Joi.number(),
          _id: Joi.string()
        }).unknown()
      }).unknown().description('违规情况'),
      // 所在polygon
      polygons: Joi.array().items(Joi.object({
        type: Joi.number(),
        name: Joi.string(),
        _id: Joi.string()
      }).unknown())
    }
  ).unknown()).description('转换过的轨迹点记录'),
  illegals: Joi.array().items(Joi.object({
    type: Joi.string().description('违章类型'),
    polygon: Joi.object({
      type: Joi.number(),
      name: Joi.string(),
      _id: Joi.string()
    }).unknown().description('违法记录'),
    points: Joi.array().items(Joi.object({
      ts: Joi.date(),
      lngLat: Joi.array().items(Joi.number())
    }).unknown()).description('违章轨迹'),
    passedPolygons: Joi.array().items(Joi.object({
      directionLine: Joi.array(),
      path: Joi.array(),
      type: Joi.number(),
      name: Joi.string(),
      _id: Joi.string()
    }).unknown()).description('通过的区块记录')
  }).unknown()),
  wrongDirectionTimes: Joi.number().description('逆行时长'),
  acrossMotorwayTimes: Joi.number().description('横跨机动车道时长'),
  totalTimes: Joi.number().description('违章总时长'),
}).unknown().empty(null);