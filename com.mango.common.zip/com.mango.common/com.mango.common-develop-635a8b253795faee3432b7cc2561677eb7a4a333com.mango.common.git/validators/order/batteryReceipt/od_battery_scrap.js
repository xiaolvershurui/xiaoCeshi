const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('申请人 ref'),
  region: Joi.string().description('大区 ref'),
  station: Joi.string().description('站点 ref'),
  status: Joi.number().description('状态'),
  appliedAt: Joi.date().description('申请时间'),
  scrapSuccess: Joi.array().items(Joi.object({
    _id: Joi.string().description('_id'),
    id: Joi.string().description('电池 ref'),
    time: Joi.date(),
    reason: Joi.string()
  })).description('报废成功'),
  scrapFailed: Joi.array().items(Joi.object({
    _id: Joi.string().description('_id'),
    id: Joi.string().description('电池 ref'),
    time: Joi.date(),
    errorMessage: Joi.string()
  })).description('报废成功'),
  nextTryRecords: Joi.array().items(Joi.object({
    _id: Joi.string().description('_id'),
    status: Joi.number().description('状态'),
    operator: Joi.string().description('操作人 ref'),
    triedAt: Joi.date()
  })).description('重试记录'),
  auditor: Joi.string().description('审核人 ref'),
  auditedAt: Joi.date().description('审核时间'),
  rejectReason: Joi.string().description('驳回理由'),
  finishedAt: Joi.date().description('完成时间')
}).unknown().empty(null);