const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string(),
  region: Joi.string(),
  station: Joi.string(),
  status:  Joi.number().description('状态'),
  maintainSuccess: Joi.array().items(Joi.object({
    id: Joi.string(),
  }).unknown()).description('返修入库成功'),
  maintainFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
    errorMessage: Joi.string()
  }).unknown()).description('返修入库失败'),
  nextTryRecords: Joi.array().items(Joi.object({
    operator: Joi.string(),
    isOutbound: Joi.boolean().description('是否是返修出库重试'),
    triedAt: Joi.date()
  }).unknown()),
  finishedAt: Joi.date().description('完成时间')
}).unknown().empty(null);
