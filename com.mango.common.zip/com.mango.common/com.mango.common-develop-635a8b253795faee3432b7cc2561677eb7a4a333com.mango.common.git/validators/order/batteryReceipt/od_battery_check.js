const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  date: Joi.date().description('盘点日期'),
  region: Joi.string().description('大区 ref'),
  station: Joi.string().description('仓库 ref'),
  storeManager: Joi.string().description('上报库管 ref'),
  batteries: Joi.object({
    inCharge: Joi.number().description('在充电池数'),
    fullCharge: Joi.number().description('满电电池数'),
    lowPower: Joi.number().description('馈电电池数'),
    damageCount: Joi.number().description('损坏电池数'),
    repairReceivedCount: Joi.number().description('维修领用数'),
    inspectorReceivedCount: Joi.number().description('巡检领用数'),
    ridingReceivedCount: Joi.number().description('骑行领用数'),
    noSealOffCount: Joi.number().description('未拆封领用数'),
    totalCount: Joi.number().description('电池总数量'),
  }).description('上报的仓库电池数量'),
  remark: Joi.string().description('库管上报的备注信息'),
  status: Joi.number().description('审核状态'),
  auditedAt: Joi.date().description('审核时间'),
  auditor: Joi.string().description('审核人 ref'),
  auditRemark: Joi.string().description('审核备注')
}).unknown().empty(null);

