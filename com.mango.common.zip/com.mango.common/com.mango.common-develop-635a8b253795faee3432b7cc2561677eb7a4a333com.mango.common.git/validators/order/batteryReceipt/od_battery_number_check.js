const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string(),
  region: Joi.string(),
  station: Joi.string(),
  reportBatteries: Joi.array().items(Joi.object()),
  onlineBatteryIds: Joi.array().items(Joi.string()),
  offlineBatteryCodes: Joi.array().items(Joi.string()),
  offlineBatteryMarks: Joi.array().items(Joi.string()),
}).unknown().empty(null);
