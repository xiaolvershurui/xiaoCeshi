const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string(),
  region: Joi.string(),
  station: Joi.string(),
  battery: Joi.string(),
  prevInfo: Joi.object({
    code: Joi.string(),
    mark: Joi.string(),
    gps: Joi.string()
  }),
  nextInfo: Joi.object({
    code: Joi.string(),
    mark: Joi.string(),
    gps: Joi.string()
  }),
  operatedAt: Joi.date()
}).unknown().empty(null);