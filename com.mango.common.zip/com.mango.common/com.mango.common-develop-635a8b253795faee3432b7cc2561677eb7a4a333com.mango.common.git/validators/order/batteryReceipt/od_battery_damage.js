const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('发起人 ref'),
  region: Joi.string().description('大区 ref'),
  station: Joi.string().description('发起站点 ref'),
  status: Joi.number().description('状态'),
  damageSuccess: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
  }).unknown()).description('报损成功'),
  damageFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
    errorMessage: Joi.string()
  }).unknown()).description('报损失败'),
  nextTryRecords: Joi.array().items(Joi.object({
    operator: Joi.string(),
    triedAt: Joi.date(),
  }).unknown()).description('重试记录'),
  finishedAt: Joi.date().description('完成时间')
}).unknown().empty(null);