const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  dispenser: Joi.string().description('发起人 ref'),
  receiver: Joi.string().description('接收人'),
  region: Joi.string().description('大区'),
  startStation: Joi.string().description('发起站点'),
  endStation: Joi.string().description('结束站点'),
  status: Joi.number(),
  outboundSuccess: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
  }).unknown()).description('调拨出库成功'),
  outboundFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
    errorMessage: Joi.string()
  }).unknown()).description('调拨出库失败'),
  inboundSuccess: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
  }).unknown()).description('调拨入库成功'),
  inboundFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
    errorMessage: Joi.string()
  }).unknown()).description('调拨入库失败'),
  nextTryRecords: Joi.array().items(Joi.object({
    operator: Joi.string(),
    triedAt: Joi.date()
  })),
  nextTry: Joi.date(),
  finishedAt: Joi.date().description('结束时间')
}).unknown().empty(null);