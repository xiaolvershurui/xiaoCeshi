const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('领用人 ref'),
  station: Joi.string().description('站点 ref'),
  region: Joi.string().description('大区 ref'),
  status: Joi.string().description('状态'),
  receiveSuccess: Joi.array().items(Joi.object({
    station: Joi.string().description('站点 ref'),
    dispenser: Joi.string().description('分发人 ref'),
    time: Joi.date().description('接收时间'),
    batteries: Joi.array().items(Joi.object({
      id: Joi.string().description('电池 Id'),
      time: Joi.date().description('电池更新时间')
    })).description('电池信息'),
  }).unknown()).description('领取成功列表'),
  receiveFailed: Joi.array().items(Joi.object({
    id: Joi.string().description('电池编号'),
    station: Joi.string().description('站点 '),
    dispenser: Joi.string().description('分发人'),
    time: Joi.date().description('归还时间'),
    errorMessage: Joi.string(),
  }).unknown()).description('电池领用失败'),
  returnSuccess: Joi.object({
    station: Joi.string().description('站点 ref'),
    receiver: Joi.string().description('接收人 ref'),
    time: Joi.date(),
    isUnknownReturn: Joi.boolean().description('是否已经录入无码'),
    unknownCount: Joi.number().description('归还无码数量'),
    batteries: Joi.array().items(Joi.object({
      id: Joi.string().description('电池 Id'),
      time: Joi.date().description('电池刷新时间')
    }).unknown()).description('电池信息'),
  }).description('电池领用成功'),
  returnFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    station: Joi.string(),
    receiver: Joi.string(),
    time: Joi.date(),
    unknownCount: Joi.number().description('归还无码电池')
  }).unknown()),
  nextTry: Joi.date().description('下次重试时间'),
  finishedAt: Joi.date().description('结束时间')
}).unknown().empty(null);