const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string(),
  region: Joi.string(),
  station: Joi.string(),
  status:  Joi.number().description('状态'),
  inboundSuccess: Joi.array().items(Joi.object({
    id: Joi.string(),
    returnedAt: Joi.date(),
  }).unknown()).description('返修入库成功'),
  inboundFailed: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date(),
    errorMessage: Joi.string()
  }).unknown()).description('返修入库失败'),
  unknownCount: Joi.number().description('归还未知数量'),
  nextTryRecords: Joi.array().items(Joi.object({
    operator: Joi.string(),
    triedAt: Joi.date()
  }).unknown()),
  nextTry: Joi.date(),
  finishedAt: Joi.date().description('完成时间')
}).unknown().empty(null);