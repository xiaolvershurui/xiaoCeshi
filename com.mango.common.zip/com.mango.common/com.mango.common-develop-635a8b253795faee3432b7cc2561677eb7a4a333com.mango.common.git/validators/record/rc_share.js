const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('分享账户 ref'),
  type: Joi.number().description('分享类型'),
  channel: Joi.number().description('分享渠道'),
  sharedAt: Joi.date().description('分享时间'),
}).unknown().empty(null);