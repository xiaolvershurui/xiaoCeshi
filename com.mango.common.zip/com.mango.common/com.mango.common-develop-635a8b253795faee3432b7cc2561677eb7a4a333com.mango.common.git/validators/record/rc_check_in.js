const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('签到账户 ref'),
  operator: Joi.string().description('运营账号 ref'),
  checkedAt: Joi.date().description('签到时间'),
  type: Joi.number().description('签到类型'),
  location: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址')
  }).description('定位'),
  totalWorkTime: Joi.number().description('工作时长'),
  isKickedOff: Joi.boolean().description('是否被踢下线'),
  isForceCheckIn: Joi.boolean().description('是否强制上线'),
}).unknown().empty(null);