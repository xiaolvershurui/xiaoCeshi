const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  operator: Joi.object({
    name: Joi.string().description('姓名'),
    tel: Joi.string().description('手机号'),
    avator: Joi.string().description('头像'),
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()).description('经纬度'),
      address: Joi.string().description('地址'),
    }).description('定位信息')
  }).unknown().description('操作人'),
  // 操作时间
  opAt: Joi.date().description('操作时间'),
  entities: Joi.object({
    stockId: Joi.string().description('车辆id'),
    stockNo: Joi.string().description('车牌号'),
    box: Joi.string().description('盒子号'),
    style: Joi.string().description('车型'),
    region: Joi.string().description('大区'),
    user: Joi.string().description('用户'),
    userTel: Joi.string().description('用户手机号'),
    order: Joi.string().description('订单'),
    reservation: Joi.string().description('预约订单'),
    btBox: Joi.string().description('电池盒子号'),
  }).unknown().description('日志实体'),
  description: Joi.string().description('描述'),
  params: Joi.object().description('参数'),
  code: Joi.string().description('用于筛选的编码'),
}).unknown().empty(null);