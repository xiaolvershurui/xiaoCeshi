const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  notified: Joi.boolean().description('是否已经发送通知'),
  type: Joi.number().description('通知类型'),
  data: Joi.object().description('通知内容参数'),
  notifiedAt: Joi.date().description('通知发送时间'),
  channel: Joi.number().description('通知渠道'),
}).unknown().empty(null);