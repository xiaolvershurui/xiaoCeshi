const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  operator: Joi.string().description('操作人'),
  stockIds: Joi.array().items(Joi.string()).description('车辆编号'),
  toRegion: Joi.string().description('去向大区'),
  carNo: Joi.string().description('卡车车牌'),
}).unknown().empty(null);