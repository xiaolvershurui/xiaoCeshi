const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  userName: Joi.string().description('用户姓名'),
  userTel: Joi.string().description('用户手机号'),
  scanContent: Joi.string().description('扫码内容'),
  isScanQR: Joi.boolean().description('是否是扫码记录'),
  issuedCoupon: Joi.boolean().description('是否发放了优惠券'),
  succeed: Joi.boolean().description('扫码结果'),
  error: Joi.string().description('扫码失败的报错信息'),
  stock: Joi.string().description('车辆 ref'),
  stockNo: Joi.string().description('车辆车牌号'),
  lngLat: Joi.array().items(Joi.number()).description('扫码位置'),
  address: Joi.string().description('地址'),
  accuracy: Joi.number().description('精度'),
  scannedAt: Joi.date().description('扫码时间'),
  // 设备信息
  deviceInfo: Joi.object({
    platform: Joi.string().description('平台'),
    version: Joi.string().description('系统版本'),
    modal: Joi.string().description('设备型号'),
    udid: Joi.string().description('udid'),
    name: Joi.string().description('设备名'),
  }).unknown().description('设备信息'),
  appVersion: Joi.string().description('app版本号'),
  city: Joi.string().description('城市'),
}).unknown().empty(null);