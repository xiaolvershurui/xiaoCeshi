const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('User ref'),
  region: Joi.string().description('Region ref'),
  refundCount: Joi.number().description('退款次数'),
  lastRefundDate: Joi.date().description('上一次退款'),
  refundDate: Joi.date().description('本次退款时间'),
  refundInterval: Joi.number(),
  historySuccessOrderCount: Joi.number(),
  successOrderCountInSection: Joi.number(),
  registeredDays: Joi.number(),
}).unknown().empty(null);