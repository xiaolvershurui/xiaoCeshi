const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  operator: Joi.string().description('操作人'),
  isInBound: Joi.boolean().description('入库'),
  sourceAccount: Joi.string().description('接收/发出 人'),
  sourceStation: Joi.string().description('接收/发出 站'),
  QRCodeCount: Joi.number().description('二维码数量'),
  noSignCount: Joi.number().description('无标数量'),
  batteries: Joi.array().items(Joi.string()).description('电池列表'),
}).unknown().empty(null);