const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  region: Joi.string().description('大区ref'),
  stock: Joi.string().description('车辆ref'),
  order: Joi.string().description('订单ref'),
  lngLat: Joi.array().items(Joi.number()).description('经纬度'),
  type: Joi.number().description('断电类型'),
  speed: Joi.number().description('速度'),
  accOn: Joi.boolean().description('电门状态'),
}).unknown().empty(null);