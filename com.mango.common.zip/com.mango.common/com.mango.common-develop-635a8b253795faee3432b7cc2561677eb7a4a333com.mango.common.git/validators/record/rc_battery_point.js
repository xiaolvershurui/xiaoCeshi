const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  deviceId: Joi.string().description('设备Id'),
  ds: Joi.number().description('数据源'),
  status: Joi.object({
    mode: Joi.number().description('工作状态'),
    voltage: Joi.number().description('电压'),
    signal: Joi.number().description('信号强度'),
  }).unknown().description('状态'),
  gpsLocation: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    speed: Joi.number().description('瞬时时速'),
    direction: Joi.number().description('方向'),
    time: Joi.date().description('时间'),
  }).unknown().description('定位信息'),
  cellLocation: Joi.object({
    mcc: Joi.number().description('??'),
    mnc: Joi.number().description('??'),
    cells: Joi.array().items(Joi.object({
      lac: Joi.number().description('??'),
      cellid: Joi.number().description('??'),
      rxl: Joi.number().description('??'),
    })).description('经纬度'),
    time: Joi.date().description('时间'),
  }).unknown().description('定位信息'),
  nId: Joi.string().description('??'),
  appVersion: Joi.string().description('app版本号'),
}).unknown().empty(null);