const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户'),
  certNo: Joi.string().description('身份证号'),
  name: Joi.string().description('姓名'),
  tel: Joi.string().description('手机号'),
  succeed: Joi.boolean().description('是否成功'),
  fee: Joi.boolean().description('是否扣费'),
  description: Joi.string().description('描述'),
  verifiedAt: Joi.date().description('时间'),
}).unknown().empty(null);