const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  mounting: Joi.string().description('配件类型'),
  count: Joi.number().description('使用数量'),
  operator: Joi.string().description('使用者'),
}).unknown().empty(null);