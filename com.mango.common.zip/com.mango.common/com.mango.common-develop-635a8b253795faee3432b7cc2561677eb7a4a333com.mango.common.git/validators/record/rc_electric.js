const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  operator: Joi.string().description('上报人'),
  station: Joi.string().description('电站'),
  electricMeterBoxImage: Joi.string().description('上报图片'),
  electricQuantity: Joi.number().description('上报度数'),
  temperature: Joi.number().description('上报温度'),
}).unknown().empty(null);