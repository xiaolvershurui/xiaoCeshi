const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('兑换人'),
  commodity: Joi.object({
    enable: Joi.boolean().description('启用状态'),
    name: Joi.string().description('商品名称'),
    image: Joi.string().description('图片地址'),
    description: Joi.string().description('商品描述'),
    type: Joi.number().description('商品类型'),
    exchangeNotice: Joi.string().description('兑换须知'),
    points: Joi.number().description('所需积分'),
    money: Joi.number().description('所需金额'),
    tag: Joi.string().description('标记')
  }).unknown(),
  beforePoints: Joi.number().description('兑换前积分'),
  beforeMoney: Joi.number().description('兑换前余额')
}).unknown().empty(null);