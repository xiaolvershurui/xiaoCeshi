const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  region: Joi.string().description('大区 ref'),
  stock: Joi.string().description('车辆 ref'),
  style: Joi.string().description('车型 ref'),
  box: Joi.string().description('盒子 ref'),
  dataSource: Joi.number().description('数据源'),
  point: Joi.string().description('采集点 ref'),
  order: Joi.string().description('订单 ref'),
  user: Joi.object({
    name: Joi.string().description('真实姓名'),
    tel: Joi.string().description('手机号'),
    certNo: Joi.string().description('身份证号'),
  }).unknown().description('账户'),
  type: Joi.number().description('警报类型'),
  time: Joi.date().description('采样点时间'),
  acc: Joi.boolean().description('采样时acc'),
  lock: Joi.boolean().description('采样时lock'),
}).unknown().empty(null);