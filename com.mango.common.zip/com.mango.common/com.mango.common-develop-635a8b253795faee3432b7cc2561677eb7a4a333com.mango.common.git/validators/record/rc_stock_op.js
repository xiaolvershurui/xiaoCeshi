const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  stockNo: Joi.string().description('车牌号'),
  region: Joi.string().description('大区'),
  style: Joi.string().description('车型'),
  type: Joi.number().description('操作类型'),
  description: Joi.string().description('操作描述'),
  operator: Joi.string().description('操作人，为空则为系统操作'),
  operatorName: Joi.string().description('操作人姓名'),
  operatorTel: Joi.string().description('操作人手机号'),
  operatorAvator: Joi.string().description('操作人头像'),
  operatedAt: Joi.date().description('操作时间'),
  locate: Joi.number().description('车辆去向'),
  lockOn: Joi.boolean().description('设防'),
  accOn: Joi.boolean().description('电门状态'),
  voltage: Joi.number().description('电压'),
  batteryLockOn: Joi.boolean().description('电池锁状态'),
  // 操作地点
  operateLocation: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址'),
  }).unknown().description('操作地点'),
  operateRemark: Joi.string().description('操作备注/描述/原因'),
  stockLocation: Joi.object({
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址'),
  }).unknown().description('车辆位置'),
  inspector: Joi.string().description('巡检人信息'),
  inspectorName: Joi.string().description('巡检人姓名'),
  inspectorTel: Joi.string().description('巡检人电话'),
  inspectorAvator: Joi.string().description('巡检人头像'),
  inspectionArea: Joi.string().description('车辆当前分配的巡检区信息'),
  inspectionAreaName: Joi.string().description('巡检区名称'),
  releasedTasks: Joi.array().description('该操作解除的任务列表'),
  addedTasks: Joi.array().description('该操作添加的任务列表'),
  prevTaskList: Joi.array().description('操作前的任务列表'),
  // 操作相关定制数据
  updateCustomNumber: Joi.object({
    prev: Joi.string().description('旧车牌'),
    next: Joi.string().description('新车牌'),
  }).unknown().description('更新定制车牌号'),
  updateTempNumber: Joi.object({
    prev: Joi.string().description('旧车牌'),
    next: Joi.string().description('新车牌'),
  }).unknown().description('更新临时车牌号'),
  updateLicenseNumber: Joi.object({
    prev: Joi.string().description('旧车牌'),
    next: Joi.string().description('新车牌'),
  }).unknown().description('更新交管局车牌号'),
  updateVin: Joi.object({
    prev: Joi.string().description('旧车架号'),
    next: Joi.string().description('新车架号'),
  }).unknown().description('更新车架号'),
  updateRegion: Joi.object({
    prev: Joi.object({
      id: Joi.string().description('大区id'),
      name: Joi.string().description('大区名称'),
    }).unknown().description('旧大区信息'),
    next: Joi.object({
      id: Joi.string().description('大区id'),
      name: Joi.string().description('大区名称'),
    }).unknown().description('新大区信息'),
  }).unknown().description('更换大区'),
  // 更换车型
  updateStyle: Joi.object({
    prev: Joi.object({
      id: Joi.string().description('车型id'),
      name: Joi.string().description('车型名称'),
      level: Joi.number(),
    }).unknown().description('旧车型信息'),
    next: Joi.object({
      id: Joi.string().description('车型id'),
      name: Joi.string().description('车型名称'),
      level: Joi.number(),
    }).unknown().description('新车型信息'),
  }).unknown().description('更换车型'),
  updateBox: Joi.object({
    prev: Joi.string().description('旧盒子'),
    next: Joi.string().description('新盒子'),
  }).unknown().description('更换盒子'),
  addDamage: Joi.object({
    id: Joi.string().description('损坏记录id'),
    description: Joi.string().description('损坏描述'),
    photo: Joi.string().description('损坏照片'),
    prevStockState: Joi.number().description('记录前车辆状态'),
    nextStockState: Joi.number().description('记录后车辆状态')
  }).unknown().description('添加损坏'),
  // 修复损坏
  repairDamage: Joi.object({
    id: Joi.string().description('损坏记录id'),
    description: Joi.string().description('损坏描述'),
    photo: Joi.string().description('损坏照片'),
    repairPhoto: Joi.string().description('修复照片'),
    repairRemark: Joi.string().description('修复备注'),
    prevStockState: Joi.number().description('修复前车辆状态'),
    nextStockState: Joi.number().description('修复后车辆状态')
  }).unknown().description('添加损坏'),
  putOn: Joi.object({
    storehouse: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('投放前仓库'),
    putOnLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('投放地址'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('投放车辆'),
  recover: Joi.object({
    recoverLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('回收前地址'),
    storehouse: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('回收到仓库'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('回收车辆'),
  reservation: Joi.object({
    user: Joi.object({
      id: Joi.string(),
      tel: Joi.string(),
      name: Joi.string(),
    }).unknown().description('预约人'),
    userLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('预约时用户的位置快照'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('预约车辆'),
  cancelReservation: Joi.object({
    succeed: Joi.boolean().description('是否预约成功'),
    user: Joi.object({
      id: Joi.string(),
      tel: Joi.string(),
      name: Joi.string(),
    }).unknown().description('预约人'),
    userLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('预约时用户的位置快照'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('预约车辆'),
  rent: Joi.object({
    order: Joi.string().description('订单号'),
    user: Joi.object({
      id: Joi.string(),
      tel: Joi.string(),
      name: Joi.string(),
    }).unknown().description('租用人'),
    userLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('车辆位置'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('租用车辆'),
  returnBack: Joi.object({
    order: Joi.string().description('订单号'),
    user: Joi.object({
      id: Joi.string(),
      tel: Joi.string(),
      name: Joi.string(),
    }).unknown().description('租用人'),
    orderState: Joi.number().description('结束时订单的状态'),
    totalAmount: Joi.number().description('订单总额'),
    duration: Joi.number().description('骑行时长'),
    distance: Joi.number().description('骑行距离'),
    outsideRegion: Joi.boolean().description('停车地点是否在围栏外'),
    insideProhibitedArea: Joi.boolean().description('是否在禁行区内'),
    insideForbiddenArea: Joi.boolean().description('是否在禁停区内'),
    insidePark: Joi.boolean().description('是否在停车区内'),
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('车辆位置'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('归还车辆'),
  startDispatch: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('开始调度位置'),
    storehouse: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('开始调度的仓库'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('开始调度'),
  finishDispatch: Joi.object({
    startLocation: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('开始调度位置或仓库'),
    startStorehouse: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown(),
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('结束调度位置'),
    storehouse: Joi.object({
      id: Joi.string(),
      name: Joi.string(),
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('结束调度的仓库'),
    prevPrevLocate: Joi.number(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('结束调度'),
  detained: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('被扣地点'),
    photo: Joi.string(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('车辆被扣上报'),
  detainedFindBack: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('找回地点'),
    photo: Joi.string(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('被扣找回'),
  applyReturnBack: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('申请时车辆地点'),
    photo: Joi.string(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('被扣找回'),
  cancelReturnBack: Joi.object({
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('取消拖回'),
  setLost: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('最后定位地点'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('登记丢失'),
  findBack: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('找回地点'),
    photo: Joi.string(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('丢失找回'),
  setSuspectedLost: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('最后定位地点'),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('登记疑似丢失'),
  suspectedLostFindBack: Joi.object({
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('找回地点'),
    photo: Joi.string(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('疑似丢失找回'),
  findStock: Joi.object({
    hasFind: Joi.boolean().description('是否找到车'),
    photo: Joi.string().description('拍照'),
    failedReason: Joi.number().description('未找到原因'),
  }).unknown().description('找车打卡'),
  exchangeBattery: Joi.object({
    prev: Joi.object({
      id: Joi.string(),
      voltage: Joi.number(),
      power: Joi.number(),
      mileage: Joi.number(),
    }).unknown().description('旧电池'),
    next: Joi.object({
      id: Joi.string(),
      voltage: Joi.number(),
      power: Joi.number(),
      mileage: Joi.number(),
    }).unknown().description('新电池')
  }).unknown().description('更换电池'),
  forceUpdate: Joi.object({
    isGpsLocation: Joi.boolean().description('是否刷新到卫星定位'),
    location: Joi.object({
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string(),
    }).unknown().description('定位地址'),
  }).unknown().description('强制刷新位置'),
  distributeInspector: Joi.object({
    inspector: Joi.string(),
    inspectorName: Joi.string(),
    inspectorTel: Joi.string(),
  }).unknown().description('分配巡检人员'),
  releaseInspector: Joi.object({
    inspector: Joi.string(),
    inspectorName: Joi.string(),
    inspectorTel: Joi.string(),
  }).unknown().description('解除巡检人员'),
  intoInspectionArea: Joi.object({
    inspectorName: Joi.string(),
    inspectorTel: Joi.string(),
  }).unknown().description('驶入巡检区'),
  outInspectionArea: Joi.object({
    inspectorName: Joi.string(),
    inspectorTel: Joi.string(),
  }).unknown().description('驶出巡检区'),
  addSpecialTask: Joi.object({
    taskId: Joi.string(),
    remark: Joi.string(),
    photo: Joi.string(),
    time: Joi.date(),
    location: {
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string()
    }
  }).unknown().description('添加特别任务'),
  removeSpecialTask: Joi.object({
    taskId: Joi.string(),
    remark: Joi.string(),
    photo: Joi.string(),
    time: Joi.date(),
    location: {
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string()
    },
    finishRemark: Joi.string(),
    finishPhoto: Joi.string(),
    finishLocation: {
      lngLat: Joi.array().items(Joi.number()),
      address: Joi.string()
    },
    finishTime: Joi.date(),
  }).unknown().description('完成特别任务'),
  releaseRevival: Joi.object({
    photo: Joi.string()
  }).unknown().description('解除复活任务'),
  adjustLocation: Joi.object({
    prev: Joi.object().description('调整前定位'),
    next: Joi.object().description('调整后定位'),
  }).unknown().description('调整定位'),
  otherOccupancy: Joi.object({
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('其它占用'),
  releaseOccupancy: Joi.object({
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
  }).unknown().description('取消占用'),
  inBound: Joi.object({
    prevPrevLocate: Joi.number(),
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
    nextStation: Joi.string(),
  }).unknown().description('入库'),
  outBound: Joi.object({
    prevLocate: Joi.number(),
    nextLocate: Joi.number(),
    prevStation: Joi.string(),
  }).unknown().description('出库'),
  // 报失电池
  batteryLost: Joi.object({
    isIntact: Joi.boolean().description('电池仓是否完好'),
    remark: Joi.string().description('备注'),
    batteryImages: Joi.array().items(Joi.string()).description('电池仓照片'),
  }).unknown().description('报失电池'),
}).unknown().empty(null);