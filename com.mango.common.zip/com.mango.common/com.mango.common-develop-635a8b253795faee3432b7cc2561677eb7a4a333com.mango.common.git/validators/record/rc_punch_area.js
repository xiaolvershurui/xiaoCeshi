const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  polygon: Joi.string().description('巡检区 ref'),
  punchArea: Joi.string().description('打卡点 ref'),
  punchedAt: Joi.date().description('打卡时间'),
  puncher: Joi.string().description('打卡人'),
  remark: Joi.string().description('打卡备注'),
  photo: Joi.string().description('打卡照片'),
}).unknown().empty(null);