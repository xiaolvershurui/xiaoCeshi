const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('User ref'),
  type: Joi.number().description('类型'),
  polygon: Joi.string().description('Polygon ref'),
  matchCount: Joi.object({
    prevMatchCount: Joi.number().description('清除前数字')
  }),
}).empty(null);