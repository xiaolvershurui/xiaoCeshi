const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  battery: Joi.string().description('电池编号 ref'),
  stock: Joi.string().description('车辆'),
  QRCode: Joi.string().description('二维码'),
  mark: Joi.string().description('标记'),
  description: Joi.string().description('描述'),
  remark: Joi.string().description('操作备注'),
  inStation: Joi.string().description('电池站'),
  type: Joi.number().description('操作类型'),
  fromStation: Joi.string().description('接收电池站来源'),
  fromAccount: Joi.string().description('巡检师傅来源'),
  operatedAt: Joi.date().description('操作时间'),
  operator: Joi.string().description('操作人'),
  operatorName: Joi.string().description('操作人姓名'),
  location: Joi.array().items(Joi.number()).description('位置'),
  address: Joi.string().description('位置'),
  batteryImages: Joi.array().items(Joi.string()).description('电池图片'),
}).unknown().empty(null);