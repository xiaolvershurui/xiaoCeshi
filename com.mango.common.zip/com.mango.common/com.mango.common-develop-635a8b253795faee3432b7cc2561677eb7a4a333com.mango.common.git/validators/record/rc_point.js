const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  date: Joi.date().description('日期'),
  month: Joi.number().description('月份'),
  approach: Joi.number().description('加分途径'),
  points: Joi.number().description('加分数值'),
  prevPoints: Joi.number().description('加分前数值')
}).unknown().empty(null);