const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('邀请人账户 ref'),
  invitedUser: Joi.string().description('被邀请人 ref'),
  invitedAt: Joi.date().description('邀请时间'),
}).unknown().empty(null);