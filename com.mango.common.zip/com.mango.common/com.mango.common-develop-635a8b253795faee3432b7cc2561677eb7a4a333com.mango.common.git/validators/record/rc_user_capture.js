const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  snappedAt: Joi.date().description('快照时间'),
  deviceInfo: Joi.object({
    platform: Joi.string().description('平台'),
    version: Joi.string().description('系统版本'),
    modal: Joi.string().description('设备型号'),
    udid: Joi.string().description('udid'),
    name: Joi.string().description('设备名'),
    heading: Joi.number().description('手机朝向'),
    battery: Joi.number().description('手机电量'),
    speed: Joi.number().description('速度'),
  }).unknown().description('设备信息'),
  appVersion: Joi.string().description('app版本号'),
  ip: Joi.string().description('ip信息'),
  lngLat: Joi.array().items(Joi.number()).description('经纬度'),
  address: Joi.string().description('地址'),
  city: Joi.string().description('城市'),
  accuracy: Joi.number().description('定位精度'),
}).unknown().empty(null);