const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  detainedArea: Joi.string().description('扣押点'),
  stock: Joi.array().items(Joi.string()).description('车辆'),
  logType: Joi.number().description('扣押点日志类型'),
  mark: Joi.string().description('打卡备注')
}).unknown().empty(null);