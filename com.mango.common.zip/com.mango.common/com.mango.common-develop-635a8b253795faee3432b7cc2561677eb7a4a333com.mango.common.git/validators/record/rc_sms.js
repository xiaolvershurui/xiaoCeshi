const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  tel: Joi.string().description('手机号'),
  user: Joi.string().description('账户 ref'),
  template: Joi.string().description('短信模板'),
  params: Joi.object().description('参数'),
  sentAt: Joi.date().description('发送时间'),
  succeed: Joi.boolean().description('是否发送成功'),
  error: Joi.object({
    message: Joi.string(),
    stack: Joi.string(),
  }).unknown().description('发送失败的原因'),
}).unknown().empty(null);