const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  user: Joi.string(),
  stock: Joi.string(),
  scannedAt: Joi.date(),
  succeed: Joi.boolean(),
  region: Joi.string(),
  order: Joi.string(),
  // 下单完成(产生费用)
  rentFinish: Joi.boolean(),
  // 骑行失败(禁行围栏导致断电订单)
  noPowerByRegion: Joi.boolean(),
  // 断电时间
  noPoweredAt: Joi.date(),
  // 断电五秒以上
  noPowerForFiveSeconds: Joi.boolean(),
  // 禁行禁停围栏导致还车失败 最后系统结束
  returnFailedByArea: Joi.boolean(),
  // 离线导致还车失败
  returnFailedByOffline: Joi.boolean()
}).unknown().empty(null);