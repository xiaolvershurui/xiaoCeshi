const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  stock: Joi.string().description('车辆 ref'),
  user: Joi.string().description('操作人 ref'),
  station: Joi.string().description('站点 ref'),
  repairProject: Joi.array().items(Joi.object({
    projectId: Joi.string().description('维修项目 ref'),
    projectName: Joi.string().description('维修项目名称'),
    projectGroupId: Joi.string().description('维修项目分组 id'),
    projectGroupName: Joi.string().description('维修项目分组名称'),
  }).unknown()).description('维修项目 ref'),
}).unknown().empty(null);
