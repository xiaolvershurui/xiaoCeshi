const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('账户 ref'),
  hasRead: Joi.boolean().description('是否已读'),
  title: Joi.string().description('标题'),
  content: Joi.string().description('内容'),
  image: Joi.string().description('图'),
  link: Joi.string().description('连接')
}).unknown().empty(null);