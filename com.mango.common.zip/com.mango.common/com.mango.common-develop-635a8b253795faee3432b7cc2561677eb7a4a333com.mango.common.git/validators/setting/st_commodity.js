const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  user: Joi.string().description('创建人'),
  year: Joi.number().description('月份'),
  month: Joi.number().description('月份'),
  commodity: Joi.array().items(Joi.object({
    id: Joi.string().description('商品id'),
    day: Joi.number().description('当月的第几天')
  })).description('每月签到奖励'),
}).unknown().empty(null);