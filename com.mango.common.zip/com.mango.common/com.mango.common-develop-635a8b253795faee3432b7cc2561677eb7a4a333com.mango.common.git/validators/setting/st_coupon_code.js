const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('是否启用'),
  life: Joi.object({
    start: Joi.date().description('开始'),
    end: Joi.date().description('结束'),
  }).unknown().description('生命期'),
  code: Joi.string().description('兑换码'),
  tels: Joi.array().items(Joi.string()).description('可兑换手机号列表'),
  exchangedTels: Joi.array().items(Joi.string()).description('已兑换手机号列表'),
  remainTimes: Joi.number().description('剩余可兑换次数'),
  type: Joi.number().description('类型'),
  name: Joi.string().description('名称'),
  amount: Joi.number().description('面额'),
  validDuration: Joi.number().description('有效期天数'),
  validRegions: Joi.array().items(Joi.string()).description('可用大区列表'),
  validStyleLevels: Joi.array().items(Joi.number()).description('可用车型level列表'),
}).unknown().empty(null);