const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  code: Joi.string().description('供应商代码'),
  name: Joi.string().description('供应商名称'),
  contact: Joi.string().description('联系人'),
  tel: Joi.string().description('联系电话'),
}).unknown().empty(null);