const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  code: Joi.string().description('code'),
  type: Joi.string().description('类型名称'),
  group: Joi.number().description('组别')
}).unknown().empty(null);