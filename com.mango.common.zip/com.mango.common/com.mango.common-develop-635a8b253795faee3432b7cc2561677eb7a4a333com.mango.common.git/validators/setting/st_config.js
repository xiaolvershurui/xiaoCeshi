const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  valid: Joi.object({
    platforms: Joi.array().items(Joi.string().description('平台类型')),
    iOSLowestVersion: Joi.string().description('IOS平台最低版本号'),
    androidLowestVersion: Joi.string().description('Android平台最低版本号'),
  }).unknown().description('启用平台'),
  key: Joi.string().description('键'),
  valueType: Joi.string().description('值类型'),
  value: [Joi.number(), Joi.date(), Joi.object(), Joi.array(), Joi.string(), Joi.boolean()],
}).unknown().empty(null);