const Joi = require('poolishark').Joi;
const validators = require('../../settings/validators');

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  number: Joi.string().description('编号'),
  lngLat: Joi.array().items(Joi.number()).description('经纬度'),
  address: Joi.string().description('地址'),
  contact: Joi.string().description('联系人'),
  tel: Joi.string().description('联系方式'),
  unit: Joi.string().description('所属单位')
}).unknown().empty(null);