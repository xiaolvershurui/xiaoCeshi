const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('是否启用'),
  life: Joi.object({
    start: Joi.date().description('开始'),
    end: Joi.date().description('结束'),
  }).unknown().description('生命期'),
  title: Joi.string().description('标题'),
  description: Joi.string().description('描述'),
  image: Joi.string().description('图片地址'),
  link: Joi.string().description('链接'),
  // 活动规则
  rule: Joi.object({
    discountRent: Joi.object({
      enable: Joi.boolean().description('是否启用'),
      cutRate: Joi.number().description('折扣率'),
    }).description('租金折扣规则'),
    cutRent: Joi.object({
      enable: Joi.boolean().description('是否启用'),
      amount: Joi.number().description('折扣面额'),
      validAmount: Joi.number().description('启用金额'),
    }).unknown().description('租金折扣'),
    freeRent: Joi.object({
      enable: Joi.boolean().description('是否启用')
    }).unknown().description('免费租车'),
    freeInsurance: Joi.object({
      enable: Joi.boolean().description('是否启用')
    }).unknown().description('免费保险'),
  }).unknown().description('活动规则'),
  validRegions: Joi.array().items(Joi.string()).description('可用大区列表'),
  validStyleLevels: Joi.array().items(Joi.number()).description('可用车型level列表'),
}).unknown().empty(null);