const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  enable: Joi.boolean().description('是否启用'),
  name: Joi.string().description('名称'),
  unit: Joi.object({
    returnBack: Joi.number().description('拖回单价'),
    exchangeBattery: Joi.number().description('换电单价'),
    backIntoRegion: Joi.number().description('回栏单价'),
    hardToFindButFound: Joi.number().description('难寻找到'),
    putOn: Joi.number().description('投放'),
    normal: Joi.number().description('普通任务'),
    returnBackUnfinished: Joi.number().description('拖回未完成')
  }).unknown().description('价格表'),
  createdAt: Joi.date().description("创建时间"),
  updatedAt: Joi.date().description("更新时间")
}).unknown().empty(null);