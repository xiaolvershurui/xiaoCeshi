const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  removed: Joi.boolean().description('是否删除'),
  name: Joi.string().description('小组名称'),
  region: Joi.string().description('大区'),
  groupLeader: Joi.string().description('组长'),
  groupMembers: Joi.array().items(Joi.string()).description('组员'),
  creator: Joi.string().description('创建人'),
  lastEditor: Joi.string().description('最近修改人'),
  lastEditedAt: Joi.date().description('最近修改时间'),
}).unknown().empty(null);
