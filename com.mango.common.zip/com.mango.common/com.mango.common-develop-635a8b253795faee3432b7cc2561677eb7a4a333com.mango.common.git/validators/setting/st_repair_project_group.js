const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  removed: Joi.boolean().description('是否删除'),
  name: Joi.string().description('分组名称'),
  description: Joi.string().description('分组描述'),
  creator: Joi.string().description('创建人'),
  lastEditor: Joi.string().description('最近修改人'),
  lastEditedAt: Joi.date().description('最近修改时间'),
}).unknown().empty(null);
