const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  life: Joi.object({
    start: Joi.date().description('开始'),
    end: Joi.date().description('结束'),
  }).unknown().description('生命期'),
  name: Joi.string().description('名称'),
  image: Joi.string().description('图片地址'),
  link: Joi.string().description('跳转链接'),
  validCities: Joi.array().items(Joi.string()).description('可见城市列表'),
  queue: Joi.number().description('排序权重'),
}).unknown().empty(null);