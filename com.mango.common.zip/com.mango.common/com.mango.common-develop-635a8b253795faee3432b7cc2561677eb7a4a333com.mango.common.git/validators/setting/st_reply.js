const Joi = require('poolishark').Joi;

module.exports = Joi.object({
  _id: Joi.string().description('_id'),
  createdAt: Joi.date().description('创建时间'),
  updatedAt: Joi.date().description('更新时间'),
  enable: Joi.boolean().description('启用状态'),
  reply: Joi.string().description('回复用户内容'),
  realReason: Joi.string().description('真实原因'),
}).unknown().empty(null);