switch (process.env.NODE_ENV) {
  case 'production':
    exports.SERVICE_DATABASE = '100.98.6.59';
    exports.SERVICE_BUSINESS = '100.98.6.49';
    exports.SERVICE_TASK = '100.98.0.17';
    exports.SERVICE_IOT = '100.98.0.11';
    break;
  case 'staging':
    exports.SERVICE_DATABASE = 'localhost';
    exports.SERVICE_BUSINESS = 'localhost';
    exports.SERVICE_TASK = 'localhost';
    exports.SERVICE_IOT = '47.106.9.38';
    break;
  default:
    exports.SERVICE_DATABASE = 'hi.mangoebike.cc';
    exports.SERVICE_BUSINESS = 'hi.mangoebike.cc';
    exports.SERVICE_TASK = 'hi.mangoebike.cc';
    exports.SERVICE_IOT = '47.106.9.38';
}
