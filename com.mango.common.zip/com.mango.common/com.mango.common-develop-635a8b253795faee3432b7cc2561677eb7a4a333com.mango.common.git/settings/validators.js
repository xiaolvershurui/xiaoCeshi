const Joi = require('poolishark').Joi;
const ObjectId = require('mongoose').Types.ObjectId;
const ValidationError = require('../errors/ValidationError');
const constants = require('../settings/constants');

// 地理位置
module.exports.location = Joi.array().empty(Joi.array().length(0)).sparse(true).length(2).items([
  Joi.number().max(180).min(-180).empty('').allow(null).description('经度').error(new ValidationError('经度不正确')),
  Joi.number().max(90).min(-90).empty('').allow(null).description('纬度').error(new ValidationError('纬度不正确')),
]);

// 自定义类型
module.exports.ObjectId = Joi.alternatives().try(Joi.object().type(ObjectId, 'ObjectId').error(new ValidationError('id不合法')), Joi.string().empty('').allow(null).alphanum().length(24).error(new ValidationError('id不合法'))).default('ffffffffffffffffffffffff').example(new ObjectId);
module.exports.ObjectIdOrNull = Joi.alternatives().try(Joi.object().type(ObjectId, 'ObjectId').error(new ValidationError('id不合法')), Joi.string().empty('').allow(null).alphanum().length(24).error(new ValidationError('id不合法'))).example(new ObjectId);

// 可读id
module.exports.id = Joi.string().empty('').allow(null).alphanum().min(8).example('1610270123001');
// ip
module.exports.ip = Joi.string().ip();
// 金额
module.exports.amount = Joi.number().min(0).integer().error(new ValidationError('金额不正确'));
// 时间戳
module.exports.timestamp = Joi.date().timestamp().description('时间戳').error(new ValidationError('时间戳不正确'));

// 手机号
module.exports.tel = Joi.string().regex(/^[0-9]{11}$/).description('手机号').error(new ValidationError('手机号不正确'));
// 身份证号
module.exports.idCard = Joi.string().regex(/^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/).description('身份证号').error(new ValidationError('身份证号不正确'));

// cache
exports.cache = Joi.object({
  enable: Joi.boolean().default(false),
  extra: Joi.array().items([Joi.string(), Joi.number(), Joi.boolean()]),
});

exports.selector = Joi.string().default('_id').allow('');

exports.findlist = {
  query: Joi.object().default({}).description('查询参数'),
  limit: Joi.number().default(20).description('限制条目'),
  sort: Joi.object().default().description('排序选项'),
  skip: Joi.number().default(0).description('跳过条目'),
  selector: exports.selector,
  populateSelector: Joi.object().description('联查选项'),
  cache: exports.cache,
};

exports.findOne = {
  selector: exports.selector,
  populateSelector: Joi.object().description('联查选项'),
  cache: exports.cache,
};

exports.tableListOutput = (validator = Joi.object()) => {
  return {
    items: Joi.array().items(validator),
    count: Joi.number(),
  };
};

exports.commonQueryValidate = {
  query: Joi.object().default({}).required(),
  sort: Joi.object().default(),
  limit: Joi.number().default(constants.PAGE_SIZE),
  skip: Joi.number().default(0),
  selector: Joi.string().default('_id').allow(''),
};

exports.isQRCode = Joi.string().regex(/^E\d{9}$|\w{16}/).description('电池二维码').error(new Error('电池二维码不正确'));
