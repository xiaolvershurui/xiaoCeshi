module.exports = {
  key: 'X5zGCpNP2t4iayjBAHdMMNxdHwWQRB45',
  iv: 'D7mrKxpddGziGsRB'
};