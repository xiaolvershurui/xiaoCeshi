const { transform } = require('xx-utils');
const isDev = ['development', 'local'].includes(process.env.NODE_ENV);
const jsonToMap = (json = {}) => Object.keys(json).reduce((memo, key) => {
  memo[json[key]] = key;
  return memo;
}, {});
// 通用

// 地球半径
exports.EARTH_RADIUS = 6378137;
// Polygon搜索半径
exports.POLYGON_SEARCH_RADIUS = isDev ? 500 : 3000;
// 车辆搜索半径
exports.STOCK_SEARCH_RADIUS = 1000;
// 管理端polygon搜索半径
exports.POLYGON_SEARCH_RADIUS_ADMIN = 1000;
// 管理端车辆搜索半径
exports.STOCK_SEARCH_RADIUS_ADMIN = 50000;
// 巡检任务就近分配人员最大搜索半径
exports.INSPECTOR_SEARCH_RADIUS = 50000;
// 巡检人员搜索半径
exports.INSPECTOR_SEARCH_RADIUS_ADMIN = 50000;
// 列表每页条数
exports.PAGE_SIZE = 20;
// 最大ID
exports.MAX_ID = 'ffffffffffffffffffffffff';

// 账户

// 性别枚举
exports.AC_GENDER_ENUMS = ['男', '女'];
// 默认头像
exports.AC_DEFAULT_AVATOR = 'https://mango.8ddao.com/avator/default.png';
// 证件类型
exports.AC_CERT_TYPE = {
  身份证: 0,
};
// 证件类型枚举
exports.AC_CERT_TYPE_ENUMS = transform.jsonToEnums(exports.AC_CERT_TYPE);
// 法定驾驶者最低年龄
exports.AC_LOWEST_USER_AGE = 16;
// 法定驾驶者最高年龄
exports.AC_HIGHEST_USER_AGE = 65;
// 信用记录类型
exports.AC_CREDIT_RECORD_TYPE = {
  加分: 0,
  扣分: 1,
};
// 信用记录类型枚举
exports.AC_CREDIT_RECORD_TYPE_ENUMS = transform.jsonToEnums(exports.AC_CREDIT_RECORD_TYPE);
// 优惠券状态
exports.AC_COUPON_STATE = {
  可使用: 0,
  已使用: 1,
  已过期: 2,
};
// 优惠券状态枚举
exports.AC_COUPON_STATE_ENUMS = transform.jsonToEnums(exports.AC_COUPON_STATE);
// 优惠券类型
exports.AC_COUPON_TYPE = {
  租金抵扣券: 0,
};
// 优惠券类型枚举
exports.AC_COUPON_TYPE_ENUMS = transform.jsonToEnums(exports.AC_COUPON_TYPE);
// 优惠券信息
exports.AC_COUPON_INFO = {
  invite: {
    count: 5,
    amount: 200,
    name: '邀请好友红包',
    validDuration: 30,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  shareApp: {
    count: 1,
    amount: 100,
    name: '分享APP红包',
    validDuration: 1,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  shareOrder: {
    count: 1,
    amount: 100,
    name: '分享行程红包',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  commentOrder: {
    count: 1,
    amount: 100,
    name: '给行程评分红包',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  shootAfterFinished: {
    count: 1,
    amount: 100,
    name: '上传停车照红包',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  scanFailed: {
    count: 1,
    amount: 100,
    name: '开锁体验补偿红包',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  studyFinished: {
    count: 1,
    amount: 100,
    name: '观看视频奖励',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
  offlineStudyFinished: {
    count: 1,
    amount: 100,
    name: '线下学习奖励',
    validDuration: 3,
    type: exports.AC_COUPON_TYPE.租金抵扣券,
  },
};
// 每日认证次数
exports.AC_CERT_TRY_TIMES_PER_DAY = 3;
// 邀请码重发时间
exports.AC_VERIFY_CODE_RESEND = '1 minute';
// 邀请码过期时间
exports.AC_VERIFY_CODE_EXPIRES = '10 minutes';
// 验证进度
exports.AC_VERIFY_STEP = {
  待验证图形验证码: 0,
  待验证短信验证码: 1,
};
// 验证进度枚举
exports.AC_VERIFY_STEP_ENUMS = transform.jsonToEnums(exports.AC_VERIFY_STEP);
// 信用记录信息
exports.AC_CREDIT_RECORD_INFO = {
  正常骑行: {
    name: '正常骑行',
    type: exports.AC_CREDIT_RECORD_TYPE.加分,
    point: 1,
  },
  举报滥用: {
    name: '举报滥用',
    type: exports.AC_CREDIT_RECORD_TYPE.加分,
    point: 1,
  },
  上报故障: {
    name: '上报故障',
    type: exports.AC_CREDIT_RECORD_TYPE.加分,
    point: 1,
  },
  邀请注册: {
    name: '邀请注册',
    type: exports.AC_CREDIT_RECORD_TYPE.加分,
    point: 2,
  },
  首次分享行程: {
    name: '首次分享行程',
    type: exports.AC_CREDIT_RECORD_TYPE.加分,
    point: 2,
  },
  长时间无移动: {
    name: '长时间无移动',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 5,
  },
  行程超时: {
    name: '行程超时',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 5,
  },
  违停: {
    name: '违停',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 20,
  },
  违章骑行: {
    name: '违章骑行',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 20,
  },
  加装私锁: {
    name: '加装私锁',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 100,
  },
  用车结束未锁车: {
    name: '用车结束未锁车',
    type: exports.AC_CREDIT_RECORD_TYPE.扣分,
    point: 100,
  },
};
// 信用分过低阈值
exports.AC_LOW_CREDIT_POINT = 0;
// 信用分过低时间单价
exports.AC_LOW_CREDIT_TIME_UNIT = 500;
// 运营账户任务分配方式
exports.AC_OPERATOR_TASK_DISTRIBUTION_METHOD = {
  即时就近: 0,
  巡检区: 1,
};
// 运营账户任务分配方式枚举
exports.AC_OPERATOR_TASK_DISTRIBUTION_METHOD_ENUMS = transform.jsonToEnums(exports.AC_OPERATOR_TASK_DISTRIBUTION_METHOD);

// 财务

// 押金退款状态
exports.FN_DEPOSIT_REFUND_STATE = {
  未缴纳: 0,
  可退款: 1,
  冻结中: 2,
  退款中: 3,
};
// 押金退款状态枚举
exports.FN_DEPOSIT_REFUND_STATE_ENUMS = transform.jsonToEnums(exports.FN_DEPOSIT_REFUND_STATE);
// 退款处理人类型
exports.FN_REFUND_PROCESSOR_TYPE = {
  运营人员: 0,
  系统: 1,
};
// 退款处理人类型枚举
exports.FN_REFUND_PROCESSOR_TYPE_ENUMS = transform.jsonToEnums(exports.FN_REFUND_PROCESSOR_TYPE);
// 支付凭据类型
exports.FN_TICKET_TYPE = {
  充值: 0,
  支付押金: 1,
};
// 支付凭据主题描述
exports.FN_TICKET_SUBJECTS = [
  '芒果电单车-充值',
  '芒果电单车-缴纳押金',
];
// 支付凭据类型枚举
exports.FN_TICKET_TYPE_ENUMS = transform.jsonToEnums(exports.FN_TICKET_TYPE);
// 支付渠道
exports.FN_TICKET_CHANNEL = {
  支付宝: 'alipay',
  微信: 'wx',
};
// 支付渠道枚举
exports.FN_TICKET_CHANNEL_ENUMS = transform.jsonToEnums(exports.FN_TICKET_CHANNEL);
// 支付API渠道
exports.FN_TICKET_PAYMENT_API_CHANNEL = {
  支付宝: 'alipay',
  微信: 'wx',
  pingxx: 'pingxx',
};
// 支付API渠道枚举
exports.FN_TICKET_PAYMENT_API_CHANNEL_ENUMS = transform.jsonToEnums(exports.FN_TICKET_PAYMENT_API_CHANNEL);
// 凭据支付状态
exports.FN_TICKET_STATE = {
  待支付: 0,
  已支付: 1,
  已取消: 2,
  退款中: 3,
  退款已确认: 4,
  已退款: 5,
  退款失败: 6,
};
// 凭据支付状态枚举
exports.FN_TICKET_STATE_ENUMS = transform.jsonToEnums(exports.FN_TICKET_STATE);
// 支付凭据取消人
exports.FN_TICKET_CANCLLER = {
  系统: 0,
  用户: 1,
};
// 支付凭据取消人枚举
exports.FN_TICKET_CANCLLER_ENUMS = transform.jsonToEnums(exports.FN_TICKET_CANCLLER);
// 退款延迟时间
exports.FN_TICKET_REFUND_DELAY = isDev ? '0 second' : '60 hours';
// 押金账单类型
exports.FN_DEPOSIT_BILL_TYPE = {
  支付押金: 0,
  退还押金: 1,
};
// 押金账单类型枚举
exports.FN_DEPOSIT_BILL_TYPE_ENUMS = transform.jsonToEnums(exports.FN_DEPOSIT_BILL_TYPE);
// 余额账单类型
exports.FN_BALANCE_BILL_TYPE = {
  收入: 0,
  支出: 1,
};
// 余额账单类型枚举
exports.FN_BALANCE_BILL_TYPE_ENUMS = transform.jsonToEnums(exports.FN_BALANCE_BILL_TYPE);
// 余额账单标记
exports.FN_BALANCE_BILL_SIGNAL = {
  充值: 0,
  管理员充值: 1,
  管理员扣钱: 2,
  充值退款: 3,
  支付订单租金: 4,
  支付订单保险: 5,
  撤销退款: 6,
  订单免单: 7,
  支付停车调度费用: 8
};
// 余额账单标记枚举
exports.FN_BALANCE_BILL_SIGNAL_ENUMS = transform.jsonToEnums(exports.FN_BALANCE_BILL_SIGNAL);
// 余额账单标记对应类型
exports.FN_BALANCE_BILL_SIGNAL_MAP = {
  [exports.FN_BALANCE_BILL_SIGNAL.充值]: exports.FN_BALANCE_BILL_TYPE.收入,
  [exports.FN_BALANCE_BILL_SIGNAL.管理员充值]: exports.FN_BALANCE_BILL_TYPE.收入,
  [exports.FN_BALANCE_BILL_SIGNAL.管理员扣钱]: exports.FN_BALANCE_BILL_TYPE.支出,
  [exports.FN_BALANCE_BILL_SIGNAL.充值退款]: exports.FN_BALANCE_BILL_TYPE.支出,
  [exports.FN_BALANCE_BILL_SIGNAL.支付订单租金]: exports.FN_BALANCE_BILL_TYPE.支出,
  [exports.FN_BALANCE_BILL_SIGNAL.支付订单保险]: exports.FN_BALANCE_BILL_TYPE.支出,
  [exports.FN_BALANCE_BILL_SIGNAL.撤销退款]: exports.FN_BALANCE_BILL_TYPE.收入,
  [exports.FN_BALANCE_BILL_SIGNAL.订单免单]: exports.FN_BALANCE_BILL_TYPE.收入,
  [exports.FN_BALANCE_BILL_SIGNAL.支付停车调度费用]: exports.FN_BALANCE_BILL_TYPE.支出,
};
// 大区流水类型
exports.FN_REGION_FLOW_TYPE = {
  保险: 0,
  租金: 1,
  押金: 2,
  退押金: 3,
};
// 大区流水类型枚举
exports.FN_REGION_FLOW_TYPE_ENUMS = transform.jsonToEnums(exports.FN_REGION_FLOW_TYPE);
// 大区流水账单结算状态
exports.FN_REGION_FLOW_STATE = {
  未结算: 0,
  已结算: 1,
};
// 大区流水账单结算状态枚举
exports.FN_REGION_FLOW_STATE_ENUMS = transform.jsonToEnums(exports.FN_REGION_FLOW_STATE);
// 大区提现账单状态
exports.FN_REGION_WITHDRAW_STATE = {
  处理中: 0,
  已完成: 1,
  已取消: 2,
};
// 大区提现账单状态枚举
exports.FN_REGION_WITHDRAW_STATE_ENUMS = transform.jsonToEnums(exports.FN_REGION_WITHDRAW_STATE);

// 运营

// 车型level
exports.OP_STYLE_LEVEL = {
  level1: 0,
  level2: 1,
  level3: 2,
};
// 车型level枚举
exports.OP_STYLE_LEVEL_ENUMS = transform.jsonToEnums(exports.OP_STYLE_LEVEL);
// 区域类型
exports.OP_POLYGON_TYPE = {
  无类型: 0,
  停车区: 1,
  禁停区: 2,
  禁行区: 3,
  巡检区: 4,
  逆行检测区: 5,
  非法横跨机动车道检测区: 6,
  行政区: 7,
};
// 区域类型枚举
exports.OP_POLYGON_TYPE_ENUMS = transform.jsonToEnums(exports.OP_POLYGON_TYPE);
// 区块社区类型
exports.OP_POLYGON_NEIGHBORHOOD = {
  无类型: 0,
  住宅小区: 1,
  高等院校: 2,
  商服用地: 3,
  医院: 4,
  事业单位: 5,
  中小学校: 6,
  文体娱乐用地: 7,
  公园与绿地: 8,
  水域: 9,
  特殊用地: 10,
  交通用地: 11,
  工业用地: 12,
  仓储用地: 13,
  老城区: 14,
};
// 区域社区类型枚举
exports.OP_POLYGON_NEIGHBORHOOD_ENUMS = transform.jsonToEnums(exports.OP_POLYGON_NEIGHBORHOOD);
// 区块状态
exports.OP_POLYGON_STATE = {
  待审: 0,
  锁定: 1,
  返工: 2,
};
// 区块状态枚举
exports.OP_POLYGON_STATE_ENUMS = transform.jsonToEnums(exports.OP_POLYGON_STATE);
// 区块返工理由
exports.OP_POLYGON_REWORK_REASON = {
  名称错误: 0,
  边界错误: 1,
  类型错误: 2,
  地域错误: 3,
  中心点错误: 4,
  其他: 5,
};
// 区块返工理由枚举
exports.OP_POLYGON_REWORK_REASON_ENUMS = transform.jsonToEnums(exports.OP_POLYGON_REWORK_REASON);
// 上报故障问题类型
exports.OP_REPORTED_DAMAGES_TYPE = {
  开不了锁: 0,
  车辆损坏: 1,
};
// 上报故障问题类型枚举
exports.OP_REPORTED_DAMAGES_TYPE_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_DAMAGES_TYPE);
// 上报故障问题类型映射
exports.OP_REPORTED_DAMAGES_TYPE_MAP = jsonToMap(exports.OP_REPORTED_DAMAGES_TYPE);
// 上报故障损坏信息
exports.OP_REPORTED_DAMAGES_DETAIL = {
  车牌掉了: 0,
  脚踏掉了: 1,
  车胎爆了: 2,
  车灯坏了: 3,
  刹车失灵: 4,
  其他: 5,
};
// 上报故障损坏信息枚举
exports.OP_REPORTED_DAMAGES_DETAIL_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_DAMAGES_DETAIL);
// 上报故障损坏信息映射
exports.OP_REPORTED_DAMAGES_DETAIL_MAP = jsonToMap(exports.OP_REPORTED_DAMAGES_DETAIL);
// 上报故障处理状态
exports.OP_REPORTED_DAMAGES_STATE = {
  待处理: 0,
  已处理: 1,
};
// 上报故障处理状态枚举
exports.OP_REPORTED_DAMAGES_STATE_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_DAMAGES_STATE);
// 上报故障处理结果
exports.OP_REPORTED_DAMAGES_RESULT = {
  属实: 0,
  误报: 1,
};
// 上报故障处理结果枚举
exports.OP_REPORTED_DAMAGES_RESULT_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_DAMAGES_RESULT);
// 举报类型
exports.OP_REPORTED_ABUSE_TYPE = {
  违停: 0,
  偷盗: 1,
  恶意损坏: 2,
  非法移车: 3,
};
// 举报类型枚举
exports.OP_REPORTED_ABUSE_TYPE_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_ABUSE_TYPE);
// 举报类型映射
exports.OP_REPORTED_ABUSE_TYPE_MAP = jsonToMap(exports.OP_REPORTED_ABUSE_TYPE);
// 举报处理状态
exports.OP_REPORTED_ABUSE_STATE = {
  待处理: 0,
  已处理: 1,
};
// 举报处理状态枚举
exports.OP_REPORTED_ABUSE_STATE_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_ABUSE_STATE);
// 举报处理结果
exports.OP_REPORTED_ABUSE_RESULT = {
  属实: 0,
  误报: 1,
};
// 上报故障处理结果枚举
exports.OP_REPORTED_ABUSE_RESULT_ENUMS = transform.jsonToEnums(exports.OP_REPORTED_ABUSE_RESULT);
// 信用申诉处理状态
exports.OP_CREDIT_APPEAL_STATE = {
  待处理: 0,
  已处理: 1,
};
// 信用申诉处理状态枚举
exports.OP_CREDIT_APPEAL_STATE_ENUMS = transform.jsonToEnums(exports.OP_CREDIT_APPEAL_STATE);
// 信用申诉结果
exports.OP_CREDIT_APPEAL_RESULT = {
  通过: 0,
  驳回: 1,
};
// 信用申诉结果枚举
exports.OP_CREDIT_APPEAL_RESULT_ENUMS = transform.jsonToEnums(exports.OP_CREDIT_APPEAL_RESULT);
// 用户反馈处理状态
exports.OP_REPORT_STATE = {
  待处理: 0,
  已处理: 1,
};
// 用户反馈处理状态枚举
exports.OP_REPORT_STATE_ENUMS = transform.jsonToEnums(exports.OP_REPORT_STATE);
// 工单类型
exports.OP_WORK_ORDER_TYPE = {
  软件反馈: 0,
  订单问题: 1,
  车辆问题: 2,
};
// 工单类型枚举
exports.OP_WORK_ORDER_TYPE_ENUMS = transform.jsonToEnums(exports.OP_WORK_ORDER_TYPE);
// 工单类型映射
exports.OP_WORK_ORDER_TYPE_MAP = transform.jsonToMap(exports.OP_WORK_ORDER_TYPE);
// 工单评价结果
exports.OP_WORK_ORDER_COMMENT_RESULT = {
  满意: 0,
  不满意: 1,
};
// 工单评价结果枚举
exports.OP_WORK_ORDER_COMMENT_RESULT_ENUMS = transform.jsonToEnums(exports.OP_WORK_ORDER_COMMENT_RESULT);
// 押金额
exports.OP_DEPOSIT_AMOUNT = 29900;
// 押金额配置键
exports.OP_DEPOSIT_AMOUNT_CONFIG_KEY = 'fn_deposit_amount';
// 任务类型
exports.OP_TASK_TYPE = {
  车辆任务: 0,
  运营站任务: 1,
  电池任务: 2,
};
// 任务类型枚举
exports.OP_TASK_TYPE_ENUMS = transform.jsonToEnums(exports.OP_TASK_TYPE);
// 任务处理状态
exports.OP_TASK_STATE = {
  已发布: 0,
  待处理: 1,
  已完成: 2,
};
// 任务处理状态枚举
exports.OP_TASK_STATE_ENUMS = transform.jsonToEnums(exports.OP_TASK_STATE);
// 巡检任务类型
exports.OP_INSPECTION_TASK_TYPE = {
  车机离线: 0,
  无卫星定位: 1,
  车辆断电: 2,
  连续位移: 3,
  低电量: 4,
  电量预警: 5,
  车辆损坏: 6,
  两天未使用: 7,
  围栏外: 8,
  禁停区内: 9,
  禁行区内: 10,
};
// 巡检任务类型枚举
exports.OP_INSPECTION_TASK_TYPE_ENUMS = transform.jsonToEnums(exports.OP_INSPECTION_TASK_TYPE);

// 配置

// 配置可启用平台
exports.ST_CONFIG_PLATFORM = {
  iOS: 'iOS',
  Android: 'Android',
  Web: 'Web',
  Server: 'Server',
};
// 配置可启用平台枚举
exports.ST_CONFIG_PLATFORM_ENUMS = transform.jsonToEnums(exports.ST_CONFIG_PLATFORM);
// 配置值类型枚举
exports.ST_CONFIG_VALUE_TYPE_ENUMS = ['Number', 'Boolean', 'String', 'Array', 'Object', 'Date'];
// 城市列表枚举
const cities = require('./cities.json');
exports.ST_CITIES_ENUMS = cities.map(city => city.name);
// 城市名
exports.ST_CITIES = cities.reduce((memo, city) => {
  memo[city.name] = city;
  return memo;
}, {});

// 扣押点操作日志
exports.ST_DETAINED_AREA_LOG_TYPE = {
  创建扣押点: 0,
  添加扣押车辆: 1,
  减少扣押车辆: 2,
  打卡: 3,
};
exports.ST_DETAINED_AREA_LOG_TYPE_ENUMS = transform.jsonToEnums(exports.ST_DETAINED_AREA_LOG_TYPE);


// 车辆

// 车辆损坏状态
exports.BK_STATE = {
  完好: 0,
  损坏可租: 1,
  损坏不可租: 2,
  报废: 3,
};
// 车辆损坏状态枚举
exports.BK_STATE_ENUMS = transform.jsonToEnums(exports.BK_STATE);
// 车辆损坏状态映射
exports.BK_STATE_MAP = transform.jsonToMap(exports.BK_STATE);
// 车辆去向
exports.BK_LOCATE = {
  空闲: 0,
  在租: 1,
  预约: 2,
  仓库: 3,
  内部使用: 4,
  丢失: 5,
  调度: 6,
  其他占用: 7,
  扣押: 8,
  待拖回: 9,
  疑似丢失: 10,
  跨区运输中: 11,
};
// 车辆去向枚举
exports.BK_LOCATE_ENUMS = transform.jsonToEnums(exports.BK_LOCATE);
// 车辆去向映射
exports.BK_LOCATE_MAP = transform.jsonToMap(exports.BK_LOCATE);
// 盒子数据源
exports.BK_BOX_DATA_SOURCE = {
  旧一动: 0,
  比德文: 1,
  一动: 2,
  小安宝: 3,
};
// 盒子数据源枚举
exports.BK_BOX_DATA_SOURCE_ENUMS = transform.jsonToEnums(exports.BK_BOX_DATA_SOURCE);
// 盒子定位类型
exports.BK_BOX_LOCATION_TYPE = {
  卫星: 0,
  基站: 1,
};
// 盒子工作模式
exports.BK_BOX_WORK_MODE = {
  工作: 0,
  省电: 1,
  休眠: 2,
};
// 盒子工作模式枚举
exports.BK_BOX_WORK_MODE_ENUMS = transform.jsonToEnums(exports.BK_BOX_WORK_MODE);
// 盒子定位类型枚举
exports.BK_BOX_LOCATION_TYPE_ENUMS = transform.jsonToEnums(exports.BK_BOX_LOCATION_TYPE);
// 车损修复状态
exports.BK_DAMAGE_STATE = {
  未修复: 0,
  正在修复: 1,
  已修复: 2,
};
// 车损修复状态枚举
exports.BK_DAMAGE_STATE_ENUMS = transform.jsonToEnums(exports.BK_DAMAGE_STATE);
// 低电阈值 弃用
exports.BK_LOW_POWER_LINE = 0.3;
// 低电阈值里程
exports.BK_LOW_POWER_MILEAGE = isDev ? 0 : 14000;
// 需要进行巡检的里程阈值
exports.BK_LOW_POWER_WARNING_MILEAGE = isDev ? 16000 : 23000;
// 强制断电里程阈值
exports.BK_FORCE_POWER_OFF_MILEAGE = isDev ? 0 : 7000;

// 零电电压
exports.BK_NO_POWER_VOLTAGE = 39; // 1%
// 强制断电电压
exports.BK_FORCE_POWER_OFF_VOLTAGE = 43.5; // 续航5公里的电压是43v 拧到最大油门最低电压为41.5v
// 050错误控制器 临时断电电压
exports.BK_TEMPORARY_FORECE_OFF_VOLTATE = 43.5;
// 050错误控制器 临时低电电压
exports.BK_TEMPORARY_LOW_POWER_VOLTATE = 45.7;
// 低电阈值电压
exports.BK_LOW_POWER_VOLTAGE = 45.7; // 续航10公里
// 高压预警电压
exports.BK_LOW_POWER_WARNING_VOLTAGE = 47.2; // 60%
// 低压预警电压
exports.BK_VERY_LOW_POWER_WARNING_VOLTAGE = 46.3; // 45%

// 车型可支持的额定电压
exports.BK_RATED_VOLTAGE = {
  '24V': 24,
  '48V': 48,
  '60V': 60,
  '72V': 72,
  '84V': 84,
};
// 车型可支持的额定电压枚举
exports.BK_RATED_VOLTAGE_ENUMS = transform.jsonToEnums(exports.BK_RATED_VOLTAGE);
// 电池损坏状态
exports.BK_BATTERY_STATE = {
  完好: 0,
  损坏: 2,
  报废: 3,
};
// 电池损坏状态枚举
exports.BK_BATTERY_STATE_ENUMS = transform.jsonToEnums(exports.BK_BATTERY_STATE);
// 电池损坏状态映射
exports.BK_BATTERY_STATE_MAP = transform.jsonToMap(exports.BK_BATTERY_STATE);
// 电池去向
exports.BK_BATTERY_LOCATE = {
  在运营站: 0,
  巡检人员携带: 1,
  安装于车辆: 2,
  丢失: 3,
  运输途中: 4,
  维修占用: 5,
  跨区运输中: 6
};
// 电池去向枚举
exports.BK_BATTERY_LOCATE_ENUMS = transform.jsonToEnums(exports.BK_BATTERY_LOCATE);
// 电池去向映射
exports.BK_BATTERY_LOCATE_MAP = transform.jsonToMap(exports.BK_BATTERY_LOCATE);
// 车辆任务类型
exports.BK_TASK_TYPE = {
  待拖回: 101,
  调度中: 201,
  被扣押: 301,
  离线复活: 2101,
  司机未找到: 401,
  白班未找到: 402,
  高手未找到: 403,
  超一天真离线: 1401,
  超一天离线扫码车: 1402,
  超一天无定位扫码车: 1403,
  超一天疑似离线: 1404,
  超一天丢失扫码车: 1405,
  一天内真离线: 501,
  一天内离线扫码车: 502,
  一天内无定位扫码车: 503,
  一天内疑似离线: 504,
  一天内丢失扫码车: 505,
  无定位: 1501,
  零电: 601,
  被盗断电: 602,
  零电断电: 603,
  空闲超速: 605,
  困难换电: 2001,
  损坏不可租: 701,
  低电: 702,
  围栏外非免单: 703,
  低压预警: 1301,
  高压预警: 801,
  特殊任务: 1001,
  损坏可租: 1101,
  一天未唤醒: 1102,
  两天未唤醒: 1103,
  四天未唤醒: 1104,
  四天未巡检: 1105,
  禁行区: 1106,
  围栏外免单: 1107,
  高压离线: 1108,
  待投放: 1201,
  禁停区: 1202,
  电池编号核实: 1601
};
// 任务权重
exports.BK_TASK_TYPE_RATE = {
  [exports.BK_TASK_TYPE.超一天离线扫码车]: 100,
  [exports.BK_TASK_TYPE.超一天无定位扫码车]: 99,
  [exports.BK_TASK_TYPE.一天内离线扫码车]: 98,
  [exports.BK_TASK_TYPE.一天内无定位扫码车]: 97,
  [exports.BK_TASK_TYPE.超一天真离线]: 96,
  [exports.BK_TASK_TYPE.超一天疑似离线]: 95,
  [exports.BK_TASK_TYPE.一天内真离线]: 94,
  [exports.BK_TASK_TYPE.一天内疑似离线]: 93,
  [exports.BK_TASK_TYPE.被盗断电]: 92,
  [exports.BK_TASK_TYPE.零电断电]: 91,
  [exports.BK_TASK_TYPE.零电]: 90,
  [exports.BK_TASK_TYPE.困难换电]: 89,
  [exports.BK_TASK_TYPE.无定位]: 88,
  [exports.BK_TASK_TYPE.低电]: 87,
  [exports.BK_TASK_TYPE.围栏外非免单]: 86,
  [exports.BK_TASK_TYPE.低压预警]: 85,
  [exports.BK_TASK_TYPE.高压预警]: 84,
  [exports.BK_TASK_TYPE.围栏外免单]: 83,
  // 以上 按任务统计优先级
  // 以下 按前端图标排序优先级
  [exports.BK_TASK_TYPE.待拖回]: 82,
  [exports.BK_TASK_TYPE.调度中]: 81,
  [exports.BK_TASK_TYPE.超一天丢失扫码车]: 80,
  [exports.BK_TASK_TYPE.一天内丢失扫码车]: 79,
  [exports.BK_TASK_TYPE.被扣押]: 78,
  [exports.BK_TASK_TYPE.高手未找到]: 77,
  [exports.BK_TASK_TYPE.白班未找到]: 76,
  [exports.BK_TASK_TYPE.司机未找到]: 75,
  [exports.BK_TASK_TYPE.空闲超速]: 74,
  [exports.BK_TASK_TYPE.损坏不可租]: 73,
  [exports.BK_TASK_TYPE.特殊任务]: 72,
  [exports.BK_TASK_TYPE.高压离线]: 71,
  [exports.BK_TASK_TYPE.损坏可租]: 70,
  [exports.BK_TASK_TYPE.四天未巡检]: 69,
  [exports.BK_TASK_TYPE.四天未唤醒]: 68,
  [exports.BK_TASK_TYPE.两天未唤醒]: 67,
  [exports.BK_TASK_TYPE.一天未唤醒]: 66,
  [exports.BK_TASK_TYPE.禁行区]: 65,
  [exports.BK_TASK_TYPE.待投放]: 64,
  [exports.BK_TASK_TYPE.禁停区]: 63,
};
// 车辆任务类型枚举
exports.BK_TASK_TYPE_ENUMS = transform.jsonToEnums(exports.BK_TASK_TYPE);
// 车辆任务类型映射
exports.BK_TASK_TYPE_MAP = transform.jsonToMap(exports.BK_TASK_TYPE);
// 车辆任务分组
exports.BK_TASK_GROUP = {
  拖车组: 1,
  调度组: 2,
  扣押组: 3,
  丢失风险组: 5,
  断电任务组: 6,
  无法租赁组: 7,
  高压换电组: 8,
  特殊任务组: 10,
  人工分配组: 11,
  无用组: 12,
  低压换电组: 13,
  丢失高风险组: 14,
  无定位组: 15,
  高手难寻组: 16,
  白班难寻组: 17,
  司机难寻组: 18,
  未巡检组: 19,
  困难换电任务组: 20,
  复活组: 21,
};
// 车辆任务分组枚举
exports.BK_TASK_GROUP_ENUMS = transform.jsonToEnums(exports.BK_TASK_GROUP);
// 车辆任务分组排序
exports.BK_TASK_GROUP_RATE = {
  [exports.BK_TASK_GROUP.拖车组]: 18,
  [exports.BK_TASK_GROUP.调度组]: 17,
  [exports.BK_TASK_GROUP.扣押组]: 16,
  [exports.BK_TASK_GROUP.复活组]: 15,
  [exports.BK_TASK_GROUP.高手难寻组]: 14,
  [exports.BK_TASK_GROUP.白班难寻组]: 13,
  [exports.BK_TASK_GROUP.司机难寻组]: 12,
  [exports.BK_TASK_GROUP.丢失高风险组]: 11,
  [exports.BK_TASK_GROUP.丢失风险组]: 10,
  [exports.BK_TASK_GROUP.无定位组]: 9,
  [exports.BK_TASK_GROUP.断电任务组]: 8,
  [exports.BK_TASK_GROUP.困难换电任务组]: 7,
  [exports.BK_TASK_GROUP.无法租赁组]: 6,
  [exports.BK_TASK_GROUP.低压换电组]: 5,
  [exports.BK_TASK_GROUP.高压换电组]: 4,
  [exports.BK_TASK_GROUP.特殊任务组]: 3,
  [exports.BK_TASK_GROUP.未巡检组]: 2,
  [exports.BK_TASK_GROUP.人工分配组]: 1,
  [exports.BK_TASK_GROUP.无用组]: 0,
};
// 车辆任务所属分组
exports.BK_GROUP_OF_TASK = {
  [exports.BK_TASK_TYPE.待拖回]: exports.BK_TASK_GROUP.拖车组,
  [exports.BK_TASK_TYPE.调度中]: exports.BK_TASK_GROUP.调度组,
  [exports.BK_TASK_TYPE.被扣押]: exports.BK_TASK_GROUP.扣押组,
  [exports.BK_TASK_TYPE.离线复活]: exports.BK_TASK_GROUP.复活组,
  [exports.BK_TASK_TYPE.高手未找到]: exports.BK_TASK_GROUP.高手难寻组,
  [exports.BK_TASK_TYPE.白班未找到]: exports.BK_TASK_GROUP.白班难寻组,
  [exports.BK_TASK_TYPE.司机未找到]: exports.BK_TASK_GROUP.司机难寻组,
  [exports.BK_TASK_TYPE.超一天真离线]: exports.BK_TASK_GROUP.丢失高风险组,
  [exports.BK_TASK_TYPE.超一天离线扫码车]: exports.BK_TASK_GROUP.丢失高风险组,
  [exports.BK_TASK_TYPE.超一天无定位扫码车]: exports.BK_TASK_GROUP.丢失高风险组,
  [exports.BK_TASK_TYPE.超一天丢失扫码车]: exports.BK_TASK_GROUP.丢失高风险组,
  [exports.BK_TASK_TYPE.超一天疑似离线]: exports.BK_TASK_GROUP.丢失高风险组,
  [exports.BK_TASK_TYPE.一天内真离线]: exports.BK_TASK_GROUP.丢失风险组,
  [exports.BK_TASK_TYPE.一天内离线扫码车]: exports.BK_TASK_GROUP.丢失风险组,
  [exports.BK_TASK_TYPE.一天内无定位扫码车]: exports.BK_TASK_GROUP.丢失风险组,
  [exports.BK_TASK_TYPE.一天内丢失扫码车]: exports.BK_TASK_GROUP.丢失风险组,
  [exports.BK_TASK_TYPE.一天内疑似离线]: exports.BK_TASK_GROUP.丢失风险组,
  [exports.BK_TASK_TYPE.无定位]: exports.BK_TASK_GROUP.无定位组,
  [exports.BK_TASK_TYPE.零电]: exports.BK_TASK_GROUP.断电任务组,
  [exports.BK_TASK_TYPE.被盗断电]: exports.BK_TASK_GROUP.断电任务组,
  [exports.BK_TASK_TYPE.零电断电]: exports.BK_TASK_GROUP.断电任务组,
  [exports.BK_TASK_TYPE.困难换电]: exports.BK_TASK_GROUP.困难换电任务组,
  [exports.BK_TASK_TYPE.损坏不可租]: exports.BK_TASK_GROUP.无法租赁组,
  [exports.BK_TASK_TYPE.低电]: exports.BK_TASK_GROUP.无法租赁组,
  [exports.BK_TASK_TYPE.围栏外非免单]: exports.BK_TASK_GROUP.无法租赁组,
  [exports.BK_TASK_TYPE.高压预警]: exports.BK_TASK_GROUP.高压换电组,
  [exports.BK_TASK_TYPE.低压预警]: exports.BK_TASK_GROUP.低压换电组,
  [exports.BK_TASK_TYPE.特殊任务]: exports.BK_TASK_GROUP.特殊任务组,
  [exports.BK_TASK_TYPE.四天未唤醒]: exports.BK_TASK_GROUP.未巡检组,
  [exports.BK_TASK_TYPE.四天未巡检]: exports.BK_TASK_GROUP.未巡检组,
  [exports.BK_TASK_TYPE.空闲超速]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.损坏可租]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.一天未唤醒]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.两天未唤醒]: exports.BK_TASK_GROUP.未巡检组,
  [exports.BK_TASK_TYPE.禁行区]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.围栏外免单]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.高压离线]: exports.BK_TASK_GROUP.人工分配组,
  [exports.BK_TASK_TYPE.待投放]: exports.BK_TASK_GROUP.无用组,
  [exports.BK_TASK_TYPE.禁停区]: exports.BK_TASK_GROUP.无用组,
  [exports.BK_TASK_TYPE.电池编号核实]: exports.BK_TASK_GROUP.无用组,
};
// 车辆任务组各组任务数量
exports.BK_COUNT_OF_GROUP = Object.keys(exports.BK_GROUP_OF_TASK).reduce((memo, task) => {
  const taskGroup = exports.BK_GROUP_OF_TASK[task];
  if (!memo[taskGroup]) memo[taskGroup] = 0;
  memo[taskGroup] += 1;
  return memo;
}, {});
// 车辆不可租原因
exports.BK_INVALID_REASON = {
  车辆未启用: 0,
  大区未启用: 1,
  车型未启用: 2,
  车辆设备离线: 3,
  车辆断电: 4,
  车辆已丢失: 5,
  车辆被预约: 6,
  车辆正在被租用: 7,
  车辆未投放: 8,
  车辆损坏: 9,
  车辆在围栏外: 10,
  车辆在禁行区: 11,
  车辆低电: 12,
  车辆被扣: 13,
  车辆待拖回: 14,
  车辆疑似丢失: 15,
  车辆无定位: 16,
};
// 车辆不可租原因枚举
exports.BK_INVALID_REASON_ENUMS = transform.jsonToEnums(exports.BK_INVALID_REASON);
// 免单车围栏外距离阈值
exports.BK_FREE_DISTANCE_OUTSIDE_REGION = -500;

// 订单

// 预约状态
exports.OD_RESERVATION_STATE = {
  预约中: 0,
  已取消: 1,
  已完成: 2,
};
// 预约状态枚举
exports.OD_RESERVATION_STATE_ENUMS = transform.jsonToEnums(exports.OD_RESERVATION_STATE);
// 预约取消原因
exports.OD_RESERVATION_CANCEL_REASON = {
  超时: 0,
  使用了其他的车: 1,
  用户取消: 2,
};
// 预约取消原因枚举
exports.OD_RESERVATION_CANCEL_REASON_ENUMS = transform.jsonToEnums(exports.OD_RESERVATION_CANCEL_REASON);
// 订单状态
exports.OD_ORDER_STATE = {
  租用中: 0,
  异常结束: 1,
  已完成: 2,
  超时结束: 3,
  长时无移动结束: 4,
  后台结束订单: 5,
  系统结束订单: 6,
  禁停区结束: 7,
};
// 订单状态枚举
exports.OD_ORDER_STATE_ENUMS = transform.jsonToEnums(exports.OD_ORDER_STATE);
// 订单评分枚举
exports.OD_COMMENT_RANK_ENUMS = [1, 2, 3, 4, 5];
// 保险状态
exports.OD_INSURANCE_STATE = {
  核保提交资料: 1,
  核保中: 3,
  核保失败: 4,
  核保成功: 5,
  承保成功未生效: 6,
  生效: 7,
  申请理赔: 8,
  核赔中: 9,
  拒赔: 10,
  同意理赔: 11,
  待支付理赔金: 12,
  理赔终止: 13,
  过期终止: 14,
  违约终止: 15,
  投保人解除终止: 16,
  其他终止: 17,
  失效: 18,
};
// 保险状态枚举
exports.OD_INSURANCE_STATE_ENUMS = transform.jsonToEnums(exports.OD_INSURANCE_STATE);
// 计价白天到晚上切换时间点
exports.OD_DAY_TO_NIGHT_AT = '20:00';
// 计价晚上到白天切换时间点
exports.OD_NIGHT_TO_DAY_AT = '06:00';
// 白天总时长 minute
exports.OD_DAY_DURATION = (_ => {
  const dayStart = exports.OD_NIGHT_TO_DAY_AT.of('today');
  const dayEnd = exports.OD_DAY_TO_NIGHT_AT.of('today');
  if (dayStart.is.over(dayEnd)) throw new Error('dayEnd should later than dayEnd');
  return (dayEnd.getTime() - dayStart.getTime()).msTo.minute;
})();
// 夜间总时长
exports.OD_NIGHT_DURATION = (24 * 60) - exports.OD_DAY_DURATION;
// 用车最长时长
exports.OD_ORDER_EXPIRE_DURATION = '3 hours';
// 无移动超时时长
exports.OD_ORDER_NO_MOVEMENT_EXPIRE_DURATION = '20 minutes';
// 预约超时时长
exports.OD_RESERVATION_EXPIRE_DURATION = isDev ? '1 minute' : '8 minutes';
// 异常订单缓冲时间 分
exports.OD_BAD_ORDER_BUFFER_TIME = isDev ? 0 : 20;
// 异常订单缓冲距离 米
exports.OD_BAD_ORDER_BUFFER_DISTANCE = isDev ? 0 : 200;
// 免单行程免单原因
exports.OD_FREE_TRIP_REASON = {
  服务区外启动: 0,
  禁行区内启动: 1,
  标记为免单车: 2,
};
// 免单行程免单原因枚举
exports.OD_FREE_TRIP_REASON_ENUMS = transform.jsonToEnums(exports.OD_FREE_TRIP_REASON);

// 数据

// 电池操作记录类型
exports.RC_BATTERY_OP_RECORD_TYPE = {
  开始充电: 0,
  结束充电: 1,
  分配电池到站: 2,
  分发电池到巡检: 3,
  接收电池到站: 4,
  电池更换到车: 5,
  电池更换下车: 6,
  电池报损: 7,
  回收电池: 8,
  更换二维码: 9,
  创建电池: 10,
  更换标记: 11,
  解绑电池: 12,
  电池丢失: 13,
  电池报废: 14,
  电池返修: 15,
  电池维修: 16,
  电池返修入库: 17,
  更换大区: 18,
};
// 电池操作记录类型枚举
exports.RC_BATTERY_OP_RECORD_TYPE_ENUMS = transform.jsonToEnums(exports.RC_BATTERY_OP_RECORD_TYPE);
// 电池所在地类型
exports.RC_BATTERY_LOCATE = {
  运营人员: 0,
  运营站: 1,
  车辆: 2,
};
// 电池所在地类型枚举
exports.RC_BATTERY_LOCATE_ENUMS = transform.jsonToEnums(exports.RC_BATTERY_LOCATE);
// 车辆使用原因
exports.RC_STOCK_USED_REASON = {
  用户订单: 0,
  调度: 1,
};
// 车辆使用原因枚举
exports.RC_STOCK_USED_REASON_ENUMS = transform.jsonToEnums(exports.RC_STOCK_USED_REASON);
// 车辆审计操作类型
exports.RC_STOCK_OP_TYPE = {
  创建车辆: 0, // √

  更新定制车牌号: 1, // √
  更新临时车牌号: 2, // √
  更新交管局车牌号: 3, // √
  更新车架号: 4, // √

  更换大区: 5, // √
  更换车型: 6, // √
  更换盒子: 7, // √

  启用车辆: 8, // √
  禁用车辆: 9, // √

  添加损坏: 10, // √
  修复损坏: 11, // √

  投放车辆: 12, // 仓库 => 空闲 √
  回收车辆: 13, // 空闲 => 仓库 √
  预约车辆: 14, // 空闲 => 预约 √
  取消预约: 15, // 预约 => 空闲 √
  租用车辆: 16, // 空闲/预约 => 租用 √
  归还车辆: 17, // 租用 => 空闲 √
  开始调度: 18, // 空闲/仓库/待拖回 => 调度 √
  结束调度: 19, // 调度 => 空闲/仓库/待拖回 √
  被扣上报: 20, // 空闲/仓库/待拖回 => 扣押 √
  被扣找回: 21, // 扣押 => 空闲/仓库/待拖回 √
  申请拖回: 22, // 空闲 => 待拖回 √
  登记丢失: 23, // 空闲/仓库/待拖回/疑似丢失 => 丢失 √
  丢失找回: 24, // 丢失 => 仓库/空闲/待拖回 √

  找车打卡: 25, // √
  更换电池: 26, // √

  强制刷新位置: 27, // √
  打开电门: 28, // √
  关闭电门: 29, // √
  设防: 30, // √
  撤防: 31, // √

  解除断电: 32, // √

  分配巡检人员: 33, // √
  解除巡检人员: 34, // √
  驶入巡检区: 35, // √
  驶出巡检区: 36, // √

  添加特别任务: 37, // √
  完成特别任务: 38, // √

  登记疑似丢失: 39, // 空闲/仓库/待拖回/丢失 => 疑似丢失 √
  疑似丢失找回: 40, // 疑似丢失 => 空闲/仓库/待拖回 √

  解除复活任务: 41, // √

  取消拖回: 42, // 待拖回 => 空闲 √

  调整定位: 43, // √

  打开电池锁: 44, // √

  其他占用: 45, // 任何去向 => 其他占用
  取消占用: 46, // 其他占用 => 任何去向
  仓库转移: 47, // 仓库 => 另一个仓库
  入库: 48,
  出库: 49,
  电池丢失: 50,
  拖回仓库: 51, // 待拖回 => 在库
  锁定车架号: 52,
  解锁车架号: 53,
  跨区入库: 54,

};
// 车辆审计操作类型枚举
exports.RC_STOCK_OP_TYPE_ENUMS = transform.jsonToEnums(exports.RC_STOCK_OP_TYPE);
// 车辆操作类型映射
exports.RC_STOCK_OP_TYPE_MAP = transform.jsonToMap(exports.RC_STOCK_OP_TYPE);
// 找车打卡未找到的原因
exports.RC_STOCK_OP_FIND_FAILED_REASON = {
  定位点无车: 0,
  所在区域不能进入: 1,
};
// 找车打卡未找到的原因枚举
exports.RC_STOCK_OP_FIND_FAILED_REASON_ENUMS = transform.jsonToEnums(exports.RC_STOCK_OP_FIND_FAILED_REASON);
// 找车打开未找到原因映射
exports.RC_STOCK_OP_FIND_FAILED_REASON_MAP = transform.jsonToMap(exports.RC_STOCK_OP_FIND_FAILED_REASON);
// 车辆警报记录类型
exports.RC_ALARM_TYPE = {
  驶出围栏: 0,
  驶入围栏: 1,
  低电警报: 2,
  解除低电: 3,
  位移警报: 4,
  断电警报: 5,
  震动警报: 6,
  设备下线: 7,
  设备上线: 8,
  电门开: 9,
  移动警报: 10,
  天线异常: 11,
  静音警报: 12,
  模块异常: 13,
  低电预警: 14,
  一天未使用: 15,
  两天未使用: 16,
  近期无定位: 17,
  解除无定位: 18,
  解除一天未使用: 19,
  解除两天未使用: 20,
  驶入禁行区: 21,
  驶出禁行区: 22,
  解除断电: 23,
  解除非法位移: 24,
  低电压警报: 25,
  严重低电压警报: 26,
  电门关: 27,
  仓锁开启: 28,
  仓锁关闭: 29,
  电量恢复: 30,
};
// 车辆警报记录类型枚举
exports.RC_ALARM_TYPE_ENUMS = transform.jsonToEnums(exports.RC_ALARM_TYPE);
// 车辆警报文字
exports.RC_ALARM_TEXT_ENUMS = transform.jsonToArray(exports.RC_ALARM_TYPE).sort((v1, v2) => v1.value - v2.value);
exports.RC_ALARM_TEXT_ENUMS[exports.RC_ALARM_TYPE.低电警报].key = '续航5km警报';
exports.RC_ALARM_TEXT_ENUMS[exports.RC_ALARM_TYPE.低电预警].key = '续航16km警报';
// 分享记录类型
exports.RC_SHARE_TYPE = {
  分享订单: 0,
  分享应用: 1,
};
// 分享记录类型枚举
exports.RC_SHARE_TYPE_ENUMS = transform.jsonToEnums(exports.RC_SHARE_TYPE);
// 验证码类型
exports.RC_VERIFY_CODE_TYPE = {
  短信: 0,
  语音: 1,
};
// 验证码类型枚举
exports.RC_VERIFY_CODE_TYPE_ENUMS = transform.jsonToEnums(exports.RC_VERIFY_CODE_TYPE);
// 分享渠道
exports.RC_SHARE_CHANNEL = {
  微信: 0,
  朋友圈: 1,
  QQ: 2,
  QZone: 3,
};
// 分享渠道枚举
exports.RC_SHARE_CHANNEL_ENUMS = transform.jsonToEnums(exports.RC_SHARE_CHANNEL);
// 通知类型
exports.RC_NOTIFICATION_TYPE = {
  其他警报: 0,
  开发通知: 1,
  支付通知: 2,
  订单通知: 3,
  巡检预警: 4,
  低电警报: 5,
  离线警报: 6,
  断电警报: 7,
  位移警报: 8,
  围栏警报: 9,
  系统错误: 10,
  请求错误: 11,
  报表导出: 12,
};
// 通知类型枚举
exports.RC_NOTIFICATION_TYPE_ENUMS = transform.jsonToEnums(exports.RC_NOTIFICATION_TYPE);
// 通知渠道
exports.RC_NOTIFICATION_CHANNEL = {
  钉钉机器人: 0,
  短信: 1,
  应用推送: 2,
  邮件: 3,
};
// 通知渠道枚举
exports.RC_NOTIFICATION_CHANNEL_ENUMS = transform.jsonToEnums(exports.RC_NOTIFICATION_CHANNEL);
// 订单通知
exports.RC_NOTIFICATION_ORDER_ACTION = {
  创建订单: 0,
  结束订单: 1,
};
// 签到类型
exports.RC_CHECK_IN_TYPE = {
  签到: 0,
  签退: 1,
};
// 签到类型枚举
exports.RC_CHECK_IN_TYPE_ENUMS = transform.jsonToEnums(exports.RC_CHECK_IN_TYPE);

// 开放云

// 应用签名方法
exports.CL_APP_AUTH_METHOD = {
  MD5: 0,
  HMACSHA256: 1,
};
// 应用签名方法枚举
exports.CL_APP_AUTH_METHOD_ENUMS = transform.jsonToEnums(exports.CL_APP_AUTH_METHOD);
// 支持的服务
exports.CL_APP_SERVICE = {
  数据转发: 0,
  开放订单: 1,
};

//导出报表类型
exports.STATEMENT_TYPE = {
  '用户活跃度': 1,
  '付费用户活跃度': 2,
  '新用户增长': 3,
  '系统规则': 4,
  '可用车辆': 5,
  '充值': 6,
  '租金': 7,
  '押金关联': 8,
  '信用申诉': 9,
  '用户反馈': 10,
  '用户举报': 11,
  '车辆报损': 12,
  // '扫码结束订单错误': 13
};
exports.STATEMENT_TYPE_ENUMS = transform.jsonToEnums(exports.STATEMENT_TYPE);

// 统计
// 小时流水统计金额类型
exports.SS_FLOW_IN_HOUR_TYPE = {
  支付押金: 0,
  退款押金: 1,
  充值: 2,
  退款余额: 3,
};

// PolygonOP 记录类型
exports.SS_POLYGON_OP_TYPE = {
  清零区块: 0,
};

// 远程调用
// 远程调用类型
exports.REMOTE_CALL_TYPE = {
  任务调用: 0,
  盒子上报: 1,
};
// 远程调用类型枚举
exports.REMOTE_CALL_TYPE_ENUMS = transform.jsonToEnums(exports.REMOTE_CALL_TYPE);

// 盒子语音
exports.BK_BOX_SOUND = {
  开机音: 0,
  设防提示: 1,
  撤防提示: 2,
  启动提示: 3,
  熄火提示: 4,
  欢迎语: 5,
  警报音: 6,
  靠近服务边界提示: 7,
  驶出服务区提示: 8,
  靠近禁行区提示: 9,
  驶入禁行区提示: 10,
  禁停区提示: 11,
};

// 物资类型
exports.BK_MOUNTING_TYPE = {
  螺母: 0,
};
//物资类型枚举
exports.BK_MOUNTING_TYPE_ENUMS = transform.jsonToEnums(exports.BK_MOUNTING_TYPE);

// 离线类型
exports.SS_OFFLINE_TIME = {
  下线: 0,
  上线: 1,
};
// 离线类型枚举
exports.SS_OFFLINE_TIME_ENUMS = transform.jsonToEnums(exports.SS_OFFLINE_TIME);
// 大区管理统计枚举
exports.SS_POLYGON_OP_TYPE_ENUMS = transform.jsonToEnums(exports.SS_POLYGON_OP_TYPE);
// 租还车错误类型
exports.SS_ERROR_TYPE = {
  扫码: 0,
  创建订单: 1,
  结束订单: 2,
};

// 租还车错误类型枚举
exports.SS_ERROR_TYPE_ENUMS = transform.jsonToEnums(exports.SS_ERROR_TYPE);

// IoT询问指令错误码
exports.IOT_QUESTION_ERROR_CODE = {
  成功: 0,
  请求超时: 1,
  不支持的指令: 2,
};

// 电池仓库类型
exports.OP_BATTERY_STATION_TYPE = {
  电池站: 0,
  中转仓: 1,
};
// 电池仓库类型枚举
exports.OP_BATTERY_STATION_TYPE_ENUMS = transform.jsonToEnums(exports.OP_BATTERY_STATION_TYPE);

// 司机审核状态
exports.AC_DRIVER_STATUS = {
  审核中: 0,
  已审核: 1,
  已驳回: 2,
};
// 电池审核么枚举
exports.AC_DRIVER_STATUS_ENUMS = transform.jsonToEnums(exports.AC_DRIVER_STATUS);

// 车辆类型
exports.AC_STOCK_TYPE = {
  金杯: 0,
  面包车: 1,
  箱货: 2,
  平板车: 3,
};

// 车辆类型枚举
exports.AC_STOCK_TYPE_ENUMS = transform.jsonToEnums(exports.AC_STOCK_TYPE);

// 司机来源类型
exports.AC_DRIVER_TYPE = {
  '58司机': 0,
  自有兼职: 1,
};

//司机来源类型枚举
exports.AC_DRIVER_TYPE_ENUMS = transform.jsonToEnums(exports.AC_DRIVER_TYPE);

// 司机类型
exports.AC_OPERATOR_TYPE = {
  司机: 0,
  白班: 1,
  公关: 2,
  候命: 3,
  高手: 4,
};

//司机类型枚举
exports.AC_OPERATOR_TYPE_ENUMS = transform.jsonToEnums(exports.AC_OPERATOR_TYPE);

// 事务状态
exports.TRANSACTION_STATE = {
  INITIAL: 'initial',
  PENDING: 'pending',
  COMMITTED: 'committed',
  ROLLBACK: 'rollback',
  CANCELLED: 'cancelled',
  ACTIVATED: 'activated',
  FINISHED: 'finished',
};
// 事务状态枚举
exports.TRANSACTION_STATE_ENUMS = transform.jsonToEnums(exports.TRANSACTION_STATE);

// 巡检订单状态
exports.OP_INSPECTION_ORDER_STATE = {
  暂停派单: 0,
  派单中: 1,
  已取消: 2,
  已截单: 3,
  待确认: 4,
  已轧账: 5,
  已结算: 6,
};
// 骑行订单状态
exports.OP_RIDER_ORDER_STATE = {
  派单中: 0,
  待审核: 1,
  已审核: 2,
};
// 骑行订单状态枚举
exports.OP_RIDER_ORDER_STATE_ENUMS = transform.jsonToEnums(exports.OP_RIDER_ORDER_STATE);

// 维修工作订单状态
exports.OP_REPAIR_WORK_ORDER_STATE = {
  未计算: 0,
  已计算: 1,
};
// 维修工作订单状态枚举
exports.OP_REPAIR_WORK_ORDER_STATE_ENUMS = transform.jsonToEnums(exports.OP_REPAIR_WORK_ORDER_STATE);

// 配件调度订单状态
exports.OD_ASSET_ORDER_STATE = {
  正在进行: 0,
  已经完成: 1,
};

// 配件盘点状态
exports.OD_ASSET_CHECK_STATE = {
  盘点中: 0,
  修正中: 1,
  修正处理中: 2,
  已经完成: 3,
};
// 配件盘点单状态枚举
exports.OD_ASSET_CHECK_STATE_ENUMS = transform.jsonToEnums(exports.OD_ASSET_CHECK_STATE);
// 巡检订单状态枚举
exports.OP_INSPECTION_ORDER_STATE_ENUMS = transform.jsonToEnums(exports.OP_INSPECTION_ORDER_STATE);

// 配件返修状态
exports.OD_ASSET_REPAIR_STATE = {
  创建中: 0,
  正在维修: 1,
  归还中: 2,
  部分归还: 3,
  已经结束: 4,
};
// 配件返修状态枚举
exports.OD_ASSET_REPAIR_STATE_ENUMS = transform.jsonToEnums(exports.OD_ASSET_REPAIR_STATE);

// 配件领用单状态
exports.OD_ASSET_RECEIVE_STATE = {
  领用中: 0,
  正在维修: 1,
  归还中: 2,
  已经完成: 3,
};
// 配件领用单状态枚举
exports.OD_ASSET_RECEIVE_STATE_ENUMS = transform.jsonToEnums(exports.OD_ASSET_RECEIVE_STATE);

// 配件报废单状态
exports.OD_ASSET_SCRAP_STATE = {
  正在进行: 0,
  已经完成: 1,
};
// 配件入库单状态
exports.OD_ASSET_INBOUND_STATE = {
  正在进行: 0,
  已经完成: 1,
};
// 任务车处理方式
exports.BK_STOCK_HANDLE_TYPE = {
  换电: 0,
  拖回: 1,
};
// 配件调配单状态
exports.OD_ASSET_DISPATCH_STATE = {
  创建中: 0,
  调配中: 1,
  入库中: 2,
  已经完成: 3,
};

// 配件采购单状态
exports.OD_ASSET_PURCHASE_STATE = {
  采购中: 0,
  审核中: 1,
  已经完成: 2,
  已驳回: 3,
};

// 车辆拖回单状态
exports.OD_STOCK_PULL_BACK = {
  正在进行: 0,
  已经完成: 1,
};

// 车辆投放单状态
exports.OD_STOCK_PUT_ON = {
  正在进行: 0,
  已经完成: 1,
};

// 跨区入库类型
exports.OD_IN_FACTORY = {
  正在进行: 0,
  已经完成: 1,
};

exports.OD_IN_FACTORY_ENUMS = transform.jsonToEnums(exports.OD_IN_FACTORY);

// 跨区入库车辆状态
exports.OD_IN_FACTORY_STOCK_STATUS = {
  失败: 0,
  成功: 1,
};

exports.OD_IN_FACTORY_STOCK_STATUS_ENUMS = transform.jsonToEnums(exports.OD_IN_FACTORY_STOCK_STATUS);

exports.OD_STOCK_DAMAGE = {
  正在进行: 0,
  已经完成: 1
};

exports.OD_STOCK_DAMAGE_ENUMS = transform.jsonToEnums(exports.OD_STOCK_DAMAGE);

exports.OD_STOCK_REPAIR = {
  正在进行: 0,
  已经完成: 1
};

exports.OD_STOCK_REPAIR_ENUMS = transform.jsonToEnums(exports.OD_STOCK_REPAIR);

// 运营人员类型
exports.AC_OPERATOR_INSPECTION_TYPE = {
  维修: 0,
  库管: 1,
  线上运营: 2,
  城市经理: 3,
  高层管理员: 4,
  骑行: 5,
  司机: 6,
};
// 运营人员枚举
exports.AC_OPERATOR_INSPECTION_TYPE_ENUMS = transform.jsonToEnums(exports.AC_OPERATOR_INSPECTION_TYPE);
// 不同任务车处理方式
exports.BK_STOCK_HANDLE_TASK = {
  [module.exports.BK_TASK_TYPE.低电]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.围栏外非免单]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.低压预警]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.四天未巡检]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.困难换电]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.高压预警]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 1,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0,
  },
  [module.exports.BK_TASK_TYPE.待拖回]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 1,
  },
  [module.exports.BK_TASK_TYPE.一天内真离线]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.一天内离线扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.一天内疑似离线]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.一天内丢失扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.一天内无定位扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.被盗断电]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 1,
  },
  [module.exports.BK_TASK_TYPE.零电]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.零电断电]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.无定位]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.司机未找到]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.超一天真离线]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.超一天离线扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.超一天无定位扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.超一天疑似离线]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.超一天丢失扫码车]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.白班未找到]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
  [module.exports.BK_TASK_TYPE.高手未找到]: {
    [module.exports.BK_STOCK_HANDLE_TYPE.换电]: 0.5,
    [module.exports.BK_STOCK_HANDLE_TYPE.拖回]: 0.5,
  },
};

exports.RC_POLYGON_OP_TYPE = {
  '清零区块': 0,
  '删除区块': 1,
};

exports.RC_POLYGON_OP_TYPE_ENUMS = transform.jsonToEnums(module.exports.RC_POLYGON_OP_TYPE);
exports.RC_POLYGON_OP_TYPE_MAP = jsonToMap(module.exports.RC_POLYGON_OP_TYPE);

// 历史成功订单等级边界
exports.HISTORY_SUCCEED_ORDER_COUNT_LEVEL_BOUND = {
  level0: {
    name: '0',
    num: 0,
  },
  level1: {
    name: '1',
    num: 1,
  },
  level2: {
    name: '2',
    num: 2,
  },
  level3: {
    name: '3-5',
    infimum: 3,
    supremum: 5,
  },
  level4: {
    name: '6-10',
    infimum: 6,
    supremum: 10,
  },
  level5: {
    name: '11-20',
    infimum: 11,
    supremum: 20,
  },
  level6: {
    name: '21-50',
    infimum: 21,
    supremum: 50,
  },
  level7: {
    name: '50-infimum',
    num: 50,
  },
};
//
// 历史成功订单等级边界
exports.REGISTER_REFUND_DAYS_LEVEL_BOUND = {
  level0: {
    name: '0-2',
    infimum: 0,
    supremum: 2,
  },
  level1: {
    name: '3-5',
    infimum: 3,
    supremum: 5,
  },
  level2: {
    name: '6-8',
    infimum: 6,
    supremum: 8,
  },
  level3: {
    name: '9-15',
    infimum: 9,
    supremum: 15,
  },
  level4: {
    name: '16-30',
    infimum: 16,
    supremum: 30,
  },
  level5: {
    name: '31-60',
    infimum: 31,
    supremum: 60,
  },
  level6: {
    name: '61-120',
    infimum: 61,
    supremum: 120,
  },
  level7: {
    name: '121-180',
    infimum: 121,
    supremum: 180,
  },
  level8: {
    name: '181-infimum',
    num: 181,
  },
};
// 退押金申请间隔天数
exports.REFUND_INTERVAL_DAYS_BOUND = {
  nan: {
    name: 'nan',
  },
  level0: {
    name: '0-4',
    infimum: 0,
    supremum: 4,
  },
  level1: {
    name: '5-7',
    infimum: 5,
    supremum: 7,
  },
  level2: {
    name: '8-15',
    infimum: 8,
    supremum: 15,
  },
  level3: {
    name: '16-30',
    infimum: 16,
    supremum: 30,
  },
  level4: {
    name: '31-60',
    infimum: 31,
    supremum: 60,
  },
  level5: {
    name: '61-120',
    infimum: 61,
    supremum: 120,
  },
  level6: {
    name: '121-180',
    infimum: 121,
    supremum: 180,
  },
  level7: {
    name: '180-infinum',
    num: 180,
  },
};
// 历史退押金次数
exports.REFUND_COUNT_BOUND = {
  level0: {
    name: '0',
    num: 0,
  },
  level1: {
    name: '1',
    num: 1,
  },
  level2: {
    name: '2',
    num: 2,
  },
  level3: {
    name: '3-5',
    infimum: 3,
    supremum: 5,
  },
  level4: {
    name: '6-10',
    infimum: 6,
    supremum: 10,
  },
  level5: {
    name: '11-20',
    infimum: 11,
    supremum: 20,
  },
  level6: {
    name: '20-50',
    infimum: 20,
    supremum: 50,
  },
  level7: {
    name: '50-infinum',
    num: 50,
  },
};

// 电池维修领用单状态
exports.OD_BATTERY_RECEIVE_STATUS = {
  领用处理中: 0,
  维修占用: 1,
  归还处理中: 2,
  已完成: 3,
};

exports.OD_BATTERY_RECEIVE_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_RECEIVE_STATUS);

// 电池报废单状态
exports.OD_BATTERY_SCRAP_STATUS = {
  报废中: 0,
  已完成: 1,
};

exports.OD_BATTERY_SCRAP_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_SCRAP_STATUS);

// 电池入库单状态
exports.OD_BATTERY_INBOUND_STATUS = {
  入库中: 0,
  已完成: 1,
};

exports.OD_BATTERY_INBOUND_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_INBOUND_STATUS);

// 电池调度单状态
exports.OD_BATTERY_DISPATCH_STATUS = {
  出库中: 0,
  运输中: 1,
  入库中: 2,
  已完成: 3,
};

exports.OD_BATTERY_DISPATCH_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_DISPATCH_STATUS);

// 电池维修单出库状态
exports.OD_BATTERY_START_REPAIR_STATUS = {
  出库中: 0,
  已完成: 1,
};

exports.OD_BATTERY_START_REPAIR_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_START_REPAIR_STATUS);

// 电池维修单出库状态
exports.OD_BATTERY_END_REPAIR_STATUS = {
  返修入库中: 0,
  已完成: 1,
};

exports.OD_BATTERY_END_REPAIR_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_END_REPAIR_STATUS);

// 电池返修单状态
exports.OD_BATTERY_REPAIR_STATUS = {
  返修中: 0,
  已完成: 1,
};

exports.OD_BATTERY_REPAIR_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_REPAIR_STATUS);

// 电池维修单状态
exports.OD_BATTERY_MAINTAIN_STATUS = {
  维修中: 0,
  已完成: 1,
};

exports.OD_BATTERY_MAINTAIN_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_MAINTAIN_STATUS);

// 电池上架单状态
exports.OD_BATTERY_START_CHARGE_STATUS = {
  上架中: 0,
  已完成: 1,
};

exports.OD_BATTERY_START_CHARGE_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_START_CHARGE_STATUS);

// 电池下架单状态
exports.OD_BATTERY_END_CHARGE_STATUS = {
  下架中: 0,
  已完成: 1,
};

exports.OD_BATTERY_END_CHARGE_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_END_CHARGE_STATUS);

// 电池报损单状态
exports.OD_BATTERY_DAMAGE_STATUS = {
  报损中: 0,
  已完成: 1,
};

exports.OD_BATTERY_DAMAGE_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_DAMAGE_STATUS);

// 电池巡检领用单状态
exports.OD_BATTERY_INSPECT_STATUS = {
  领用处理中: 0,
  电池携带: 1,
  归还处理中: 2,
  已完成: 3,
};

exports.OD_BATTERY_INSPECT_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_INSPECT_STATUS);

// 电池盘点单状态
exports.OD_BATTERY_CHECK_STATUS = {
  审核中: 0,
  审核成功: 1,
  审核失败: 2,
};

exports.OD_BATTERY_CHECK_STATUS_ENUMS = transform.jsonToEnums(exports.OD_BATTERY_CHECK_STATUS);

exports.RC_POINTS_APPROACH = {
  签到: 0,
};

exports.RC_POINTS_APPROACH_VALUE = {
  [exports.RC_POINTS_APPROACH.签到]: 10,
};

exports.RC_POINTS_APPROACH_ENUMS = transform.jsonToEnums(exports.RC_POINTS_APPROACH);

exports.STO_COMMODITY_TYPE = {
  优惠券: 0,
};

exports.STO_COMMODITY_TYPE_ENUMS = transform.jsonToEnums(exports.STO_COMMODITY_TYPE);

// 发票申请状态
exports.FN_INVOICE_STATE = {
  申请中: 0,
  已驳回: 1,
  已完成: 2,
};

exports.FN_INVOICE_STATE_ENUMS = transform.jsonToEnums(exports.FN_INVOICE_STATE);

// 发票最低金额
exports.FN_INVOICE_AMOUNT_STANDARD = 10000;

// 配件组别
exports.ST_ASSET_GROUP = {
  配件: 0,
  工具: 1,
};

exports.ST_ASSET_GROUP_MAP = transform.jsonToMap(exports.ST_ASSET_GROUP);

exports.ST_ASSET_GROUP_ENUMS = transform.jsonToEnums(exports.ST_ASSET_GROUP);

exports.RC_ERROR_TYPE = {
  预约: 0,
  扫码: 1,
  下单: 2,
};

exports.RC_ERROR_TYPE_ENUMS = transform.jsonToEnums(exports.RC_ERROR_TYPE);

exports.RC_ERROR_DESCRIPTION = {
  车辆未启用: 0,
  大区未启用: 1,
  车型未启用: 2,
  车辆设备离线: 3,
  车辆断电: 4,
  车辆已丢失: 5,
  车辆已被预约: 6,
  车辆正在被租用: 7,
  车辆未投放: 8,
  车辆损坏: 9,
  车辆在围栏外: 10,
  车辆在禁行区: 11,
  车辆低电: 12,
  车辆被扣: 13,
  车辆待拖回: 14,
  车辆疑似丢失: 15,
  车辆无定位: 16,

};

exports.RC_ERROR_DESCRIPTION_ENUMS = transform.jsonToEnums(exports.RC_ERROR_DESCRIPTION);

// 账户操作类型
exports.RC_USER_OP = {
  注销账号: 0,
};
// 账户操作类型枚举
exports.RC_USER_OP_ENUMS = transform.jsonToEnums(exports.RC_USER_OP);

// 断电类型
exports.RC_POWER_UNLINK_TYPE = {
  围栏外断电: 0,
  禁行区断电: 1,
  正常骑行断电: 2,
  低电断电: 3,
};

exports.RC_POWER_UNLINK_TYPE_ENUMS = transform.jsonToEnums(exports.RC_POWER_UNLINK_TYPE);

exports.OP_GEOJSON_CHECK_STATUS = {
  未审核: 0,
  合格: 1,
  不合格: 2,
};

// 大区配置 停车区外的规则
exports.OP_REGION_PATTERN = {
  不可停: 0,
  可停收费: 1,
  可停不收费: 2,
};

exports.OP_REGION_PATTERN_ENUMS = transform.jsonToEnums(exports.OP_REGION_PATTERN);

// 大区停车区展示类型
exports.OP_REGION_PARKING_PATTERN = {
  旧停车区: 0,
  新停车区: 1,
  新旧停车区: 2,
};
exports.OP_REGION_PARKING_PATTERN_ENUMS = transform.jsonToEnums(exports.OP_REGION_PARKING_PATTERN);

// 禁行区等信息刷新时间间隔 (测试1分钟) 12小时
exports.OP_REGION_INFO_REFRESH = isDev ? 60 * 1000 : 12 * 3600 * 1000;

// 停车区审核状态
exports.OP_PARKING_LOT_REVIEW_STATE = {
  待审: 0,
  合格: 1,
  不合格: 2,
};

exports.OP_PARKING_LOT_REVIEW_STATE_ENUMS = transform.jsonToEnums(exports.OP_PARKING_LOT_REVIEW_STATE);

exports.BK_REPAIR_STATUS = {
  不需要维修: 0,
  需要维修: 1,
};

exports.BK_REPAIR_STATUS_ENUMS = transform.jsonToEnums(exports.BK_REPAIR_STATUS);
