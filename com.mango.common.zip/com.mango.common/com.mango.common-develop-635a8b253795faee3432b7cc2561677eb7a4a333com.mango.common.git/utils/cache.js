const Redis = require('ioredis');
const isPro = process.env.NODE_ENV === 'production';
const isLocal = process.env.LOCAL_REDIS === '1';

const config = (_ => {
  switch (process.env.NODE_ENV) {
    case 'production':
      return {
        host: 'r-wz9c87121c529ed4798.redis.rds.aliyuncs.com',
        port: 6379,
        password: 'Xxcy987412365',
      };
    case 'staging':
      return {
        host: 'localhost',
        port: 6379,
        password: 'mango987412365',
      };
    default:
      return {
        host: 'hi.mangoebike.cc',
        port: 6379,
        password: 'mango987412365',
      };
  }
})();

const redis = new Redis(config);

class Cache {
  constructor (prefix = 'mg.heap') {
    this._prefix = prefix;
  }

  set (key, value, ...extra) {
    redis.set(`${this._prefix}?${key}`, value, ...extra);
  }

  setJSON (key, value, ...extra) {
    this.set(key, JSON.stringify(value), ...extra);
  }

  async get (key) {
    return await redis.get(`${this._prefix}?${key}`);
  }

  async getByPattern (regex) {
    const keys = await redis.keys(`${this._prefix}?${regex}`);
    const data = await redis.mget(keys);
    return keys.map((key, index) => {
      return {
        key,
        value: data[index],
      };
    });
  }

  async getJSON (key) {
    try {
      const data = await this.get(key);
      return JSON.parse(data);
    } catch (err) {
      return null;
    }
  }

  async getJSONByPattern (regex) {
    try {
      const data = await this.getByPattern(regex);
      return data.map(item => {
        item.value = JSON.parse(item.value);
        return item;
      });
    } catch (err) {
      return [];
    }
  }

  async wrap (key, fn, { json = true, extra = [] } = {}) {
    let data = await this[json ? 'getJSON' : 'get'](key);
    if (!data) {
      data = await fn();
      if (data) {
        this[json ? 'setJSON' : 'set'](key, data, ...extra);
      }
    }
    return data;
  }

  async delete (key) {
    return await redis.del(`${this._prefix}?${key}`);
  }

}

module.exports = Cache;
