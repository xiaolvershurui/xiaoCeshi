const Joi = require('poolishark').Joi;
const Hookoo = require('hookoo');
const dirTraveler = require('dir-traveler');

const hookoo = new Hookoo((_ => {
  if(process.env.NODE_ENV === 'development') {
    if(!process.env.LOCAL_HOOKOO) return 'nats://hi.mangoebike.cc:4222'
  } else {
    return 'nats://39.108.207.64:4222'
  }
})());

module.exports = hookoo;

module.exports.initHooks = (hookPath, shark) => {
  const memo = dirTraveler(hookPath);
  Object.keys(memo).forEach(key => {
    const { validate = {}, handler = _ => null } = require(memo[key]) || (_ => null);
    handler(hookoo, shark, key.slice(0, key.lastIndexOf('.')), fn => {
      return async params => {
        const { value, error } = Joi.validate(params, validate);
        if(error) throw error;
        return await fn(value);
      };
    });
  });
};