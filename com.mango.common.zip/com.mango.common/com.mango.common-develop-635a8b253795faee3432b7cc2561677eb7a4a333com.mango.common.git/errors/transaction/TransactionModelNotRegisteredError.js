class TransactionModelNotRegisteredError extends require('../CustomError') {};
module.exports = TransactionModelNotRegisteredError;