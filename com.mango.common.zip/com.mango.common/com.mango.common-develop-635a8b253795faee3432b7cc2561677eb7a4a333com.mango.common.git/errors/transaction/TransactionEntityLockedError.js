class TransactionEntityLockedError extends require('../CustomError') {};
module.exports = TransactionEntityLockedError;