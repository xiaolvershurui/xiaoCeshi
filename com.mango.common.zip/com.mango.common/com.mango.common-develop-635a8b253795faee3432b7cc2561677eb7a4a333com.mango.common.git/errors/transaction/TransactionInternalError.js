class TransactionInternalError extends require('../CustomError') {};
module.exports = TransactionInternalError;