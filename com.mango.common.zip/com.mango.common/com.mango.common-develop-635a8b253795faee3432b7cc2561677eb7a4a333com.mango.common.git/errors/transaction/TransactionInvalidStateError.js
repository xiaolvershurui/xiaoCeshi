class TransactionInvalidStateError extends require('../CustomError') {};
module.exports = TransactionInvalidStateError;