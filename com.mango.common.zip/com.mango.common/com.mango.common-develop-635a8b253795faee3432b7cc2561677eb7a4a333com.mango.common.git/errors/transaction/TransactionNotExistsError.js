class TransactionNotExistsError extends require('../CustomError') {};
module.exports = TransactionNotExistsError;