class TransactionDupKeyError extends require('../CustomError') {};
module.exports = TransactionDupKeyError;