class TransactionInvalidParamsError extends require('../CustomError') {};
module.exports = TransactionInvalidParamsError;