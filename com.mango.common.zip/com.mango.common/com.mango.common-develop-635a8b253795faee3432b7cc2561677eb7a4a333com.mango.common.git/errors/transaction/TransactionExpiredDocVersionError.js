class TransactionExpiredDocVersionError extends require('../CustomError') {}
module.exports = TransactionExpiredDocVersionError;