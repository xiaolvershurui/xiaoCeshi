class ValidationError extends require('./CustomError') {}
module.exports = ValidationError;