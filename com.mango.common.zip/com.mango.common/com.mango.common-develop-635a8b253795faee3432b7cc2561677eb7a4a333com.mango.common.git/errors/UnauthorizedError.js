class UnauthorizedError extends require('./CustomError') {}
module.exports = UnauthorizedError;