class ForbiddenError extends require('./CustomError') {}
module.exports = ForbiddenError;