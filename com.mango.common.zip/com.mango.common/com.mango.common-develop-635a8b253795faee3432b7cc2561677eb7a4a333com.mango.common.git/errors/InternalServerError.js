class InternalServerError extends require('./CustomError') {}
module.exports = InternalServerError;