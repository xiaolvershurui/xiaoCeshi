class BadRequestError extends require('./CustomError') {}
module.exports = BadRequestError;