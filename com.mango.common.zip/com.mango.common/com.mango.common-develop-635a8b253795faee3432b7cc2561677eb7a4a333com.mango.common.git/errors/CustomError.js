class CustomError extends Error {
  constructor (message) {
    super(message);
    Error.captureStackTrace(this.constructor, this);
    this.name = this.constructor.name;
  }

  inspect () {
    return this.stack;
  }
}

module.exports = CustomError;