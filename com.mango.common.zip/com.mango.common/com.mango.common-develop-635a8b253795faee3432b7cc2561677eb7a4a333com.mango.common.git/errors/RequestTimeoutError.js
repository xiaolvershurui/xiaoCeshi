class RequestTimeoutError extends require('./CustomError') {}
module.exports = RequestTimeoutError;