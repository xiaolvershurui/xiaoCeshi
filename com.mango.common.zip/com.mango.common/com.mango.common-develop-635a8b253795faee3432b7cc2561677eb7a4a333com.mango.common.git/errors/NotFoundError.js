class NotFoundError extends require('./CustomError') {}
module.exports = NotFoundError;