const Cache = require('@mangoebike/cache');

const isPro = process.env.NODE_ENV === 'production';
const isLocal = process.env.LOCAL_REDIS === '1';

const uri = (_ => {
  switch (process.env.NODE_ENV) {
    case 'production':
      return 'redis://:Xxcy987412365@r-wz9c87121c529ed4.redis.rds.aliyuncs.com:6379';
    case 'staging':
      return 'redis://:mango987412365@hi.mangoebike.cc:6379';
    default:
      return 'redis://localhost:6379';
  }
})();

const getCache = module.exports = (prefix = 'mg.heap', db = 0) => {
  return new Cache(`${uri}/${db}`, prefix);
};
