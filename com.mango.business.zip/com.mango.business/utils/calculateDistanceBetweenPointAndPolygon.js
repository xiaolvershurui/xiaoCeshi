const geolib = require('geolib');

class LngLat {
  constructor ([lng, lat]) {
    return { longitude: lng, latitude: lat };
  }
}

// 海伦公式求三角形面积
const heron = (a, b, c) => {
  const p = (a + b + c) / 2;
  return Math.sqrt(p * (p - a) * (p - b) * (p - c));
};

// 求两地理位置间距离
const getDistance = (lngLat1, lngLat2) => {
  return geolib.getDistance(lngLat1, lngLat2, 0, 3);
};

module.exports = (path, point) => {
  if (!path || !point) throw new Error('Path and point are required!');
  // 去尾
  path.pop();

  let mpp = Infinity;
  let mppi = -1;

  const pointLngLat = new LngLat(point);

  // 求出车辆最小距离点和点位
  path.forEach((p, i) => {
    const d = getDistance(new LngLat(p), pointLngLat);
    if (d < mpp) {
      mpp = d;
      mppi = i;
    }
  });
  // 获取车辆最小距离点位左右相邻点
  const centerP = new LngLat(path[mppi]);
  const leftP = new LngLat(path[mppi === 0 ? path.length - 1 : mppi - 1]);
  const rightP = new LngLat(path[mppi === path.length - 1 ? 0 : mppi + 1]);
  // 计算左右相邻点分别和中间点和车辆点距离
  const leftCenterD = getDistance(centerP, leftP);
  const rightCenterD = getDistance(centerP, rightP);
  const leftPD = getDistance(leftP, pointLngLat);
  const rightPD = getDistance(rightP, pointLngLat);

  // 判断左右相邻点和中间点和车辆点组成的三角形在中间点位置是否是钝角
  const mppPow = mpp * mpp;
  const leftIsObtuse = mppPow + (leftCenterD * leftCenterD) < (leftPD * leftPD);
  const rightIsObtuse = mppPow + (rightCenterD * rightCenterD) < (rightPD * rightPD);

  let leftMD = Infinity;
  let rightMD = Infinity;
  // 如果是钝角，则最近距离应该就是距最近点的距离，否则是车辆到对边的垂线长度，分别求出两边三角形得到的最近距离
  if (leftIsObtuse) {
    leftMD = mpp;
  } else {
    leftMD = heron(leftCenterD, leftPD, mpp) * 2 / leftCenterD;
  }
  if (rightIsObtuse) {
    rightMD = mpp;
  } else {
    rightMD = heron(rightCenterD, rightPD, mpp) * 2 / rightCenterD;
  }
  // 最终得到车辆距离围栏距离为左右两三角形最近距离中的最小值
  const md = Math.min(leftMD, rightMD);

  return parseFloat(md.toFixed(2));
};
