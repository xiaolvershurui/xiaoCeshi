const Transaction = require('../services/database/transaction');

module.exports = ({ validate, handler }, action) => {
  return {
    validate,
    handler: async function (params) {
      const tid = await Transaction.initialize({ action });
      try {
        return await handler.bind(this)(params, tid, Transaction);
      } catch (error) {
        Transaction.cancel({
          tid,
          error: {
            name: error.name,
            message: error.message,
            stack: error.stack
          }
        });
        throw error;
      }
    }
  };
};