const path = require('path');
const logger = require('./com.mango.common/utils/logger');
const { Server } = require('poolish');
const Poolishark = require('poolishark');
const ports = require('./com.mango.common/settings/ports');

process.on('unhandledRejection', console.error);
process.on('uncaughtException', console.error);

const shark = new Poolishark(new Server(ports.SERVICE_BUSINESS), path.resolve(__dirname, 'controllers'));
// shark.on('reg', name => logger.info(`Controller [${name}] has registered!`));
shark.on('exec_succeed', (name, params, cost) => {
  if (process.env.NODE_ENV !== 'production') {
    logger.info(`Executed [${name}] success! Time cost: ${cost}ms`);
  }
});
shark.on('exec_failed', (name, params, error) => {
  if (process.env.NODE_ENV === 'production') {
    logger.error(`Executed [${name}] failed. Error: ${error.message} ${error.stack && error.stack.split('\n')[1]}`);
  } else {
    console.error(error);
  }
});
shark.on('listening', port => logger.info('Business service listening on %s', port));
shark.on('error', (error, tag) => {
  if (error.client && !error.client.remoteAddress) return;
  if (tag !== 'CONTROLLER') logger.error(tag, error.message);
});
