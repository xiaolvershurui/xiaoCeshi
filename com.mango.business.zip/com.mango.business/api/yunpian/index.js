const axios = require('axios');
const ins = axios.create();
const qs = require('querystring');
const settings = require('./settings');
const constants = require('../../com.mango.common/settings/constants');
const logger = require('../../com.mango.common/utils/logger');

ins.interceptors.request.use(request => {
  if (['post', 'put'].includes(request.method.toLowerCase())) {
    request.data = request.data || {};
    request.data.apikey = settings.apikey;
    request.data = qs.stringify(request.data);
  } else {
    request.params = request.params || {};
    request.params.apikey = settings.apikey;
  }
  return request;
});
ins.interceptors.response.use(response => response.data, error => {
  if (error.response) {
    return Promise.reject(new Error(`${error.response.data.msg}:${error.response.data.detail}`));
  } else {
    return Promise.reject(error);
  }
});

module.exports.batchSend = async (tels, text) => {
  return await ins({
    method: 'post',
    url: 'https://sms.yunpian.com/v2/sms/batch_send.json',
    data: {
      mobile: tels.join(','),
      text
    }
  });
};

const sendText = module.exports.sendText = async (tel, text) => {
  return await ins({
    method: 'post',
    url: 'https://sms.yunpian.com/v2/sms/single_send.json',
    data: {
      mobile: tel,
      text
    }
  });
};

const sendVoice = module.exports.sendVoice = async (tel, code) => {
  return await ins({
    method: 'post',
    url: 'https://voice.yunpian.com/v2/voice/send.json',
    data: {
      mobile: tel,
      code,
    }
  });
};

module.exports.sendCode = async (tel, code, expires, type = constants.RC_VERIFY_CODE_TYPE.短信) => {
  if (process.env.NODE_ENV !== 'production') {
    return logger.debug({ tel, code, type });
  }
  if (type === constants.RC_VERIFY_CODE_TYPE.短信) {
    return await sendText(tel, `【芒果电单车】验证码为${code}，请在${expires}分钟内使用。`);
  } else {
    return await sendVoice(tel, code);
  }
};

const getUser = async _ => {
  return await ins({
    url: 'https://sms.yunpian.com/v2/user/get.json',
  });
};