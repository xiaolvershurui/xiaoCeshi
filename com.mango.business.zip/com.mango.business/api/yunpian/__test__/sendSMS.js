const sms = require('../index');

(async _ => {
  const result = await sms.sendText('15810103580', `【芒果电单车】您的行程1710241402007发生了违规：逆行17次，详情请查看http://192.168.1.181:4004/orderIllegal/1710241402007?selector=`);
  console.log(result);
})().catch(console.error);