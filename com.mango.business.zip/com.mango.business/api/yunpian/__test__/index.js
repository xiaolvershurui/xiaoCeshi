const tels = require('./tels.json');

const sms = require('../');

/*eslint-disable*/
sms.batchSend(tels, '尊敬的用户，您好。您于今天下午被系统影响的行程，已统一被免单处理。请您稍后在我的行程中查看确认。如有疏漏，请在芒果电单车APP中提交反馈，工作人员会尽快为您解决，请您放心。给您带来的不便非常抱歉，请您谅解。').then(_ => {
  console.log('done');
}).catch(console.error);