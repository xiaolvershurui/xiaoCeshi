const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
const ACCredit = require('../../../services/database/account/credit');

exports.validate = {
  id: Joi.string().required(),
  result: Joi.number().required(),
  processor: Joi.string().required(),
  remark: Joi.string().required()
};

exports.handler = async ({ id, result, processor, remark },tid, Transaction ) => {
  const reportedAbuse = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'op_reported_abuse',
      id
    }]
  });
  if(!reportedAbuse){
    throw new NotFoundError('不存在此毁损举报单');
  }
  if( result === constants.OP_REPORTED_ABUSE_RESULT.属实 ){
    const reporter = reportedAbuse.reporter;
    await Transaction.findAndLockEntity({
      tid,
      entities: [{
        model: 'ac_credit',
      }]
    });
    const acUser = await Transaction.findAndLockEntity({
      tid,
      entities: [{
        model: 'ac_user',
        id:reporter,
      }]
    });
    const creditId = await ACCredit.genId();
    await Transaction.commit({
      tid,
      updates: [{
        _id: id,
        $set:{
          state: constants.OP_REPORTED_DAMAGES_STATE.已处理,
          processor,
          processedAt: new Date(),
          result,
          remark
        }
      }, {
        _id: creditId,
        $set:{
          type: constants.AC_CREDIT_RECORD_INFO.上报故障.type,
          user: reporter,
          name: constants.AC_CREDIT_RECORD_INFO.上报故障.name,
          point: constants.AC_CREDIT_RECORD_INFO.上报故障.point
        }
      },{
        _id: acUser,
        $inc: {
          credit: constants.AC_CREDIT_RECORD_INFO.上报故障.point
        }
      }]
    });
  }else{
    await Transaction.commit({
      tid,
      updates: [{
        _id: id,
        $set: {
          state: constants.OP_REPORTED_DAMAGES_STATE.已处理,
          processor,
          processedAt: new Date(),
          result,
          remark
        }
      }]
    })
  }
};

module.exports = injectTransaction(exports, 'operation.reportedDamage.process');