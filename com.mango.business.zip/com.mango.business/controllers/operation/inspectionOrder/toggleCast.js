const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const _calculateProject = require('../../account/operator/_calculateProject');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function ({ id }) {
  const inspectionOrder = await OPInspectionOrder.findById({
    id,
    selector:'needCast updatedAt'
  });
  if(!inspectionOrder){
    throw new NotFoundError('未找到该巡检订单');
  }
  await OPInspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      "needCast": !inspectionOrder.needCast
    }
  });
  if (!inspectionOrder.needCast) {
    await _calculateProject({ id: inspectionOrder._id })
  }
};
