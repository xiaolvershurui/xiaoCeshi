const Joi = require('poolishark').Joi;
const InspectionOrder = require('../../../services/database/operation/inspectionOrder');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const calculateProject = require('../../account/operator/_calculateProject');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  index: Joi.number().min(0).required()
};


exports.handler = async ({ id, index }) => {
  const inspectionOrder = await InspectionOrder.findById({ id, selector: 'updatedAt payment.extraProjects' });
  if (!inspectionOrder) throw new NotFoundError('不存在该巡检订单');
  if ([constants.OP_INSPECTION_ORDER_STATE.已结算, constants.OP_INSPECTION_ORDER_STATE.已轧账].includes(inspectionOrder.state)) throw new BadRequestError('轧账/计算状态无法修改巡检单');
  inspectionOrder.payment.extraProjects.splice(index, 1);
  await InspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      'payment.extraProjects': inspectionOrder.payment.extraProjects
    }
  });
  // 触发更新 projects 计算
  calculateProject({ id });
};