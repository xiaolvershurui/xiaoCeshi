const Joi = require('poolishark').Joi;
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const _calculateProject = require('../../account/operator/_calculateProject');

exports.validate = {
  id: Joi.string().required(),
  index: Joi.number().required(),
  task: Joi.object(),
};

exports.handler = async ({ id, index, task }) => {
  let inspectionOrder = await OPInspectionOrder.findById({ id, selector: 'user.id user.dispatchAbility inspectedStocks fixedStatistic needCast' });
  if (!inspectionOrder) throw new NotFoundError(`id为${id}的巡检订单不存在`);

  const operator = await ACOperator.findByUser({
    user: inspectionOrder.user && inspectionOrder.user.id,
    selector: 'wrongCount missCount'
  });
  if (!operator) throw new NotFoundError('运营账户不存在');

  let finalUpdate = Object.keys(task).reduce((memo, item) => {
    memo[`inspectedStocks.${index}.${item}`] = task[item];
    inspectionOrder.inspectedStocks[index][item] = task[item];
    return memo;
  }, {});

  const fixedStatistic = inspectionOrder.inspectedStocks.reduce((memo, item) => {
    memo.total += 1;
    // 寻到
    if (item.hasFound) memo.found += 1;
    // 未锁
    if (!item.isBatteryLock) {
      if (!item.isReturnedBack) memo.batteryUnLock += 1;
      else memo.returnBack += 1;
    }
    // 难寻找到
    else if (item.isHardToFindButFound) memo.hardToFindButFound += 1;
    // 投放
    else if (item.isPutOn) memo.putOn += 1;
    // 拖回
    else if (item.isReturnedBack) memo.returnBack += 1;
    // 回栏
    else if (item.isBackIntoRegion) memo.backIntoRegion += 1;
    // 换电
    else if (item.isExchangedBattery) memo.exchangeBattery += 1;
    else if (item.isNormal) memo.normal += 1;
    else {
      const addedTasks = item.lastTaskList.filter(task => !item.prevTaskList.search({ code: task.code }));
      const releasedTasks = item.prevTaskList.filter(task => !item.lastTaskList.search({ code: task.code }));
      if (!(releasedTasks.length > 0 && addedTasks.length === 0)) {
        // 未完成的任务
        if (item.hasFound && item.lastTaskList.search({ code: constants.BK_TASK_TYPE.待拖回 })) {
          // 未完成的拖回任务
          memo.returnBackUnfinished += 1;
        }
        //未完成的其他任务
        memo.unfinished[item.taskGroup] = memo.unfinished[item.taskGroup] || 0;
        memo.unfinished[item.taskGroup] += 1;
      }
    }
    return memo;
  }, {
    total: 0,
    found: 0,
    returnBack: 0,
    exchangeBattery: 0,
    batteryUnLock: 0,
    backIntoRegion: 0,
    hardToFindButFound: 0,
    putOn: 0,
    normal: 0,
    unfinished: {},
    returnBackUnfinished: 0,
  });
  // 根据调度能力重计未完成拖回任务数
  fixedStatistic.returnBackUnfinished = Math.max(0, Math.min(fixedStatistic.returnBackUnfinished, inspectionOrder.user.dispatchAbility - fixedStatistic.returnBack));
  fixedStatistic.mileage = 0;
  fixedStatistic.wrongChange = operator.wrongCount;
  fixedStatistic.lostBattery = operator.missCount;

  finalUpdate = Object.assign({
    fixedStatistic: Object.assign(inspectionOrder.fixedStatistic, fixedStatistic)
  }, finalUpdate);

  await OPInspectionOrder.update({
    id: inspectionOrder._id,
    data: finalUpdate,
  });

  if (inspectionOrder.needCast) {
    await _calculateProject({ id: inspectionOrder._id }).catch(console.error);
  }
};
