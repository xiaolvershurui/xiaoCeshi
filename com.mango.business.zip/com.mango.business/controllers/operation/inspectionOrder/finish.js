const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const InspectionOrder = require('../../../services/database/operation/inspectionOrder');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async ({ id }) => {
  const inspectionOrder = await InspectionOrder.findById({ id, selector: 'state updatedAt', populateSelector: {
    'user.operator': 'needCast'
  } });
  if (!inspectionOrder) throw new NotFoundError('不存在该巡检单');
  if (inspectionOrder.state !== constants.OP_INSPECTION_ORDER_STATE.已轧账) throw new BadRequestError('非轧账状态无法结算');
  if (!inspectionOrder.user.operator.needCast) throw new BadRequestError('该司机不需要结算');
  return await InspectionOrder.update({
    id, updatedAt: inspectionOrder.updatedAt, data: {
      state: constants.OP_INSPECTION_ORDER_STATE.已结算
    }
  })
};