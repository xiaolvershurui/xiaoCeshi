const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACOperator = require('../../../services/database/account/operator');


exports.validate = {
  id: Joi.string().required()
};
exports.handler = async function ({ id }) {
  const inspection = await ACOperator.findById({
    id,
    selector:'_id'
  });
  if(!inspection){
    throw new NotFoundError('巡检人员不存在');
  }
  return await this.exec({
    c: 'account/operator/createInspectionOrder',
    params: {
      id: inspection._id,
    }
  })
};
