const Joi = require('poolishark').Joi;
const InspectionOrder = require('../../../services/database/operation/inspectionOrder');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const calculateProject = require('../../account/operator/_calculateProject');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  name: Joi.string().required(),
  value: Joi.number().required()
};

exports.handler = async ({ id, name, value }) => {
  const inspectionOrder = await InspectionOrder.findById({ id, selector: 'updatedAt payment.extraProjects state' });
  if (!inspectionOrder) throw new NotFoundError('不存在该巡检订单');
  if (![constants.OP_INSPECTION_ORDER_STATE.已截单, constants.OP_INSPECTION_ORDER_STATE.待确认].includes(inspectionOrder.state)) throw new BadRequestError('非截单/待确认状态无法修改巡检单');
  inspectionOrder.payment.extraProjects.push({ name, value });
  await InspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      'payment.extraProjects': inspectionOrder.payment.extraProjects
    }
  });
  // 触发更新 projects 计算
  calculateProject({id});
};