const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const InspectionOrder = require('../../../services/database/operation/inspectionOrder');
const constants = require('../../../com.mango.common/settings/constants');
const _calculateProject = require('../../account/operator/_calculateProject');

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object({
    'fixedStatistic.total': Joi.number(),
    'fixedStatistic.found': Joi.number(),
    'fixedStatistic.returnBack': Joi.number(),
    'fixedStatistic.exchangeBattery': Joi.number(),
    'fixedStatistic.backIntoRegion': Joi.number(),
    'fixedStatistic.hardToFindButFound': Joi.number(),
    'fixedStatistic.putOn': Joi.number(),
    'fixedStatistic.normal': Joi.number(),
    'fixedStatistic.returnBackUnfinished': Joi.number(),
    'fixedStatistic.mileage': Joi.number(),
    'fixedStatistic.unfinished': Joi.object(),
  }).unknown().required()
};

exports.handler = async ({ id, data }) => {
  const inspectionOrder = await InspectionOrder.findById({ id, selector: 'state updatedAt' });
  if (!inspectionOrder) throw new NotFoundError('不存在该巡检单');
  if ([constants.OP_INSPECTION_ORDER_STATE.已截单, constants.OP_INSPECTION_ORDER_STATE.待确认].includes(inspectionOrder.state)) throw new BadRequestError('非截单/待确认状态无法修改');
  await InspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data
  });
  _calculateProject({ id })
};