const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');


exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function ({ id }) {
  const inspection = await OPInspectionOrder.findById({
    id,
    selector:'user.operator'
  });
  if(!inspection){
    throw new NotFoundError('未找到该巡检订单');
  }
  return await this.exec({
    c: 'account/operator/pauseInspection',
    params: {
      id: inspection.user.operator._id
    }
  })

};
