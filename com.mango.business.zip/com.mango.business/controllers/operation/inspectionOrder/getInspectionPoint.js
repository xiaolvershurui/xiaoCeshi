const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const { combineLngLats } = require('./_getLngLats');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  const inspectionOrder = await OPInspectionOrder.findById({
    id,
    selector: 'user.name user.operator times box',
    populateSelector: {
      'user.operator': 'box',
    },
  });
  const times = inspectionOrder.times;
  if (!inspectionOrder) throw new NotFoundError(`巡检单${id}不存在`);
  const box = inspectionOrder.box;
  // const route = inspectionOrder.route;
  // if (!route) throw new NotFoundError(`巡检单${id}不存在路线信息`);
  // const now = route.offDuty.finishedAt;
  const now = times.stoppedAt || times.lastInspectionFinishedAt || new Date();
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}0`.slice(-3, -1);

  if (box) {
    // 上班路程
    const onDutyLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.startedAt).getTime(),
      endTime: new Date(times.firstInspectionStartedAt).getTime(),
    }, { earliestTime: times.startedAt });
    // 巡检路程
    const inInspectionLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.firstInspectionStartedAt).getTime(),
      endTime: new Date(times.lastInspectionFinishedAt).getTime(),
    }, { earliestTime: times.startedAt });
    // 下班路程
    const offDutyLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.lastInspectionFinishedAt).getTime(),
      endTime: new Date(times.stoppedAt).getTime(),
    }, { earliestTime: times.startedAt });
    return {
      onDuty: onDutyLngLats,
      inInspection: inInspectionLngLats,
      offDuty: offDutyLngLats,
    };
  } else {
    throw new NotFoundError(`盒子号不存在，请巡检员${inspectionOrder.user && inspectionOrder.user.name}绑定盒子号`);
  }
};
