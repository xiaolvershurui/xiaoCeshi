const OTSStockPoint = require('../../../services/ots/stockPoint');
const OTSBatteryInStockPoint = require('../../../services/ots/batteryInStockPoint');
const constants = require('../../../com.mango.common/settings/constants');

const limit = 2000;
const now = new Date();

const getLngLats = async ({ box, battery, year, month, startTime, endTime, type }) => {
  const OTS = type === 'batteryPoint' ? OTSBatteryInStockPoint : OTSStockPoint;
  const query = type === 'batteryPoint' ?
    { battery_month: `${battery}_${year}${month}`, time: [startTime, endTime] }
    :
    { box_month: `${box}_${year}${month}`, time: [startTime, endTime] };
  return await OTS.find(
    query,
    ['=', 'gps.locationType', constants.BK_BOX_LOCATION_TYPE.卫星],
    { limit });
};
// select: ['gps', 'extra', 'acc', 'lock', 'stock', 'box', 'battery', 'time'],
/**
 * @param box
 * @param year
 * @param month
 * @param startTime
 * @param endTime
 * @returns {Promise.<*>}
 */
exports.getLngLatsInLimit = async ({ box, battery, year, month, startTime, endTime, type }) => {
  let lngLats = await getLngLats({ box, battery, year, month, startTime, endTime, type });

  if (!lngLats || !lngLats.length) return [];

  let nextStartTime = lngLats[lngLats.length - 1].time;
  let diffTimestamp = endTime - nextStartTime;
  // 剩余时间大于10s
  while (diffTimestamp > 10 * 1000) {
    const tempLngLats = await getLngLats({ box, battery, year, month, startTime: nextStartTime, endTime, type });
    lngLats = [...lngLats, ...tempLngLats];
    if (tempLngLats && tempLngLats.length === limit) {
      nextStartTime = tempLngLats[tempLngLats.length - 1].time;
      diffTimestamp = endTime - nextStartTime;
    } else {
      break;
    }
  }
  return lngLats;
};

/**
 *
 * @param box 盒子号
 * @param now 时间范围的最大值
 * @param year 年份
 * @param month 月份
 * @param startTime 开始时间戳
 * @param endTime 结束时间戳
 * @param earliestTime 如果是分段查询，则是最早的时间节点，如果不是，则时间戳等于startTime
 * @returns {Promise.<Array>}
 */
exports.combineLngLats = async ({
  box = '',
  battery = '',
  now = now,
  year = now.getFullYear(),
  month = now.getMonth() + 1,
  startTime = now.getTime(),
  endTime = now.getTime(),
  type = 'stockPoint',
}, {
  earliestTime,
}) => {
  earliestTime = earliestTime || new Date(startTime);

  const thisMonthLngLats = await exports.getLngLatsInLimit({ box, battery, year, month, startTime, endTime, type });

  let lastMonthLngLats = [];
  if (now.getDate() === 1 && earliestTime.getDate() !== 1) {
    lastMonthLngLats = await exports.getLngLatsInLimit({ box, battery, year, month: month - 1, startTime, endTime, type });
  }

  let lngLats = [];
  if (thisMonthLngLats && thisMonthLngLats.length) lngLats = [...lngLats, ...thisMonthLngLats];
  if (lastMonthLngLats && lastMonthLngLats.length) lngLats = [...lngLats, ...lastMonthLngLats];
  return lngLats;
};