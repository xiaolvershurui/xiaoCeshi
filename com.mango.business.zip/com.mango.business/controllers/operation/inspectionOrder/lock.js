const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const InspectionOrder = require('../../../services/database/operation/inspectionOrder');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async ({ id }) => {
  const inspectionOrder = await InspectionOrder.findById({ id, selector: 'state updatedAt' });
  if (!inspectionOrder) throw new NotFoundError('不存在该巡检单');
  if (![constants.OP_INSPECTION_ORDER_STATE.已截单, constants.OP_INSPECTION_ORDER_STATE.待确认].includes(inspectionOrder.state)) throw new BadRequestError('非截单/待确认状态无法轧账');
  return await InspectionOrder.update({
    id, updatedAt: inspectionOrder.updatedAt, data: {
      state: constants.OP_INSPECTION_ORDER_STATE.已轧账
    }
  })
};