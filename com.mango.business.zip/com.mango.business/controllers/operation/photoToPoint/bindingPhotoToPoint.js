const Joi = require('poolishark').Joi;
const OPPhotoToPoint = require('../../../services/database/operation/photoToPoint');
const OPParkingLot = require('../../../services/database/operation/parkingLot');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
const validators = require('../../../com.mango.common/settings/validators');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const Core = require('../../../services/core/shark');

exports.validate = {
  id: validators.id.required(),
  parkingLotId: validators.id.required(),
};

exports.handler = async ({ id, parkingLotId }, tid, Transaction) => {

  const photoToPoint = await OPPhotoToPoint.findById({
    id,
    selector: 'parkingLot',
    populateSelector: {
      parkingLot: 'name photoToPoint',
    },
  });
  if (!photoToPoint) throw new NotFoundError(`停车区照片${id}不存在`);
  if (photoToPoint.parkingLot) throw new BadRequestError(`该照片已绑定${photoToPoint.parkingLot.name}停车区，不可重复绑定`);

  const parkingLot = await OPParkingLot.findById({
    id: parkingLotId,
    selector: 'photoToPoint'
  });

  if (parkingLot && parkingLot.photoToPoint) {
    await OPPhotoToPoint.update({
      id: parkingLot.photoToPoint._id,
      data: {
        parkingLot: null
      },
    });
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'op_photo_to_point',
      id,
    }, {
      model: 'op_parking_lot',
      id: parkingLotId,
    }],
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        parkingLot: parkingLotId,
      },
    }, {
      _id: parkingLotId,
      $set: {
        photoToPoint: id,
      },
    }],
  });

};

module.exports = injectTransaction(exports, 'operation.photoToPoint.bindingPhoto');
