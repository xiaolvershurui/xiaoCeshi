const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');
const OPWorkOrder = require('../../../services/database/operation/workOrder');

exports.validate = {
  id: Joi.string().required(),
  reply: Joi.string().required(),
  processor: Joi.string().required(),
  reason: Joi.string().required()
};

exports.handler = async ({ id, reply, processor, reason }) => {
   const acUser = await ACUser.findById({
      id: processor
    });
   if(!acUser){
     throw new NotFoundError('未找到此用户');
   }
  const opWorkOrder = await OPWorkOrder.findById({
    id,
    selector:'createdAt processed'
  });
  if(!opWorkOrder){
    throw new NotFoundError('未找到此工单') ;
  }
  if(opWorkOrder.processed){
    throw BadRequestError(`改工单已被处理 WorkOrder Id: ${id}`);
  }
  return await OPWorkOrder.update({
    id: id,
    data: {
      reply: reply,
      reason: reason,
      processed: true,
      processedAt: new Date(),
      processor: processor,
      timeCost: Date.now() - (new Date(opWorkOrder.createdAt)).getTime()
    }
  });
};
