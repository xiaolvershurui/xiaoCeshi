const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPRegion = require('../../../services/database/operation/region');
const ACUser = require('../../../services/database/account/user');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const STAsset = require('../../../services/database/setting/asset');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  region: Joi.string().required().description('大区　ID'),
  name: Joi.string().required().description('大区名称'),
  director: Joi.string().required().description('负责人'),
  enable: Joi.boolean().description('是否启用'),
  location: Joi.object({
    address: Joi.string().allow(null).description('地址'),
    lngLat: Joi.array().items(Joi.number().allow(null)).description('经纬度')
  }).description('地址')
};
exports.handler = async function ({ region, name, director, enable, location }) {
  const re = await OPRegion.findById({ id: region, selector: '_id' });
  if (!re) throw new NotFoundError('该大区不存在');
  const operator = await ACUser.findById({ id: director, selector: '_id' });
  if (!operator) throw new NotFoundError('该用户不存在');

  // const existStation = await OPBatteryStation.findByDirector({ director, selector: 'name' });
  // if (existStation) throw new BadRequestError(`该运营人员已是${existStation.name}仓库负责人`);

  const station = await OPBatteryStation.create({
    region,
    name,
    director,
    enable,
    location
  });

  const stAssets = await STAsset.find({
    query: {},
    selector: 'code type'
  });

  process.nextTick(_ => {
    (async _ => {
      for (let asset of stAssets) {
        try {
          await this.exec({
            c: 'ebike/asset/create',
            params: {
              region,
              station: station._id,
              asset: asset._id,
              code: asset.code,
              group: constants.ST_ASSET_GROUP.配件
            }
          })
        } catch (err) {
          console.error(err)
        }
      }
    })()
  });

  return station
};
