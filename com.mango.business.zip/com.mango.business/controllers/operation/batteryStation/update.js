const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  id: Joi.string().description('仓库 ID'),
  data: Joi.object({
    name: Joi.string().description('大区名称'),
    director: Joi.string().description('负责人'),
    enable: Joi.boolean().description('是否启用'),
  }).allow('').unknown()
};
exports.handler = async function ({ id, data }) {

  const station = await OPBatteryStation.findById({ id, selector: '_id updatedAt' });
  if (!station) throw new NotFoundError(`电池站：${id}不存在`);

  if (data.director) {
    const user = await ACUser.findById({ id: data.director, selector: "_id" });
    if (!user) throw new NotFoundError(`用户：${data.director}不存在`)
  }

  return await OPBatteryStation.update({
    id,
    updatedAt: station.updatedAt,
    data
  });
};
