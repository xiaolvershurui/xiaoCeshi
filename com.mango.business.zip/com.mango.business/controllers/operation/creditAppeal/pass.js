const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPCreditAppeal = require('../../../services/database/operation/creditAppeal');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  processor: Joi.string().required(),
  passRemark: Joi.string().required()
};
exports.handler = async ({ id, processor, passRemark  }, tid, Transaction) => {
  const acUser = await  ACUser.findById({
    id: processor
  });
  if(!acUser){
    throw new NotFoundError(`未找到此操作人Id${processor}`);
  }
  const opCreditAppeal = await OPCreditAppeal.findById({
    id,
    selector: 'state credit'
  });
  if (!opCreditAppeal) {
    throw new NotFoundError(`信用记录未找到:${params.id}`)
  }
  if (opCreditAppeal.state !== constants.OP_CREDIT_APPEAL_STATE.待处理) {
    throw new BadRequestError(`该记录当前无法处理sate:${opCreditAppeal.state}`);
  }
  const [acCredit] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id: opCreditAppeal.credit._id,
      model: 'ac_credit',
      selector: 'credit'
    }]
  });
  if (!acCredit) {
    throw new NotFoundError(`不存在此申诉记录 ${opCreditAppeal.credit._id}`);
  }
  if (!credit.appeal.appealed) {
    if (!acCredit.appeal.appealedAt) {
      throw new BadRequestError(`该记录未申诉: ${opCreditAppeal.credit._id}`);
    }
    if (acCredit.appeal.passedAt) {
      throw new BadRequestError(`该申请已经通过 ${opCreditAppeal.credit._id}`)
    }
    if(acCredit.appeal.rejectedAt) {
      throw new BadRequestError(`该申请已经驳回 ${opCreditAppeal.credit._id}`)
    }
  }
  const [opCredit] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id: opCreditAppeal._id,
      selector: 'op_credit_appeal'
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: acCredit._id,
      $set: {
        'appeal.result': constants.OP_CREDIT_APPEAL_RESULT.通过,
        'appeal.passedAt': new Date(),
      }
    }, {
      _id: opCredit._id,
      $set: {
        state: constants.OP_CREDIT_APPEAL_STATE.已处理,
        result: constants.OP_CREDIT_APPEAL_RESULT.通过,
        processor,
        passRemark,
        passedAt: new Date()
      }
    }]
  });
};

module.exports = injectTransaction(exports, 'account.operation.creditAppeal.pass');