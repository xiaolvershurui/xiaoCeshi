const Joi = require('poolishark').Joi;
const BKStock = require('../../../services/database/ebike/stock');
const RCStockRepair = require('../../../services/database/record/stockRepair');
const OPRepairWorkOrder = require('../../../services/database/operation/repairWorkOrder');
const STRepairTeam = require('../../../services/database/setting/repairTeam');
const RCStockOp = require('../../../services/database/record/stockOp');
const constants = require('../../../com.mango.common/settings/constants');

exports.handler = async _ => {
  const repairWorkOrders = await OPRepairWorkOrder.find({
    query: {
      status: constants.OP_REPAIR_WORK_ORDER_STATE.未计算,
    },
    limit: 0,
    selector: 'repairStocks',
  });


  for (let order of repairWorkOrders) {
    let repairStocks = order.repairStocks;

    const stocks = await BKStock.find({
      query: {
        _id: {
          $in: repairStocks.map(item => item.id._id),
        },
      },
      limit: 0,
      selector: 'locate',
    });
    repairStocks = repairStocks.map(item => {
      const s = stocks.find(i => i._id === item.id._id);
      if (s && s.locate === constants.BK_LOCATE.调度) {
        Object.assign(item, {
          isValid: true,
        });
      }
      return item;
    });

    await OPRepairWorkOrder.update({
      id: order._id,
      data: {
        status: constants.OP_REPAIR_WORK_ORDER_STATE.已计算,
        repairStocks
      }
    })
  }
};
