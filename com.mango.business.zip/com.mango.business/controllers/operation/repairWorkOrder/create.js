const Joi = require('poolishark').Joi;
const BKStock = require('../../../services/database/ebike/stock');
const RCStockRepair = require('../../../services/database/record/stockRepair');
const OPRepairWorkOrder = require('../../../services/database/operation/repairWorkOrder');
const STRepairTeam = require('../../../services/database/setting/repairTeam');
const RCStockOp = require('../../../services/database/record/stockOp');
const ODStockRepair = require('../../../services/database/order/stockRepair');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  stock: Joi.string().required(),
  repairOrderId: Joi.string().required(),
};

exports.handler = async ({ stock, repairOrderId }) => {
  const odStockRepair = await ODStockRepair.findById({
    id: repairOrderId,
    selector: 'repairSuccess',
    populateSelector: {
      repairSuccess: 'damageTime'
    }
  });
  const startTime = new Date(Math.min(...odStockRepair.repairSuccess.filter(item => item.damageTime).map(item => item.damageTime.getTime())));

  const bkStock = await BKStock.findById({
    id: stock,
    selector: 'region station damageTime repairTime box number.custom number.vin',
    populateSelector: {
      region: 'name'
    }
  });
  // 置损 -> 维修之间的维修记录
  const rcStockRepairs = await RCStockRepair.find({
    query: {
      createdAt: {
        $gte: bkStock.damageTime,
        $lt: bkStock.repairTime,
      },
    },
    limit: 0,
    sort: { createdAt: -1 },
    selector: 'user',
  });
  if (!rcStockRepairs || !rcStockRepairs.length) return;

  // 当前操作人的维修小组
  let repairTeam, repairCreate;
  const repairTeams = await STRepairTeam.find({
    query: {
      groupMembers: {
        $in: rcStockRepairs.map(item => item.user._id),
      },
    },
    limit: 0,
    sort: { createdAt: -1 },
    selector: 'name groupMembers region',
  });
  if (repairTeams && repairTeams.length > 1) {
    repairTeam = (await STRepairTeam.find({
      query: {
        groupMembers: rcStockRepairs[0].user._id,
      },
      limit: 0,
      sort: { createdAt: -1 },
      selector: 'name groupMembers region',
    }))[0];
    repairCreate = {
      repairMembers: repairTeam.groupMembers.map(item => item._id),
      team: {
        id: repairTeam._id,
        name: repairTeam.name,
      },
    };
  } else if (repairTeams && repairTeams.length === 1) {
    repairTeam = repairTeams[0];
    repairCreate = {
      repairMembers: repairTeam.groupMembers.map(item => item._id),
      team: {
        id: repairTeam._id,
        name: repairTeam.name,
      },
    };
  } else {
    // 若此人不在组内
    repairCreate = {
      repairMembers: [rcStockRepairs[0].user._id],
    };
  }

  // 通过车辆操作记录查看是否是扣押拖回车辆
  const stockOps = await RCStockOp.find({
    query: {},
    limit: 2,
    sort: { _id: -1 },
    selector: 'type',
  });
  let isDetainedAndPullBack = false;
  if (stockOps && stockOps.length === 2) {
    if (stockOps[0].type === constants.RC_STOCK_OP_TYPE.拖回仓库 && stockOps[1].type === constants.RC_STOCK_OP_TYPE.被扣找回) {
      isDetainedAndPullBack = true;
    }
  }


  const createWorkOrder = async _ => {
    await OPRepairWorkOrder.create(Object.assign(repairCreate, {
      region: repairTeam.region && repairTeam.region._id,
      station: bkStock.station && bkStock.station.name,
      repairStocks: [{
        id: bkStock._id,
        number: bkStock.number.custom,
        box: bkStock.box,
        vin: bkStock.number.vin,
        isDetainedAndPullBack,
      }],
    }));
  };

  const updateWorkOrder = async (repairWorkOrder) => {
    await OPRepairWorkOrder.update({
      id: repairWorkOrder._id,
      data: {},
      arrayOp: {
        $addToSet: {
          repairStocks: {
            id: bkStock._id,
            number: bkStock.number.custom,
            box: bkStock.box,
            vin: bkStock.number.vin,
            isDetainedAndPullBack,
          }
        }
      }
    })
  };

  if (repairCreate.team) {
    const repairWorkOrder = await OPRepairWorkOrder.find({
      query: {
        'team.id': repairCreate.team.id,
        createdAt: { $gte: startTime }
      },
      limit: 0,
      sort: { createdAt: -1 }
    });
    if (repairWorkOrder && repairWorkOrder.length) {
      await updateWorkOrder(repairWorkOrder[0]);
    } else {
      await createWorkOrder();
    }
  } else {
      const repairWorkOrder = await OPRepairWorkOrder.find({
        query: {
          repairMembers: {
            $in: repairCreate.repairMembers
          },
          createdAt: { $gte: startTime }
        },
        limit: 0,
        sort: { createdAt: -1 }
      });
      if (repairWorkOrder && repairWorkOrder.length) {
          await updateWorkOrder(repairWorkOrder[0]);
      } else {
          await createWorkOrder();
      }
  }
};
