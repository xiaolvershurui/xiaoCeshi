const Joi = require('poolishark').Joi;
const OPPunchArea = require('../../../services/database/operation/punchArea');
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPPolygon = require('../../../services/database/operation/polygon');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  puncher: Joi.string().required(),
  remark: Joi.string(),
  photo: Joi.string(),
};

exports.handler = async ({ id, puncher, remark, photo }, tid, Transaction) => {
  const opPunchArea = await OPPunchArea.findById({
    id,
    selector: 'name polygon needPunch'
  });
  if (!opPunchArea) throw new NotFoundError(`打卡点${id}不存在`);
  if (!opPunchArea.needPunch) throw new BadRequestError(`打卡点${opPunchArea.name}已经打过卡`);


  const operator = await ACOperator.findByUser({
    user: puncher,
    selector: 'isWorking',
  });
  if (!operator.isWorking) throw new BadRequestError(`运营人员${operator.user && operator.user.cert && operator.user.cert.name}不在班`);

  const polygon = opPunchArea.polygon && opPunchArea.polygon._id;
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'op_punch_area',
      id,
    }, {
      model: 'rc_punch_area',
    }],
  });

  const now = new Date();
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        needPunch: false,
        punchInfo: {
          punchedAt: now,
          puncher
        }
      },
    }, {
      polygon,
      punchArea: id,
      punchedAt: now,
      puncher,
      remark,
      photo,
    }],
  });
};

module.exports = injectTransaction(exports, 'operation.punchArea');
