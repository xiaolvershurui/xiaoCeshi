const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const OPRiderOrder = require('../../../services/database/operation/riderOrder');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  remark: Joi.string(),
  auditedBikes: Joi.array().items(Joi.object({
    id: Joi.string().required(),
    isPassed: Joi.boolean().required(),
  })),
  auditor: Joi.string().required(),
};
exports.handler = async function ({ id, auditedBikes, auditor, remark }) {
  const riderOrder = await OPRiderOrder.findById({
    id,
    selector: 'updatedAt state inspectedStocks user',
  });
  const operator = await ACOperator.findById({ id: riderOrder.user.operator._id, selector: 'wrongCount missCount statistic user.dispatchAbility ' })

  if (!riderOrder) throw new NotFoundError(`骑行订单${id}不存在`);
  if (riderOrder.state !== constants.OP_RIDER_ORDER_STATE.待审核) throw new NotFoundError(`骑行订单${id}非待审核状态`);

  if (riderOrder.inspectedStocks.length !== auditedBikes.length) throw new BadRequestError(`审核车辆数量不正确`);
  
  const inspectedStocks = riderOrder.inspectedStocks.map(item => {
    const inspectedBike = auditedBikes.find(i => i.id === item.id);
    if (inspectedBike) {
      item.isPassed = inspectedBike.isPassed;
    }
    return item;
  });

  const statistic = inspectedStocks.filter(item => item.isPassed && item.findStockPhoto).reduce((memo, item) => {
    memo.total += 1;
    // 找到数
    if (item.hasFound) memo.found += 1;
    // 难寻巡检数
    if (item.isHardToFind && item.isPassed) {
      memo.hardToFind += 1;
      if (item.isHardToFindButFound) {
        memo.hardToFindButFound += 1;
      } else {
        memo.hardToFindButNotFound += 1;
      }
    }
    // 离线巡检数
    else if (item.isOffline && item.isPassed) {
      memo.offline += 1;
      if (item.isOfflineButFound) {
        memo.offlineButFound += 1;
      } else {
        memo.offlineButNotFound += 1;
      }
    }
    // 断电巡检数
    else if (item.isPowerOff && item.isPassed) {
      memo.powerOff += 1;
      if (item.isPowerOffButFound) {
        memo.powerOffButFound += 1;
      } else {
        memo.powerOffButNotFound += 1;
      }
    }
    // 其他任务找到数
    else if (item.otherFinished && item.isPassed) {
      memo.otherFinished += 1;
    }
    else if (item.isMoveAndWakeUp) {
      memo.moveAndWakeUp += 1;
    }

    // 拖回
    if (!item.isBatteryLock && item.isReturnedBack) memo.returnBack += 1;
    // 投放
    else if (item.isPutOn) memo.putOn += 1;
    // 拖回
    else if (item.isReturnedBack) memo.returnBack += 1;
    // 回栏
    else if (item.isBackIntoRegion) memo.backIntoRegion += 1;
    // 换电
    else if (item.isExchangedBattery) memo.exchangeBattery += 1;
    else if (item.isNormal) memo.normal += 1;
    else {
      const addedTasks = item.lastTaskList.filter(task => !item.prevTaskList.search({ code: task.code }));
      const releasedTasks = item.prevTaskList.filter(task => !item.lastTaskList.search({ code: task.code }));
      if (!(releasedTasks.length > 0 && addedTasks.length === 0)) {
        // 未完成的任务
        if (item.hasFound && item.lastTaskList.search({ code: constants.BK_TASK_TYPE.待拖回 })) {
          // 未完成的拖回任务
          memo.returnBackUnfinished += 1;
        }
      }
    }
    return memo;
  }, {
    total: 0,
    found: 0,
    hardToFind: 0,
    hardToFindButFound: 0,
    hardToFindButNotFound: 0,
    offline: 0,
    offlineButFound: 0,
    offlineButNotFound: 0,
    powerOff: 0,
    powerOffButFound: 0,
    powerOffButNotFound: 0,
    moveAndWakeUp: 0,
    otherFinished: 0,
    returnBack: 0,
    exchangeBattery: 0,
    backIntoRegion: 0,
    putOn: 0,
    normal: 0,
    returnBackUnfinished: 0,
  });

  statistic.returnBackUnfinished = Math.max(0, Math.min(statistic.returnBackUnfinished, riderOrder.user.dispatchAbility - statistic.returnBack));
  statistic.mileage = 0;
  statistic.wrongChange = operator.wrongCount;
  statistic.lostBattery = operator.missCount;

  await OPRiderOrder.update({
    id: riderOrder._id,
    updatedAt: riderOrder.updatedAt,
    data: {
      state: constants.OP_RIDER_ORDER_STATE.已审核,
      inspectedStocks,
      statistic,
      'times.auditedAt': new Date(),
      auditor,
      remark,
    },
  });


};
