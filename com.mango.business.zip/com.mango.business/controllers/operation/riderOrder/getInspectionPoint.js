const OPRiderOrder = require('../../../services/database/operation/riderOrder');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const { combineLngLats } = require('../../operation/inspectionOrder/_getLngLats');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  const riderOrder = await OPRiderOrder.findById({
    id,
    selector: 'user.name user.operator times box',
    populateSelector: {
      'user.operator': 'box',
    },
  });
  const times = riderOrder.times;
  if (!riderOrder) throw new NotFoundError(`骑行单${id}不存在`);
  const box = riderOrder.box;
  // const route = riderOrder.route;
  // if (!route) throw new NotFoundError(`骑行单${id}不存在路线信息`);
  const now = times.finishedAt || times.lastInspectionFinishedAt || new Date();
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}`.slice(-2);

  if (box) {
    // 上班路程
    const onDutyLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.startedAt).getTime(),
      endTime: new Date(times.firstInspectionStartedAt).getTime()
    }, { earliestTime: times.startedAt });
    // 巡检路程
    const inInspectionLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.firstInspectionStartedAt).getTime(),
      endTime: new Date(times.lastInspectionFinishedAt).getTime()
    }, { earliestTime: times.startedAt });
    // 下班路程
    const offDutyLngLats = await combineLngLats({
      box,
      now,
      year,
      month,
      startTime: new Date(times.lastInspectionFinishedAt).getTime(),
      endTime: new Date(times.finishedAt).getTime()
    }, { earliestTime: times.startedAt });
    return {
      onDuty: onDutyLngLats,
      inInspection: inInspectionLngLats,
      offDuty: offDutyLngLats,
    };
   } else {
    throw new NotFoundError(`盒子号不存在，请骑手${riderOrder.user && riderOrder.user.name}绑定盒子号`)
  }
};
