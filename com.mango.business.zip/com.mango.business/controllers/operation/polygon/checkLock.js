const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPPolygon = require('../../../services/database/operation/polygon');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async ({ id }) => {
  const opPolygon = await OPPolygon.findById({
    id,
    selector: 'state updatedAt isCleaned'
  });
  if (opPolygon.state === constants.OP_POLYGON_STATE.锁定) {
    throw new BadRequestError('该区块已经锁定,管理员解锁后可以编辑');
  }
  return opPolygon;
};