const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPPolygon = require('../../../services/database/operation/polygon');
const RCPolygon = require('../../../services/database/record/polygon');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  user: Joi.string().required(),
  id: Joi.string().required(),
};

exports.handler = async function ({ user, id }, tid, Transaction) {
  const opPolygon = await this.exec({
    c: 'operation/polygon/checkLock',
    params: { id }
  });
  if (opPolygon.isCleaned) throw new BadRequestError('该区块已被删除');

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'op_polygon',
      selector: 'isCleaned'
    }, {
      model: 'rc_polygon_op'
    }]
  });
  const rcPolygonId = await RCPolygon.genId();
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        isCleaned: true,
      }
    }, {
      _id: rcPolygonId,
      type: constants.RC_POLYGON_OP_TYPE.删除区块,
      polygon: id,
      user
    }]
  });
};

module.exports = injectTransaction(exports, 'operation.polygon.cleanPolygon');