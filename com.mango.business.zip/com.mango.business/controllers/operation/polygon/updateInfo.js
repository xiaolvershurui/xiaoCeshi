const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPPolygon = require('../../../services/database/operation/polygon');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object().required()
};

exports.handler = async ({ id, data }) => {
  const opPolygon = this.exec({
    c: 'operation/polygon/checkLock',
    params: {
      stock: stock._id,
      operator
    }
  });
  return await OPPolygon.update({
    id,
    updatedAt: opPolygon.updatedAt,
    data: Object.assign({
      state: constants.OP_POLYGON_STATE.待审,
    },data)
  });
};