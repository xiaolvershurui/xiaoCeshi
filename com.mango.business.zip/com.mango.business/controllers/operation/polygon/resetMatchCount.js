const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const RCPolygon = require('../../../services/database/record/polygon');
const OPPolygon = require('../../../services/database/operation/polygon');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  operator: Joi.string().required()
};

exports.handler = async ({ id, operator }, tid, Transaction) => {
  const [opPolygon] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'op_polygon',
      selector: 'matchCount'
    }]
  });
  if (opPolygon.matchCount === 0) {
    throw new Error('当前matchCount已经为0,无法重置')
  }
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'rc_polygon_op'
    }]
  });
  const rcPolygonId = await RCPolygon.genId();
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        matchCount: 0,
        lastCleanAt: new Date()
      }
    }, {
      _id: rcPolygonId,
      type: constants.RC_POLYGON_OP_TYPE.清零区块,
      matchCount: {
        prevMatchCount: opPolygon.matchCount
      },
      polygon: opPolygon._id,
      user: operator
    }]
  });
};

module.exports = injectTransaction(exports, 'operation.polygon.resetMatchCount');