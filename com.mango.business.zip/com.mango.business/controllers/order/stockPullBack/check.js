const Joi = require('poolishark').Joi;
const ODStockPullBack = require('../../../services/database/order/stockPullBack');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = Joi.object({
  stocks: Joi.array().items(Joi.object()),
}).unknown();

exports.handler = async function ({ stocks }) {
  let bkStocks = [];
  let s;
  for (let stock of stocks) {
    if (stock.number) {
      s = await BKStock.findByNumber(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: stock.number, notFound: true }];
    } else if (stock.vin) {
      s = await BKStock.findByVin(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { vin: stock.vin, notFound: true }];
    } else if (stock.box){
      s = await BKStock.findByBox(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { box: stock.box, notFound: true }];
    }
  }
  bkStocks = bkStocks.map(item => {
    if (item.notFound) {
      return Object.assign(item, {
        canPullBack: item.locate === constants.BK_LOCATE.调度
      })
    } else {
      return {
        stockId: item._id,
        number: item.number && item.number.custom,
        vin: item.number && item.number.vin,
        box: item.box && item.box._id,
        notFound: false,
        canPullBack: item.locate === constants.BK_LOCATE.调度
      };
    }
  });
  return bkStocks;
};
