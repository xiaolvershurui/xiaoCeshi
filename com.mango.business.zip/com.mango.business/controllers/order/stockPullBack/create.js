const Joi = require('poolishark').Joi;
const ODStockPullBack = require('../../../services/database/order/stockPullBack');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = Joi.object({
  station: Joi.string().required(),
  storeManager: Joi.string(),
  driver: Joi.string(),
  stocks: Joi.array().items(Joi.string()),
}).unknown();

exports.handler = async function ({ station, storeManager, driver, stocks }) {

  const _user = ACUSer.findById({ id: storeManager });
  if (!_user) throw new NotFoundError(`未找到用户：${storeManager}`);

  const _station = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!_station) throw new NotFoundError(`未找到仓库：${station}`);

  const region = _station.region && _station.region._id;

  const stockPullBack = await ODStockPullBack.findByStoreManager({
    storeManager,
    status: constants.OD_STOCK_PULL_BACK.正在进行,
  });
  // if (stockPullBack) throw new BadRequestError('该用户有正在进行的拖回单');
  let bkStocks = await BKStock.find({
    query: {
      _id: {
        $in: stocks
      }
    },
    limit: 0,
    selector: '',
  });

  bkStocks.forEach(item => {
    if (item.locate !== constants.BK_LOCATE.调度) throw new BadRequestError(`车牌号为${item.number && item.number.custom}的车辆非调度状态`);
  });
  bkStocks = bkStocks.map(item => item._id);

  const odStockPullBack = await ODStockPullBack.create({
    region,
    station,
    storeManager,
    driver,
    date: new Date()
  });
  await this.exec({
    c: 'order/stockPullBack/pullBack',
    params: {
      id: odStockPullBack._id,
      stocks: bkStocks,
    },
  });
};
