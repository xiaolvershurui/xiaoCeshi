const Joi = require('poolishark').Joi;
const ODStockPullBack = require('../../../services/database/order/stockPullBack');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const stockPullBack = await ODStockPullBack.findById({
    id,
    selector: 'status pullBackFailed nextTry'
  });
  if (!stockPullBack) throw new NotFoundError('不存在该拖回单');
  if (constants.OD_STOCK_PULL_BACK.正在进行 !== stockPullBack.status) throw new BadRequestError('非正在进行拖回单不能重试');
  if (stockPullBack.nextTry) {
    if (new Date().getTime() < stockPullBack.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (stockPullBack.status === constants.OD_STOCK_PULL_BACK.正在进行) {
    await this.exec({
      c: 'order/stockPullBack/pullBack',
      params: {
        id,
        stocks: stockPullBack.pullBackFailed.map(item => item._id)
      }
    })
  }
};