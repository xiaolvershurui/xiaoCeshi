const Joi = require('poolishark').Joi;
const ODStockPullBack = require('../../../services/database/order/stockPullBack');
const BKStock = require('../../../services/database/ebike/stock');
const RCStockOp = require('../../../services/database/record/stockOp');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stock: Joi.string().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date(),
};

exports.handler = async ({ id, stock, status, finishedAt }, tid, Transaction) => {
  const bkStock = await BKStock.findById({ id: stock, selector: 'number.custom style' });
  if (!bkStock) throw new NotFoundError(`车辆${stock}不存在`);

  const odStockPullBack = await ODStockPullBack.findById({
    id,
    selector: 'region station driver storeManager stocks pullBackFailed pullBackSuccess',
    populateSelector: {
      storeManager: '_id cert.name auth.tel profile.avator',
      station: 'name'
    }
  });
  if (!odStockPullBack) throw new NotFoundError(`车辆${id}不存在`);
  // 添加成功
  odStockPullBack.pullBackSuccess.push(stock);
  const odStockPullBackUpdates = {
    _id: id,
    $pull: {
      pullBackFailed: stock,
    },
    $addToSet: {
      pullBackSuccess: stock,
      stocks: stock,
    },
    $set: {
      status,
      finishedAt,
    }
  };

  // 车辆操作记录
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_stock_pull_back',
      id: odStockPullBack._id,
    }, {
      model: 'bk_stock',
      id: stock,
    }, {
      model: 'rc_stock_op',
    }],
  });

  await Transaction.commit({
    tid,
    updates: [odStockPullBackUpdates, {
      _id: stock,
      $set: {
        locate: constants.BK_LOCATE.仓库,
        station: odStockPullBack.station._id
      },
    }, {
      stock,
      stockNo: bkStock.number && bkStock.number.custom,
      type: constants.RC_STOCK_OP_TYPE.拖回仓库,
      region: odStockPullBack.region._id,
      style: bkStock.style._id,
      operatedAt: new Date(),
      operator: odStockPullBack.storeManager && odStockPullBack.storeManager._id,
      operatorTel: odStockPullBack.storeManager && odStockPullBack.storeManager.auth.tel,
      operatorName: odStockPullBack.storeManager && odStockPullBack.storeManager.cert.name,
      operatorAvator: odStockPullBack.storeManager && odStockPullBack.storeManager.profile.avator,
      description: `将车牌号为${bkStock.number && bkStock.number.custom}的车辆拖回${odStockPullBack.station && odStockPullBack.station.name}仓库`,
      pullBack: {
        driver: odStockPullBack.driver._id,
        storehouse: {
          id: odStockPullBack.station._id,
          name: odStockPullBack.station.name,
        },
      }
    }],
  });
};

module.exports = injectTransaction(exports, 'account.order.odStockPullBack.pullBackOne');
