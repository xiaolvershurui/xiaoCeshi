const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  query: Joi.object().description('查询参数'),
  limit: Joi.number().empty('').description('查询条数'),
  sort: Joi.object().empty('').description('查询条件'),
  skip: Joi.number().empty('').description('跳过条数'),
  selector: Joi.string().empty('').description('字段选择器')
};

exports.handler = async ({ query, limit, sort, skip, selector }) => {
  const assetReceives = await ODAssetReceive.find({ query, limit, sort, skip, selector });
  const existReceive = assetReceives.find(item => {
    return item.status !== constants.OD_ASSET_RECEIVE_STATE.已经完成
  });
  if (existReceive) {
    const userId = query.user;
    return {
      id: existReceive._id,
      isExist: true
    }
  } else {
    return {
      id: '',
      isExist: false
    }
  }
};