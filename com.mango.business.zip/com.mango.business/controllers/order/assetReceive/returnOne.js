const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const BKAsset = require('../../../services/database/ebike/asset');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  dispenser: Joi.string().required(),
  asset: Joi.object({
    code: Joi.string(),
    name: Joi.string(),
    backIntactCount: Joi.number(),
    backBadCount: Joi.number(),
  }),
  status: Joi.number().required()
};

exports.handler = async ({ id, asset, status, dispenser }, tid, Transaction) => {
  const odAssetReceive = await ODAssetReceive.findById({
    id,
    selector: 'updatedAt station region assets status returnFailed returnSuccess'
  });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetReceive.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });
  const odAssetReceiveUpdates = {
    _id: odAssetReceive._id,
    returnSuccess: odAssetReceive.returnSuccess,
    status: odAssetReceive.returnFailed.length > 1 ? constants.OD_ASSET_RECEIVE_STATE.归还中 : status,
    finishedAt: (odAssetReceive.returnFailed.length === 1) && (status === constants.OD_ASSET_RECEIVE_STATE.已经完成) ? new Date() : undefined
  };
  // 删除失败记录
  odAssetReceiveUpdates.$pull = { returnFailed: { code: asset.code } };
  // 添加成功记录
  odAssetReceive.returnSuccess.push({
    dispenser,
    code: asset.code,
    name: asset.name,
    backIntactCount: asset.backIntactCount,
    backBadCount: asset.backBadCount,
    time: new Date()
  });

  const newAsset = odAssetReceive.assets.search({ code: asset.code });
  newAsset.backIntactCount = asset.backIntactCount;
  newAsset.backBadCount = asset.backBadCount;
  newAsset.lostCount = newAsset.receiveCount - asset.backIntactCount - asset.backBadCount;
  newAsset.id = newAsset.id._id;
  odAssetReceiveUpdates.assets = odAssetReceive.assets;

  const bkAssetUpdates = {
    _id: bkAsset._id,
    $inc: {
      totalCount: asset.backBadCount + asset.backIntactCount,
      intactCount: asset.backIntactCount,
      damageCount: asset.backBadCount
    }
  };
  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount + asset.backIntactCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_receive',
      id
    }, {
      model: 'bk_asset',
      id: bkAsset._id
    }]
  });
  await Transaction.commit({
    tid,
    updates: [odAssetReceiveUpdates, bkAssetUpdates]
  });

};


module.exports = injectTransaction(exports, 'account.order.odAssetReceive.returnOne');
