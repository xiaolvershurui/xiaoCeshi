const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  isRetry: Joi.boolean().required(),
  dispenser: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    receiveCount: Joi.number(),
  }))
};


exports.handler = async function ({ id, assets, isRetry, dispenser }) {
  // 若存在未录入配件 直接报错
  const odAssetReceive = await ODAssetReceive.findById({
    id,
    selector: 'updatedAt status'
  });
  if (!odAssetReceive) throw new NotFoundError(`不存在领用单${id}`);
  if (![constants.OD_ASSET_RECEIVE_STATE.领用中, constants.OD_ASSET_RECEIVE_STATE.正在维修].includes(odAssetReceive.status)) throw new BadRequestError('该领用单不在进行中');
  const stAssets = await STAsset.findByCodes({ codes: assets.map(asset => asset.code), selector: 'type code' });
  const wrongAsset = assets.filter(asset => !stAssets.search({ code: asset.code }));
  if (wrongAsset.length > 0) throw new BadRequestError(`存在未录入配件${wrongAsset.map(asset => asset.code).join(',')}`);
  const assetMap = {};
  stAssets.forEach(stAsset => {
    assetMap[stAsset.code] = {
      name: stAsset.type
    }
  });
  // 初始化 所有配件是失败 重试时间
  if (!isRetry) arrayOp = {
    $push: {
      receiveSuccess: []
    }
  };
  const updateData = {
    id: odAssetReceive._id,
    updatedAt: odAssetReceive.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      receiveFailed: assets.map(asset => {
        return {
          dispenser,
          code: asset.code,
          name: assetMap[asset.code].name,
          count: asset.receiveCount,
          errMessage: '初始化',
          time: new Date()
        }
      }),
    }
  };
  if(!isRetry) updateData.arrayOp = {
    $push: {
      receiveSuccess: []
    }
  };
  await ODAssetReceive.update(updateData);
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetReceive/takeOne',
            params: {
              id,
              dispenser,
              asset: Object.assign(asset, {
                name: assetMap[asset.code].name
              }),
              status: count === assets.length ? constants.OD_ASSET_RECEIVE_STATE.正在维修 : constants.OD_ASSET_RECEIVE_STATE.领用中
            }
          });
        } catch (err) {
          console.error(err);
        }
      }
    })().catch(error => console.error(error));
  });
};

