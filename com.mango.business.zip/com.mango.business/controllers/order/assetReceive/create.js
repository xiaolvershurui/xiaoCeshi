const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BKAsset = require('../../../services/database/ebike/asset');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  dispenser: Joi.string().required(),
  station: Joi.string().required(),
  region: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    receiveCount: Joi.number(),
  }).required())
};

exports.handler = async function ({ user, station, region, dispenser, assets }) {
  const assetReceive = await ODAssetReceive.findByUser({
    user,
    status: [constants.OD_ASSET_RECEIVE_STATE.领用中, constants.OD_ASSET_RECEIVE_STATE.正在维修, constants.OD_ASSET_RECEIVE_STATE.归还中]
  });
  if (assetReceive) throw new BadRequestError('该用户有未完成的领用单');

  let limitResult = [];
  for (let asset of assets ) {
    const bkAsset = await BKAsset.findByCodeAndStation({
      code: asset.code,
      station,
      selector: 'intactCount totalCount'
    });
    if (!bkAsset) {
      const opStation = await OPBatteryStation.findById({ id: station, selector: 'name' });
      throw new NotFoundError(`${opStation.name}仓库下没有${asset.code}配件`);
    }
    if (bkAsset.intactCount < asset.receiveCount || bkAsset.intactCount < asset.totalCount) limitResult = [...limitResult, asset.code]
  }
  if (limitResult.length) throw new BadRequestError(`${limitResult.join(' ')}等配件出库数量大于在库数量，请与线上运营核对在库数量后再尝试`);

  const odAssetReceive = await ODAssetReceive.create({
    user,
    station,
    region,
    dispenser,
  });
  await this.exec({
    c: 'order/assetReceive/take',
    params: {
      id: odAssetReceive._id,
      dispenser,
      isRetry: false,
      assets
    }
  });
};
