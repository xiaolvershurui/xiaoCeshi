const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  dispenser: Joi.string().required(),
  isRetry: Joi.boolean().description('是否属于重试'),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    backIntactCount: Joi.number(),
    backBadCount: Joi.number()
  }))
};

exports.handler = async function ({ id, dispenser, assets, isRetry}) {
  const odAssetReceive = await ODAssetReceive.findById({
    id,
    selector: 'assets returnFailed updatedAt',
    populateSelector: {
      'assets.id': 'type'
    }
  });
  if (odAssetReceive.assets.length !== assets.length && isRetry!==true) throw new BadRequestError('请一次性还清配件');
  const assetMap = {};
  odAssetReceive.assets.forEach(asset => {
    if (!odAssetReceive.assets.search({ code: asset.code })) throw new BadRequestError('请一次性还清配件');
    assetMap[asset.code] = {
      name: asset.id.type
    }
  });

  // 初始化 所有归还配件失败 下次重试时间
  const now = new Date();
  await ODAssetReceive.update({
    id: odAssetReceive._id,
    updatedAt: odAssetReceive.updatedAt,
    data: {
      nextTry: now.getTime() + 3 * 60 * 1000, // 3分钟后重试
      returnFailed: assets.map(asset => {
        return {
          dispenser,
          code: asset.code,
          name: assetMap[asset.code].name,
          backIntactCount: asset.backIntactCount,
          backBadCount: asset.backBadCount,
          errMessage: '初始化',
          time: now
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetReceive/returnOne',
            params: {
              id,
              dispenser,
              asset: Object.assign(asset, {
                name: assetMap[asset.code].name
              }),
              status: count === assets.length ? constants.OD_ASSET_RECEIVE_STATE.已经完成 : constants.OD_ASSET_RECEIVE_STATE.归还中
            }
          });
        } catch (err) {
          console.error(err);
        }
      }
    })().catch(err => console.error(err))
  })
};

