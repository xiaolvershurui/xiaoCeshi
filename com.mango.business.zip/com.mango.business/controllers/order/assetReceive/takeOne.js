const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  dispenser: Joi.string().required(),
  asset: Joi.object({
    code: Joi.string(),
    name: Joi.string(),
    receiveCount: Joi.number(),
  }).required(),
  status: Joi.number().required()
};

exports.handler = async ({ id, asset, status, dispenser }, tid, Transaction) => {
  const odAssetReceive = await ODAssetReceive.findById({
    id,
    selector: 'region station assets receiveFailed receiveSuccess'
  });
  const assetData = await STAsset.findByCode({ code: asset.code, selector: 'code type' });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetReceive.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });
  const exists = odAssetReceive.assets.search({ code: asset.code });
  if (exists) {
    exists.receiveCount += asset.receiveCount
  } else {
    odAssetReceive.assets.push({
      id: assetData._id,
      code: asset.code,
      receiveCount: asset.receiveCount
    });
  }
  // 添加成功记录
  odAssetReceive.receiveSuccess[odAssetReceive.receiveSuccess.length - 1].push({
    dispenser,
    code: asset.code,
    name: asset.name,
    count: asset.receiveCount,
    time: new Date()
  });
  const assetReceiveUpdates = {
    _id: odAssetReceive._id,
    assets: odAssetReceive.assets,
    receiveSuccess: odAssetReceive.receiveSuccess
  };
  // 删除失败记录
  assetReceiveUpdates.$pull = { receiveFailed: { code: asset.code } };
  // 状态变更
  assetReceiveUpdates.status = odAssetReceive.receiveFailed.length > 1 ? constants.OD_ASSET_RECEIVE_STATE.领用中 : status;

  const bkAssetUpdates = {
    _id: bkAsset._id,
    $inc: {
      totalCount: -asset.receiveCount,
      intactCount: -asset.receiveCount
    }
  };
  if (bkAsset.purchaseCount) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount - asset.receiveCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_receive',
      id: odAssetReceive._id
    }, {
      model: 'bk_asset',
      id: bkAsset._id
    }]
  });

  await Transaction.commit({
    tid,
    updates: [assetReceiveUpdates, bkAssetUpdates]
  });
};


module.exports = injectTransaction(exports, 'account.order.odAssetReceive.takeOne');
