const Joi = require('poolishark').Joi;
const ODAssetReceive = require('../../../services/database/order/assetReceive');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  dispenser: Joi.string().required()
};

exports.handler = async function ({ id, dispenser }) {
  const assetReceive = await ODAssetReceive.findById({
    id,
    selector: 'status receiveFailed returnFailed nextTry'
  });
  if (!assetReceive) throw new NotFoundError('不存在该领用单');
  if (![constants.OD_ASSET_RECEIVE_STATE.归还中, constants.OD_ASSET_RECEIVE_STATE.领用中].includes(assetReceive.status)) throw new BadRequestError('非领用/归还中无法重试');
  if (new Date().getTime() < assetReceive.nextTry.getTime()) throw  new BadRequestError('您重试太频繁了,请稍后再试');
  if (assetReceive.status === constants.OD_ASSET_RECEIVE_STATE.领用中) {
    await this.exec({
      c: 'order/assetReceive/take',
      params: {
        id,
        isRetry: true,
        dispenser,
        assets: assetReceive.receiveFailed.map(asset => {
          return {
            code: asset.code,
            receiveCount: asset.count
          }
        })
      }
    });
  } else {
    await this.exec({
      c: 'order/assetReceive/returnBack',
      params: {
        id,
        dispenser,
        isRetry: true,
        assets: assetReceive.returnFailed.map(asset => {
          return {
            code: asset.code,
            backIntactCount: asset.backIntactCount,
            backBadCount: asset.backBadCount
          }
        })
      }
    });
  }
};
