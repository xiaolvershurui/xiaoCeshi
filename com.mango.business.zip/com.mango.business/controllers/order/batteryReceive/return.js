const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.object({
    id: Joi.string(),
    time: Joi.date()
  })),
  receiver: Joi.string().required(),
  station: Joi.string().required(),
  unknownCount: Joi.number().required()
};

exports.handler = async function ({ id, receiver, batteries, station, unknownCount }) {
  process.nextTick(_ => {
    (async _ => {
      // 对每个电池进行领用
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryReceive/returnOne',
            params: {
              id,
              station,
              unknownCount,
              receiver,
              battery: battery.id,
              status: count === batteries.length ? constants.OD_BATTERY_RECEIVE_STATUS.已完成 : constants.OD_BATTERY_RECEIVE_STATUS.归还处理中
            }
          });
        } catch (err) {
          console.error(err);
        }
      }
    })().catch(error => console.error(error));
  });
};