const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  receiver: Joi.string().required(),
  dispenser: Joi.string(),
  station: Joi.string(),
  batteries: Joi.array().items(Joi.object({
    id: Joi.string()
  }))
};


exports.handler = async function ({ id, receiver, dispenser, batteries, station }) {
  process.nextTick(_ => {
    (async _ => {
      // 对每个电池进行领用
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryReceive/takeOne',
            params: {
              id,
              receiver,
              station,
              dispenser,
              battery: battery.id,
              status: count === batteries.length ? constants.OD_BATTERY_RECEIVE_STATUS.维修占用 : constants.OD_BATTERY_RECEIVE_STATUS.领用处理中
            }
          });
        } catch (err) {
          console.error(err);
        }
      }
    })().catch(error => console.error(error));
  });
};
