const Joi = require('poolishark').Joi;
const ODBatteryReceive = require('../../../services/database/order/batteryReceive');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
 id: Joi.string()
};

exports.handler = async function ({id}){
  const odBatteryInspect = await ODBatteryReceive.findById({
    id,
    selector: 'dispenser status user receiveFailed returnFailed nextTry'
  });
  if([constants.OD_BATTERY_RECEIVE_STATUS.领用处理中,constants.OD_BATTERY_RECEIVE_STATUS.归还处理中].includes(odBatteryInspect.status)){
    if(new Date().getTime() < new Date(odBatteryInspect.nextTry).getTime()){
      throw new BadRequestError(`重试过于频繁请在${(new Date(odBatteryInspect.nextTry)).toLocaleString()}后重试。`)
    }
    if(odBatteryInspect.status === constants.OD_BATTERY_RECEIVE_STATUS.领用处理中){
      // 领用失败
      const retryReceive = {
        dispenser: odBatteryInspect.receiveFailed[0].dispenser,
        station: odBatteryInspect.receiveFailed[0].station,
        receiver: odBatteryInspect.user._id,
        batteries: []
      };
      odBatteryInspect.receiveFailed.map(r=>{
        retryReceive.batteries.push({id: r.id})
      });
      await this.exec({
        c: 'order/batteryInspect/take',
        params: {
          id,
          dispenser: retryReceive.dispenser,
          station: retryReceive.station,
          receiver: retryReceive.receiver,
          batteries: retryReceive.batteries
        }
      });
    }else{
      // 归还失败
      const retryReturn = {
        receiver: odBatteryInspect.returnFailed[0].receiver,
        station: odBatteryInspect.returnFailed[0].station,
        unknownCount: odBatteryInspect.unknownCount,
        batteries: []
      };
      odBatteryInspect.returnFailed.map(r=>{
        retryReturn.batteries.push({id: r.id})
      });
      await this.exec({
        c: 'order/batteryReceive/return',
        params: {
          id,
          dispenser: retryReturn.dispenser,
          station: retryReturn.station,
          receiver: retryReturn.receiver,
          batteries: retryReturn.batteries
        }
      });
    }
  }
  await ODBatteryReceive.update({
    id,
    data: {
      nextTry: new Date()
    }
  })
};