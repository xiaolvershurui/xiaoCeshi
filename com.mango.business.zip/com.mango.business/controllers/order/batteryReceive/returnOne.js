const Joi = require('poolishark').Joi;
const ODBatteryInspect = require('../../../services/database/order/batteryInspect');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');



exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string().required(),
  station: Joi.string().required(),
  status: Joi.number().required(),
  receiver: Joi.string().required(),
  unknownCount: Joi.number().required()
};

exports.handler = async function ({ id, receiver, battery, station, status, unknownCount }, tid, Transaction) {
 const odBatteryInspect = await  ODBatteryInspect.findById({
    id,
    selector: 'returnSuccess.number returnSuccess.unknownCount  returnSuccess.isUnknownReturn'
  });
  const findAndLocks = [
    {
      model: 'od_battery_inspect',
      id,
    }, {
      model: 'bk_battery',
      id: battery
    }
  ];
 const updates = [
   {
     _id: id,
     $pull:{
       "returnFailed":{ id: battery }
     },
     $set: {
       'returnSuccess.status': status,
     },
     $push:{
       'returnSuccess.batteries': {
         id: battery,
         time: new Date()
       }
     }
   }, {
     _id: battery,
     $set: {
       locate: constants.BK_BATTERY_LOCATE.在运营站,
       inspector: receiver
     }
   }
 ];
   if( status === constants.OD_BATTERY_RECEIVE_STATUS.已完成 ){
      updates[0].$set['finishedAt'] = new Date();
   }
  if(odBatteryInspect.returnSuccess.isUnknownReturn === false){
    updates[0].$set['returnSuccess.unknownCount'] = unknownCount;
    updates[0].$set['returnSuccess.isUnknownReturn'] = true;
    findAndLocks.push({
      model: 'op_battery_station',
      id: station
    });
    updates.push({
      _id: station,
      $inc:{
        'battery.unknownCount': unknownCount
      }
    });
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: findAndLocks
  });
  await Transaction.commit({
    tid,
    updates: updates
  });
};

module.exports = injectTransaction(exports, 'order.batteryReceive.returnOne');