const Joi = require('poolishark').Joi;
const ODBatteryInspect = require('../../../services/database/order/batteryInspect');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');
const BKBattery = require('../../../services/database/ebike/battery');

exports.validate = {
  id: Joi.string(),
  station: Joi.string(),
  dispenser: Joi.string(),
  batteries: Joi.array().items(Joi.object({
    id: Joi.string()
  }))
};

exports.handler = async function ({ id, station, dispenser, batteries }) {
  const bkBattery = await BKBattery.find({
    query:{
      _id: {
        $in: batteries.map((b)=>{
          return b.id
        })
      },
      station,
      locate: constants.BK_BATTERY_LOCATE.在运营站
    },
    limit: 0,
    selector: 'status'
  });
  if(bkBattery.length !== batteries.length){
    const exceptions = batteries.filter(b=> {
      const thisBattery = bkBattery.search({ _id: b.id });
      if(!thisBattery){
        return b.id
      }
    });
    throw new BadRequestError(`${exceptions.join('')} 状态异常或不存在`);
  }
 const odBatteryInspect = await ODBatteryInspect.findById({
    id,
    selector: 'status user'
  });
 if( odBatteryInspect.status === constants.OD_BATTERY_RECEIVE_STATUS.领用处理中 ){
   throw new BadRequestError(`当前维修电池领用单状态异常(上次未领取或已经完成),请尝试重试`);
 }
  const receiveObj = batteries.map(b=>{
    return {
      id: b.id,
      station,
      dispenser,
      time: new Date()
    }
  });
  await ODBatteryInspect.update({
    id,
    data: {
      receiveFailed: receiveObj,
      nextTry: new Date(Date.now()+ 180000)
    }
  });
  await this.exec({
    c: 'order/batteryReceive/take',
    params: {
      id,
      dispenser,
      station,
      receiver: odBatteryInspect.user._id,
      batteries
    }
  });
};