const Joi = require('poolishark').Joi;
const ODBatteryInspect = require('../../../services/database/order/batteryInspect');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  receiver: Joi.string().required(),
  station: Joi.string().required(),
  dispenser: Joi.string().required(),
  battery: Joi.string().required(),
  status: Joi.number().required()
};

exports.handler = async ({ id, receiver, station, dispenser, status, battery }, tid, Transaction) => {
  const odBatteryInspect =  await ODBatteryInspect.findById({
    id,
    selector: 'receiveSuccess'
  });
  const receiveSuccess = odBatteryInspect.receiveSuccess;
  receiveSuccess.map(r=>{
    r.station =  r.station._id;
  });
  const thisStation = receiveSuccess.search({station: station});
  if(!thisStation){
    receiveSuccess.push({
      station,
      dispenser,
      time: new Date(),
      batteries: [{
        id: battery,
        time: new Date()
      }]
    })
  }else{
    thisStation.batteries.push({
      id: battery,
      time: new Date()
    })
  }
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_battery_inspect',
      id
    }, {
      model: 'bk_battery',
      id: battery
    }]
  });

  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $pull:{
        "receiveFailed":{ id: battery }
      },
      $set: {
        status,
        receiveSuccess
      }
    }, {
      _id: battery,
      $set: {
        locate: constants.BK_BATTERY_LOCATE.维修占用,
        inspector: receiver
      }
    }]
  });
};


module.exports = injectTransaction(exports, 'order.batteryReceive.takeOne');
