const Joi = require('poolishark').Joi;
const ODBatteryDamage = require('../../../services/database/order/batteryDamage');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function ( { id, user } ) {
  const batteryDamage = await ODBatteryDamage.findById({ id, selector: 'status damageFailed nextTry' });
  if (!batteryDamage) throw new NotFoundError('不存在该报损单');

  if (batteryDamage.nextTry) {
    if (new Date().getTime() < batteryDamage.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }

  if (batteryDamage.status === constants.OD_BATTERY_DAMAGE_STATUS.报损中) {
    await this.exec({
      c: 'order/batteryDamage/damage',
      params: {
        id,
        batteries: batteryDamage.damageFailed.map(battery => battery.id._id)
      }
    })
  }
};
