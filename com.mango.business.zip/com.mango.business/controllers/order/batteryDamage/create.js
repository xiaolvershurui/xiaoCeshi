const Joi = require('poolishark').Joi;
const ODBatteryDamage = require('../../../services/database/order/batteryDamage');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ user, station, batteries }) {
  batteries = [... new Set(batteries)];
  const bkBBatteries = (await BKBattery.find({
    query: {
      QRCode: {
        $in: batteries,
      },
      state: constants.BK_BATTERY_STATE.完好,
      locate: constants.BK_BATTERY_LOCATE.在运营站,
    },
    limit: 0,
  })).map(item => item._id);

  if (bkBBatteries.length !== batteries.length) throw new BadRequestError('存在电池状态不正确，请重新检测');

  const acUser = ACUser.findById({ id: user });
  if (!acUser) throw new NotFoundError(`未找到用户：${user}`);
  const opBatteryStation = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!opBatteryStation) throw new NotFoundError(`未找到仓库：${station}`);
  const opRegion = opBatteryStation.region._id;

  const isExistsOdBatteryDamage =  await ODBatteryDamage.findByUser({ user, status: constants.OD_BATTERY_DAMAGE_STATUS.报损中 });
  if (isExistsOdBatteryDamage) throw new BadRequestError('该用户有正在报损中报损单');

  if (!batteries.length) throw new BadRequestError('请报废至少一个电池');

  // const batteryDetails = await BKBattery.findByIds({ ids: batteryIds, selector: '_id region station locate state' });
  // const allInStationAndIntact = batteryDetails.every(batteryDetail => {
  //   return batteryDetail.locate === constants.BK_BATTERY_LOCATE.在运营站 && batteryDetail.state === constants.BK_BATTERY_STATE.完好
  // });
  //
  // if (!allInStationAndIntact) throw new BadRequestError ('有电池不在运营站或存在已报废电池');

  const odBatteryDamage = await ODBatteryDamage.create({
    user,
    region: opRegion,
    station: opBatteryStation._id,
  });

  await this.exec({
    c: 'order/batteryDamage/damage',
    params: {
      id: odBatteryDamage._id,
      batteries: bkBBatteries
    }
  })
};
