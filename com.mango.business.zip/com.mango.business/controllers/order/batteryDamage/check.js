const Joi = require('poolishark').Joi;
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  batteries: Joi.array().items(Joi.string()),
};

exports.handler = async ({ batteries }) => {
  // const bkBatteries = [... new Set(batteries)];
  // if (bkBatteries.length !== batteries.length) throw new BadRequestError(`存在重复二维码，请仔细检查`);

  const bkBatteries = await BKBattery.find({
    query: {
      QRCode: {
        $in: batteries,
      },
      // state: constants.BK_BATTERY_STATE.完好,
      // locate: constants.BK_BATTERY_LOCATE.在运营站,
    },
    limit: 0,
    selector: 'state locate QRCode',
  });

  return batteries.reduce((memo, item) => {
    const s = bkBatteries.find(i => i.QRCode === item);
    if (!s) {
      memo = [...memo, Object.assign({ notFound: true }, { QRCode: item })];
    } else {
      if (s.state !== constants.BK_BATTERY_STATE.完好) {
        Object.assign(s, { notIntact: true });
      }
      if (s.locate !== constants.BK_BATTERY_LOCATE.在运营站) {
        Object.assign(s, { notInStation: true });
      }
      memo = [...memo, s];
    }
    return memo;
  }, []).map(item => {
    if (item.notFound) {
      return {
        QRCode: item.QRCode,
        shouldNotCommitReason: `${item.QRCode}不存在`,
      };
    } else if (item.notIntact || item.notInStation) {
      return {
        _id: item._id,
        QRCode: item.QRCode,
        shouldNotCommitReason: `
          ${item.notIntact ? '状态应为完好, ' : ''}
          ${item.notInStation ? '去向应为在运营站' : ''}
        `,
      };
    } else {
      return {
        _id: item._id,
        QRCode: item.QRCode,
      };
    }
  });
};
