const Joi = require('poolishark').Joi;
const ODBatteryDamage = require('../../../services/database/order/batteryDamage');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ id, batteries }) {
  const odBatteryDamage = await ODBatteryDamage.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryDamage) throw new NotFoundError(`不存在报损单:${id}`);

  if (odBatteryDamage.status !== constants.OD_BATTERY_DAMAGE_STATUS.报损中) throw new BadRequestError('该报损单不在报损中');

  await ODBatteryDamage.update({
    id: odBatteryDamage._id,
    updatedAt: odBatteryDamage.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      damageFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryDamage/damageOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_DAMAGE_STATUS.已完成 : constants.OD_BATTERY_DAMAGE_STATUS.报损中
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};
