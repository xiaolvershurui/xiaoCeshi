const Joi = require('poolishark').Joi;
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ODAssetRepair = require('../../../services/database/order/assetRepair');
exports.validate = {
  id: Joi.string().required(),
  receiver: Joi.string().required(),
  isFinished: Joi.boolean().required(),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    code: Joi.string(),
    damageCount: Joi.number(),
    intactCount: Joi.number(),
    bkAsset: Joi.string()
  }).unknown())
};
exports.handler = async function ({ id, receiver, isFinished, assets }) {
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetRepair/returnOne',
            params: {
              id,
              asset,
              status: count === assets.length ? constants.OD_ASSET_REPAIR_STATE.部分归还 : constants.OD_ASSET_REPAIR_STATE.归还中,
              isFinished,
              receiver
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => console.error(error));
  });
};