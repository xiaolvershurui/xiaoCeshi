const Joi = require('poolishark').Joi;
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ODAssetRepair = require('../../../services/database/order/assetRepair');
exports.validate = {
  id: Joi.string().required(),
  assets: Joi.array().items(Joi.object()),
};
exports.handler = async function ({ id, assets }) {
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetRepair/takeOne',
            params: {
              id,
              asset,
              status: count === assets.length ? constants.OD_ASSET_REPAIR_STATE.正在维修 : constants.OD_ASSET_REPAIR_STATE.创建中
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => console.error(error));
  });
};