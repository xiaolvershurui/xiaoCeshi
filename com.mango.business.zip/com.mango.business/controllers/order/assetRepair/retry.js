const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ODAssetRepair = require('../../../services/database/order/assetRepair');


exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ({ id }) {
  const odAssetRepair = await ODAssetRepair.findById({
    id,
    selector: 'status createFailed toFinish dispenser receiver returnBackFailed nextTry'
  });
  const nextTry = new Date(odAssetRepair.nextTry);
  if(nextTry.getTime()>Date.now()){
    throw new Error(`请在${nextTry.toLocaleString()}后重试`);
  }
  if(!odAssetRepair){
    throw new NotFoundError('未找到此返修单');
  }
  if(![constants.OD_ASSET_REPAIR_STATE.归还中,constants.OD_ASSET_REPAIR_STATE.创建中].includes(odAssetRepair.status)){
    if(odAssetRepair.status===constants.OD_ASSET_REPAIR_STATE.创建中){
      await this.exec({
        c: 'order/assetRepair/take',
        params: {
          id,
          assets: odAssetRepair.createFailed
        }
      });
    }
    if(odAssetRepair.status===constants.OD_ASSET_REPAIR_STATE.归还中){
      await this.exec({
        c: 'order/assetRepair/return',
        params: {
          id: id,
          receiver: odAssetRepair.returnBackFailed[0].receiver,
          isFinished: odAssetRepair.toFinish,
          endAssets: odAssetRepair.returnBackFailed,
        }
      });
    }
  }else{
    throw new Error('订单状态属于非可重试状态')
  }
};