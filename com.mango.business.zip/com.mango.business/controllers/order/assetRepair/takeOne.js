const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');
const ODAssetRepair = require('../../../services/database/order/assetRepair');
const BKAsset = require('../../../services/database/ebike/asset');

exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object(),
  status: Joi.number(),
};

exports.handler = async ({id, asset, status}, tid, Transaction) => {
  const odAssetRepair  = await ODAssetRepair.findById({
    id,
    selector: 'region station assets'
  });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetRepair.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });

  const bkAssetUpdates = {
    _id:asset.bkAsset,
    $inc: {
      totalCount: - asset.outboundCount,
      damageCount: - asset.outboundCount,
      repairCount: + asset.outboundCount
    }
  };

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'od_asset_repair'
    }, {
      id: asset.bkAsset,
      model: 'bk_asset'
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $push: {
        assets: {
          id: asset.id,
          code: asset.code,
          outboundCount: asset.outboundCount
        }
      },
      $pull: {
        createFailed:{
          id: asset.id
        }
      },
      $set: {
        status
      }
    }, bkAssetUpdates]
  });
};
module.exports = injectTransaction(exports, 'account.order.assetRepair.takeOne');
