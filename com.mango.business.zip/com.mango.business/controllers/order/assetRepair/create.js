const Joi = require('poolishark').Joi;
const ODAssetRepair = require('../../../services/database/order/assetRepair');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');

exports.validate = {
  dispenser: Joi.string().required(),
  region: Joi.string().required(),
  station: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    outboundCount: Joi.number()
  }))
};

exports.handler = async function ({ dispenser, region, station, assets }) {
  const acUser = await ACUser.findById({
    id: dispenser
  });
  if(!acUser){
    throw new NotFoundError('不存在此运营人员');
  }
  const stAssets = await STAsset.find({
    query: {
      code: {
        $in: assets.map(asset=>{
          return asset.code
        })
      }
    },
    limit: 0,
    selector: '_id code'
  });
  if( stAssets.length!==assets.length ){
    const noExist= stAssets.filter(stAsset=>!assets.search({code: stAsset.code}));
    throw new NotFoundError(`配件列表不存在此配件${noExist}`);
  }
  const bkAssets = await BKAsset.find({
    query: {
      station,
      asset: {
        $in: stAssets.map(asset=>{
          return asset._id
        })
      }
    },
    selector:'asset _id',
    limit: 0,
  });
  bkAssets.map(bkAsset=>{
    bkAsset.asset = bkAsset.asset._id
  });
  if(bkAssets.length!==assets.length){
    const noExist= bkAssets.filter(stAsset=>!assets.search({code: stAsset.code}));
    throw new NotFoundError(`仓库不存在此配件${noExist}`);
  }
  assets.map(asset=> {
    const thisAssets = stAssets.search({code: asset.code});
    const thisBkAsset = bkAssets.search({asset: thisAssets._id});
    asset.bkAsset = thisBkAsset._id;
    asset.id = thisAssets._id
  });
  const assetRepairId = await ODAssetRepair.create({
    station,
    status: constants.OD_ASSET_REPAIR_STATE.创建中,
    region,
    dispenser,
    createFailed:assets,
    nextTry: Date.now()+120000
  });
  await this.exec({
    c: 'order/assetRepair/take',
    params: {
      id: assetRepairId._id,
      assets
    }
  });
};
