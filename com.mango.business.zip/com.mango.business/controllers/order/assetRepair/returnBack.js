const Joi = require('poolishark').Joi;
const ODAssetRepair = require('../../../services/database/order/assetRepair');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUser = require('../../../services/database/account/user');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');

exports.validate = {
  id: Joi.string().required(),
  receiver: Joi.string().required(),
  isFinished: Joi.boolean(),
  assets: Joi.array().items(Joi.object({
    id: Joi.string().required(),
    code: Joi.string().required(),
    damageCount: Joi.number().required(),
    intactCount: Joi.number().required(),
  }))
};

exports.handler = async function ({ id, receiver, isFinished, assets }) {
  const acUser = await ACUser.findById({
    id: receiver,
  });
  if (!acUser) {
    throw new NotFoundError(`未找到 接收人:${id}`);
  }
  const assetRepair = await ODAssetRepair.findById({
    id,
    selector: 'assets station status returnBackFailed updatedAt'
  });
  if (!assetRepair) {
    throw new NotFoundError('该返修单不存在');
  }
  if(![constants.OD_ASSET_REPAIR_STATE.正在维修,constants.OD_ASSET_REPAIR_STATE.部分归还].includes(assetRepair.status)){
    throw new BadRequestError('返修单状态异常，请尝试重试');
  }
  const stAssets = await STAsset.find({
    query:{
      _id: {
        $in: assets.map(asset=>{
          return asset.id
        })
      }
    }
  });
  if(stAssets.length!==assets.length){
    const noExist= assets.filter(asset=>!stAssets.search({_id: asset.id}));
    throw new NotFoundError(`仓库不存在此配件${JSON.stringify(noExist,null,2)}`);
  }
  const bkAssets = await BKAsset.find({
    query:{
      station: assetRepair.station._id,
      asset: {
        $in: assets.map(asset=>{
          return asset.id
        })
      }
    },
    selector:'_id asset',
    limit: 0,
  });
  bkAssets.map(bkAsset=>{
    const thisAsset = assets.search({id: bkAsset.asset._id});
    if(thisAsset){
      thisAsset.bkAsset = bkAsset._id;
      thisAsset.receiver = receiver
    }
  });
  await ODAssetRepair.update({
    id,
    data: {
      returnBackFailed: assets,
      nextTry: Date.now() + 120000,
      toFinish: isFinished,
    },
    status: constants.OD_ASSET_REPAIR_STATE.归还中,
    updatedAt: assetRepair.updatedAt
  });
  return await this.exec({
    c: 'order/assetRepair/return',
    params: {
      id: assetRepair._id,
      assets,
      receiver,
      isFinished
    }
  });
};
