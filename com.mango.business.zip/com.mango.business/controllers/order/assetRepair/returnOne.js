const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');
const ODAssetRepair = require('../../../services/database/order/assetRepair');
const BKAsset = require('../../../services/database/ebike/asset');

exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object().required(),
  status: Joi.number().required(),
  isFinished: Joi.boolean().required(),
  receiver: Joi.string().required()
};

exports.handler = async ({id, asset, receiver, status, isFinished}, tid, Transaction) => {
  const odAssetRepair = await ODAssetRepair.findById({
    id,
    selector: 'updatedAt assets station'
  });

  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetRepair.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });
  let record={};
  odAssetRepair.assets.map(odasset => {
    if (odasset.id._id === asset.id) {
      odasset.damageCount = asset.damageCount;
      odasset.intactCount = asset.intactCount;
      record.damageCount = asset.damageCount;
      record.intactCount = asset.intactCount;
      record.id = asset.id;
      record.code = odasset.code;
      record.receiver = receiver
    }
  });
  const odAssetUpdates = {
    _id: id,
    $pull: {
      returnBackFailed: {
        id: asset.id
      }
    },
    $set:{
      assets: odAssetRepair.assets,
      status,
    },
    $push: {
      records: record
    }
  };
  if (status === constants.OD_ASSET_REPAIR_STATE.部分归还 && isFinished === true) {
    odAssetUpdates.$set.finishedAt = Date.now();
    odAssetUpdates.$set.status = constants.OD_ASSET_REPAIR_STATE.已经结束;
  }

  const bkAssetUpdates = {
    _id: asset.bkAsset,
    $inc: {
      totalCount: (asset.intactCount + asset.damageCount),
      intactCount: asset.intactCount,
      damageCount: asset.damageCount
    }
  };

  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount + asset.intactCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'od_asset_repair',
    }, {
      id: asset.bkAsset,
      model: 'bk_asset',
    }]
  });
  await Transaction.commit({
    tid,
    updates: [odAssetUpdates, bkAssetUpdates],
  });
};
module.exports = injectTransaction(exports, 'account.order.assetRepair.returnOne');