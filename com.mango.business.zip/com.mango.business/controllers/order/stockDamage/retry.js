const Joi = require('poolishark').Joi;
const ODStockDamage = require('../../../services/database/order/stockDamage');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const stockDamage = await ODStockDamage.findById({
    id,
    selector: 'status damageFailed nextTry'
  });
  if (!stockDamage) throw new NotFoundError('不存在该置损单');
  if (constants.OD_STOCK_DAMAGE.正在进行 !== stockDamage.status) throw new BadRequestError('置损单不在进行中，请检查后重试');
  if (stockDamage.nextTry) {
    if (new Date().getTime() < stockDamage.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (stockDamage.status === constants.OD_STOCK_DAMAGE.正在进行) {
    await this.exec({
      c: 'order/stockDamage/damage',
      params: {
        id,
        stocks: stockDamage.damageFailed.map(item => item._id)
      }
    })
  }
};
