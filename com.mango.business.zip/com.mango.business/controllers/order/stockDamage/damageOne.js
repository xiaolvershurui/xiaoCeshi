const Joi = require('poolishark').Joi;
const ODStockDamage = require('../../../services/database/order/stockDamage');
const BKStock = require('../../../services/database/ebike/stock');
const RCStockOp = require('../../../services/database/record/stockOp');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stock: Joi.string().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date(),
};

exports.handler = async ({ id, stock, status, finishedAt }, tid, Transaction) => {
  const bkStock = await BKStock.findById({ id: stock, selector: 'number.custom style repairStatus' });
  if (!bkStock) throw new NotFoundError(`车辆${stock}不存在`);

  const odStockDamage = await ODStockDamage.findById({
    id,
    selector: 'region station driver storeManager stocks damageFailed damageSuccess',
    populateSelector: {
      storeManager: '_id cert.name auth.tel profile.avator',
      station: 'name'
    }
  });
  if (!odStockDamage) throw new NotFoundError(`置损单${id}不存在`);
  // 添加成功
  odStockDamage.damageSuccess.push(stock);
  const odStockDamageUpdates = {
    _id: id,
    $pull: {
      damageFailed: stock,
    },
    $addToSet: {
      damageSuccess: stock,
    },
    $set: {
      status,
      finishedAt,
    }
  };

  // 车辆操作记录
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_stock_damage',
      id: odStockDamage._id,
    }, {
      model: 'bk_stock',
      id: stock,
    }, {
      model: 'rc_stock_op',
    }],
  });

  await Transaction.commit({
    tid,
    updates: [odStockDamageUpdates, {
      _id: stock,
      $set: {
        repairStatus: constants.BK_REPAIR_STATUS.需要维修,
        damageTime: new Date()
      },
    }, {
      stock,
      stockNo: bkStock.number && bkStock.number.custom,
      type: constants.RC_STOCK_OP_TYPE.添加损坏,
      region: odStockDamage.region._id,
      style: bkStock.style._id,
      operatedAt: new Date(),
      operator: odStockDamage.storeManager && odStockDamage.storeManager._id,
      operatorTel: odStockDamage.storeManager && odStockDamage.storeManager.auth.tel,
      operatorName: odStockDamage.storeManager && odStockDamage.storeManager.cert.name,
      operatorAvator: odStockDamage.storeManager && odStockDamage.storeManager.profile.avator,
      description: `将车牌号为${bkStock.number && bkStock.number.custom}的车辆维修状态置为需要维修`,
      addDamage: {
        prevRepairStatus: bkStock.repairStatus,
        nextRepairStatus: constants.BK_REPAIR_STATUS.需要维修
      }
    }],
  });
};

module.exports = injectTransaction(exports, 'account.order.odStockDamage.damageOne');
