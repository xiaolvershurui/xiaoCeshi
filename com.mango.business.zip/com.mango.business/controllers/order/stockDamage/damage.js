const Joi = require('poolishark').Joi;
const ODStockDamage = require('../../../services/database/order/stockDamage');
const BKStock = require('../../../services/database/ebike/stock');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stocks: Joi.array().items(Joi.string())
};

exports.handler = async function ( { id, stocks } ) {
  const odStockDamage =  await ODStockDamage.findById({
    id,
    selector: '_id updatedAt status'
  });
  if (!odStockDamage) throw new NotFoundError('该置损单不存在');

  if (constants.OD_STOCK_DAMAGE.正在进行 !== odStockDamage.status) throw new BadRequestError('该置损单不在进行中');

  const bkStocks = await BKStock.find({query: {
    _id: {
      $in: [...new Set(stocks)]
    }
  }});
  if (bkStocks.length !== stocks.length) throw new BadRequestError('有车辆不存在');
  // 初始化
  await ODStockDamage.update({
    id: odStockDamage._id,
    updatedAt: odStockDamage.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000,
      damageFailed: bkStocks.map(item => item._id)
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let stock of bkStocks) {
        count++;
        try {
          await this.exec({
            c: 'order/stockDamage/damageOne',
            params: {
              id,
              stock: stock._id,
              status: count === bkStocks.length ? constants.OD_STOCK_DAMAGE.已经完成 : constants.OD_STOCK_DAMAGE.正在进行,
              finishedAt: count === bkStocks.length ? new Date() : undefined
            }
          })
        } catch (err) {
          count--;
          console.error(err);
        }
      }
    })()
  })
};
