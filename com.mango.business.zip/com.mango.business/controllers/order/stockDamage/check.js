const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BKStock = require('../../../services/database/ebike/stock');

exports.validate = Joi.object({
  stocks: Joi.array().items(Joi.object()),
  station: Joi.string().required(),
}).unknown();

exports.handler = async function({ stocks, station }) {
  let bkStocks = [];
  let s;
  for (let stock of stocks) {
    if (stock.number) {
      s = await BKStock.findByNumber(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: { custom: stock.number }, notFound: true }];
    } else if (stock.vin) {
      s = await BKStock.findByVin(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: { vin: stock.vin }, notFound: true }];
    } else if (stock.box) {
      s = await BKStock.findByBox(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { box: stock.box, notFound: true }];
    }
  }

  const a = bkStocks.reduce((memo, item) => {
    const reason = {};
    if (item.notFound) {
      reason.shouldNotCommitReason = `${item.number.custom || item.number.vin || item.box}不存在`;
    } else if (item.locate !== constants.BK_LOCATE.仓库 || item.repairStatus !== constants.BK_REPAIR_STATUS.不需要维修 || (item.station && item.station._id) !== station) {
      reason.shouldNotCommitReason = `
        ${item.locate !== constants.BK_LOCATE.仓库 ? '去向应为仓库, ' : ''}
        ${item.repairStatus !== constants.BK_REPAIR_STATUS.不需要维修 ? '维修状态应为不需要维修, ' : ''}
        ${(item.station && item.station._id) !== station ? '该车辆不在您当前所在的仓库, 请联系线上运营, ' : ''}
      `;
    }
    Reflect.deleteProperty(item, 'repairStatus');
    Reflect.deleteProperty(item, 'locate');
    Reflect.deleteProperty(item, 'station');
    memo = [...memo, Object.assign({}, item, reason)];
    return memo;
  }, []);

  console.log(a)
  return a
};
