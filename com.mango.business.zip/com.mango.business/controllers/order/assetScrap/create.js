const Joi = require('poolishark').Joi;
const ODAssetScrap = require('../../../services/database/order/assetScrap');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');


exports.validate = {
  dispenser: Joi.string().required(),
  region: Joi.string().required(),
  station: Joi.string().required(),
  assets: Joi.array().items({
    code: Joi.string().required(),
    intactCount: Joi.number().required(),
    damageCount: Joi.number().required()
  })
};

exports.handler = async function ({ dispenser, region, station, assets }) {
  const _user = ACUser.findById({ id: dispenser });
  if (!_user) throw new NotFoundError(`未找到用户：${dispenser}`);

  const _region = OPRegion.findById({ id: region });
  if (!_region) throw new NotFoundError(`未找到大区：${region}`);

  const _station = OPRegion.findById({ id: station });
  if (!_station) throw new NotFoundError(`未找到仓库：${region}`);

  const assetScrap =  await ODAssetScrap.findByUser({
    user: dispenser,
    status: constants.OD_ASSET_SCRAP_STATE.正在进行
  });
  if (assetScrap) throw new BadRequestError('该用户有正在进行的报废单');

  const odAssetScrap = await ODAssetScrap.create({
    dispenser,
    station,
    region,
    assets: []
  });
  await this.exec({
    c: 'order/assetScrap/scrap',
    params: {
      id: odAssetScrap._id,
      assets
    }
  })
};
