const Joi = require('poolishark').Joi;
const ODAssetScrap = require('../../../services/database/order/assetScrap');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object({
    code: Joi.string(),
    name: Joi.string(),
    intactCount: Joi.number(),
    damageCount: Joi.number(),
  }).required(),
  status: Joi.number().required()
};

exports.handler = async ({ id, asset, status }, tid, Transaction) => {
  const odAssetScrap  = await ODAssetScrap.findById({
    id,
    selector: 'region station assets scrapFailed scrapSuccess'
  });
  const assetData = await STAsset.findByCode({ code: asset.code, selector: 'code type' });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetScrap.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });
  const exists = odAssetScrap.assets.search({ code: asset.code });
  if (exists) {
    if (asset.intactCount) exists.intactCount += asset.intactCount;
    if (asset.damageCount) exists.damageCount += asset.damageCount;
  }else {
    odAssetScrap.assets.push({
      id: assetData._id,
      code: asset.code,
      intactCount: asset.intactCount,
      damageCount: asset.damageCount,
    })
  }
  // 添加成功
  odAssetScrap.scrapSuccess.push({
    code: asset.code,
    name: asset.name,
    intactCount: asset.intactCount,
    damageCount: asset.damageCount,
    time: new Date()
  });
  const assetScrapUpdates = {
    _id: odAssetScrap._id,
    assets: odAssetScrap.assets,
    scrapSuccess: odAssetScrap.scrapSuccess
  };
  // 删除失败记录
  assetScrapUpdates.$pull = { scrapFailed: { code: asset.code } };

  assetScrapUpdates.status = odAssetScrap.scrapFailed.length > 1 ? constants.OD_ASSET_SCRAP_STATE.正在进行 : status;
  assetScrapUpdates.finishedAt = odAssetScrap.scrapFailed.length === 1 ? new Date() : undefined;

  const bkAssetUpdates = {
    _id: bkAsset._id,
    $inc: {
      totalCount: -(asset.intactCount + asset.damageCount),
      intactCount: -asset.intactCount,
      damageCount: -asset.damageCount,
      scrapCount: asset.intactCount + asset.damageCount
    }
  };
  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.totalCount - asset.intactCount)
  }


  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_scrap',
      id: odAssetScrap._id
    }, {
      model: 'bk_asset',
      id: bkAsset._id
    }]
  });

  await Transaction.commit({
    tid,
    updates: [assetScrapUpdates, bkAssetUpdates]
  })
};

module.exports = injectTransaction(exports, 'account.order.odAssetScrap.scrapOne');