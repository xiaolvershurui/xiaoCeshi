const Joi = require('poolishark').Joi;
const ODAssetScrap = require('../../../services/database/order/assetScrap');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const assetScrap = await ODAssetScrap.findById({
    id,
    selector: 'status scrapFailed nextTry'
  });
  if (!assetScrap) throw new NotFoundError('不存在该报废单');
  if (constants.OD_ASSET_SCRAP_STATE.正在进行 !== assetScrap.status) throw new BadRequestError('非正在进行报废单不能重试');
  if (assetScrap.nextTry) {
    if (new Date().getTime() < assetScrap.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (assetScrap.status === constants.OD_ASSET_SCRAP_STATE.正在进行) {
    await this.exec({
      c: 'order/assetScrap/scrap',
      params: {
        id,
        assets: assetScrap.scrapFailed.map(asset => {
          return {
            code: asset.code,
            intactCount: asset.intactCount,
            damageCount: asset.damageCount,
          }
        })
      }
    })
  }
};