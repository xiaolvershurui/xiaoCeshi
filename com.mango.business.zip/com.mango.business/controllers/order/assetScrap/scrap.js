const Joi = require('poolishark').Joi;
const ODAssetScrap = require('../../../services/database/order/assetScrap');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    intactCount: Joi.number(),
    damageCount: Joi.number()
  }))
};

exports.handler = async function ({ id, assets }) {
  const odAssetScrap = await ODAssetScrap.findById({
    id,
    selector: 'updatedAt status'
  });
  if (!odAssetScrap) throw new NotFoundError(`不存在报废单${id}`);
  if (constants.OD_ASSET_SCRAP_STATE.正在进行　!== odAssetScrap.status) throw new BadRequestError('该报废单不在进行中');
  const stAssets = await STAsset.findByCodes({ codes: assets.map(asset => asset.code), selector: 'type code' });
  const wrongAsset = assets.filter(asset => !stAssets.search({ code: asset.code }));
  if (wrongAsset.length > 0) throw new BadRequestError(`存在未录入配件${wrongAsset.map(asset => asset.code).join(',')}`);
  const assetMap = {};
  stAssets.forEach(stAsset => {
    assetMap[stAsset.code] = { name: stAsset.type }
  });
  // 初始化
  await ODAssetScrap.update({
    id: odAssetScrap._id,
    updatedAt: odAssetScrap.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      scrapFailed: assets.map(asset => {
        return {
          code: asset.code,
          name: assetMap[asset.code].name,
          intactCount: asset.intactCount,
          damageCount: asset.damageCount,
          errMessage: '初始化',
          time: new Date()
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetScrap/scrapOne',
            params: {
              id,
              asset: Object.assign(asset, {
                name: assetMap[asset.code].name
              }),
              status: count === assets.length ? constants.OD_ASSET_SCRAP_STATE.已经完成 : constants.OD_ASSET_SCRAP_STATE.正在进行
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};