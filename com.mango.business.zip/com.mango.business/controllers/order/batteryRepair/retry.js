const Joi = require('poolishark').Joi;
const ODBatteryRepair = require('../../../services/database/order/batteryRepair');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const batteryRepair = await ODBatteryRepair.findById({ id, selector: 'status repairFailed nextTry' });
  if (!batteryRepair) throw new NotFoundError('不存在该报返修单');

  if (batteryRepair.nextTry) {
    if (new Date().getTime() < batteryRepair.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (batteryRepair.status === constants.OD_BATTERY_REPAIR_STATUS.返修中) {
    await this.exec({
      c: 'order/batteryRepair/repair',
      params: {
        id,
        batteries: batteryRepair.repairFailed.map(battery => battery.id._id)
      }
    })
  }
};
