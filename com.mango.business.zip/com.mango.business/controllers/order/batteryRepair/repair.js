const Joi = require('poolishark').Joi;
const ODBatteryRepair = require('../../../services/database/order/batteryRepair');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ id, batteries }) {
  const odBatteryRepair = await ODBatteryRepair.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryRepair) throw new NotFoundError(`不存在返修单:${id}`);

  if (odBatteryRepair.status !== constants.OD_BATTERY_REPAIR_STATUS.返修中) throw new BadRequestError('该返修单不在返修中');

  await ODBatteryRepair.update({
    id: odBatteryRepair._id,
    updatedAt: odBatteryRepair.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      repairFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryRepair/repairOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_REPAIR_STATUS.已完成 : constants.OD_BATTERY_REPAIR_STATUS.返修中
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};
