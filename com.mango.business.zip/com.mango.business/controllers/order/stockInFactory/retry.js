const Joi = require('poolishark').Joi;
const ODStockInFactory = require('../../../services/database/order/stockInFactory');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function({ id }) {
  const stockInFactory = await ODStockInFactory.findById({
    id,
    selector: 'status stocks nextTry',
  });
  if (!stockInFactory) throw new NotFoundError('不存在该跨区入库单');
  if (constants.OD_IN_FACTORY.正在进行 !== stockInFactory.status) throw new BadRequestError('非正在进行跨区入库单不能重试');
  if (stockInFactory.nextTry) {
    if (new Date().getTime() < stockInFactory.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (stockInFactory.status === constants.OD_IN_FACTORY.正在进行) {
    const stocks = stockInFactory.stocks.reduce((memo, item) => {
      if (item.status === constants.OD_IN_FACTORY_STOCK_STATUS.失败) {
        memo = [...memo, {
          id: item.id._id,
          status: item.status
        }]
      }
      return memo;
    }, []);

    await this.exec({
      c: 'order/stockInFactory/inFactory',
      params: {
        id,
        stocks
      },
    });
  }
};
