const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BKStock = require('../../../services/database/ebike/stock');

exports.validate = Joi.object({
  stocks: Joi.array().items(Joi.object()),
}).unknown();

exports.handler = async function({ stocks }) {
  const stocksSplit = stocks.reduce((memo, item) => {
    if (item.number) {
      memo.numbers.push(item.number);
    } else if (item.box) {
      memo.boxes.push(item.box);
    }
    return memo;
  }, {
    numbers: [],
    boxes: [],
  });

  let bkStocks = [];

  if (stocksSplit.numbers.length) {
    const stocksByNumber = await BKStock.find({
      query: {
        'number.custom': {
          $in: stocksSplit.numbers,
        },
      },
      limit: 0,
      selector: '_id number.custom number.vin box locate',
    });
    bkStocks.push(...stocksByNumber);
  }

  if (stocksSplit.boxes.length) {
    const stocksByBoxes= await BKStock.find({
      query: {
        box: {
          $in: stocksSplit.boxes,
        },
      },
      limit: 0,
      selector: '_id number.custom number.vin box locate',
    });
    bkStocks.push(...stocksByBoxes);
  }

  bkStocks = stocks.reduce((memo, item) => {
    const s = bkStocks.find(i => {
      return (i.number && i.number.custom) === item.number || i.box._id === item.box;
    });
    if (s) {
      memo.push(s);
    } else if (item.number) {
      memo.push({ number: item.number, notFound: true });
    } else if (item.box) {
      memo.push({ box: item.box, notFound: true });
    }
    return memo;
  }, []);

  return bkStocks.map(item => {
    if (item.notFound) {
      return Object.assign(item, {
        canInFactory: item.locate === constants.BK_LOCATE.跨区运输中,
        shouldNotCommitReason: `车辆不存在`,
      });
    } else {
      const reason = {
        stockId: item._id,
        number: item.number && item.number.custom,
        box: item.box && item.box._id,
        notFound: false,
        canInFactory: item.locate === constants.BK_LOCATE.跨区运输中,
      };

      if (item.locate !== constants.BK_LOCATE.跨区运输中) {
        reason.shouldNotCommitReason = '去向应为跨区运输中';
      }
      return reason;
    }
  });
};
