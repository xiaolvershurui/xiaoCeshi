const Joi = require('poolishark').Joi;
const ODStockInFactory = require('../../../services/database/order/stockInFactory');
const BKStock = require('../../../services/database/ebike/stock');
const BKBattery = require('../../../services/database/ebike/battery');
const RCStockOp = require('../../../services/database/record/stockOp');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stock: Joi.object({
    id: Joi.string().required(),
    status: Joi.number().required(),
  }).required(),
  index: Joi.number().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date(),
};

exports.handler = async ({ id, stock, index, status, finishedAt }, tid, Transaction) => {
  const now = new Date();
  const bkStock = await BKStock.findById({
    id: stock.id,
    selector: 'number.custom style region station battery factoryInfo.firstInBoundDate factoryInfo.firstInBoundRegion',
    populateSelector: {
      'battery.id': 'QRCode region station',
    },
  });
  if (!bkStock) throw new NotFoundError(`车辆${stock._id}不存在`);

  const odStockInFactory = await ODStockInFactory.findById({
    id,
    selector: 'region station storeManager stocks',
    populateSelector: {
      storeManager: '_id cert.name auth.tel profile.avator',
      station: 'name',
    },
  });
  if (!odStockInFactory) throw new NotFoundError(`跨区入库单${id}不存在`);
  const odStockInFactoryUpdate = {
    _id: id,
    $set: {
      [`stocks.${index}`]: {
        id: bkStock._id,
        status: constants.OD_IN_FACTORY_STOCK_STATUS.成功,
      },
      status,
      finishedAt,
    },
  };

  let entities = [{
    model: 'od_stock_in_factory',
    id: odStockInFactory._id,
  }, {
    model: 'bk_stock',
    id: bkStock._id,
  }, {
    model: 'rc_stock_op',
  }];
  if (bkStock.battery && bkStock.battery.id) {
    entities = [...entities, {
      model: 'bk_battery',
      id: bkStock.battery.id._id,
    }, {
      model: 'rc_battery_op',
    }];
  }
  // 车辆操作记录
  await Transaction.findAndLockEntity({
    tid,
    entities,
  });

  const stockUpdate = {
    _id: bkStock._id,
    $set: {
      locate: constants.BK_LOCATE.仓库,
      region: odStockInFactory.region._id,
      station: odStockInFactory.station._id,
    },
  };


  if (!(bkStock.factoryInfo && bkStock.factoryInfo.firstInBoundDate) || !(bkStock.factoryInfo && bkStock.factoryInfo.firstInBoundRegion)) {
    // 查询出库时大区为新日成品大区的车辆操作记录
    let rcStockOp = await RCStockOp.findNewest({
      query: {
        type: constants.RC_STOCK_OP_TYPE.出库,
        stock: bkStock._id,
        region: '1802101223850',
      },
      selector: 'region'
    });

    if (rcStockOp) {
      stockUpdate.$set['factoryInfo.firstInBoundDate'] = now;
      stockUpdate.$set['factoryInfo.firstInBoundRegion'] = odStockInFactory.region._id;
    }
  }

  let updates = [odStockInFactoryUpdate, stockUpdate, {
    stock: bkStock._id,
    stockNo: bkStock.number && bkStock.number.custom,
    type: constants.RC_STOCK_OP_TYPE.跨区入库,
    region: odStockInFactory.region._id,
    style: bkStock.style._id,
    operatedAt: now,
    operator: odStockInFactory.storeManager && odStockInFactory.storeManager._id,
    operatorTel: odStockInFactory.storeManager && odStockInFactory.storeManager.auth.tel,
    operatorName: odStockInFactory.storeManager && odStockInFactory.storeManager.cert.name,
    operatorAvator: odStockInFactory.storeManager && odStockInFactory.storeManager.profile.avator,
    description: `车牌号为${bkStock.number && bkStock.number.custom}的车辆跨区调入${odStockInFactory.station && odStockInFactory.station.name}仓库`,
    inFactory: {
      prevRegion: bkStock.region._id,
      nextRegion: odStockInFactory.region._id,
    },
  }];

  if (bkStock.battery.id) {
    const battery = bkStock.battery.id;
    updates = [...updates, {
      _id: battery._id,
      $set: {
        region: odStockInFactory.region._id,
        station: odStockInFactory.station._id,
      },
    }, {
      battery: battery._id,
      region: battery.region && battery.region._id,
      stock: bkStock._id,
      QRCode: battery.QRCode,
      mark: battery.mark,
      inStation: battery.station && battery.station._id,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.车辆跨区入库,
      description: `二维码为${battery.QRCode}的电池调入${odStockInFactory.station && odStockInFactory.station.name}仓库`,
      operator: odStockInFactory.storeManager && odStockInFactory.storeManager._id,
      operatorName: odStockInFactory.storeManager && odStockInFactory.storeManager.cert.name,
      operatedAt: now,
      updateRegion: {
        prev: bkStock.region && bkStock.region._id,
        next: odStockInFactory.region && odStockInFactory.region._id,
      },
      updateStation: {
        prev: {
          id: bkStock.station && bkStock.station._id,
        },
        next: {
          id: odStockInFactory.station && odStockInFactory.station._id,
        },
      },
    }];
  }

  await Transaction.commit({
    tid,
    updates,
  });
};

module.exports = injectTransaction(exports, 'account.order.odStockInFactory.inFactoryOne');
