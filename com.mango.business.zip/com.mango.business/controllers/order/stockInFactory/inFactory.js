const Joi = require('poolishark').Joi;
const ODStockInFactory = require('../../../services/database/order/stockInFactory');
const BKStock = require('../../../services/database/ebike/stock');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stocks: Joi.array().items(Joi.object({
    id: Joi.string().required(),
    status: Joi.number().required(),
  })),
};

exports.handler = async function({ id, stocks }) {
  const odStockInFactory = await ODStockInFactory.findById({
    id,
    selector: '_id updatedAt stocks status',
  });
  if (!odStockInFactory) throw new NotFoundError('该跨区入库单不存在');

  if (constants.OD_IN_FACTORY.正在进行 !== odStockInFactory.status) throw new BadRequestError('该跨区入库单不在进行中');

  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let stock of stocks) {
        const index = odStockInFactory.stocks.findIndex(item => item.id._id === stock.id);
        count++;
        try {
          await this.exec({
            c: 'order/stockInFactory/inFactoryOne',
            params: {
              id,
              stock,
              index,
              status: count === stocks.length ? constants.OD_IN_FACTORY.已经完成 : constants.OD_IN_FACTORY.正在进行,
              finishedAt: count === stocks.length ? new Date() : undefined,
            },
          });
        } catch (err) {
          count--;
          console.error(err);
        }
      }
    })();
  });
};
