const Joi = require('poolishark').Joi;
const ODStockInFactory = require('../../../services/database/order/stockInFactory');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = Joi.object({
  storeManager: Joi.string(),
  station: Joi.string().required(),
  stocks: Joi.array().items(Joi.string()),
}).unknown();

exports.handler = async function({ storeManager, station, stocks }) {
  const _user = ACUSer.findById({ id: storeManager });
  if (!_user) throw new NotFoundError(`未找到用户：${storeManager}`);

  const _station = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!_station) throw new NotFoundError(`未找到仓库：${station}`);

  const region = _station.region && _station.region._id;

  const stockPullBack = await ODStockInFactory.findByStoreManager({
    storeManager,
    status: constants.OD_IN_FACTORY.正在进行,
  });
  // if (stockPullBack) throw new BadRequestError('该用户有正在进行的拖回单');

  let bkStocks = await BKStock.find({
    query: {
      _id: {
        $in: [...new Set(stocks)],
      },
    },
    limit: 0,
    selector: '',
  });

  if (bkStocks.length !== stocks.length) throw new BadRequestError('')
  bkStocks.forEach(item => {
    if (item.locate !== constants.BK_LOCATE.跨区运输中) throw new BadRequestError(`车牌号为${item.number && item.number.custom}的车辆非跨区运输中状态`);
  });
  bkStocks = bkStocks.map(item => {
    return {
      id: item._id,
      status: constants.OD_IN_FACTORY_STOCK_STATUS.失败
    }
  });

  const odStockInFactory = await ODStockInFactory.create({
    storeManager,
    region,
    station,
    stocks: bkStocks,
    status: constants.OD_IN_FACTORY.正在进行,
    date: new Date(),
    nextTry: Date.now() + 3 * 60 * 1000,
  });
  await this.exec({
    c: 'order/stockInFactory/inFactory',
    params: {
      id: odStockInFactory._id,
      stocks: bkStocks,
    },
  });
};
