const Joi = require('poolishark').Joi;
const ODBatteryMaintain = require('../../../services/database/order/batteryMaintain');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ id, batteries }) {
  const odBatteryMaintain = await ODBatteryMaintain.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryMaintain) throw new NotFoundError(`不存在报废单:${id}`);

  if (odBatteryMaintain.status !== constants.OD_BATTERY_MAINTAIN_STATUS.维修中) throw new BadRequestError('该维修单不在维修中');

  await ODBatteryMaintain.update({
    id: odBatteryMaintain._id,
    updatedAt: odBatteryMaintain.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      maintainFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryMaintain/maintainOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_MAINTAIN_STATUS.已完成 : constants.OD_BATTERY_MAINTAIN_STATUS.维修中
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};
