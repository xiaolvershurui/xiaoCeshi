const Joi = require('poolishark').Joi;
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  batteries: Joi.array().items(Joi.object()),
};

exports.handler = async ({ batteries }) => {
  const bkBatteries = [];
  const bkBatteriesMap = batteries.reduce((memo, item) => {
    if (item.QRCode) {
      memo.QRCodes.push(item.QRCode);
    } else if (item.mark) {
      memo.marks.push(item.mark);
    }
    return memo;
  }, {
    QRCodes: [],
    marks: [],
  });

  if (bkBatteriesMap.QRCodes && bkBatteriesMap.QRCodes.length) {
    const batteries = await BKBattery.find({
      query: {
        QRCode: {
          $in: bkBatteriesMap.QRCodes,
        },
      },
      limit: 0,
      selector: 'mark state locate QRCode',
    });
    if (batteries && batteries.length) bkBatteries.push(...batteries);
  }

  if (bkBatteriesMap.marks && bkBatteriesMap.marks.length) {
    const batteries = await BKBattery.find({
      query: {
        mark: {
          $in: bkBatteriesMap.marks,
        },
      },
      limit: 0,
      selector: 'mark state locate QRCode',
    });
    if (batteries && batteries.length) bkBatteries.push(...batteries);
  }

  // const bkBatteries = await BKBattery.find({
  //   query: {
  //     QRCode: {
  //       $in: batteries,
  //     },
  //     // state: {
  //     //   $in: [constants.BK_BATTERY_STATE.报废, constants.BK_BATTERY_STATE.损坏]
  //     // },
  //     // locate: constants.BK_BATTERY_LOCATE.在运营站,
  //   },
  //   limit: 0,
  //   selector: 'state locate QRCode',
  // });

  return batteries.reduce((memo, item) => {
    const s = bkBatteries.find(i => i.QRCode === item.QRCode || i.mark === item.mark);
    if (!s) {
      memo = [...memo, Object.assign({ notFound: true }, { [item.QRCode ? 'QRCode' : 'mark']: item.QRCode || item.mark })];
    } else {
      if (s.state !== constants.BK_BATTERY_STATE.报废 && s.state !== constants.BK_BATTERY_STATE.损坏) {
        Object.assign(s, { notScrapOrDamage: true });
      }

      if (s.locate !== constants.BK_BATTERY_LOCATE.在运营站) {
        Object.assign(s, { notInStation: true });
      }
      memo = [...memo, s];
    }
    return memo;
  }, []).map(item => {
    if (item.notFound) {
      return {
        [item.QRCode ? 'QRCode': 'mark']: item.QRCode || item.mark,
        shouldNotCommitReason: `${item.QRCode || item.mark}不存在`,
      };
    } else if (item.notScrapOrDamage || item.notInStation) {
      return {
        _id: item._id,
        QRCode: item.QRCode,
        mark: item.mark,
        shouldNotCommitReason: `
          ${item.notScrapOrDamage ? '状态应为报废或损坏, ' : ''}
          ${item.notInStation ? '去向应为在运营站' : ''}
        `,
      };
    } else {
      return {
        _id: item._id,
        QRCode: item.QRCode,
        mark: item.mark,
      };
    }
  });
};
