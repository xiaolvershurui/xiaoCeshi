const Joi = require('poolishark').Joi;
const ODBatteryMaintain = require('../../../services/database/order/batteryMaintain');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const batteryMaintain = await ODBatteryMaintain.findById({ id, selector: 'status maintainFailed nextTry' });
  if (!batteryMaintain) throw new NotFoundError('不存在该报废单');

  if (batteryMaintain.nextTry) {
    if (new Date().getTime() < batteryMaintain.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (batteryMaintain.status === constants.OD_BATTERY_MAINTAIN_STATUS.维修中) {
    await this.exec({
      c: 'order/batteryMaintain/maintain',
      params: {
        id,
        batteries: batteryMaintain.maintainFailed.map(battery => battery.id._id)
      }
    })
  }
};
