const Joi = require('poolishark').Joi;
const ODAssetCheck = require('../../../services/database/order/assetCheck');
const BKAsset = require('../../../services/database/ebike/asset');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  region: Joi.string().required(),
};

exports.handler = async ({user, region, station}) => {
  const acUser = await ACUser.findById({
    id:user
  });
  if(!acUser){
    throw new NotFoundError('不存在User');
  }
  const ret = {
    region,
    station,
    user,
    status: constants.OD_ASSET_CHECK_STATE.盘点中,
    assets: (await BKAsset.find({
      query: {
        station
      },
      limit: 0,
      selector: 'intactCount damageCount  asset code'
    })).reduce((memo, items) => {
      const asset = {
        id: items.asset._id,
        code: items.code,
        intactCount: items.intactCount,
        damageCount: items.damageCount,
      };
      memo.push(asset);
      return memo;
    }, [])
  };
  return await ODAssetCheck.create(ret);
};

