const Joi = require('poolishark').Joi;
const ODAssetCheck = require('../../../services/database/order/assetCheck');
const BKAsset = require('../../../services/database/ebike/asset');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');


exports.validate = {
  id: Joi.string().required(),
  operator: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string().required(),
    actualDamageCount: Joi.number().required(),
    actualIntactCount: Joi.number().required(),
  })).required(),
};

exports.handler = async ({id, operator, assets}) => {
  const acUser = await ACUser.findById({
    id: operator
  });
  if(!acUser){
    throw new NotFoundError('不存在此Operator Id');
  }
  const odAssetCheck = await ODAssetCheck.findById({
    id,
    selector: 'station assets status updatedAt'
  });
  if(!odAssetCheck){
    throw new NotFoundError('不存在此盘点单');
  }
  if(odAssetCheck.status!==constants.OD_ASSET_CHECK_STATE.盘点中){
    throw new BadRequestError('盘点单状态异常');
  }
  const odAssets = odAssetCheck.assets;
  odAssets.map(asset => {
    asset.id = asset.id._id;
    const thisAssets = assets.search({ code: asset.code });
    if(thisAssets){
      asset.actualDamageCount = thisAssets.actualDamageCount;
      asset.actualIntactCount = thisAssets.actualIntactCount;
    }
  });
 return await ODAssetCheck.update({
    id,
    data:{
      submitter: operator,
      submittedAt: new Date(),
      assets: odAssets,
      status: constants.OD_ASSET_CHECK_STATE.修正中
    },
    updatedAt: odAssetCheck.updatedAt
  });
};