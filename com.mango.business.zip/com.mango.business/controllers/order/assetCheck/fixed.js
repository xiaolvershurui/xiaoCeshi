const Joi = require('poolishark').Joi;
const ODAssetCheck = require('../../../services/database/order/assetCheck');
const BKAsset = require('../../../services/database/ebike/asset');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  operator: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string().description('物料二维码'),
    fixedDamageCount: Joi.number().description('盘点损坏数量'),
    fixedIntactCount: Joi.number().description('盘点完好数量'),
  })).required(),
};

exports.handler = async function({id, operator, assets}, tid, Transaction)  {
  const acUser = ACUser.findById({
    id: operator
  });
  if(!acUser){
    throw new NotFoundError('未存在此人员');
  }
  const odAssetCheck = await ODAssetCheck.findById({
      id,
    selector:'status  station'
  });
  if(!odAssetCheck){
    throw new NotFoundError('未找到此盘点单');
  }
  if(odAssetCheck.status!==constants.OD_ASSET_CHECK_STATE.修正中){
    throw  new BadRequestError('状态异常');
  }
  // 如果为空结束盘点
  if(assets.length===0){
   return await ODAssetCheck.update({
      id,
      data: {
        status: constants.OD_ASSET_CHECK_STATE.已经完成,
      }
    });
  }
  const stAsset = await STAsset.find({
    query: {
      code: {
        $in: assets.map(a=>{
          return a.code
        })
      }
    },
    selector: '_id code'
  });
  assets.map(asset=>{
   const thisAsset = stAsset.search({code: asset.code});
   if(!thisAsset){
     throw new NotFoundError(`${asset.code}未录入配件库`)
   }
   asset.id = thisAsset._id
  });
  const bkAssets = await BKAsset.find({
    query: {
      station: odAssetCheck.station._id,
      asset: {
        $in: assets.map(a=>{
          return a.id
        })
      }
    },
    selector: 'asset'
  });
  bkAssets.map(bkAsset=>{
    const thisAsset = assets.search({ id: bkAsset.asset._id });
    thisAsset.bkAsset = bkAsset._id;
  });
  await ODAssetCheck.update({
    id,
    data: {
      fixedUser: operator,
      fixedAt: new Date(),
      status: constants.OD_ASSET_CHECK_STATE.修正处理中,
      fixedFailed: assets,
      nextTry: Date.now()+120000
    }
  });
  await this.exec({
    c: 'order/assetCheck/fixedAll',
    params: {
      id,
      assets: assets
    }
  });
};

module.exports = injectTransaction(exports, 'order.assetCheck.fixed');
