const Joi = require('poolishark').Joi;
const ODAssetCheck = require('../../../services/database/order/assetCheck');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function ({id}) {
  const odAssetCheck = await ODAssetCheck.findById({
    id,
    selector: 'status nextTry fixedFailed'
  });
  if(odAssetCheck.status!==constants.OD_ASSET_CHECK_STATE.修正处理中){
    throw new Error('该状态异常无法重试');
  }
  if(new Date(odAssetCheck.nextTry).getTime()>Date.now()){
    throw new Error(`重试频繁,请在 ${(new Date(odAssetCheck.nextTry)).toLocaleString()} 后重试！`)
  }
  await ODAssetCheck.update({
    id,
    data: {
      retry: Date.now() + 120000
    }
  });
  await this.exec({
    c: 'order/assetCheck/fixedAll',
    params: {
      id,
      assets: odAssetCheck.fixedFailed
    }
  });
};