const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BKAsset = require('../../../services/database/ebike/asset');
const ODAssetCheck = require('../../../services/database/order/assetCheck');

exports.validate = {
  id: Joi.string().required(),
  assets: Joi.array().items(Joi.object()).required(),
};

exports.handler = async function({id ,assets}){
   const odAssetCheck = await ODAssetCheck.findById({
    id,
    selector: 'station'
  });

  const codes = assets.map(asset=>{
    return asset.code
  });
 let bkAssets= await BKAsset.find({
    query:{
      station: odAssetCheck.station._id,
      code: { $in:[...codes] }
    },
   limit: 0,
   selector: 'code'
  });
  bkAssets.map(bkAsset=>{
    const thisAsset = assets.search({ code: bkAsset.code });
    if(thisAsset){
      thisAsset.bkAsset = bkAsset._id
    }
  });
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetCheck/fixedOne',
            params: {
              id,
              asset: asset,
              status: count === assets.length ? constants.OD_ASSET_CHECK_STATE.已经完成 : constants.OD_ASSET_CHECK_STATE.修正处理中,
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => console.error(error));
  });
};