const Joi = require('poolishark').Joi;
const ODAssetCheck = require('../../../services/database/order/assetCheck');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object().required(),
  status: Joi.number().required(),
};
exports.handler = async ({id, asset, status}, tid, Transaction) => {
  const odAssetCheck = await ODAssetCheck.findById({
    id,
    selector: 'assets'
  });
  odAssetCheck.assets.map(checkAsset => {
    checkAsset.id = checkAsset.id._id;
    if (asset.id === checkAsset.id) {
      checkAsset.fixedTotalCount = asset.fixedIntactCount + asset.fixedDamageCount;
      checkAsset.fixedIntactCount = asset.fixedIntactCount;
      checkAsset.fixedDamageCount = asset.fixedDamageCount;
    }
  });
  const odAssetCheckUpdates = {
    _id: id,
    $set: {
      status,
      assets: odAssetCheck.assets
    },
    $pull: {
      fixedFailed: {
        id: asset.id
      }
    },
  };
  if (status === constants.OD_ASSET_CHECK_STATE.盘点完成) {
    odAssetCheckUpdates.$set.finishedAt = new Date();
  }
  const bkAssetUpdates = {
    _id: asset.bkAsset,
    $set: {
      totalCount: (asset.fixedDamageCount + asset.fixedIntactCount),
      intactCount: asset.fixedIntactCount,
      damageCount: asset.fixedDamageCount
    }
  };
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_check',
      id: id
    }, {
      id: asset.bkAsset,
      model: 'bk_asset',
    }]
  });
  await Transaction.commit({
    tid,
    updates: [odAssetCheckUpdates, bkAssetUpdates]
  });
};
module.exports = injectTransaction(exports, 'account.order.assetcheck.fixedOne');
