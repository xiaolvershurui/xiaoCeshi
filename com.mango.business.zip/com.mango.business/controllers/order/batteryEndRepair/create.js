const Joi = require('poolishark').Joi;
const ODBatteryEndRepair = require('../../../services/database/order/batteryEndRepair');
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  batteries: Joi.array().items(Joi.string()),
};

exports.handler = async function ({ user, station, batteries }) {
  batteries = [... new Set(batteries)];
  const bkBatteries = (await BKBattery.find({
    query: {
      QRCode: {
        $in: batteries,
      },
      locate: constants.BK_BATTERY_LOCATE.维修占用,
    },
    limit: 0,
  })).map(item => item._id);
  if (bkBatteries.length !== batteries.length) throw new BadRequestError('存在电池状态不正确，请重新检测');

  const acUser = await ACUser.findById({ id: user });
  if (!acUser) throw new NotFoundError(`未找到用户：${user}`);

  const opBatteryStation = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!opBatteryStation) throw new NotFoundError(`未找到仓库：${station}`);
  const opRegion = opBatteryStation.region._id;

  const isExistsOdBatteryRepair =  await ODBatteryEndRepair.findByUser({ user, status: constants.OD_BATTERY_END_REPAIR_STATUS.返修入库中 });
  if (isExistsOdBatteryRepair) throw new BadRequestError('该用户有未完成返修入库单');

  const odBatteryEndRepair = await ODBatteryEndRepair.create({
    user,
    region: opRegion,
    station: opBatteryStation._id
  });

  await this.exec({
    c: 'order/batteryEndRepair/inbound',
    params: {
      id: odBatteryEndRepair._id,
      batteries: bkBatteries
    }
  });
};
