const Joi = require('poolishark').Joi;
const ODBatteryEndRepair = require('../../../services/database/order/batteryEndRepair');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string()),
};
exports.handler = async function({ id, batteries }) {
  const odBatteryEndRepair = await ODBatteryEndRepair.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryEndRepair) throw new NotFoundError(`不存在返修入库单:${id}`);

  if (odBatteryEndRepair.status !== constants.OD_BATTERY_END_REPAIR_STATUS.返修入库中) throw new BadRequestError('该返修入库单状态不正确');

  await ODBatteryEndRepair.update({
    id: odBatteryEndRepair._id,
    updatedAt: odBatteryEndRepair.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      inboundFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: "初始化"
        }
      })
    }
  });

  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行入库操作
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryEndRepair/inboundOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_END_REPAIR_STATUS.已完成 : constants.OD_BATTERY_END_REPAIR_STATUS.返修入库中,
            },
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => console.error(error));
  });
};
