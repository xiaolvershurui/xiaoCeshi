const Joi = require('poolishark').Joi;
const ODBatteryEndRepair = require('../../../services/database/order/batteryEndRepair');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function ({ id }) {
  const odBatteryEndRepair = await ODBatteryEndRepair.findById({ id, selector: 'status inboundFailed nextTry' });
  if(!odBatteryEndRepair) throw new NotFoundError('不存在此返修入库单');

  if (odBatteryEndRepair.nextTry) {
    if (new Date().getTime() < odBatteryEndRepair.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }

  if (odBatteryEndRepair.status !== constants.OD_BATTERY_END_REPAIR_STATUS.返修入库中) throw new BadRequestError('返修入库单状态不正确');

  if(odBatteryEndRepair.status === constants.OD_BATTERY_END_REPAIR_STATUS.返修入库中){
    await this.exec({
      c: 'order/batteryEndRepair/inbound',
      params: {
        id: id,
        batteries: odBatteryEndRepair.inboundFailed.map(battery => battery.id._id),
      }
    });
  }
};
