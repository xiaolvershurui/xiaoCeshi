const Joi = require('poolishark').Joi;
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  batteries: Joi.array().items(Joi.string()),
};

exports.handler = async ({ batteries }) => {

  const bkBatteries = await BKBattery.find({
    query: {
      QRCode: {
        $in: batteries,
      },
      // state: constants.BK_BATTERY_STATE.完好,
      // locate: constants.BK_BATTERY_LOCATE.维修占用,
    },
    limit: 0,
    selector: 'state locate QRCode',
  });

  return batteries.reduce((memo, item) => {
    const s = bkBatteries.find(i => i.QRCode === item);
    if (!s) {
      memo = [...memo, Object.assign({ notFound: true }, { QRCode: item })];
    } else {
      if (s.locate !== constants.BK_BATTERY_LOCATE.维修占用) {
        Object.assign(s, { notInRepair: true });
      }
      memo = [...memo, s];
    }
    return memo;
  }, []).map(item => {
    if (item.notFound) {
      return {
        QRCode: item.QRCode,
        shouldNotCommitReason: `${item.QRCode}不存在`,
      };
    } else if (item.notInRepair) {
      return {
        _id: item._id,
        QRCode: item.QRCode,
        shouldNotCommitReason: `
          ${item.notInRepair ? '去向应为维修占用' : ''}
        `,
      };
    } else {
      return {
        _id: item._id,
        QRCode: item.QRCode,
      };
    }
  });
};
