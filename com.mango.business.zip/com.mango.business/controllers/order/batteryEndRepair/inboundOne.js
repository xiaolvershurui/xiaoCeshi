const Joi = require('poolishark').Joi;
const BKBattery = require('../../../services/database/ebike/battery');
const ODBatteryEndRepair = require('../../../services/database/order/batteryEndRepair');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string().required(),
  status: Joi.number().required(),
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {
  const now = new Date();
  const bkBattery = await BKBattery.findById({ id: battery, selector: 'QRCode mark locate state' });
  if (!bkBattery) throw new NotFoundError(`电池${battery}不存在`);

  const odBatteryEndRepair = await ODBatteryEndRepair.findById({
    id,
    selector: 'user region station batteries inboundFailed',
    populateSelector: {
      user: 'cert.name',
    },
  });

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_battery_end_repair',
      id: odBatteryEndRepair._id,
    }, {
      model: 'bk_battery',
      id: bkBattery._id,
    }, {
      model: 'rc_battery_op',
    }],
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: odBatteryEndRepair._id,
      $set: {
        status,
        finishedAt: odBatteryEndRepair.inboundFailed.length === 1 ? now : undefined,
      },
      $pull: {
        inboundFailed: { id: bkBattery._id },
      },
      $push: {
        inboundSuccess: { id: bkBattery._id, time: now },
      },
    }, {
      _id: bkBattery._id,
      $set: {
        state: constants.BK_BATTERY_STATE.完好,
        locate: constants.BK_BATTERY_LOCATE.在运营站,
        lastUpdatedStateAt: now,
      },
    }, {
      battery: bkBattery._id,
      QRCode: bkBattery.QRCode,
      mark: bkBattery.mark,
      description: `将二维码为${bkBattery.QRCode}的电池返修入库`,
      remark: '',
      inStation: odBatteryEndRepair.station._id,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池返修入库,
      operatedAt: now,
      operator: odBatteryEndRepair.user._id,
      operatorName: odBatteryEndRepair.user.cert.name,
      updateLocate: {
        prev: constants.BK_BATTERY_LOCATE.维修占用,
        next: constants.BK_BATTERY_LOCATE.在运营站,
      },
      updateState: {
        prev: bkBattery.state,
        next: constants.BK_BATTERY_STATE.完好,
      },
    }],
  });
};
module.exports = injectTransaction(exports, 'order.batteryEndRepair.inboundOne');
