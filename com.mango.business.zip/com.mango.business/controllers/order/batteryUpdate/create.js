const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const ODBatteryUpdate = require('../../../services/database/order/batteryUpdate');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  code: Joi.string().required(),
  updateInfo: Joi.object({
    code: Joi.string().required(),
    mark: Joi.string(),
    gps: Joi.string(),
  })
};

exports.handler = async function ({  user, station, code, updateInfo }, tid, Transaction) {
  const acUser = ACUser.findById({ id: user });
  if (!acUser) throw new NotFoundError(`未找到用户：${user}`);

  const opStation = await OPBatteryStation.findById({ id: station, selector: '_id region' });
  if (!opStation) throw new NotFoundError(`未找到仓库：${station}`);

  const region = opStation.region;

  const batteryInfo = await BKBattery.findByCode({ code, selector: 'QRCode mark gps' });
  if (!batteryInfo) throw new NotFoundError(`该电池: ${code}不存在`);

  const batteryUpdateId = await ODBatteryUpdate.genId();

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_battery_update'
    }, {
      id: batteryInfo._id,
      model: 'bk_battery'
    }]
  });

  const odBatteryUpdates = {
    _id: batteryUpdateId,
    user,
    region,
    station,
    battery: batteryInfo._id,
    prevInfo: {
      code: batteryInfo.QRCode,
      mark: batteryInfo.mark,
      gps: batteryInfo.gps
    },
    nextInfo: {
      code: updateInfo.code,
      mark:  updateInfo.code ? updateInfo.code : undefined,
      gps: updateInfo.gps ? updateInfo.gps : undefined,
    }
  };
  const bkBatteryUpdates = {
    _id: batteryInfo._id,
    QRCode: updateInfo.code,
    mark: updateInfo.mark ? updateInfo.mark : undefined,
    gps: updateInfo.gps ? updateInfo.gps : undefined,
  };

  await Transaction.commit({
    tid,
    updates: [odBatteryUpdates, bkBatteryUpdates]
  });
};

module.exports = injectTransaction(exports, 'account.order.batteryUpdate.create');
