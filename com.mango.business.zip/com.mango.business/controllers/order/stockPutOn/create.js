const Joi = require('poolishark').Joi;
const ODStockPutOn = require('../../../services/database/order/stockPutOn');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = Joi.object({
  station: Joi.string().required(),
  storeManager: Joi.string(),
  driver: Joi.string(),
  stocks: Joi.array().items(Joi.string()),
}).unknown();

exports.handler = async function ( { station, storeManager, driver, stocks } ) {

  const _user = ACUSer.findById({ id: storeManager });
  if (!_user) throw new NotFoundError(`未找到用户：${storeManager}`);

  const _station = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!_station) throw new NotFoundError(`未找到仓库：${station}`);

  const region = _station.region && _station.region._id;

  const stockPutOn = await ODStockPutOn.findByStoreManager({
    storeManager,
    status: constants.OD_STOCK_PUT_ON.正在进行
  });
  // if (stockPutOn) throw new BadRequestError('该用户有正在进行的投放单');
  let bkStocks = await BKStock.find({
    query: {
      _id: {
        $in: stocks
      }
    },
    limit: 0,
    selector: '_id locate lockVin box number.custom'
  });

  bkStocks.forEach(item => {
    if (item.locate !== constants.BK_LOCATE.仓库) throw new BadRequestError(`车牌号为${item.number && item.number.custom}的车辆非在库状态`);
    if (!(item.lockVin && item.lockVin.isLocked)) throw new BadRequestError(`车牌号为${item.number && item.number.custom}的车辆的车架号不存在或未绑定`);
    if(!item.box) throw new BadRequestError(`车牌号为${item.number && item.number.custom}的车辆的未绑定盒子`)
  });
  bkStocks = bkStocks.map(item => item._id);

  const odStockPutOn = await ODStockPutOn.create({
    region,
    station,
    storeManager,
    driver,
    date: new Date()
  });
  await this.exec({
    c: 'order/stockPutOn/putOn',
    params: {
      id: odStockPutOn._id,
      stocks: bkStocks
    }
  })
};
