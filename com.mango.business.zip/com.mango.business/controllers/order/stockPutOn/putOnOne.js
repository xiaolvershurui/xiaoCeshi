const Joi = require('poolishark').Joi;
const ODStockPutOn = require('../../../services/database/order/stockPutOn');
const BKStock = require('../../../services/database/ebike/stock');
const RCStockOp = require('../../../services/database/record/stockOp');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stock: Joi.string().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date(),
};

exports.handler = async ({ id, stock, status, finishedAt }, tid, Transaction) => {
  const bkStock = await BKStock.findById({ id: stock, selector: 'number.custom style taskList taskGroup solution' });
  const codes = bkStock.taskList.map(task => task.code);
  if ([constants.BK_TASK_TYPE.低电, constants.BK_TASK_TYPE.高压离线].some(item => codes.includes(item))
    || [constants.BK_TASK_GROUP.断电任务组, constants.BK_TASK_GROUP.无定位组, constants.BK_TASK_GROUP.丢失风险组, constants.BK_TASK_GROUP.丢失高风险组, constants.BK_TASK_GROUP.困难换电任务组].some(item => bkStock.taskGroup === item)) {
    throw new BadRequestError(`车辆${bkStock.number.custom}有未完成任务`);
  }
  if (!bkStock) throw new NotFoundError(`车辆${stock}不存在`);
  if (!bkStock.solution) throw new BadRequestError(`车辆${stock.number.custom} 未分批次,请联系线上运营`);
  const odStockPutOn = await ODStockPutOn.findById({
    id,
    selector: 'region station driver storeManager stocks putOnFailed putOnSuccess',
    populateSelector: {
      storeManager: '_id cert.name auth.tel profile.avator',
      station: 'name',
    },
  });
  if (!odStockPutOn) throw new NotFoundError(`投放单据${id}不存在`);
  // 添加成功
  odStockPutOn.putOnSuccess.push(stock);
  const odStockPutOnUpdates = {
    _id: id,
    $pull: {
      putOnFailed: stock,
    },
    $addToSet: {
      putOnSuccess: stock,
      stocks: stock,
    },
    $set: {
      status,
      finishedAt,
    },
  };

  // 车辆操作记录

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_stock_put_on',
      id: odStockPutOn._id,
    }, {
      model: 'bk_stock',
      id: stock,
    }, {
      model: 'rc_stock_op',
    }],
  });

  await Transaction.commit({
    tid,
    updates: [odStockPutOnUpdates, {
      _id: stock,
      $set: {
        locate: constants.BK_LOCATE.调度,
        station: '',
      },
    }, {
      stock,
      stockNo: bkStock.number && bkStock.number.custom,
      type: constants.RC_STOCK_OP_TYPE.投放车辆,
      region: odStockPutOn.region._id,
      style: bkStock.style._id,
      latestMovedAt: new Date(),
      operatedAt: new Date(),
      operator: odStockPutOn.storeManager && odStockPutOn.storeManager._id,
      operatorTel: odStockPutOn.storeManager && odStockPutOn.storeManager.auth.tel,
      operatorName: odStockPutOn.storeManager && odStockPutOn.storeManager.cert.name,
      operatorAvator: odStockPutOn.storeManager && odStockPutOn.storeManager.profile.avator,
      description: `将位于${odStockPutOn.station && odStockPutOn.station.name}仓库的车牌号为${bkStock.number && bkStock.number.custom}的车辆投放出库`,
      putOn: {
        driver: odStockPutOn.driver._id,
        storehouse: {
          id: odStockPutOn.station._id,
          name: odStockPutOn.station.name,
        },
      },
    }],
  });
};

module.exports = injectTransaction(exports, 'account.order.odStockPutOn.putOnOne');
