const Joi = require('poolishark').Joi;
const ODStockPutOn = require('../../../services/database/order/stockPutOn');
const BKStock = require('../../../services/database/ebike/stock');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stocks: Joi.array().items(Joi.string())
};

exports.handler = async function ( { id, stocks } ) {
  const odStockPutOn =  await ODStockPutOn.findById({
    id,
    selector: '_id updatedAt status'
  });
  if (!odStockPutOn) throw new NotFoundError('该投放单不存在');

  if (constants.OD_STOCK_PUT_ON.正在进行 !== odStockPutOn.status) throw new BadRequestError('该投放单不在进行中');

  const bkStocks = await BKStock.find({query: {
    _id: {
      $in: [...new Set(stocks)]
    }
  }});
  if (bkStocks.length !== stocks.length) throw new BadRequestError('有车辆不存在');
  // 初始化
  await ODStockPutOn.update({
    id: odStockPutOn._id,
    updatedAt: odStockPutOn.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000,
      putOnFailed: bkStocks.map(item => item._id)
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let stock of bkStocks) {
        count++;
        try {
          await this.exec({
            c: 'order/stockPutOn/putOnOne',
            params: {
              id,
              stock: stock._id,
              status: count === bkStocks.length ? constants.OD_STOCK_PUT_ON.已经完成 : constants.OD_STOCK_PUT_ON.正在进行,
              finishedAt: count === bkStocks.length ? new Date() : undefined
            }
          })
        } catch (err) {
          count--;
          console.error(err);
        }
      }
    })()
  })
};
