const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BKStock = require('../../../services/database/ebike/stock');

exports.validate = Joi.object({
  stocks: Joi.array().items(Joi.object()),
}).unknown();

exports.handler = async function ({ stocks }) {
  let bkStocks = [];
  let s;
  for (let stock of stocks) {
    if (stock.number) {
      s = await BKStock.findByNumber(Object.assign({}, stock, { selector: '_id number.custom number.vin box mark locate lockVin taskGroup taskList' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: stock.number, notFound: true }];
    } else if (stock.vin) {
      s = await BKStock.findByVin(Object.assign({}, stock, { selector: '_id number.custom number.vin box mark locate lockVin taskGroup taskList' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { vin: stock.vin, notFound: true }];
    } else if (stock.box) {
      s = await BKStock.findByBox(Object.assign({}, stock, { selector: '_id number.custom number.vin box mark locate lockVin taskGroup taskList' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { box: stock.box, notFound: true }];
    }
  }
  bkStocks = bkStocks.map(item => {
    if (item.notFound) {
      return Object.assign(item, {
        canPutOn: false,
        isLocked: !!(item.lockVin && item.lockVin.isLocked),
      });
    } else {
      return {
        stockId: item._id,
        number: item.number && item.number.custom,
        vin: item.number && item.number.vin,
        box: item.box && item.box._id,
        notFound: false,
        canPutOn: item.locate === constants.BK_LOCATE.仓库 &&
        ![constants.BK_TASK_GROUP.断电任务组,
          constants.BK_TASK_GROUP.无定位组,
          constants.BK_TASK_GROUP.丢失风险组,
          constants.BK_TASK_GROUP.丢失高风险组,
          constants.BK_TASK_GROUP.困难换电任务组].includes(item.taskGroup) &&
        !(item.taskList.filter(task => [constants.BK_TASK_TYPE.高压离线, constants.BK_TASK_TYPE.低电].includes(task)).length),
        isLocked: !!(item.lockVin && item.lockVin.isLocked),
        noMark: !!item.mark,
      };
    }
  });

  return bkStocks;
};
