const Joi = require('poolishark').Joi;
const ODStockPutOn = require('../../../services/database/order/stockPutOn');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const stockPutOn = await ODStockPutOn.findById({
    id,
    selector: 'status putOnFailed nextTry'
  });
  if (!stockPutOn) throw new NotFoundError('不存在该投放单');
  if (constants.OD_STOCK_PUT_ON.正在进行 !== stockPutOn.status) throw new BadRequestError('非正在进行投放单不能重试');
  if (stockPutOn.nextTry) {
    if (new Date().getTime() < stockPutOn.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (stockPutOn.status === constants.OD_STOCK_PUT_ON.正在进行) {
    await this.exec({
      c: 'order/stockPutOn/putOn',
      params: {
        id,
        stocks: stockPutOn.putOnFailed.map(item => item._id)
      }
    })
  }
};