const Joi = require('poolishark').Joi;
const ODBatteryInbound = require('../../../services/database/order/batteryInbound');
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = {
  user: Joi.string().required(),
  region: Joi.string().required(),
  station: Joi.string().required(),
  unitCost: Joi.number().required()
};

exports.handler = async function ({ user, region, station, unitCost }) {
  const isExistUser = ACUSer.findById({ id: user });
  if (!isExistUser) throw new NotFoundError(`未找到用户：${user}`);

  const _region = OPRegion.findById({ id: region });
  if (!_region) throw new NotFoundError(`未找到大区：${region}`);

  const batteryInbound = await ODBatteryInbound.findByUser({ user, status: constants.OD_BATTERY_INBOUND_STATUS.入库中 });
  if (batteryInbound) throw new BadRequestError('该用户有正在进行的入库单');

  return await ODBatteryInbound.create({
    user,
    region,
    station,
    unitCost
  })
};
