const Joi = require('poolishark').Joi;
const ODBatteryInbound = require('../../../services/database/order/batteryInbound');
const BKBattery = require('../../../services/database/ebike/battery');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  station: Joi.string().required(),
  battery: Joi.object({
    code: Joi.string(),
    mark: Joi.string(),
    gps: Joi.string()
  })
};

exports.handler = async function ({ id, station, battery }, tid, Transaction) {
  const odBatteryInbound =  await ODBatteryInbound.findById({ id,  selector: 'updatedAt status' });
  if (!odBatteryInbound) throw new NotFoundError('该入库单不存在');
  if (constants.OD_BATTERY_INBOUND_STATUS.入库中 !== odBatteryInbound.status) throw new BadRequestError('该入库单不在入库中');

  if (!/^E[0-9]{9}$/.test(battery.code)) throw new BadRequestError(`code${battery.code}格式不正确`);
  if (!/^E[0-9]{9}$/.test(battery.mark)) throw new BadRequestError(`mark${battery.mark}格式不正确`);
  if (!/^[0-9]{15}$/.test(battery.gps)) throw new BadRequestError(`gps${battery.gps}格式不正确`);

  const isExistBattery = await BKBattery.find({
    query: {
      $or: [{
        QRCode: battery.code,
      }, {
        mark: battery.mark,
      }, {
        gps: battery.gps,
      }]
    },
    selector: '_id QRCode mark gps'
  });
  if (isExistBattery.length) throw new BadRequestError(`该电池已经存在`);

  const regionObj = await OPBatteryStation.findById({ id: station, selector: '_id region' });
  const bkBatteryId = await BKBattery.genId();
  const bkBatteryUpdates = {
    _id: bkBatteryId,
    region: regionObj.region,
    station,
    QRCode: battery.code,
    mark: battery.mark,
    gps: battery.gps,
  };
  const bkBatteryInboundUpdates = {
    _id: id,
    $set: {
      finishedAt: new Date(),
    },
    $push: {
      inboundBatteries: {
        battery: bkBatteryId,
        time: new Date()
      }
    }
  };
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'bk_battery'
    }, {
      model: 'od_battery_inbound',
      id
    }]
  });
  await Transaction.commit({
    tid,
    updates: [bkBatteryUpdates, bkBatteryInboundUpdates]
  })
};

module.exports = injectTransaction(exports, 'order.batteryInbound.inbound');