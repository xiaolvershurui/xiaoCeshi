const Joi = require('poolishark').Joi;
const ODBatteryInbound = require('../../../services/database/order/batteryInbound');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  status: Joi.number().required()
};

exports.handler = async function ({ id, status }) {
  const odBatteryInbound =  await ODBatteryInbound.findById({ id,  selector: 'updatedAt status' });
  if (!odBatteryInbound) throw new NotFoundError('该入库单不存在');
  if (constants.OD_BATTERY_INBOUND_STATUS.已完成 === odBatteryInbound.status) throw new BadRequestError('该入库单已经完成');

  await ODBatteryInbound.update({
    id,
    updatedAt: odBatteryInbound.updatedAt,
    data: {
      status
    }
  })
};