const Joi = require('poolishark').Joi;
const ODBatteryScrap = require('../../../services/database/order/batteryScrap');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string().required(),
  status: Joi.number().required()
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {
  const now = new Date();

  const bkBattery = await BKBattery.findById({ id: battery, selector: 'QRCode mark state' });
  if (!bkBattery) throw new NotFoundError(`电池${battery}不存在`);

  const odBatteryScrap = await ODBatteryScrap.findById({
    id,
    selector: 'user region station batteries scrapFailed scrapSuccess',
    populateSelector: {
      user: 'cert.name'
    }
  });

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_battery_scrap',
      id: odBatteryScrap._id,
    }, {
      model: 'bk_battery',
      id: bkBattery._id,
    }, {
      model: 'rc_battery_op',
    }],
  });

  await Transaction.commit({
    tid,
    updates: [{
      _id: odBatteryScrap._id,
      $set: {
        status,
        finishedAt: odBatteryScrap.scrapFailed.length === 1 ? now : undefined
      },
      $pull: {
        scrapFailed: { id: bkBattery._id },
      },
      $push: {
        scrapSuccess: { id: bkBattery._id, time: now }
      }
    }, {
      _id: bkBattery._id,
      $set: {
        state: constants.BK_BATTERY_STATE.报废,
        lastUpdatedStateAt: now
      }
    }, {
      battery: bkBattery._id,
      QRCode: bkBattery.QRCode,
      mark: bkBattery.mark,
      description: `将二维码为${bkBattery.QRCode}的电池状态设置为报废`,
      remark: '',
      inStation: odBatteryScrap.station._id,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池报废,
      operatedAt: now,
      operator: odBatteryScrap.user._id,
      operatorName: odBatteryScrap.user.cert.name,
      updateState: {
        prev: bkBattery.state,
        next: constants.BK_BATTERY_STATE.报废
      }
    }],
  });
};

module.exports = injectTransaction(exports, 'order.odBatteryScrap.scrapOne');
