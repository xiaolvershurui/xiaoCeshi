const Joi = require('poolishark').Joi;
const ODBatteryScrap = require('../../../services/database/order/batteryScrap');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ user, station, batteries }) {
  batteries = [... new Set(batteries)];
  const bkBatteries = (await BKBattery.find({
    query: {
      _id: {
        $in: batteries,
      },
      state: {
        $in: [constants.BK_BATTERY_STATE.完好, constants.BK_BATTERY_STATE.损坏]
      },
      locate: constants.BK_BATTERY_LOCATE.在运营站,
      station
    },
    limit: 0,
  })).map(item => item._id);

  if (bkBatteries.length !== batteries.length) throw new BadRequestError('存在电池状态不正确，请重新检测');

  const acUser = ACUser.findById({ id: user });
  if (!acUser) throw new NotFoundError(`未找到用户：${user}`);
  const opBatteryStation = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!opBatteryStation) throw new NotFoundError(`未找到仓库：${station}`);
  const opRegion = opBatteryStation.region._id;

  const isExistsOdBatteryScrap =  await ODBatteryScrap.findByUser({ user, status: constants.OD_BATTERY_SCRAP_STATUS.报废中 });
  if (isExistsOdBatteryScrap) throw new BadRequestError('该用户有正在报废中报废单');

  if (!batteries.length) throw new BadRequestError('请报废至少一个电池');


  const odBatteryScrap = await ODBatteryScrap.create({
    user,
    region: opRegion,
    station: opBatteryStation._id
  });

  await this.exec({
    c: 'order/batteryScrap/scrap',
    params: {
      id: odBatteryScrap._id,
      batteries: bkBatteries
    }
  })
};
