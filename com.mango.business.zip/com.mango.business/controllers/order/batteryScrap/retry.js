const Joi = require('poolishark').Joi;
const ODBatteryScrap = require('../../../services/database/order/batteryScrap');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function ( { id } ) {
  const batteryScrap = await ODBatteryScrap.findById({ id, selector: 'status scrapFailed nextTry' });
  if (!batteryScrap) throw new NotFoundError('不存在该报废单');

  if (batteryScrap.nextTry) {
    if (new Date().getTime() < batteryScrap.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (batteryScrap.status === constants.OD_BATTERY_SCRAP_STATUS.报废中) {
    await this.exec({
      c: 'order/batteryScrap/scrap',
      params: {
        id,
        batteries: batteryScrap.scrapFailed.map(battery => battery.id._id)
      }
    })
  }
};
