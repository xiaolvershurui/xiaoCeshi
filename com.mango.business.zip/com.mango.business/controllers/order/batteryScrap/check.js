const Joi = require('poolishark').Joi;
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  batteries: Joi.array().items(Joi.string()),
  station: Joi.string().required()
};

exports.handler = async ({ batteries, station }) => {
  // batteries = [... new Set(batteries)];

  const bkBatteries = await BKBattery.find({
    query: {
      QRCode: {
        $in: batteries,
      },
      // state: {
      //   $in: [constants.BK_BATTERY_STATE.完好, constants.BK_BATTERY_STATE.损坏]
      // },
      // locate: constants.BK_BATTERY_LOCATE.在运营站,
      // station
    },
    limit: 0,
    selector: 'QRCode state locate station',
  });

  return batteries.reduce((memo, item) => {
    const s = bkBatteries.find(i => i.QRCode === item);
    if (!s) {
      memo = [...memo, Object.assign({ notFound: true }, { QRCode: item })];
    } else {
      if (s.station) {
        if (s.station._id !== station) {
          Object.assign(s, { notInSelfStation: true })
        }
      }
      if (s.state !== constants.BK_BATTERY_STATE.完好 && s.state !== constants.BK_BATTERY_STATE.损坏) {
        Object.assign(s, { notIntactOrDamage: true });
      }

      if (s.locate !== constants.BK_BATTERY_LOCATE.在运营站) {
        Object.assign(s, { notInStation: true });
      }
      memo = [...memo, s];
    }
    return memo;
  }, []).map(item => {
    if (item.notFound) {
      return {
        QRCode: item.QRCode,
        shouldNotCommitReason: `${item.QRCode}不存在`,
      };
    } else if (item.notIntactOrDamage || item.notInStation || item.notInSelfStation) {
      return {
        _id: item._id,
        QRCode: item.QRCode,
        shouldNotCommitReason: `
          ${item.notIntactOrDamage ? '状态应为完好或损坏, ' : ''}
          ${item.notInStation ? '去向应为在运营站' : ''}
          ${item.notInSelfStation ? '且应为自己当前站点' : ''}
        `,
      };
    } else {
      return {
        _id: item._id,
        QRCode: item.QRCode,
      };
    }
  });
};
