const Joi = require('poolishark').Joi;
const ODBatteryScrap = require('../../../services/database/order/batteryScrap');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string())
};

exports.handler = async function ({ id, batteries }) {
  const odBatteryScrap = await ODBatteryScrap.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryScrap) throw new NotFoundError(`不存在报废单:${id}`);

  if (odBatteryScrap.status !== constants.OD_BATTERY_SCRAP_STATUS.报废中) throw new BadRequestError('该报废单不在报废中');

  await ODBatteryScrap.update({
    id: odBatteryScrap._id,
    updatedAt: odBatteryScrap.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      scrapFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryScrap/scrapOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_SCRAP_STATUS.已完成 : constants.OD_BATTERY_SCRAP_STATUS.报废中
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};
