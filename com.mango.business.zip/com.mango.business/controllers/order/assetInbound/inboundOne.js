const Joi = require('poolishark').Joi;
const ODAssetInbound = require('../../../services/database/order/assetInbound');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object({
    code: Joi.string(),
    name: Joi.string(),
    count: Joi.number(),
    unitCost: Joi.number(),
  }).required(),
  status: Joi.number().required()
};

exports.handler = async ({ id, asset, status }, tid, Transaction) => {
  const odAssetInbound = await ODAssetInbound.findById({
    id,
    selector: 'region station assets inboundFailed inboundSuccess'
  });
  const assetData = await STAsset.findByCode({ code: asset.code, selector: 'code type' });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetInbound.station._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });
  const exists = odAssetInbound.assets.search({ code: asset.code });
  if (exists) {
    exists.intactCount += asset.intactCount;
  }else {
    odAssetInbound.assets.push({
      id: assetData._id,
      code: asset.code,
      count: asset.count,
    })
  }
  let success = {
    code: asset.code,
    name: asset.name,
    count: asset.count,
    time: new Date(),
  };
  if(asset.unitCost){
    success.unitCost = asset.unitCost
  }
  // 添加成功
  odAssetInbound.inboundSuccess.push(success);
  const assetInboundUpdates = {
    _id: odAssetInbound._id,
    assets: odAssetInbound.assets,
    inboundSuccess: odAssetInbound.inboundSuccess
  };
  // 删除失败记录
  assetInboundUpdates.$pull = { inboundFailed: { code: asset.code } };

  assetInboundUpdates.status = odAssetInbound.inboundFailed.length > 1 ? constants.OD_ASSET_INBOUND_STATE.正在进行 : status;
  assetInboundUpdates.finishedAt = odAssetInbound.inboundFailed.length === 1 ? new Date() : undefined;

  const bkAssetUpdates = {
    _id: bkAsset._id,
    $inc: {
      totalCount: asset.count,
      intactCount: asset.count
    }
  };
  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount + asset.intactCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_inbound',
      id: odAssetInbound._id
    }, {
      model: 'bk_asset',
      id: bkAsset._id
    }]
  });

  await Transaction.commit({
    tid,
    updates: [assetInboundUpdates, bkAssetUpdates]
  })
};

module.exports = injectTransaction(exports, 'account.order.odAssetInbound.inboundOne');