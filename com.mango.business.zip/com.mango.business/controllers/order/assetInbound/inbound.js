const Joi = require('poolishark').Joi;
const ODAssetInbound = require('../../../services/database/order/assetInbound');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    count: Joi.number(),
    unitCost: Joi.number(),
  }))
};

exports.handler = async function ( { id, assets } ) {
  const odAssetInbound =  await ODAssetInbound.findById({
    id,
    selector: 'updatedAt status'
  });
  if (!odAssetInbound) throw new NotFoundError('该入库单不存在');
  if (constants.OD_ASSET_INBOUND_STATE.正在进行 !== odAssetInbound.status) throw new BadRequestError('该入库单不在进行中');
  const stAssets = await STAsset.findByCodes({ codes: assets.map(asset => asset.code), selector: 'type code' });
  const wrongAsset = assets.filter(asset => !stAssets.search({ code: asset.code }));
  if (wrongAsset.length > 0) throw new BadRequestError(`存在未录入配件${wrongAsset.map(asset => asset.code).join(',')}`);
  const assetMap = {};
  stAssets.forEach(stAsset => {
    assetMap[stAsset.code] = { name: stAsset.type }
  });
  // 初始化
  await ODAssetInbound.update({
    id: odAssetInbound._id,
    updatedAt: odAssetInbound.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000,
      inboundFailed: assets.map(asset => {
        const obj ={
          code: asset.code,
          name: assetMap[asset.code].name,
          count: asset.count,
          errMessage: '初始化',
          time: new Date()
        };
        if(asset.unitCost){
          obj.unitCost = asset.unitCost;
        }
        return obj;
      })
    }
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetInbound/inboundOne',
            params: {
              id,
              asset: Object.assign(asset, {
                name: assetMap[asset.code].name
              }),
              status: count === assets.length ? constants.OD_ASSET_INBOUND_STATE.已经完成 : constants.OD_ASSET_INBOUND_STATE.正在进行
            }
          })
        } catch (err) {
          count--;
          console.error(err);
        }
      }
    })()
  })
};