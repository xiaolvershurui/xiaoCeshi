const Joi = require('poolishark').Joi;
const ODAssetInbound = require('../../../services/database/order/assetInbound');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = {
  user: Joi.string().required(),
  region: Joi.string().required(),
  station: Joi.string().required(),
  assets: Joi.array().items({
    code: Joi.string().required(),
    count: Joi.number().required(),
    unitCost: Joi.number(),
  }),
};

exports.handler = async function ( { user, region, station, assets, unitCost } ) {
  const _user = ACUSer.findById({ id: user });
  if (!_user) throw new NotFoundError(`未找到用户：${user}`);

  const _region = OPRegion.findById({ id: region });
  if (!_region) throw new NotFoundError(`未找到大区：${region}`);

  const _station = OPRegion.findById({ id: station });
  if (!_station) throw new NotFoundError(`未找到仓库：${region}`);

  const assetInbound = await ODAssetInbound.findByUser({
    user,
    status: constants.OD_ASSET_INBOUND_STATE.正在进行
  });
  if (assetInbound) throw new BadRequestError('该用户有正在进行的入库单');

  const odAssetInbound = await ODAssetInbound.create({
    user,
    station,
    region,
    assets: []
  });
  await this.exec({
    c: 'order/assetInbound/inbound',
    params: {
      id: odAssetInbound._id,
      assets
    }
  })
};
