const Joi = require('poolishark').Joi;
const ODBatteryEndCharge = require('../../../services/database/order/batteryEndCharge');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  user: Joi.string(),
};

exports.handler = async function ( { id, user } ) {
  const batteryEndCharge = await ODBatteryEndCharge.findById({ id, selector: 'status endChargeFailed nextTry' });
  if (!batteryEndCharge) throw new NotFoundError('不存在该下架单');

  if (batteryEndCharge.status !== constants.OD_BATTERY_END_CHARGE_STATUS.下架中) throw new BadRequestError('非下架中下架单不能重试');

  if (batteryEndCharge.nextTry) {
    if (new Date().getTime() < batteryEndCharge.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (batteryEndCharge.status === constants.OD_BATTERY_END_CHARGE_STATUS.下架中) {
    await this.exec({
      c: 'order/batteryEndCharge/endCharge',
      params: {
        id,
        user,
        batteries: batteryEndCharge.endChargeFailed.map(battery => battery.id._id)
      }
    })
  }
};