const Joi = require('poolishark').Joi;
const ODBatteryEndCharge = require('../../../services/database/order/batteryEndCharge');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  user: Joi.string().allow(''), // 重试操作人
  batteries: Joi.array().items(Joi.string()),
};

exports.handler = async function ({ id, user, batteries }) {
  const odBatteryEndCharge = await ODBatteryEndCharge.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryEndCharge) throw new NotFoundError(`不存在报废单:${id}`);

  if (odBatteryEndCharge.status !== constants.OD_BATTERY_END_CHARGE_STATUS.下架中) throw new BadRequestError('该上架单不在上架中');

  await ODBatteryEndCharge.update({
    id: odBatteryEndCharge._id,
    updatedAt: odBatteryEndCharge.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      endChargeFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      }),
    },
    arrayOp: user ? {
      $push: {
        nextTryRecords: {
          operator: user,
          triedAt: new Date()
        }
      }
    } : undefined
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryEndCharge/endChargeOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_END_CHARGE_STATUS.已完成 : constants.OD_BATTERY_END_CHARGE_STATUS.下架中,
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};