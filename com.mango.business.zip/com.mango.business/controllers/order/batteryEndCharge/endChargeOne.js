const Joi = require('poolishark').Joi;
const ODBatteryEndCharge = require('../../../services/database/order/batteryEndCharge');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string().required(),
  status: Joi.number().required(),
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {

  const odBatteryEndCharge  = await ODBatteryEndCharge.findById({ id, selector: 'region station endChargeFailed endChargeSuccess' });
  if (!odBatteryEndCharge) throw new NotFoundError('报损单不存在');

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id: odBatteryEndCharge._id,
      model: 'od_battery_end_charge'
    }, {
      id: battery,
      model: 'bk_battery'
    }]
  });

  await Transaction.commit({
    tid,
    updates: [{
      _id: odBatteryEndCharge._id,
      $set: {
        status: status === constants.OD_BATTERY_END_CHARGE_STATUS.已完成 ? status === constants.OD_BATTERY_END_CHARGE_STATUS.已完成 : status,
        finishedAt: odBatteryEndCharge.endChargeFailed === 1 ? new Date() : undefined,
      },
      $pull: { endChargeFailed: { id: battery } },
      $push: { endChargeSuccess: { id: battery, time: new Date() } }
    }, {
      _id: battery,
      $set: {
        charge: false,
        underVoltage: false
      }
    }]
  });
};

module.exports = injectTransaction(exports, 'account.order.odBatteryEndCharge.endChargeOne');