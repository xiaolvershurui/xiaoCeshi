const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const ODBatteryEndCharge = require('../../../services/database/order/batteryEndCharge');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  batteries: Joi.array().items({
    code: Joi.string().required(),
  })
};

exports.handler = async function ({ user, station, batteries }) {
  const acUser = ACUser.findById({ id: user });
  if (!acUser) throw new NotFoundError(`未找到用户：${user}`);

  console.log(station);
  const opStation = await OPBatteryStation.findById({ id: station, selector: '_id region' });
  if (!opStation) throw new NotFoundError(`未找到仓库：${station}`);

  const region = opStation.region;

  const batteryEndChargeApply =  await ODBatteryEndCharge.findByUser({ user, status: constants.OD_BATTERY_END_CHARGE_STATUS.下架中 });
  if (batteryEndChargeApply) throw new BadRequestError('该用户有正在上架中的上架单');

  if (!batteries.length) throw new BadRequestError('请上架至少一个电池');

  let batteryIds = await BKBattery.findByCodesAndStation({
    codes: batteries.map(battery => battery.code),
    station,
    selector: '_id state'
  });
  batteryIds = batteryIds.map(battery => battery._id);
  if (batteries.length !== batteryIds.length) throw new BadRequestError('请确认该电池存在并且存在于您当前所在仓库');

  const batteryDetails = await BKBattery.findByIds({ ids: batteryIds, selector: '_id region station locate state' });
  const allInStationAndIntact = batteryDetails.every(batteryDetail => {
    return batteryDetail.locate === constants.BK_BATTERY_LOCATE.在运营站 && batteryDetail.state === constants.BK_BATTERY_STATE.完好
  });
  if (!allInStationAndIntact) throw new BadRequestError ('有电池不在运营站或存在已损坏电池');

  const odBatteryEndCharge = await ODBatteryEndCharge.create({
    user,
    region,
    station
  });
  await this.exec({
    c: 'order/batteryEndCharge/endCharge',
    params: {
      id: odBatteryEndCharge._id,
      batteries: batteryIds,
    }
  })
};
