const Joi = require('poolishark').Joi;
const ODBatteryInspect = require('../../../services/database/order/batteryInspect');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');
const BKBattery = require('../../../services/database/ebike/battery');

exports.validate = {
  station: Joi.string(),
  operator: Joi.string(),
  receiver: Joi.string(),
  batteries: Joi.array().items(Joi.object({
    id: Joi.string()
  }))
};

exports.handler = async function ({  station, receiver, batteries, operator }){
  const bkBattery = await BKBattery.find({
    query:{
      _id: {
        $in: batteries.map((b)=>{
          return b.id
        })
      },
      station,
      locate: constants.BK_BATTERY_LOCATE.在运营站
    },
    limit: 0,
    selector: 'status'
  });
  if(bkBattery.length !== batteries.length){
   const exceptions = batteries.filter(b=> {
     const thisBattery = bkBattery.search({ _id: b.id });
     if(!thisBattery){
       return b.id
     }
   });
    throw new BadRequestError(`${exceptions.join('')} 状态异常或不存在`);
  }
  const odBatteryInspect = await ODBatteryInspect.create({
    station,
    region: (await OPBatteryStation.findById({
      id: station,
      selector: 'region'
    })).region._id,
    operator,
    status: constants.OD_BATTERY_INSPECT_STATUS.领用处理中,
    batteries,
    user: receiver,
    nextTry: Date.now() + 180000,
  });
  await this.exec({
    c: 'order/batteryInspect/take',
    params: {
      id: odBatteryInspect._id,
      dispenser: operator,
      station,
      receiver,
      batteries
    }
  });
};