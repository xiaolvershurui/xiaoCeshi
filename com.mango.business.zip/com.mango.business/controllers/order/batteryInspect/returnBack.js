const Joi = require('poolishark').Joi;
const ODBatteryInspect = require('../../../services/database/order/batteryInspect');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  station: Joi.string().required(),
  receiver: Joi.string().required(),
  batteries: Joi.array().items({
    id: Joi.string()
  }),
  unknownCount: Joi.number()
};

exports.handler = async function ({ id, station, receiver, batteries, unknownCount }) {
  const bkBattery = await BKBattery.find({
    query:{
      _id: {
        $in: batteries.map((b)=>{
          return b.id
        })
      },
      station,
      locate: constants.BK_BATTERY_LOCATE.在运营站
    },
    limit: 0,
    selector: 'status'
  });
  if(bkBattery.length !== batteries.length){
    const exceptions = batteries.filter(b=> {
      const thisBattery = bkBattery.search({ _id: b.id });
      if(!thisBattery){
        return 1;
      }
    });
    const error = exceptions.map(e=>{
      return e.id;
    });
    throw new BadRequestError(`电池 Id: ${error.join('-').toString()} 状态异常或不存在`);
  }
  const odBatteryInspect = await ODBatteryInspect.findById({
    id,
    selector:' status '
  });
  if(!odBatteryInspect){
    throw new BadRequestError('该电池领取巡检单不存在');
  }
  if( odBatteryInspect.status!== constants.OD_BATTERY_INSPECT_STATUS.电池携带){
    throw new BadRequestError('当前非携带状态,无法归还');
  }
  let batteriesArray = batteries.map(b=>{
      return {
        id: b.id,
        time: new Date()
      }
  });
  const batteryObjs = batteriesArray.map(b=>{
    return {
      id: b.id,
      station,
      receiver,
      time: b.time,
      unknownCount,
    }
  });
  await ODBatteryInspect.update({
    id,
    data: {
      returnFailed: batteryObjs,
      nextTry: new Date(Date.now()+180000),
      returnSuccess: {
        station,
        receiver,
        time: new Date()
      }
    }
  });
  await this.exec({
    c: 'order/batteryInspect/return',
    params: {
      id,
      batteries,
      station,
      receiver,
      unknownCount
    }
  });
};
