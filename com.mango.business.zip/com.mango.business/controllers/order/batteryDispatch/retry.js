const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  operator: Joi.string(),
};

exports.handler = async function ({ id, operator }) {
  const odBatteryDispatch = await ODBatteryDispatch.findById({
    id,
    selector: 'status outboundFailed dispenser receiver inboundFailed nextTry'
  });
  if (!odBatteryDispatch) throw new NotFoundError('未找到此调度单');
  const nextTry = new Date(odBatteryDispatch.nextTry);
  if (nextTry.getTime() > Date.now()) {
    throw new BadRequestError(`请在${nextTry.toLocaleString()}后重试`);
  }
  if ([constants.OD_BATTERY_DISPATCH_STATUS.出库中, constants.OD_BATTERY_DISPATCH_STATUS.入库中].includes(odBatteryDispatch.status)) {
    await ODBatteryDispatch.update({
      id,
      data: {},
      arrayOp: {
        $push: {
          nextTryRecords: {
            operator,
            triedAt: new Date()
          }
        }
      }
    });
    if (odBatteryDispatch.status === constants.OD_BATTERY_DISPATCH_STATUS.出库中) {
      await this.exec({
        c: 'order/batteryDispatch/take',
        params: {
          id,
          batteries: odBatteryDispatch.outboundFailed.map(battery => battery.id._id)
        }
      });
    }
    if (odBatteryDispatch.status === constants.OD_BATTERY_DISPATCH_STATUS.入库中) {
      await this.exec({
        c: 'order/batteryDispatch/return',
        params: {
          id,
          endBatteries: odBatteryDispatch.inboundFailed.map(battery => battery.id._id),
        }
      });
    }
  } else {
    throw new Error('订单状态属于非可重试状态')
  }
};