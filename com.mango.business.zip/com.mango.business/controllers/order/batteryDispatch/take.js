const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const BKBattery = require('../../../services/database/ebike/battery');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string(),
   batteries: Joi.array().items(Joi.string())
};

exports.handler = async function({ id, batteries }) {
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryDispatch/takeOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_DISPATCH_STATUS.运输中 : constants.OD_BATTERY_DISPATCH_STATUS.出库中
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => {
      throw new BadRequestError('调度单出库错误')
    });
  });
};