const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const BKBattery = require('../../../services/database/ebike/battery');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  dispenser: Joi.string().required(),
  startStation: Joi.string().required(),
  endStation: Joi.string().required(),
  batteries: Joi.array().items(Joi.object({
    code: Joi.string(),
  }))
};

exports.handler = async function ({ dispenser, startStation, endStation, batteries }){
  const acUser = await ACUser.findById({ id: dispenser });
  if(!acUser) throw new  NotFoundError(`发起人: ${dispenser}不存在`);

  const opStations = await OPBatteryStation.find({
    query: { _id: { $in: [startStation,endStation] } },
    selector: '_id region'
  });
  if(opStations.length !== 2) throw new NotFoundError(`Station 不存在`);
  const region = opStations[0].region;

  let batteryIds = await BKBattery.findByCodesAndStation({
    codes: batteries.map(battery => battery.code),
    station: startStation,
    selector: '_id state'
  });
  batteryIds = batteryIds.map(battery => battery._id);
  if (batteries.length !== batteryIds.length) throw new BadRequestError('请确认该电池存在并且存在于您当前所在仓库');

  const odBatteryDispatch = await ODBatteryDispatch.create({
    dispenser,
    startStation,
    endStation,
    region,
    status: constants.OD_BATTERY_DISPATCH_STATUS.出库中,
    nextTry: Date.now() + 120000,
    outboundFailed: batteryIds.map(battery => {
      return {
        id: battery,
        time: new Date(),
        errorMessage: '初始化出库'
      }
    })
  });
  await this.exec({
    c: 'order/batteryDispatch/take',
    params: {
      id: odBatteryDispatch._id,
      batteries: batteryIds
    }
  });
};