const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const BKBattery = require('../../../services/database/ebike/battery');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string().required(),
  status: Joi.number().required(),
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {
  const odBatteryDispatch = await ODBatteryDispatch.findById({ id, selector: 'region startStation endStation' });
  if (!odBatteryDispatch) throw new NotFoundError('该调配单不存在');

  const odDispatchUpdates = {
    _id: id,
    $set: {
      status: status === constants.OD_BATTERY_DISPATCH_STATUS.已完成 ? constants.OD_BATTERY_DISPATCH_STATUS.已完成 : status ,
      finishedAt: status === constants.OD_BATTERY_DISPATCH_STATUS.已完成 ? new Date() : undefined
    },
    $pull:{
      inboundFailed: {
        id: battery
      }
    },
    $push: {
      inboundSuccess: {
        id: battery,
        time: new Date()
      }
    }
  };
  const bkBatteryUpdates = {
    _id: battery,
    $set: {
      fromStation: odBatteryDispatch.startStation,
      station: odBatteryDispatch.endStation,
      locate: constants.BK_BATTERY_LOCATE.在运营站
    }
  };

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_battery_dispatch',
      id
    }, {
      model: 'bk_battery',
      id: battery
    }]
  });
  await Transaction.commit({
    tid,
    updates: [ odDispatchUpdates, bkBatteryUpdates]
  });
};

module.exports = injectTransaction(exports, 'account.order.batteryDispatch.returnOne');
