const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const BKBattery = require('../../../services/database/ebike/battery');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string(),
  status: Joi.number(),
};

exports.handler = async function({ id, battery, status }, tid, Transaction){
  const odBatteryDispatch  = await ODBatteryDispatch.findById({ id, selector: 'region startStation' });
  if (!odBatteryDispatch) throw new NotFoundError('该调度单不存在');

  const bkBatteryUpdates = {
    _id: battery,
    $set:{
      locate: constants.BK_BATTERY_LOCATE.运输途中
    }
  };

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'od_battery_dispatch',
    }, {
      id: battery,
      model: 'bk_battery',
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        status: status === constants.OD_BATTERY_DISPATCH_STATUS.运输中 ? constants.OD_BATTERY_DISPATCH_STATUS.运输中 : status
      },
      $pull:{
        outboundFailed:{
          id: battery
        }
      },
      $push: {
        outboundSuccess: {
          id: battery,
        }
      }
    }, bkBatteryUpdates]
  });
};

module.exports = injectTransaction(exports, 'account.order.batteryDispatch.takeOne');
