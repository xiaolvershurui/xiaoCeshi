const Joi = require('poolishark').Joi;
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  endBatteries: Joi.array().items(Joi.string()),
};

exports.handler = async function({id, endBatteries}){
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let battery of endBatteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryDispatch/returnOne',
            params: {
              id,
              battery,
              status: count === endBatteries.length ? constants.OD_BATTERY_DISPATCH_STATUS.已完成 : constants.OD_BATTERY_DISPATCH_STATUS.入库中,
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => {
      throw new BadRequestError('调配单入库失败')
    });
  });
};