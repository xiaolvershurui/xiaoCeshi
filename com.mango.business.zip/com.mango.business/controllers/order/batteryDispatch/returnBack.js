const Joi = require('poolishark').Joi;
const ODBatteryDispatch = require('../../../services/database/order/batteryDispatch');
const BKBattery = require('../../../services/database/ebike/battery');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  receiver: Joi.string().required(),
  endBatteries: Joi.array().items({
    code: Joi.string().required(),
  })
};

exports.handler = async function({ receiver, id, endBatteries }){
  const acUser = await ACUser.findById({ id: receiver, selector:'_id' });
  if (!acUser)  throw new NotFoundError(`未找到此运营人员${receiver}`);

  let batteryDispatch = await ODBatteryDispatch.findById({ id, selector: 'status region endStation updatedAt' });
  if(!batteryDispatch) throw new NotFoundError(`未找到此调配单: ${id}`);

  if( batteryDispatch.status !== constants.OD_BATTERY_DISPATCH_STATUS.运输中 ) throw new BadRequestError(`调配单状态异常`);

  let batteryIds = await BKBattery.findByCodes({
    codes: endBatteries.map(battery => battery.code),
    selector: '_id state'
  });
  batteryIds = batteryIds.map(battery => battery._id);
  // if (batteries.length !== batteryIds.length) throw new BadRequestError('请确认该电池存在并且存在于始发仓库');

  await ODBatteryDispatch.update({
    id,
    data:{
      nextTry: Date.now()+120000,
      receiver,
      status: constants.OD_BATTERY_DISPATCH_STATUS.入库中,
      inboundFailed: batteryIds.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '调度单入库初始化'
        }
      })
    }
  });
  await this.exec({
    c: 'order/batteryDispatch/return',
    params: {
      id: batteryDispatch._id,
      endBatteries,
    }
  });
};