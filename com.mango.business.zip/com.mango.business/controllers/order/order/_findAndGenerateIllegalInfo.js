const constants = require('../../../com.mango.common/settings/constants');
const OPPolygon = require('../../../services/database/operation/polygon');
const ODOrder = require('../../../services/database/order/order');
const ACUser = require('../../../services/database/account/user');
const ODIllegal = require('../../../services/database/order/illegal');
const STSUrl = require('../../../services/database/setting/surl');
const SMS = require('../../../api/yunpian');
const { crypto } = require('xx-utils');
const { key, iv } = require('../../../com.mango.common/settings/keys');

const findNearestSegment = require('./_findNearestSegment');

const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

module.exports = async (id, selector, populateSelector) => {
  const illegal = await ODIllegal.findByOrder({
    order: id,
    selector,
    populateSelector,
  });
  if (illegal) return illegal;
  const order = await ODOrder.findById({
    id, selector: 'route.path user region', populateSelector: {
      user: 'auth.tel auth.roles illegalCount updatedAt credit',
    },
  });
  if (!order) throw new NotFoundError('未查询到相应的订单');
  const points = order.route ? order.route.path.coordinates : [];
  const result = await points.reduce(async (memo, lngLat, index) => {
    memo = await memo;
    const ts = order.route.path.ts[index];
    const info = {
      ts,
      lngLat,
      illegals: {
        wrongDirection: null,
        acrossMotorway: null,
      },
    };
    const intersectPolygons = await OPPolygon.findIntersect({
      center: lngLat,
      query: {
        enable: true,
      },
      selector: '_id directionLine path type name',
    });
    info.polygons = intersectPolygons.map(polygon => {
      const transformedPolygon = {
        type: polygon.type,
        name: polygon.name,
        _id: polygon._id,
      };
      // 暂时未检测到逆行的情况下，如果在逆行检测区，并且检测区有方向数据，则进行逆行检测
      if (!info.illegals.wrongDirection && polygon.type === constants.OP_POLYGON_TYPE.逆行检测区 && polygon.directionLine) {
        if (memo.points.length > 0) {
          const prevLngLat = memo.points[memo.points.length - 1].lngLat;
          // 检测逆行
          // 匹配方向线
          const [p1, p2] = findNearestSegment(lngLat, polygon.directionLine.coordinates).segment;
          // 方向线向量
          const directionVector = [p2[0] - p1[0], p2[1] - p1[1]];
          // 轨迹瞬时向量
          const trackVector = [lngLat[0] - prevLngLat[0], lngLat[1] - prevLngLat[1]];
          // 求点乘
          const dotMulti = (directionVector[0] * trackVector[0]) + (directionVector[1] * trackVector[1]);
          if (dotMulti < 0) {
            // 逆行
            info.illegals.wrongDirection = transformedPolygon;
          }
        }
      }

      // 检查非法横跨机动车道
      if (!info.illegals.acrossMotorway && polygon.type === constants.OP_POLYGON_TYPE.非法横跨机动车道检测区) {
        info.illegals.acrossMotorway = transformedPolygon;
      }

      // 经过的polygon记录
      if (transformedPolygon.type !== constants.OP_POLYGON_TYPE.巡检区 && !memo.passedPolygons.search({ _id: transformedPolygon._id })) {
        memo.passedPolygons.add(Object.assign({
          path: polygon.path,
          directionLine: polygon.directionLine,
        }, transformedPolygon));
      }
      return transformedPolygon;
    });

    // 已经有缓存的逆行信息，本次没有逆行信息或者逆行信息和缓存不一致，则进行逆行信息归并
    if (memo._tempWrongDirection && (!info.illegals.wrongDirection || info.illegals.wrongDirection._id !== memo._tempWrongDirection[0].polygon._id)) {
      // 判断是否逆行的点数阈值 少于N个点，认为是误判
      if (memo._tempWrongDirection.length >= 10 || (order.region._id === '1703301201006' && memo._tempWrongDirection.length >= 3)) {
        const illegal = memo._tempWrongDirection.reduce((stuff, info, index) => {
          if (!stuff.polygon) stuff.polygon = info.polygon;
          stuff.points.push({
            lngLat: info.lngLat,
            ts: info.ts,
          });
          if (index === memo._tempWrongDirection.length - 1) {
            stuff.duration = Math.ceil((info.ts.getTime() - memo._tempWrongDirection[0].ts.getTime()) / 1000);
          }
          return stuff;
        }, {
          type: 'wrongDirection',
          polygon: null,
          points: [],
          duration: 0,
        });
        // 如果本次的polygon与上次的相同，则进行合并
        const lastIllegal = memo.illegals.length > 0 ? memo.illegals[memo.illegals.length - 1] : null;
        if (lastIllegal && lastIllegal.type === 'wrongDirection' && lastIllegal.polygon._id === illegal.polygon._id) {
          lastIllegal.points.push(...illegal.points);
          lastIllegal.duration += illegal.duration;
        } else {
          memo.illegals.push(illegal);
          memo.wrongDirectionTimes += 1;
          memo.totalTimes += 1;
        }
      }
      memo._tempWrongDirection = null;
    } else if (info.illegals.wrongDirection) {
      // 补充缓存的逆行信息
      if (!memo._tempWrongDirection) memo._tempWrongDirection = [];
      memo._tempWrongDirection.push({
        polygon: info.illegals.wrongDirection,
        lngLat,
        ts,
      });
    }

    // 对非法横跨机动车道信息的归并
    if (memo._tempAcrossMotorway && (!info.illegals.acrossMotorway || info.illegals.acrossMotorway._id !== memo._tempAcrossMotorway[0].polygon._id)) {
      // 少于2个点，认为是误判
      if (memo._tempAcrossMotorway.length >= 2) {
        const illegal = memo._tempAcrossMotorway.reduce((stuff, info, index) => {
          if (!stuff.polygon) stuff.polygon = info.polygon;
          stuff.points.push({
            lngLat: info.lngLat,
            ts: info.ts,
          });
          if (index === memo._tempAcrossMotorway.length - 1) {
            stuff.duration = Math.ceil((info.ts.getTime() - memo._tempAcrossMotorway[0].ts.getTime()) / 1000);
          }
          return stuff;
        }, {
          type: 'acrossMotorway',
          polygon: null,
          points: [],
          duration: 0,
        });

        // 如果本次的polygon与上次的相同，则进行合并
        const lastIllegal = memo.illegals.length > 0 ? memo.illegals[memo.illegals.length - 1] : null;
        if (lastIllegal && lastIllegal.type === 'acrossMotorway' && lastIllegal.polygon._id === illegal.polygon._id) {
          lastIllegal.points.push(...illegal.points);
          lastIllegal.duration += illegal.duration;
        } else {
          memo.illegals.push(illegal);
          memo.acrossMotorwayTimes += 1;
          memo.totalTimes += 1;
        }
      }
      memo._tempAcrossMotorway = null;
    } else if (info.illegals.acrossMotorway) {
      // 补充缓存的非法横跨机动车道信息
      if (!memo._tempAcrossMotorway) memo._tempAcrossMotorway = [];
      memo._tempAcrossMotorway.push({
        polygon: info.illegals.acrossMotorway,
        lngLat,
        ts,
      });
    }

    memo.points.push(info);
    return memo;
  }, Promise.resolve({
    points: [],
    illegals: [],
    wrongDirectionTimes: 0,
    acrossMotorwayTimes: 0,
    totalTimes: 0,
    passedPolygons: [],
    _tempWrongDirection: null,
    _tempAcrossMotorway: null,
  }));
  const { _id } = await ODIllegal.create({
    user: order.user._id,
    region: order.region._id,
    order: order._id,
    points: result.points,
    illegals: result.illegals,
    passedPolygons: result.passedPolygons,
    wrongDirectionTimes: result.wrongDirectionTimes,
    acrossMotorwayTimes: result.acrossMotorwayTimes,
    totalTimes: result.totalTimes,
  });
  if (result.totalTimes > 0 && process.env.NODE_ENV === 'production') {
    const secretId = crypto.aes256(key, iv, 'utf-8', 'hex').encode(id);
    const surl = await STSUrl.findSUrl(`https://mangoebike.com/operation/index.html#/order/illegal?id=${secretId}`);
    await SMS.sendText(order.user.auth.tel, `【芒果电单车】您的行程${order._id}发生了违规：${[result.wrongDirectionTimes > 0 ? `逆行${result.wrongDirectionTimes}次` : '', result.acrossMotorwayTimes > 0 ? `非法横穿机动车道${result.acrossMotorwayTimes}次` : ''].join('、')}，详情请查看 http://u.nowon.top/${surl}`);
  }

  ODOrder.update({
    id, data: {
      illegal: _id,
      isIllegal: !!result.totalTimes,
    },
  });

  ACUser.update({
    id: order.user._id,
    updatedAt: order.user.updatedAt,
    data: {
      illegalCount: (order.user.illegalCount || 0) + 1,
      // credit: order.illegalCount ? (order.user.credit - constants.ILLEGAL_RIDING_CREDIT) : order.user.credit
    },
  });

  return await ODIllegal.findById({
    id: _id,
    selector,
    populateSelector,
    read: 'primary',
  });
};
