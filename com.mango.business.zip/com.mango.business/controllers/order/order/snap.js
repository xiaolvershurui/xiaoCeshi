const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const ODOrder = require('../../../services/database/order/order');
const BKStock = require('../../../services/database/ebike/stock');
const OPPolygon = require('../../../services/database/operation/polygon');
const OPRegion = require('../../../services/database/operation/region');
const ACCoupon = require('../../../services/database/account/coupon');
const RCUserCapture = require('../../../services/database/record/userCapture');
const constants = require('../../../com.mango.common/settings/constants');
const { judgement } = require('xx-utils');
const Cache = require('../../../com.mango.common/utils/cache');
const Core = require('../../../services/core/shark');
const calculateDistanceBetweenPointAndPolygon = require('../../../utils/calculateDistanceBetweenPointAndPolygon');


const calculateLease = ({ startTime, endTime }) => {
  if (startTime.is.over(endTime)) throw new Error('结束时间不能比开始时间早');
  const {
    OD_DAY_TO_NIGHT_AT, OD_NIGHT_TO_DAY_AT, OD_ORDER_EXPIRE_DURATION,
    OD_DAY_DURATION, OD_NIGHT_DURATION,
  } = constants;
  let dayDuration = 0;
  let nightDuration = 0;
  let totalDuration = Math.ceil((endTime.getTime() - startTime.getTime()).msTo.minute);
  const todayStart = OD_NIGHT_TO_DAY_AT.of(startTime);
  const todayEnd = OD_DAY_TO_NIGHT_AT.of(startTime);
  const tomorrowStart = '1 day'.after(todayStart);
  const tomorrowEnd = '1 day'.after(todayEnd);
  // 判断是否超过24小时，超过24小时按24小时算，计算使用时长
  if (endTime.is.over('24 hours'.after(startTime))) {
    dayDuration = OD_DAY_DURATION;
  } else if (todayStart.is.over(startTime)) {
    if (todayStart.is.over(endTime)) { // 全算夜间
    } else if (todayEnd.is.over(endTime)) { // 先夜间后白天 todayStart分界
      dayDuration = (endTime.getTime() - todayStart.getTime()).msTo.minute;
    } else { // 整个白天，剩下夜间
      dayDuration = OD_DAY_DURATION;
    }
  } else if (startTime.is.over(todayEnd)) {
    if (tomorrowStart.is.over(endTime)) { // 全算夜间
    } else if (tomorrowEnd.is.over(endTime)) { // 先夜间后白天 tomorrowStart分界
      dayDuration = (endTime.getTime() - tomorrowStart.getTime()).msTo.minute;
    } else { // 整个白天，剩下夜间
      dayDuration = OD_DAY_DURATION;
    }
  } else {
    if (todayEnd.is.over(endTime)) { // 全算白天
      dayDuration = totalDuration;
    } else if (tomorrowStart.is.over(endTime)) { // 先白天后夜间 todayEnd分界
      dayDuration = (todayEnd.getTime() - startTime.getTime()).msTo.minute;
    } else { // 整个夜间，剩下白天
      nightDuration = OD_NIGHT_DURATION;
      dayDuration = totalDuration - nightDuration;
    }
  }
  dayDuration = Math.ceil(dayDuration);
  nightDuration = totalDuration - dayDuration;
  return {
    dayDuration,
    nightDuration,
    totalDuration,
  };
};

const checkBad = ({ duration, distance }) => {
  return (duration <= constants.OD_BAD_ORDER_BUFFER_TIME) && (distance <= constants.OD_BAD_ORDER_BUFFER_DISTANCE);
};

const calculatePayInfo = async ({
  user, calculateDistance, inPark, price,
  dayDuration, nightDuration,
  isBad, isFreeTrip, parkingDiscount,
}) => {
  let { timeUnit, mileageUnit, floorCost, enableInsurance, insurance } = price;
  const ret = await new Cache('mg.setup.client').getJSON('parkingRate');
  const parkingRate = (parkingDiscount && parkingDiscount.rate) || (ret && ret.value && parseFloat(ret.value.discount)) || 1;
  const parkingRateContent = (parkingDiscount && parkingDiscount.content) || (ret && ret.value && ret.value.content) || '';
  if (isFreeTrip || isBad) {
    timeUnit = 0;
    mileageUnit = 0;
    floorCost = 0;
    insurance = 0;
  }
  // 计时租金
  const timeRent = {};
  // 原单价
  timeRent.originalUnit = parseInt(timeUnit);
  // 是否停在停车区
  timeRent.actualUnit = inPark ? Math.ceil(timeUnit * parkingRate) : timeUnit;
  if (user.credit < constants.AC_LOW_CREDIT_POINT) {
    // 信用分过低的情况5元/分钟
    timeRent.actualUnit = constants.AC_LOW_CREDIT_TIME_UNIT;
  }
  timeRent.actualUnit = parseInt(timeRent.actualUnit);
  // 白天时长计费活动折前
  timeRent.dayOriginalTotal = parseInt(timeRent.actualUnit * dayDuration);
  // 夜间时长计费活动折前
  timeRent.nightOriginalTotal = parseInt(timeRent.actualUnit * nightDuration);
  // 活动折前总租金
  timeRent.originalTotal = timeRent.dayOriginalTotal + timeRent.nightOriginalTotal;
  // 白天活动折后租金 TODO: 添加活动处理
  timeRent.dayDiscountTotal = timeRent.dayOriginalTotal;
  // 夜间活动折后租金 TODO: 添加活动处理
  timeRent.nightDiscountTotal = timeRent.nightOriginalTotal;
  // 活动折后总租金
  timeRent.discountTotal = timeRent.dayDiscountTotal + timeRent.nightDiscountTotal;
  // 实际白天租金
  timeRent.dayActualTotal = timeRent.dayDiscountTotal;
  // 实际夜间租金
  // timeRent.nightActualTotal = parseInt(timeRent.isNightCeiling ? nightCeilingCost : timeRent.nightDiscountTotal);
  timeRent.nightActualTotal = timeRent.nightDiscountTotal;
  // 实际计时租金
  timeRent.actualTotal = timeRent.dayActualTotal + timeRent.nightActualTotal;

  // 里程部分租金
  const mileageRent = {};
  // 原单价
  mileageRent.originalUnit = parseInt(mileageUnit);
  // 实际单价
  mileageRent.actualUnit = parseInt(inPark ? Math.ceil(mileageUnit * parkingRate) : mileageUnit);
  // 活动折前总租金
  mileageRent.originalTotal = parseInt(mileageRent.actualUnit * calculateDistance);
  // 活动折后总租金 // TODO: 添加活动处理
  mileageRent.discountTotal = mileageRent.originalTotal;

  // 总计租金
  const total = timeRent.actualTotal + mileageRent.discountTotal;
  // 是否保底
  const isFloor = total < floorCost;
  // 保底后实际租金
  const actualTotal = parseInt(isFloor ? floorCost : total);

  // 优惠券减免租金
  // 查找合适的优惠券
  const coupon = {
    actualDiscount: 0,
  };
  if (actualTotal > 0) {
    const validCoupon = await ACCoupon.findValid({
      amount: actualTotal,
      user: user._id,
      type: constants.AC_COUPON_TYPE.租金抵扣券,
      selector: '_id amount',
    });
    if (validCoupon) {
      coupon.actualDiscount = Math.min(validCoupon.amount, actualTotal);
      coupon.ref = validCoupon._id;
    }
  }

  // 优惠券减免的租金
  const discount = parseInt(coupon.actualDiscount);
  // 最终实付总租金
  const finalTotal = parseInt(actualTotal - discount);

  // 保险费用
  const insuranceAmount = enableInsurance ? insurance : 0;
  // 结算总金额
  const totalAmount = finalTotal + insuranceAmount;

  return {
    rent: {
      timeRent,
      mileageRent,
      total,
      isFloor,
      actualTotal,
      discount,
      finalTotal,
    },
    coupon,
    insurance: {
      amount: insuranceAmount,
    },
    parkingRate,
    parkingRateContent,
    totalAmount,
  };
};

exports.validate = {
  id: Joi.string().required(),
  parkingLot: Joi.string().allow(null).empty(''),
};
exports.handler = async ({ id, parkingLot }) => {
  const order = await ODOrder.findById({
    id,
    selector: [
      '_id user updatedAt stock state',
      'lease.totalDuration lease.dayDuration lease.nightDuration lease.startTime lease.endTime',
      'route.location route.distance route.startMileage route.end route.startPhaseMileage route.latestUpdatedPhaseMileageAt',
      'highestDeltaDistance highestDeltaTime highestSpeed',
      'payInfo.locked price mbr isFreeTrip region preFinish',
    ].join(' '),
  });
  if (!order) return;

  // 如果订单不是租用中，则不进行更新
  if (order.state !== constants.OD_ORDER_STATE.租用中) return;

  const stock = await BKStock.findById({
    id: order.stock._id,
    selector: '_id location record speed parkingLot lastOutParkingLotTime',
  });

  const user = await ACUser.findById({
    id: order.user._id,
    selector: '_id location.lngLat credit',
  });

  const region = await OPRegion.findById({ id: order.region._id, selector: '_id parkingPattern parkingDiscount parkingLotRadius' });

  let {
    lease, route, payInfo, mbr, isFreeTrip, updatedAt,
    highestDeltaDistance, highestDeltaTime, highestSpeed,
  } = order;
  const { location, record, speed } = stock;
  const now = new Date();

  const orderUpdate = {
    'lease.endTime': now,
  };

  // 计算相位距离
  const phaseMileage = Math.max(0, record.phaseMileage - route.startPhaseMileage);
  orderUpdate['route.endPhaseMileage'] = record.phaseMileage;
  orderUpdate['route.phaseMileage'] = phaseMileage;
  orderUpdate['route.latestUpdatedPhaseMileageAt'] = phaseMileage === route.phaseMileage ? route.latestUpdatedPhaseMileageAt : now;

  // 判断位置
  let {
    intersectPolygon = null, intersectRegion = null, intersectPolygonType = null, intersectPolygonNeighborhood = null,
    distanceWithPark = null, distanceWithRegionPath = null,
    distanceWithProhibitedArea = null, distanceWithForbiddenArea = null,
    lngLat,
  } = location;
  orderUpdate['route.end'] = {
    lngLat, distanceWithPark, distanceWithRegionPath,
    distanceWithProhibitedArea, distanceWithForbiddenArea,
  };

  // 老停车区才计算优惠
  // 是否在停车区 10m内也算在停车区
  // 如果车不在停车区，用户在停车区，也算在停车区
  let userIntersectPolygonType = null;
  let inPark = false;
  if ([constants.OP_REGION_PARKING_PATTERN.旧停车区, constants.OP_REGION_PARKING_PATTERN.新旧停车区].includes(region.parkingPattern)) {
    inPark = judgement.isNotEmpty(distanceWithPark) && distanceWithPark >= -10;
    if (user.location && user.location.lngLat && user.location.lngLat[0]) {
      const userIntersectParks = await OPPolygon.findIntersect({
        center: user.location.lngLat,
        query: {
          type: constants.OP_POLYGON_TYPE.停车区,
          enable: true,
        },
        selector: 'type',
        limit: 1,
      });
      const userIntersectPark = userIntersectParks.length > 0 ? userIntersectParks[0] : null;
      if (userIntersectPark) {
        userIntersectPolygonType = constants.OP_POLYGON_TYPE.停车区;
        if (!inPark) {
          intersectPolygonType = userIntersectPolygonType;
          intersectPolygon = userIntersectPark._id;
          inPark = true;
        }
      }
    }
  } else {
    if (order.preFinish && order.preFinish.inPark && now < new Date(order.preFinish.expires).getTime() && order.preFinish.parkingLot) {
      stock.parkingLot = order.preFinish.parkingLot;
      inPark = true;
    } else {
      if (!stock.parkingLot) {
        const userCapture = await RCUserCapture.findOne({ query: { user: order.user._id }, sort: { _id: -1 }, selector: 'lngLat accuracy' });
        if (userCapture && userCapture.lngLat && userCapture.lngLat[0] && userCapture.lngLat[1]) {
          ret = await Core.send({
            c: 'operation/parkingLot/triggerIO.s.2',
            params: {
              stockId: stock._id,
              lngLat: userCapture.lngLat,
              radius: region.parkingLotRadiu || 10,
            },
          });
          stock.parkingLot = ret.parkingLot;
          // 前端认为在停车区 且 距离上次出停车区三秒内 则认为确实是在停车区
          // if (!ret.parkingLot && parkingLot && stock.lastOutParkingLotTime && (Date.now() - new Date(stock.lastOutParkingLotTime).getTime() < 3 * 1000)) {
          if (!ret.parkingLot && parkingLot) {
            stock.parkingLot = parkingLot;
          }
          stock.nearParkingLots = ret.nearParkingLots;
        }
      }
      inPark = !!stock.parkingLot || !!parkingLot;
    }
  }

  orderUpdate['route.end'].parkingLot = stock.parkingLot;
  orderUpdate['route.end'].lastSnapParkingLot = parkingLot;
  orderUpdate['route.end'].nearParkingLots = stock.nearParkingLots;
  orderUpdate['route.inPark'] = inPark;
  orderUpdate['route.intersectRegion'] = intersectRegion;
  orderUpdate['route.intersectPolygon'] = intersectPolygon;
  orderUpdate['route.intersectPolygonType'] = intersectPolygonType;
  orderUpdate['route.intersectPolygonNeighborhood'] = intersectPolygonNeighborhood;
  orderUpdate['route.userIntersectPolygonType'] = userIntersectPolygonType;
  orderUpdate['route.userCapture'] = user.location;
// 距离围栏距离小于0 则出围栏
  if (route.end.distanceWithRegionPath < 0) orderUpdate['route.hasOutsideRegion'] = true;
// 计费未锁定，则重新计费
  if (!payInfo.locked) {
    // 计算时间距离
    const { totalDuration, dayDuration, nightDuration } = calculateLease({
      startTime: lease.startTime,
      endTime: now,
    });
    const distance = Math.max(Math.round(record.mileageInAll - route.startMileage), 0);
    const calculateDistance = Math.ceil(distance / 1000);
    const deltaDistance = distance - route.distance;
    if (deltaDistance > 0) {
      highestDeltaDistance = Math.max(highestDeltaDistance, deltaDistance);
      const deltaTime = now.getTime() - lease.endTime.getTime();
      highestDeltaTime = Math.max(highestDeltaTime, deltaTime);
    }
    orderUpdate['lease.totalDuration'] = totalDuration;
    orderUpdate['lease.dayDuration'] = dayDuration;
    orderUpdate['lease.nightDuration'] = nightDuration;
    orderUpdate['route.endMileage'] = record.mileageInAll;
    orderUpdate['route.distance'] = distance;
    orderUpdate['route.calculateDistance'] = calculateDistance;
    orderUpdate['highestSpeed'] = Math.max(highestSpeed || 0, speed);
    orderUpdate['averageSpeed'] = totalDuration === 0 ? 0 : distance * 0.06 / totalDuration;
    orderUpdate['highestDeltaDistance'] = highestDeltaDistance;
    orderUpdate['highestDeltaTime'] = highestDeltaTime;

    // 计算价格
    const isBad = checkBad({ duration: totalDuration, distance });
    const { rent, coupon, insurance, totalAmount, parkingRate, parkingRateContent } = await calculatePayInfo({
      user,
      calculateDistance,
      parkingDiscount: region.parkingDiscount,
      inPark,
      price: order.price,
      dayDuration,
      nightDuration,
      isBad,
      isFreeTrip,
    });
    orderUpdate['isBad'] = isBad;
    orderUpdate['payInfo.rent'] = rent;
    orderUpdate['payInfo.coupon'] = coupon;
    orderUpdate['payInfo.insurance.amount'] = insurance.amount;
    orderUpdate['payInfo.parkingRate'] = inPark ? parkingRate : 1;
    orderUpdate['payInfo.parkingRateContent'] = inPark ? parkingRateContent : ' ';
    orderUpdate['payInfo.dispatchCost'] = (stock.parkingLot || isBad || inPark) && (intersectRegion || isFreeTrip) ? 0 : order.price.dispatchCost;
    orderUpdate['payInfo.totalAmount'] = totalAmount + orderUpdate['payInfo.dispatchCost'];
  }

  ODOrder.update({ id: order._id, updatedAt, data: orderUpdate });
};
