process.env.NODE_ENV = 'development';
const shark = require('../../../../__test__/shark');

shark.sendSync({
  c: 'order/order/afterFinished',
  params: {
    id: '1710242301679'
  }
}).catch(console.error);