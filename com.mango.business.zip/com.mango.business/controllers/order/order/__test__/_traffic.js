const rule = require('../generateIllegalInfoAndNotify');

rule.handler({ id: '1710121428297' }).catch(console.error);