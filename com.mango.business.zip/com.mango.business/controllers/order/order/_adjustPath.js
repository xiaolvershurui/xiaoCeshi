const geolib = require('geolib');

const getVector = (speed, direction) => {
  direction = direction % 360;
  const tanA = Math.tan(direction * Math.PI / 180);
  let x = speed / Math.sqrt(1 + tanA * tanA);
  if (direction > 90 && direction < 270) x = -x;
  let y = x * tanA;
  // if (direction > 180 && direction < 360) y = -y;
  return [parseFloat(x.toFixed(6)), parseFloat(y.toFixed(6))];
};

const getModOfVector = vector => {
  return Math.sqrt(Math.pow(vector[0], 2) + Math.pow(vector[1], 2));
};

const getDirectionOfVector = vector => {
  if (vector[0] === 0) {
    if (vector[1] > 0) return 90;
    if (vector[1] < 0) return 270;
    return 0;
  }
  const direction = Math.atan(vector[1] / vector[0]) * 180 / Math.PI;
  if (vector[0] >= 0 && vector[1] >= 0) return direction;
  if (vector[0] <= 0 && vector[1] >= 0) return 180 + direction;
  if (vector[0] <= 0 && vector[1] <= 0) return 180 + direction;
  if (vector[0] >= 0 && vector[1] <= 0) return 360 + direction;
};

const getAngleBetweenDirections = (d1, d2) => {
  const deltaD = (d1 - d2) % 360;
  if (deltaD <= 180 && deltaD >= -180) return deltaD;
  if (deltaD < -180) return deltaD + 360;
  return deltaD - 360;
};

class Point {
  get isStill () {
    return this.speed <= 1;
  }

  get prevPoint () {
    return this._prevPoint;
  }

  set prevPoint (point) {
    this._prevPoint = point;
    this.isStart = false;
  }

  get nextPoint () {
    return this._nextPoint;
  }

  set nextPoint (point) {
    this._nextPoint = point;
    this.isEnd = false;
  }

  get coordinates () {
    return this._coordinates;
  }

  get time () {
    return this._time;
  }

  get direction () {
    return this._direction;
  }

  get speed () {
    return this._speed;
  }

  set coordinates (coordinates) {
    this.lng = coordinates[0];
    this.lat = coordinates[1];
    this._coordinates = coordinates;
  }

  set time (time) {
    this._time = new Date(time);
  }

  set speed (speed) {
    this._speed = speed;
  }

  set direction (direction) {
    this._direction = direction;
  }

  get vector () {
    return getVector(this.speed, this.direction);
  }

  get ts () {
    return this.time.getTime();
  }

  get distanceWithPrevPoint () {
    if (!this.prevPoint) return Infinity;
    return geolib.getDistance(this.coordinates, this.prevPoint.coordinates, 1, 3);
  }

  get distanceWithOriginal () {
    return geolib.getDistance(this.coordinates, this._originalCoordinates, 1, 3);
  }

  getMiddleVectorWith (point, rate) {
    return [
      this.vector[0] * rate + point.vector[0] * (1 - rate),
      this.vector[1] * rate + point.vector[1] * (1 - rate),
    ];
  }

  getAngleWith (point) {
    return getAngleBetweenDirections(this.direction, point.direction);
  }

  adjust () {
    const prevPoint = this.prevPoint;
    if (!prevPoint) return;

    const dts = this.ts - prevPoint.ts;

    // 校正静止点的方向
    if (this.isStill) {
      this.direction = prevPoint.direction;
    }

    const speedFix = 1;

    const middleVector = this.getMiddleVectorWith(prevPoint, 0.5);
    const speed = getModOfVector(middleVector);
    const direction = getDirectionOfVector(middleVector);
    const possibleDistanceWithPrevPoint = ((speed + speedFix) * dts / 3600);

    const distanceFixRate = 1 + Math.PI * Math.abs(this.getAngleWith(prevPoint)) / 180;

    if (this._lineString && !this.isEnd && !this.isStart && this.distanceWithPrevPoint >= possibleDistanceWithPrevPoint * 10) {
      // 过远的点，移除
      this._lineString.removePoint(this);
      return Infinity;
    }

    if (possibleDistanceWithPrevPoint * distanceFixRate <= this.distanceWithPrevPoint) {
      const { latitude, longitude } = geolib.computeDestinationPoint(prevPoint.coordinates, possibleDistanceWithPrevPoint, direction);

      const moveRate = 0.5;

      const [deltaLng, deltaLat] = [
        (this.lng - longitude) * moveRate,
        (this.lat - latitude) * moveRate,
      ];

      const distanceMoved = geolib.getDistance(prevPoint.coordinates, { latitude, longitude }, 1, 3) * moveRate;

      const maxDistanceWithOriginalPoint = 50;
      if (this.prevPoint && !this.prevPoint.isStart && this.prevPoint.distanceWithOriginal <= maxDistanceWithOriginalPoint) {
        this.prevPoint.coordinates = [this.prevPoint.lng + deltaLng, this.prevPoint.lat + deltaLat];
      }
      if (!this.isEnd && this.distanceWithOriginal <= maxDistanceWithOriginalPoint) {
        this.coordinates = [this.lng - deltaLng, this.lat - deltaLat];
      }
      return distanceMoved;
    }
    return 0

  }

  tween (maxDeltaTime = 5000) {
    const nextPoint = this.nextPoint;
    if (!nextPoint) return 0;
    if(this.isStill && nextPoint.isStill) return 0;
    const dts = nextPoint.ts - this.ts;
    const addCount = Math.ceil(dts / maxDeltaTime) - 1;
    const [deltaLng, deltaLat] = [nextPoint.lng - this.lng, nextPoint.lat - this.lat];
    const deltaSpeed = nextPoint.speed - this.speed;
    const deltaDirection = nextPoint.getAngleWith(this);

    for (let i = addCount; i > 0; i -= 1) {
      const rate = i / (addCount + 1);
      const point = new Point({
        coordinates: [this.lng + deltaLng * rate, this.lat + deltaLat * rate],
        time: this.ts + dts * rate,
        speed: this.speed + deltaSpeed * rate,
        direction: this.direction + deltaDirection * rate,
      }, this._lineString);

      this._lineString.addPointAfter(this, point);
    }

    return addCount;
  }

  constructor ({ coordinates, time, speed, direction }, lineString) {
    this.isStart = true;
    this.isEnd = true;
    this._originalCoordinates = coordinates;
    this.coordinates = coordinates;
    this.time = time;
    this.speed = speed;
    this.direction = direction;
    this._lineString = lineString;
  }
}

class LineString {

  get points () {
    return this._points;
  }

  get geojson () {
    return {
      type: 'Feature',
      geometry: {
        type: 'LineString',
        coordinates: this.points.map(point => point.coordinates),
      },
      properties: this._properties,
    };
  }

  get path () {
    return this.points.map(point => {
      return {
        gps: {
          lngLat: point.coordinates,
          direction: point.direction,
          speed: point.speed,
        },
        time: point.time,
      };
    });
  }

  _genPoints (items) {
    return items.reduce((pts, point, index) => {
      const prevPoint = pts[0];
      const pt = new Point({
        coordinates: point.gps.lngLat,
        time: point.time,
        direction: point.gps.direction,
        speed: point.gps.speed,
      }, this);
      if (prevPoint) {
        pt.prevPoint = prevPoint;
        prevPoint.nextPoint = pt;
      } else {
        pt.isStart = true;
      }
      if (index + 1 === items.length) {
        pt.isEnd = true;
      }
      pts.unshift(pt);
      return pts;
    }, []).reverse();
  }

  constructor (items) {
    this._points = this._genPoints(items);
  }

  removePoint (point) {
    const prevPoint = point.prevPoint;
    const nextPoint = point.nextPoint;
    prevPoint.nextPoint = nextPoint;
    nextPoint.prevPoint = prevPoint;
    this._points.splice(this._points.indexOf(point), 1);
  }

  addPointAfter (prevPoint, point) {
    const nextPoint = prevPoint.nextPoint;
    prevPoint.nextPoint = point;
    if(nextPoint) {
      nextPoint.prevPoint = point;
    }
    point.prevPoint = prevPoint;
    point.nextPoint = nextPoint;
    this._points.splice(this._points.indexOf(prevPoint) + 1, 0, point);
  }

  adjust () {
    let maxDeltaDistance = 0;
    this._points.forEach(point => {
      maxDeltaDistance = Math.max(point.adjust() || 0, maxDeltaDistance);
    });
    return maxDeltaDistance;
  }

  cycleAdjust ({ minDeltaDistance = 5, maxTimes = 100 } = {}) {
    let n = 0;
    for (; n < maxTimes; n += 1) {
      const maxDeltaDistance = this.adjust();
      if (maxDeltaDistance <= minDeltaDistance) {
        break;
      }
    }
    return n;
  }

  thin ({ maxDeltaAngle = 5, maxTimes = 5, onlyStill = false } = {}) {
    let removedCount = 0;
    for (let n = 0; n < maxTimes; n += 1) {
      let currentRemovedCount = 0;
      [...this.points].forEach(point => {
        if (point.isStart || point.isEnd) return;
        const prevPoint = point.prevPoint;
        const nextPoint = point.nextPoint;
        if (point.isStill && prevPoint.isStill && nextPoint.isStill) {
          this.removePoint(point);
          removedCount += 1;
          currentRemovedCount += 1;
        } else if (!onlyStill) {
          const deltaAngleWithPrevPoint = Math.abs(point.getAngleWith(prevPoint));
          const deltaAngleWithNextPoint = Math.abs(point.getAngleWith(nextPoint));
          if (deltaAngleWithNextPoint <= maxDeltaAngle && deltaAngleWithPrevPoint <= maxDeltaAngle) {
            this.removePoint(point);
            removedCount += 1;
            currentRemovedCount += 1;
          }
        }
      });
      if (currentRemovedCount === 0) break;
    }
    return removedCount;
  }

  tween ({ maxDeltaTime = 5000 } = {}) {
    let addedCount = 0;
    [...this.points].forEach(point => {
      addedCount += point.tween(maxDeltaTime);
    });
    return addedCount;
  }
}

module.exports = points => {
  const line = new LineString(points);
  const removedCount = line.thin();
  const tryTimes = line.cycleAdjust();
  const addedCount = line.tween();
  return line.path;
};