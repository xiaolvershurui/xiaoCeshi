const dotMulti = (u, v) => {
  return u[0] * v[0] + u[1] * v[1];
};

const calculateDisPow = (p1, p2, p3) => {
  const [dx1, dy1] = [p3[0] - p1[0], p3[1] - p1[1]]; // u
  const [dx2, dy2] = [p2[0] - p1[0], p2[1] - p1[1]]; // v
  if (dotMulti([dx1, dy1], [dx2, dy2]) <= 0) {
    return dx1 * dx1 + dy1 * dy1;
  }
  if (dotMulti([dx1 - dx2, dy1 - dy2], [dx2, dy2]) >= 0) {
    return Math.pow(dx1 - dx2, 2) + Math.pow(dy1 - dy2, 2);
  }
  const k = (dx1 * dx2 + dy1 * dy2) / ((dx2 * dx2) + (dy2 * dy2));
  return Math.pow(dx1 - (k * dx2), 2) + Math.pow(dy1 - (k * dy2), 2);
};

module.exports = (point, segments) => {
  const { segment, disPow } = segments.reduce((memo, current) => {
    const prev = memo.prev;
    memo.prev = current;
    if (prev) {
      const disPow = calculateDisPow(prev, current, point);
      if (disPow < memo.disPow) {
        memo.disPow = disPow;
        memo.segment = [prev, current];
      }
    }
    return memo;
  }, {
    segment: [],
    disPow: Infinity,
    prev: null,
  });
  return { segment, disPow };
};
