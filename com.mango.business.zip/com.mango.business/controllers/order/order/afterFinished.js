const Joi = require('poolishark').Joi;
const lngLatToGridIndex = require('../../../utils/lngLatToGridIndex');
const RCStockPoint = require('../../../services/database/record/stockPoint');
const ODOrder = require('../../../services/database/order/order');
const adjustPath = require('./_adjustPath');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function ({ id }) {
  const order = await ODOrder.findById({
    id, selector: [
      'box lease route.distance',
      'route.start.lngLat route.end.lngLat'
    ].join(' ')
  });
  // 获取原始轨迹
  let routePath = await RCStockPoint.findPathWithGPSInfo({
    box: order.box._id,
    startTime: order.lease.startTime,
    endTime: order.lease.endTime
  });
  // 校准
  routePath = adjustPath(routePath);

  // 千米点密度
  const ppk = order.route.distance === 0 ? 0 : routePath.length / order.route.distance * 1000;
  // 小时点密度
  const pph = order.lease.totalDuration === 0 ? 0 : routePath.length / order.lease.totalDuration * 60;

  let points = routePath.map(point => point.gps.lngLat);
  let ts = routePath.map(point => point.time);

  if (points.length < 2) {
    points = [order.route.start.lngLat, ...points, order.route.end.lngLat];
    ts = [order.lease.startTime, ...ts, order.lease.endTime];
  }

  // 生成网格索引
  const grids = points.reduce((memo, point) => {
    memo.add(lngLatToGridIndex(point));
    return memo;
  }, []);

  // 生成开始结束 网格索引
  const startGrid = lngLatToGridIndex(order.route.start.lngLat);
  const endGrid = lngLatToGridIndex(order.route.end.lngLat);

  // 更新订单
  await ODOrder.update({
    id,
    data: {
      ppk,
      pph,
      grids,
      startGrid,
      endGrid,
      'route.path': {
        type: 'LineString',
        coordinates: points,
        ts
      }
    }
  });

  // 生成违章单
  this.exec({
    c: 'order/order/generateIllegalInfoAndNotify',
    params: {
      id
    }
  }).catch(error => this.emit('error', error, 'controller.order.order.afterFinished.generateIllegalInfo'));
};
