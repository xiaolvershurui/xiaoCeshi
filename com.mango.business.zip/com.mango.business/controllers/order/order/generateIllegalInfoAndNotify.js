const Joi = require('poolishark').Joi;
const findAndGenerateIllegalInfo = require('./_findAndGenerateIllegalInfo');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  return await findAndGenerateIllegalInfo(id);
};