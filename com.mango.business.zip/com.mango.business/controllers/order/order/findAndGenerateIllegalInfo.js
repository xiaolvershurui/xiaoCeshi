const Joi = require('poolishark').Joi;
const findAndGenerateIllegalInfo = require('./_findAndGenerateIllegalInfo');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = {
  id: Joi.string().required(),
  selector: validators.selector,
  populateSelector: Joi.object({
    user: Joi.string().default('_id').allow(null),
    order: Joi.string().default('_id').allow(null),
  })
};

exports.handler = async ({ id, selector, populateSelector }) => {
  return await findAndGenerateIllegalInfo(id, selector, populateSelector);
};