const injectTransaction = require('../../../utils/injectTransaction');
const ODOrder = require('../../../services/database/order/order');
const ACWallet = require('../../../services/database/account/wallet');
const FNBalanceBill = require('../../../services/database/finance/balanceBill');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const Iot = require('../../../services/iot');
const Joi = require('joi');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async function({ id }, tid, Transaction) {
  await this.exec({
    c: 'order/order/snap',
    params: {
      id,
    },
  });
  let [order] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_order',
      id,
      selector: 'state',
    }],
  });
  if (order.state === constants.OD_ORDER_STATE.租用中) {
    order = await ODOrder.findById({
      id,
      selector: [].join(' '),
      populateSelector: {
        user: '_id',
        stock: '_id battery',
      },
    });
    const now = new Date();
    const rentBillId = order.payInfo.rent.finalTotal > 0 ? await FNBalanceBill.genId() : null;
    const insuranceBillId = order.payInfo.insurance && order.payInfo.insurance.amount > 0 ? await FNBalanceBill.genId() : null;
    const dispatchCostBillId = order.payInfo.dispatchCost > 0 ? await FNBalanceBill.genId() : null;
    let decreaseBalance = 0;
    const lockEntities = [];
    const updates = [{
      _id: id,
      $set: {
        state: constants.OD_ORDER_STATE.长时无移动结束,
        'payInfo.rentBill': rentBillId,
        'payInfo.insuranceBill': insuranceBillId,
        'payInfo.dispatchBill': dispatchCostBillId,
        finishedAt: now,
        endVoltage: order.stock.battery.voltage,
      },
    }];
    // 保驾订单不结算
    if (!order.baojia.isBaojia) {
      const walletData = await ACWallet.findByUser({ user: order.user._id, selector: 'deposit' });
      if (!walletData.deposit.paid) throw new BadRequestError('还未缴纳押金');
      if (order.payInfo.rent.finalTotal > 0) {
        lockEntities.push({
          model: 'fn_balance_bill',
        });
        decreaseBalance += order.payInfo.rent.finalTotal;
        updates.push({
          _id: rentBillId,
          user: order.user._id,
          order: id,
          amount: order.payInfo.rent.finalTotal,
          signal: constants.FN_BALANCE_BILL_SIGNAL.支付订单租金,
          type: constants.FN_BALANCE_BILL_TYPE.支出,
          region: order.region._id,
          style: order.style._id,
        });
      }
      if (order.payInfo.insurance.amount > 0) {
        lockEntities.push({
          model: 'fn_balance_bill',
        });
        decreaseBalance += order.payInfo.insurance.finalTotal;
        updates.push({
          _id: insuranceBillId,
          user: order.user._id,
          order: id,
          amount: order.payInfo.insurance.finalTotal,
          signal: constants.FN_BALANCE_BILL_SIGNAL.支付订单保险,
          type: constants.FN_BALANCE_BILL_TYPE.支出,
          region: order.region._id,
          style: order.style._id,
        });
      }
      if (order.payInfo.dispatchCost > 0) {
        lockEntities.push({
          model: 'fn_balance_bill',
        });
        decreaseBalance += order.payInfo.dispatchCost;
        updates.push({
          _id: dispatchCostBillId,
          user: order.user._id,
          order: id,
          amount: order.payInfo.dispatchCost,
          signal: constants.FN_BALANCE_BILL_SIGNAL.支付停车调度费用,
          type: constants.FN_BALANCE_BILL_TYPE.支出,
          region: order.region._id,
          style: order.style._id,
        });
      }
      // 解冻押金
      lockEntities.push({
        model: 'ac_wallet',
        id: walletData._id,
      });

      updates.push({
        _id: walletData._id,
        $set: {
          'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.可退款,
        },
        $inc: {
          balance: -decreaseBalance,
        },
      });
    }
    lockEntities.push({
      model: 'bk_stock',
      id: order.stock._id,
    });
    const orderUpdate = {
      _id: order.stock._id,
      $set: {
        locate: constants.BK_LOCATE.空闲,
        latestUpdatedLocateAt: now,
        latestScannedAt: null,
      },
    };
    if (order.lock.isLocked) {
      order.$set['lock.isLocked'] = false;
      const index = order.lock.times.length - 1;
      const lease = parseInt((now - new Date(order.lock.times[index].start).getTime()) / 60000);
      order.$set['lock.times'][index].end = now;
      order.$set['lock.times'][index].lease = lease;
    }
    updates.push(orderUpdate);

    // 关闭电门
    Iot.stopAsync(order.box._id);
    await Transaction.findAndLockEntity({
      tid,
      entities: lockEntities,
    });
    await Transaction.commit({
      tid,
      updates,
    });

    try {
      this.exec({
        c: 'order/order/afterFinished',
        params: {
          id,
        },
      });
    } catch (error) {
      //
    }
  }
  else {
    await Transaction.cancel({
      tid,
      error: {
        name: 'OrderHadBeenFinished',
        message: '订单已结束',
        stack: null,
      },
    });
  }
};

module.exports = injectTransaction(exports, 'order.order.safeFinish');
