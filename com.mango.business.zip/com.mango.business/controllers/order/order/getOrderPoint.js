const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const Joi = require('poolishark').Joi;
const { combineLngLats } = require('../../operation/inspectionOrder/_getLngLats');

exports.validate = {
  now: Joi.date().required(),
  box: Joi.date().required(),
  year: Joi.number().required(),
  month: Joi.string().required(),
  startTime: Joi.number().required(),
  endTime: Joi.number().required(),
};

exports.handler = async ({ now, box, year, month, startTime, endTime }) => {
  return await combineLngLats({
    now,
    box,
    year,
    month,
    startTime,
    endTime,
  }, { earliestTime: new Date(startTime) })
};