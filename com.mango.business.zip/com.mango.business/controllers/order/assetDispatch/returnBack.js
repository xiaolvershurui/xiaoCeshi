const Joi = require('poolishark').Joi;
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  receiver: Joi.string().required(),
  id: Joi.string().required(),
  endAssets: Joi.array().items({
    id: Joi.string().required(),
    code: Joi.string().required(),
    endIntactCount: Joi.number().required(),
    endBadCount: Joi.number().required()
  })
};

exports.handler = async function ({ receiver, id, endAssets }) {
  const user = await ACUser.findById({
    id: receiver,
    selector: '_id'
  });
  if (!user) {
    throw new NotFoundError(`未找到此运营人员${receiver}`);
  }
  let assetDispatch = await ODAssetDispatch.findById({
    id,
    selector: 'status assets region endStation assets updatedAt endStation',
    populateSelector: {
      "assets.id": 'code'
    }
  });
  if (!assetDispatch) {
    throw new NotFoundError(`未找到此调配单${dispatchOrderId}`);
  }
  if (assetDispatch.status !== constants.OD_ASSET_DISPATCH_STATE.调配中) {
    throw new BadRequestError(`调配单状态异常`);
  }
  let stationAssets = await BKAsset.find({
    query: {
      station: assetDispatch.endStation, code: {
        '$in': endAssets.map(endAsset => {
          return endAsset.code
        })
      }
    },
    selector: '_id asset code updatedAt',
    populateSelector: {
      asset: 'code '
    },
    limit: 0
  });
  stationAssets.map(stationAsset => {
    stationAsset.asset = stationAsset.asset._id;
  });
  assetDispatch.assets.map(asset => {
    asset.id = asset.id._id;
  });
  endAssets.map(endAsset => {
    const thisAsset = assetDispatch.assets.search({ id: endAsset.id });
    const stationAsset = stationAssets.search({ asset: endAsset.id });
    if (!thisAsset || !stationAsset) {
      throw new BadRequestError(`调度单或仓库不存在该配件信息${JSON.stringify(endAsset, null, 2)}`);
    }
    endAsset.id = thisAsset.id;
    endAsset.bkAsset = stationAsset._id
  });
  assetDispatch = await ODAssetDispatch.update({
    id,
    data: {
      nextTry: Date.now() + 120000,
      receiver,
      status: constants.OD_ASSET_DISPATCH_STATE.入库中,
      endFailed: endAssets
    }
  });
  await this.exec({
    c: 'order/assetDispatch/return',
    params: {
      id: assetDispatch._id,
      endAssets: endAssets,
    }
  });
};