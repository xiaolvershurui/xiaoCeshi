const Joi = require('poolishark').Joi;
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  dispenser: Joi.string().required(),
  startStation: Joi.string().required(),
  endStation: Joi.string().required(),
  region: Joi.string().required(),
  assets: Joi.array().items(Joi.object({
    code: Joi.string(),
    startIntactCount: Joi.number(),
    startBadCount: Joi.number(),
  })),
};

exports.handler = async function ({ dispenser, region, startStation, endStation, assets }) {
  const acUser = await ACUser.findById({
    id: dispenser,
  });
  if (!acUser) {
    throw new NotFoundError(`dispenser 不存在`);
  }
  const opRegion = await OPRegion.findById({
    id: region,
  });
  if (!opRegion) {
    throw new NotFoundError(`Region 不存在`);
  }
  const opStations = await OPBatteryStation.find({
    query: {
      _id: { $in: [startStation, endStation] },
    },
  });
  if (opStations.length !== 2) {
    throw new NotFoundError(`Station 不存在`);
  }
  const codes = assets.map((assets) => {
    return assets.code;
  });
  // 检查映射表
  const stAssets = await STAsset.findByCodes({
    codes: [...codes],
    selector: '_id type code',
  });
  if (codes.length !== stAssets.length) {
    const unExistsAssetCodesAssets = codes.filter(code => {
      !stAssets.search({ code: code });
    });
    throw new NotFoundError(`未录入配件:${unExistsAssetCodesAssets}`);
  }
  const stationAssets = await BKAsset.find({
    query: { station: startStation, code: { '$in': [...codes] } },
    selector: '_id asset code updatedAt',
    limit: 0,
    populateSelector: {
      asset: 'code ',
    },
  });
  stationAssets.map(stationAsset => {
    const thisAsset = assets.search({ 'code': stationAsset.code });
    const thisAssetMap = stAssets.search({ 'code': stationAsset.code });
    stationAsset.startIntactCount = thisAsset.startIntactCount;
    stationAsset.startBadCount = thisAsset.startBadCount;
    stationAsset.id = thisAssetMap._id;
    stationAsset.bkAsset = stationAsset._id;
    delete stationAsset._id;
  });

  let limitResult = [];
  for (let asset of assets) {
    const bkAsset = await BKAsset.findByCodeAndStation({
      code: asset.code,
      station: startStation,
      selector: 'intactCount damageCount totalCount',
    });
    if (!bkAsset) {
      const station = await OPBatteryStation.findById({ id: startStation, selector: 'name' });
      throw new NotFoundError(`${station.name}仓库下没有${asset.code}配件`);
    }
    if (bkAsset.intactCount < asset.startIntactCount || bkAsset.damageCount < asset.startBadCount) limitResult = [...limitResult, asset.code];
  }
  if (limitResult.length && region !== '1704062319008') throw new BadRequestError(`${limitResult.join(' ')}等配件出库数量大于在库数量，请与线上运营核对在库数量后再尝试`);

  const odAssetDispatch = await ODAssetDispatch.create({
    startStation,
    endStation,
    region,
    dispenser,
    status: constants.OD_ASSET_DISPATCH_STATE.创建中,
    createFailed: stationAssets,
    nextTry: Date.now() + 120000,
  });
  await this.exec({
    c: 'order/assetDispatch/take',
    params: {
      id: odAssetDispatch._id,
      assets: stationAssets,
    },
  });
};
