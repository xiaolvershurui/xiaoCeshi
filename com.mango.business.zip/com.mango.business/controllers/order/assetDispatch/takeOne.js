const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const BKAsset = require('../../../services/database/ebike/asset');


exports.validate = {
  id: Joi.string(),
  asset: Joi.object(),
  status: Joi.number(),
};

exports.handler = async function({ id, asset, status}, tid, Transaction){
  const odAssetDispatch  = await ODAssetDispatch.findById({
    id,
    selector: 'region startStation assets'
  });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetDispatch.startStation._id,
    code: asset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });

  const bkAssetUpdates = {
    _id: asset.bkAsset,
    $inc:{
      totalCount: -(asset.startBadCount + asset.startIntactCount),
      intactCount: -asset.startIntactCount,
      damageCount: -asset.startBadCount
    }
  };
  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount - asset.startIntactCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_dispatch',
      id: id
    }, {
      model: 'bk_asset',
      id: asset.bkAsset
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        status
      },
      $pull:{
        createFailed: {
          id: asset.id
        }
      },
      $push: {
        assets:{
          id: asset.id,
          code: asset.code,
          startIntactCount: asset.startIntactCount,
          startBadCount: asset.startBadCount,
          endIntactCount: 0,
          endBadCount: 0
        }
      }
    }, bkAssetUpdates]
  });
};

module.exports = injectTransaction(exports, 'account.order.assetDispatch.takeOne');
