const Joi = require('poolishark').Joi;
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string(),
  assets: Joi.array().items(Joi.object())
};

exports.handler = async function({ id, assets }) {
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let asset of assets) {
        count++;
        try {
          await this.exec({
            c: 'order/assetDispatch/takeOne',
            params: {
              id,
              asset,
              status: count === assets.length ? constants.OD_ASSET_DISPATCH_STATE.调配中 : constants.OD_ASSET_DISPATCH_STATE.创建中
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => console.error(error));
  });
};