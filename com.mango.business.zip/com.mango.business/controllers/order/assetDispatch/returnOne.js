const Joi = require('poolishark').Joi;
const ODAssetDispatch = require('../../../services/database/order/assetDispatch');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const ACUser = require('../../../services/database/account/user');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  endAsset: Joi.object().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date()
};

exports.handler = async ({id, endAsset, status, finishedAt}, tid, Transaction) => {
  const odAssetDispatch = await ODAssetDispatch.findById({
     id,
     selector: 'region endStation assets'
   });
  const bkAsset = await BKAsset.findByCodeAndStation({
    station: odAssetDispatch.endStation._id,
    code: endAsset.code,
    selector: 'totalCount intactCount needPurchase purchaseCount'
  });

  odAssetDispatch.assets.map(asset=>{
    asset.id =asset.id._id;
  });
  let assets = odAssetDispatch.assets;
  const thisAsset = assets.search({id: endAsset.id});
  thisAsset.endIntactCount = endAsset.endIntactCount;
  thisAsset.endBadCount = endAsset.endBadCount;

  const odDispatchUpdates = {
    _id: id,
    $set: {
      status,
      assets,
    },
    $pull:{
      endFailed: {
        id: endAsset.id
      }
    },
  };
  if(status === constants.OD_ASSET_DISPATCH_STATE.已经完成){
    odDispatchUpdates.$set.finishedAt = finishedAt;
  }

  const bkAssetUpdates = {
    _id: endAsset.bkAsset,
    $inc:{
      totalCount: (thisAsset.endIntactCount + thisAsset.endBadCount),
      intactCount: thisAsset.endIntactCount,
      damageCount: thisAsset.endBadCount
    }
  };
  if (bkAsset.purchaseCount ) {
    bkAssetUpdates.needPurchase = bkAsset.purchaseCount > (bkAsset.intactCount + thisAsset.endIntactCount)
  }

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_asset_dispatch',
      id: id
    }, {
      model: 'bk_asset',
      id: endAsset.bkAsset
    }]
  });
  await Transaction.commit({
    tid,
    updates: [ odDispatchUpdates, bkAssetUpdates]
  });
};

module.exports = injectTransaction(exports, 'account.order.assetDispatch.returnOne');
