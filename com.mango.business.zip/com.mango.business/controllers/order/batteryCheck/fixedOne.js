const Joi = require('poolishark').Joi;
const ODBatteryCheck = require('../../../services/database/order/batteryCheck');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  battery: Joi.object().required(),
  status: Joi.number().required(),
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {
  const odBatteryCheck = await ODBatteryCheck.findById({ id, selector: 'fullCharge inCharge needCharge damage unknownCount' });

  const type = battery.type;
  let $odBatteryCheckSet;
  let $bkBatterySet;
  switch (type) {
    case 'fullCharge':
      $odBatteryCheckSet = { status, fullCharge: { fixed: battery }};
      $bkBatterySet = { underVoltage: false, charge: false };
      break;
    case 'inCharge':
      $odBatteryCheckSet = { status, inCharge: { fixed: battery }};
      $bkBatterySet = { charge: true };
      break;
    case 'needCharge':
      $odBatteryCheckSet = { status, needCharge: { fixed: battery }};
      $bkBatterySet = { underVoltage: true };
      break;
    case 'damage':
      $odBatteryCheckSet = { status, damage: { fixed: battery }};
      $bkBatterySet = { state: constants.BK_BATTERY_STATE.损坏 };
      break;
    case 'unknownCount':
      $odBatteryCheckSet = { status, unknownCount: { fixed: battery }};
      break;
  }
  const odBatteryCheckUpdates = {
    _id: id,
    $set: $odBatteryCheckSet
  };
  if (status === constants.OD_BATTERY_CHECK_STATUS.已完成) {
    odBatteryCheckUpdates.$set.finishedAt = new Date();
  }
  const bkBatteryUpdates = {
    _id: battery.id,
    $set: $bkBatterySet ? $bkBatterySet : undefined
  };
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'od_battery_check'
    }, {
      id: battery.id,
      model: 'bk_battery',
    }]
  });
  await Transaction.commit({
    tid,
    updates: [odBatteryCheckUpdates, bkBatteryUpdates]
  });
};
module.exports = injectTransaction(exports, 'account.order.batteryCheck.fixedOne');
