const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const ODBatteryCheck = require('../../../services/database/order/batteryCheck');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');


exports.validate = {
  id: Joi.string().required(),
  // operator: Joi.string().required(),
  batteryStatus: Joi.object({
    fullCharge: Joi.array().items(Joi.string().allow('')),
    inCharge: Joi.array().items(Joi.string().allow('')),
    needCharge: Joi.array().items(Joi.string().allow('')),
    damage: Joi.array().items(Joi.string().allow('')),
    unknownCount: Joi.number()
  }),
};

exports.handler = async ({ id, batteryStatus }) => {
  // const acUser = await ACUser.findById({ id: operator });
  // if(!acUser) throw new NotFoundError('不存在此Operator Id');

  const odBatteryCheck = await ODBatteryCheck.findById({ id, selector: 'station status updatedAt unknownCount fullCharge inCharge damage needCharge ' });
  if(!odBatteryCheck) throw new NotFoundError('不存在此盘点单');
  if(odBatteryCheck.status !== constants.OD_BATTERY_CHECK_STATUS.盘点中) throw new BadRequestError('盘点单状态异常');

  if (batteryStatus.fullCharge) batteryStatus.fullCharge = (await BKBattery.findByCodes({ codes: batteryStatus.fullCharge, selector: '_id QRCode' })).map(item => {
    return { id: item._id, code: item.QRCode }
  });
  if (batteryStatus.inCharge) batteryStatus.inCharge = (await BKBattery.findByCodes({ codes: batteryStatus.inCharge, selector: '_id QRCode' })).map(item => {
    return { id: item._id, code: item.QRCode }
  });
  if (batteryStatus.needCharge) batteryStatus.needCharge = (await BKBattery.findByCodes({ codes: batteryStatus.needCharge, selector: '_id QRCode' })).map(item => {
    return { id: item._id, code: item.QRCode }
  });
  if (batteryStatus.damage) batteryStatus.damage = (await BKBattery.findByCodes({ codes: batteryStatus.damage, selector: '_id QRCode' })).map(item => {
    return { id: item._id, code: item.QRCode }
  });

  return await ODBatteryCheck.update({
    id,
    data:{
      status: constants.OD_BATTERY_CHECK_STATUS.修正中,
      fullCharge: Object.assign({}, odBatteryCheck.fullCharge, {
        actual: batteryStatus.fullCharge
      }),
      inCharge: Object.assign({}, odBatteryCheck.inCharge, {
        actual: batteryStatus.inCharge
      }),
      needCharge: Object.assign({}, odBatteryCheck.needCharge, {
        actual: batteryStatus.needCharge
      }),
      damage: Object.assign({}, odBatteryCheck.damage, {
        actual: batteryStatus.damage
      }),
      unknownCount: Object.assign({}, odBatteryCheck.unknownCount, {
        actual: batteryStatus.unknownCount
      })
    },
    updatedAt: odBatteryCheck.updatedAt
  });
};