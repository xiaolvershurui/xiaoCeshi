const Joi = require('poolishark').Joi;
const ODBatteryCheck = require('../../../services/database/order/batteryCheck');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  dispenser: Joi.string().required(),
  startStation: Joi.string().required(),
};

exports.handler = async ({ dispenser, startStation }) => {
  const acUser = await ACUser.findById({ id: dispenser });
  if(!acUser) throw new NotFoundError('该用户不存在');
  const opRegion = await OPBatteryStation.findById({ id: startStation, selector: '_id region' });
  const region = opRegion.region;

  const batteries = await BKBattery.find({ query: { station: startStation }, limit: 0, selector: 'state QRCode charge underVoltage' });

  const batteryStatus = batteries.reduce((memo, battery) => {
    if (battery.state === constants.BK_BATTERY_STATE.损坏) {
      memo.damage.push({ id: battery._id, code: battery.QRCode });
    } else {
      if (!battery.underVoltage) { // 非馈电状态
        memo.fullCharge.push({ id: battery._id, code: battery.QRCode });
      } else if (battery.underVoltage && battery.charge) { // 馈电状态且正在充电
        memo.inCharge.push({ id: battery._id, code: battery.QRCode });
      } else if (battery.underVoltage) { // 馈电状态
        memo.needCharge.push({ id: battery._id, code: battery.QRCode });
      }
    }
    return memo
  }, {
    fullCharge: [],
    inCharge: [],
    needCharge: [],
    damage: [],
    unknownCount: 0,
  });

  const ret = {
    dispenser,
    region,
    startStation,
    status: constants.OD_BATTERY_CHECK_STATUS.盘点中,
    fullCharge: {
      online: batteryStatus.fullCharge
    },
    inCharge: {
      online: batteryStatus.inCharge
    },
    needCharge: {
      online: batteryStatus.needCharge
    },
    damage: {
      online: batteryStatus.damage
    },
    unknownCount: {
      online: batteryStatus.unknownCount
    }
  };
  return await ODBatteryCheck.create(ret);
};

