const Joi = require('poolishark').Joi;
const ODBatteryCheck = require('../../../services/database/order/batteryCheck');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required(),
  batteryStatus: Joi.object({
    fullCharge: Joi.array().items(Joi.string().allow('')),
    inCharge: Joi.array().items(Joi.string().allow('')),
    needCharge: Joi.array().items(Joi.string().allow('')),
    damage: Joi.array().items(Joi.string().allow('')),
    unknownCount: Joi.number()
  }),
};

exports.handler = async function({ id, batteryStatus }, tid, Transaction)  {
  const odBatteryCheck = await ODBatteryCheck.findById({ id, selector:'status station unknownCount' });
  if(!odBatteryCheck) throw new NotFoundError('未找到此盘点单');

  if(odBatteryCheck.status !== constants.OD_BATTERY_CHECK_STATUS.修正中) throw new BadRequestError('盘点单状态异常');

  // 如果为空结束盘点
  const isEmptyCheck = Object.keys(batteryStatus).every(item => {
    return !batteryStatus[item].length && batteryStatus['unknownCount'] === 0
  });
  await ODBatteryCheck.update({
    id,
    data: {
      status: isEmptyCheck ? constants.OD_BATTERY_CHECK_STATUS.已完成 : odBatteryCheck.status,
      unknownCount: Object.assign({}, odBatteryCheck.unknownCount, {
        fixed: {
          prev: true,
          next: true
        }
      })
    }
  });

  batteryStatus = Object.keys(batteryStatus).map(item => {
    return batteryStatus[item].map(i => {
      return {
        code: i,
        type: item
      }
    })
  });
  const batteries = [].concat.apply([], batteryStatus);


  process.nextTick( _ => {
    (async _ => {
      let count = 0;
      for (let battery of batteryList) {
        try {
          await this.exec({
            c: 'order/batteryCheck/fixedOne',
            params: {
              id,
              batteries,
              status: count === batteries.length ? constants.OD_BATTERY_CHECK_STATUS.已完成 : constants.OD_BATTERY_CHECK_STATUS.修正中
            }
          })
        } catch (err) {
          count --;
        }
      }
    })().catch(err => {
      throw new BadRequestError('盘点错误')
    });
  })

  // await this.exec({
  //   c: 'order/assetCheck/fixedAll',
  //   params: {
  //     id,
  //     assets: assets
  //   }
  // });
};

// module.exports = injectTransaction(exports, 'order.batteryCheck.fixed');
