const Joi = require('poolishark').Joi;
const ODBatteryStartRepair = require('../../../services/database/order/batteryStartRepair');
const ACUser = require('../../../services/database/account/user');
const BKBattery = require('../../../services/database/ebike/battery');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  station: Joi.string().required(),
  batteries: Joi.array().items(Joi.object({
    code: Joi.string(),
  }))
};

exports.handler = async function ({ user, station, batteries }) {
  const acUser = await ACUser.findById({ id: user });
  if(!acUser) throw new NotFoundError('不存在此运营人员');

  const regionObj = await OPBatteryStation.findById({ id: station,selector: '_id region' });
  const region = regionObj.region;

  let batteryIds = await BKBattery.findByCodesAndStation({
    codes: batteries.map(battery => battery.code),
    station,
    selector: '_id state'
  });
  batteryIds = batteryIds.map(battery => battery._id);
  if (batteries.length !== batteryIds.length) throw new BadRequestError('请确认该电池存在并且存在于您当前所在仓库');

  const batteryRepairId = await ODBatteryStartRepair.create({
    user,
    region,
    station,
    status: constants.OD_BATTERY_START_REPAIR_STATUS.出库中,
    nextTry: Date.now() + 120000,
    outboundFailed: batteryIds.map(battery => {
      return {
        id: battery,
        time: new Date(),
        errorMessage: '初始化出库'
      }
    })
  });
  await this.exec({
    c: 'order/batteryStartRepair/take',
    params: {
      id: batteryRepairId._id,
      batteries: batteryIds
    }
  });
};
