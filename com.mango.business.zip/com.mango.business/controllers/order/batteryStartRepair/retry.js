const Joi = require('poolishark').Joi;
const ODBatteryStartRepair = require('../../../services/database/order/batteryStartRepair');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  operator: Joi.string().required()
};

exports.handler = async function ({ id, operator }) {
  const odBatteryStartRepair = await ODBatteryStartRepair.findById({
    id,
    selector: '_id status outboundFailed nextTry'
  });
  if(!odBatteryStartRepair) throw new NotFoundError('未找到此返修单');

  const nextTry = new Date(odBatteryStartRepair.nextTry);
  if(nextTry.getTime() > Date.now()) throw new Error(`请在${nextTry.toLocaleString()}后重试`);
  if (odBatteryStartRepair.status !== constants.OD_BATTERY_START_REPAIR_STATUS.出库中) throw new BadRequestError('订单非可重试状态');
  if(odBatteryStartRepair.status === constants.OD_BATTERY_START_REPAIR_STATUS.出库中){
    await this.exec({
      c: 'order/batteryStartRepair/take',
      params: {
        id: id,
        batteries: odBatteryStartRepair.outboundFailed.map(battery => battery.id._id),
      }
    });
  }
  await ODBatteryStartRepair.update({
    id: odBatteryStartRepair._id,
    data: {},
    arrayOp: {
      $push: {
        nextTryRecords: {
          operator,
          triedAt: new Date()
        }
      }
    }
  })
};