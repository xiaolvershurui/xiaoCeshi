const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  batteries: Joi.array().items(Joi.string()),
};
exports.handler = async function ({ id, batteries }) {
  process.nextTick(_ => {
    (async _ => {
      // 对每种配件进行领用操作
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryStartRepair/takeOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_START_REPAIR_STATUS.已完成 : constants.OD_BATTERY_START_REPAIR_STATUS.出库中
            }
          });
        } catch (err) {
          count--;
        }
      }
    })().catch(error => {
      throw new BadRequestError('返修出库失败');
    });
  });
};