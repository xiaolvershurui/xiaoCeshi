const Joi = require('poolishark').Joi;
const ODBatteryStartRepair = require('../../../services/database/order/batteryStartRepair');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');


exports.validate = {
  id: Joi.string().required(),
  battery: Joi.string(),
  status: Joi.number(),
};

exports.handler = async ({ id, battery, status }, tid, Transaction) => {
  console.log(battery);
  const odBatteryStartRepair  = await ODBatteryStartRepair.findById({ id, selector: 'region station' });
  if (!odBatteryStartRepair) throw new NotFoundError('该返修单不存在');

  const bkBatteryUpdates = {
    _id:battery,
    $set: {
      locate: constants.BK_BATTERY_LOCATE.巡检人员携带
    }
  };

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id,
      model: 'od_battery_start_repair'
    }, {
      id: battery,
      model: 'bk_battery'
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: id,
      $push: {
        outboundSuccess: {
          id: battery,
        }
      },
      $pull: {
        outboundFailed:{
          id: battery
        }
      },
      $set: {
        status
      }
    }, bkBatteryUpdates]
  });
};
module.exports = injectTransaction(exports, 'account.order.batteryStartRepair.takeOne');
