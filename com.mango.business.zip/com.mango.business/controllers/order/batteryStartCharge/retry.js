const Joi = require('poolishark').Joi;
const ODBatteryStartCharge = require('../../../services/database/order/batteryStartCharge');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  user: Joi.string(),
};

exports.handler = async function ( { id, user } ) {
  const batteryStartCharge = await ODBatteryStartCharge.findById({ id, selector: 'status startChargeFailed nextTry' });
  if (!batteryStartCharge) throw new NotFoundError('不存在该上架单');

  if (batteryStartCharge.status !== constants.OD_BATTERY_START_CHARGE_STATUS.上架中) throw new BadRequestError('非上架中上架单不能重试');

  if (batteryStartCharge.nextTry) {
    if (new Date().getTime() < batteryStartCharge.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (batteryStartCharge.status === constants.OD_BATTERY_START_CHARGE_STATUS.上架中) {
    await this.exec({
      c: 'order/batteryStartCharge/startCharge',
      params: {
        id,
        user,
        batteries: batteryStartCharge.startChargeFailed.map(battery => battery.id._id)
      }
    })
  }
};