const Joi = require('poolishark').Joi;
const ODBatteryStartCharge = require('../../../services/database/order/batteryStartCharge');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  user: Joi.string().allow(''), // 重试操作人
  batteries: Joi.array().items(Joi.string()),
};

exports.handler = async function ({ id, user, batteries }) {
  const odBatteryStartCharge = await ODBatteryStartCharge.findById({ id, selector: 'updatedAt status' });
  if (!odBatteryStartCharge) throw new NotFoundError(`不存在报废单:${id}`);

  if (odBatteryStartCharge.status !== constants.OD_BATTERY_START_CHARGE_STATUS.上架中) throw new BadRequestError('该上架单不在上架中');

  await ODBatteryStartCharge.update({
    id: odBatteryStartCharge._id,
    updatedAt: odBatteryStartCharge.updatedAt,
    data: {
      nextTry: Date.now() + 3 * 60 * 1000, // 3分钟后重试
      startChargeFailed: batteries.map(battery => {
        return {
          id: battery,
          time: new Date(),
          errorMessage: '初始化',
        }
      }),
    },
    arrayOp: user ? {
      $push: {
        nextTryRecords: {
          operator: user,
          triedAt: new Date()
        }
      }
    } : undefined
  });
  process.nextTick(_ => {
    (async _ => {
      let count = 0;
      for (let battery of batteries) {
        count++;
        try {
          await this.exec({
            c: 'order/batteryStartCharge/startChargeOne',
            params: {
              id,
              battery,
              status: count === batteries.length ? constants.OD_BATTERY_START_CHARGE_STATUS.已完成 : constants.OD_BATTERY_START_CHARGE_STATUS.上架中,
            }
          })
        } catch (err) {
          count--;
          console.error(err)
        }
      }
    })()
  })
};