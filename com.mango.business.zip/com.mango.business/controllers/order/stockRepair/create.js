const Joi = require('poolishark').Joi;
const ODStockRepair = require('../../../services/database/order/stockRepair');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACUSer = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');

exports.validate = Joi.object({
  station: Joi.string().required(),
  storeManager: Joi.string(),
  stocks: Joi.array().items(Joi.string()),
}).unknown();

exports.handler = async function({ station, storeManager, stocks }) {

  let bkStocks = await BKStock.find({
    query: {
      _id: {
        $in: stocks,
      },
      repairStatus: constants.BK_REPAIR_STATUS.需要维修,
      station
    },
    limit: 0,
  });
  if (bkStocks.length !== stocks.length) throw new BadRequestError(`存在车辆状态不正确，请重新检测`);

  const _user = ACUSer.findById({ id: storeManager });
  if (!_user) throw new NotFoundError(`未找到用户：${storeManager}`);

  const _station = await OPBatteryStation.findById({ id: station, selector: 'region' });
  if (!_station) throw new NotFoundError(`未找到仓库：${station}`);

  const region = _station.region && _station.region._id;

  const stockRepair = await ODStockRepair.findByStoreManager({
    storeManager,
    status: constants.OD_STOCK_REPAIR.正在进行,
  });
  // if (stockDamage) throw new BadRequestError('该用户有正在进行的置损单');

  const odStockRepair = await ODStockRepair.create({
    region,
    station,
    storeManager,
    stocks: bkStocks.map(item => item._id),
    date: new Date(),
  });

  await this.exec({
    c: 'order/stockRepair/repair',
    params: {
      id: odStockRepair._id,
      stocks: bkStocks.map(item => item._id),
    },
  });
};
