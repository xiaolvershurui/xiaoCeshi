const Joi = require('poolishark').Joi;
const ODStockRepair = require('../../../services/database/order/stockRepair');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ( { id } ) {
  const stockRepair = await ODStockRepair.findById({
    id,
    selector: 'status repairFailed nextTry'
  });
  if (!stockRepair) throw new NotFoundError('不存在该维修单');
  if (constants.OD_STOCK_REPAIR.正在进行 !== stockRepair.status) throw new BadRequestError('维修单不在进行中，请检查后重试');
  if (stockRepair.nextTry) {
    if (new Date().getTime() < stockRepair.nextTry.getTime()) throw new BadRequestError('您重试太频繁了，请稍后再试');
  }
  if (stockRepair.status === constants.OD_STOCK_REPAIR.正在进行) {
    await this.exec({
      c: 'order/stockRepair/repair',
      params: {
        id,
        stocks: stockRepair.repairFailed.map(item => item._id)
      }
    })
  }
};
