const Joi = require('poolishark').Joi;
const ODStockRepair = require('../../../services/database/order/stockRepair');
const BKStock = require('../../../services/database/ebike/stock');
const RCStockOp = require('../../../services/database/record/stockOp');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  stock: Joi.string().required(),
  status: Joi.number().required(),
  finishedAt: Joi.date(),
};

exports.handler = async function ({ id, stock, status, finishedAt }, tid, Transaction) {
  const bkStock = await BKStock.findById({ id: stock, selector: 'number.custom style repairStatus' });
  if (!bkStock) throw new NotFoundError(`车辆${stock}不存在`);

  const odStockRepair = await ODStockRepair.findById({
    id,
    selector: 'region station driver storeManager stocks repairFailed repairSuccess',
    populateSelector: {
      storeManager: '_id cert.name auth.tel profile.avator',
      station: 'name'
    }
  });
  if (!odStockRepair) throw new NotFoundError(`维修单${id}不存在`);
  // 添加成功
  odStockRepair.repairSuccess.push(stock);
  const odStockRepairUpdates = {
    _id: id,
    $pull: {
      repairFailed: stock,
    },
    $addToSet: {
      repairSuccess: stock,
    },
    $set: {
      status,
      finishedAt,
    }
  };

  // 车辆操作记录
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'od_stock_repair',
      id: odStockRepair._id,
    }, {
      model: 'bk_stock',
      id: stock,
    }, {
      model: 'rc_stock_op',
    }],
  });

  await Transaction.commit({
    tid,
    updates: [odStockRepairUpdates, {
      _id: stock,
      $set: {
        repairStatus: constants.BK_REPAIR_STATUS.不需要维修,
        repairTime: new Date(),
      },
    }, {
      stock,
      stockNo: bkStock.number && bkStock.number.custom,
      type: constants.RC_STOCK_OP_TYPE.修复损坏,
      region: odStockRepair.region._id,
      style: bkStock.style._id,
      operatedAt: new Date(),
      operator: odStockRepair.storeManager && odStockRepair.storeManager._id,
      operatorTel: odStockRepair.storeManager && odStockRepair.storeManager.auth.tel,
      operatorName: odStockRepair.storeManager && odStockRepair.storeManager.cert.name,
      operatorAvator: odStockRepair.storeManager && odStockRepair.storeManager.profile.avator,
      description: `将车牌号为${bkStock.number && bkStock.number.custom}的车辆置为不需要维修`,
      repairDamage: {
        prevRepairStatus: bkStock.repairStatus,
        nextRepairStatus: constants.BK_REPAIR_STATUS.不需要维修,
      }
    }],
  });

  await this.exec({
    c: 'operation/repairWorkOrder/create',
    params: { stock, repairOrderId: odStockRepair._id }
  })
};

module.exports = injectTransaction(exports, 'order.stockRepair.repairOne');
