const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BKStock = require('../../../services/database/ebike/stock');

exports.validate = Joi.object({
  stocks: Joi.array().items(Joi.object()),
  station: Joi.string().required(),
}).unknown();

exports.handler = async function({ stocks, station }) {
  let bkStocks = [];
  let s;
  for (let stock of stocks) {
    if (stock.number) {
      s = await BKStock.findByNumber(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: { custom: stock.number }, notFound: true }];
    } else if (stock.vin) {
      s = await BKStock.findByVin(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { number: { vin: stock.vin }, notFound: true }];
    } else if (stock.box) {
      s = await BKStock.findByBox(Object.assign({}, stock, { selector: '_id number.custom number.vin box locate repairStatus station' }));
      bkStocks = s ? [...bkStocks, s] : [...bkStocks, { box: stock.box, notFound: true }];
    }
  }
  return bkStocks.reduce((memo, item) => {
    const reason = {};
    const s = bkStocks.filter(i => i._id === item._id);
    if (item.notFound) {
      reason.shouldNotCommitReason = `
      ${item.number.custom || item.number.vin || item.box}不存在
      ${ s && s.length > 1 ? `${(item.number.custom || item.number.vin || item.box)}存在重复` : '' }
      `;
    } else if (item.repairStatus !== constants.BK_REPAIR_STATUS.需要维修 || (item.station && item.station._id) !== station) {
      reason.shouldNotCommitReason = `
        ${item.repairStatus !== constants.BK_REPAIR_STATUS.需要维修 ? '维修状态应为需要维修, ' : ''}
        ${(item.station && item.station._id) !== station ? '该车辆不在您当前所在的仓库, 请联系线上运营, ' : ''}
        ${ s && s.length > 1 ? `${(item.number.custom || item.number.vin || item.box)}存在重复` : '' }
      `;
    } else if (s && s.length > 1) {
      reason.shouldNotCommitReason = `${(item.number.custom || item.number.vin || item.box)}存在重复`
    }
    Reflect.deleteProperty(item, 'repairStatus');
    Reflect.deleteProperty(item, 'locate');
    Reflect.deleteProperty(item, 'station');
    memo = [...memo, Object.assign({}, item, reason)];
    return memo;
  }, []);
};
