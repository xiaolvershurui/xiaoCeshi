const Joi = require('poolishark').Joi;
const ODAssetPurchase = require('../../../services/database/order/assetPurchase');
const STSupplier = require('../../../services/database/setting/supplier');
const STAsset = require('../../../services/database/setting/asset');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  supplier: Joi.string().required(),
  contractFile: Joi.string(),
  assets: Joi.array().items(Joi.object({
    id: Joi.string().required(),
    specification: Joi.string().required(),
    count: Joi.number().required(),
    price: Joi.number().required(),
    style: Joi.string().required(),
  })).required(),
};


exports.handler = async function ({ user, supplier, contractFile, assets }) {
  const assetPurchase = await ODAssetPurchase.findByUser({
    user,
    status: [constants.OD_ASSET_PURCHASE_STATE.采购中, constants.OD_ASSET_PURCHASE_STATE.审核中],
  });

  const supplierInfo = await STSupplier.findById({ id: supplier, selector: '_id' });
  if (!supplierInfo) throw new NotFoundError('该运营商不存在');

  const stAssets = await STAsset.find({
    query: {
      _id: {
        $in: assets.map(asset => asset.id),
      },
    },
  });
  if (stAssets.length !== assets.length) throw new BadRequestError('有重复配件或未录入配件');

  const odAssetPurchase = await ODAssetPurchase.create({
    user,
    supplier,
    contractFile,
    assets: [],
  });
  await this.exec({
    c: 'order/assetPurchase/purchase',
    params: {
      id: odAssetPurchase._id,
      assets,
    },
  });

};