const Joi = require('poolishark').Joi;
const ODAssetPurchase = require('../../../services/database/order/assetPurchase');
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  supplier: Joi.string(),
  contractFile: Joi.string(),
  assets: Joi.array().items(Joi.object({
    id: Joi.string(),
    specification: Joi.string(),
    count: Joi.number(),
    price: Joi.number(),
    style: Joi.string(),
  }))
};

exports.handler = async function ( { id, supplier, contractFile, assets } ) {
  const odAssetPurchase =  await ODAssetPurchase.findById({ id, selector: 'updatedAt status' });
  if (!odAssetPurchase) throw new NotFoundError('该采购单不存在');

  if (![constants.OD_ASSET_PURCHASE_STATE.采购中, constants.OD_ASSET_PURCHASE_STATE.已驳回].includes(odAssetPurchase.status)) throw new BadRequestError('该采购单不在采购中或已驳回');

  const stAssets = await STAsset.find({ query: {
    _id: {
      $in: assets.map(asset => asset.id)
    }
  } });
  if (stAssets.length !== assets.length) throw new BadRequestError('有重复配件或未录入配件');

  // 计算采购总额
  const total = assets.reduce((memo, item) => {
    memo += item.price * item.count;
    return memo;
  }, 0);

  return await ODAssetPurchase.update({
    id: odAssetPurchase._id,
    updatedAt: odAssetPurchase.updatedAt,
    data: {
      supplier,
      contractFile,
      assets,
      status: constants.OD_ASSET_PURCHASE_STATE.审核中,
      total,
      finishedAt: new Date()
    }
  });
};