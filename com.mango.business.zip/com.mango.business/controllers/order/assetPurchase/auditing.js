const Joi = require('poolishark').Joi;
const ODAssetPurchase = require('../../../services/database/order/assetPurchase');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  auditor: Joi.string().required(),
  status: Joi.number().required()
};

exports.handler = async function ({ id, auditor, status }) {
  const assetPurchase = await ODAssetPurchase.findById({
    id,
    selector: 'user status purchaseFailed purchaseSuccess nextTry',
  });
  if (!assetPurchase) throw new NotFoundError('不存在该采购单');

  if (constants.OD_ASSET_PURCHASE_STATE.审核中 !== assetPurchase.status) throw new BadRequestError('非审核中订单无法审核');

  await ODAssetPurchase.update({
    id,
    data: {
      status,
      auditor,
      auditAt: new Date()
    }
  })
};
