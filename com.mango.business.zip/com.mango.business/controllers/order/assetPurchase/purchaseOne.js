const Joi = require('poolishark').Joi;
const ODAssetPurchase = require('../../../services/database/order/assetPurchase');
const STAsset = require('../../../services/database/setting/asset');
const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  asset: Joi.object({
    id: Joi.string(),
    specification: Joi.string(),
    count: Joi.number(),
    price: Joi.number(),
    style: Joi.string(),
  }).required(),
  status: Joi.number().required(),
};

exports.handler = async ({ id, asset, status }, tid, Transaction) => {
  const odAssetPurchase = await ODAssetPurchase.findById({
    id,
    selector: 'region station assets purchaseFailed purchaseSuccess',
  });
  if (!odAssetPurchase) throw new NotFoundError('没有此采购单');

  const assetPurchaseUpdates = {
    assets: odAssetPurchase.assets,
    purchaseSuccess: odAssetPurchase.purchaseSuccess,
    purchaseFailed: odAssetPurchase.purchaseFailed
  };
  assetPurchaseUpdates.assets.push(asset);
  assetPurchaseUpdates.purchaseSuccess.push(Object.assign({}, asset, { time: new Date() }));
  assetPurchaseUpdates.purchaseFailed = odAssetPurchase.purchaseFailed.filter(item => item.id._id !== asset.id);
  assetPurchaseUpdates.status = odAssetPurchase.purchaseFailed.length > 1 ? constants.OD_ASSET_PURCHASE_STATE.采购中 : status;
  assetPurchaseUpdates.finishedAt = odAssetPurchase.purchaseFailed.length === 1 ? new Date() : undefined;
  assetPurchaseUpdates.total = odAssetPurchase.purchaseSuccess.reduce((memo, item) => {
    memo += item.price * item.count;
    return memo;
  }, 0);

  await ODAssetPurchase.update({
    id: odAssetPurchase._id,
    data: assetPurchaseUpdates,
  })
};