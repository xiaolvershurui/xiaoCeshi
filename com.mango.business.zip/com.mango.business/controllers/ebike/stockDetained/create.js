const STDetainedArea = require('../../../services/database/setting/detainedArea');
const BKStock = require('../../../services/database/ebike/stock');
const ACUser = require('../../../services/database/account/user');
const BKStockDetained = require('../../../services/database/ebike/stockDetained');
const RCDetainedAreaLog = require('../../../services/database/record/detainedAreaLog');
const RCStockOp = require('../../../services/database/record/stockOp');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  detainedArea: Joi.string().required(),
  stock: Joi.array().items(Joi.string().required()).required(),
  reporter: Joi.string().required(),
  operator: Joi.string().required(),
};

exports.handler = async function ({ detainedArea, stock, reporter, operator }, tid, Transaction) {
  const stDetainedArea = await STDetainedArea.findById({ id: detainedArea, selector: 'name lngLat address' });
  if (!stDetainedArea) throw new NotFoundError('暂无该扣押点');

  reporter = await ACUser.findById({
    id: reporter,
    selector: 'auth.tel cert.name profile',
  });

  const bkStocks = await BKStock.find({
    query: {
      'number.custom': {
        $in: stock,
      },
      locate: { $nin: [constants.BK_LOCATE.预约, constants.BK_LOCATE.扣押, constants.BK_LOCATE.在租] },
    },
    selector: '_id locate number.custom region style',
  });
  const stocks = bkStocks.map(stock => stock._id);
  if (stocks.length !== stock.length || bkStocks.filter(stock => stock.locate !== constants.BK_LOCATE.扣押).length !== stock.length) throw new NotFoundError('有车辆不存在或已是扣押状态');
  let bkEntities = [];
  bkEntities = stocks.map(stock => {
    return {
      id: stock,
      model: 'bk_stock',
    };
  });
  await Transaction.findAndLockEntity({
    tid,
    entities: [...[{
      model: 'st_detained_area',
      id: detainedArea,
    }, {
      model: 'bk_stock_detained',
    }, {
      model: 'rc_detained_area_log',
    }], ...bkEntities],
  });


  const stockDetainedId = await BKStockDetained.genId();
  const detainedAreaLogId = await RCDetainedAreaLog.genId();

  const now = new Date();
  const bkUpdates = stocks.map(stock => {
    return {
      _id: stock,
      $set: {
        locate: constants.BK_LOCATE.扣押,
        detainedArea,
      },
    };
  });
  await Transaction.commit({
    tid,
    updates: [...[{
      _id: stDetainedArea._id,
      $addToSet: {
        stocks: {
          $each: stocks,
        },
      },
    }, {
      _id: stockDetainedId,
      detainedArea,
      stock: stocks,
      reportTime: now,
      reporter: reporter._id,
      operator,
    }, {
      _id: detainedAreaLogId,
      detainedArea,
      stock: stocks,
      logType: constants.ST_DETAINED_AREA_LOG_TYPE.添加扣押车辆,
      mark: '添加扣押车辆',
      operator,
    }], ...bkUpdates],
  });

  process.nextTick(async _ => {
    for (let stock of bkStocks) {
      await RCStockOp.create({
        data: {
          stock: stock._id,
          stockNo: stock.number && stock.number.custom,
          type: constants.RC_STOCK_OP_TYPE.被扣上报,
          region: stock.region._id,
          style: stock.style._id,
          operatedAt: now,
          operator: reporter._id,
          operatorTel: reporter.auth.tel,
          operatorName: reporter.cert.name,
          operatorAvator: reporter.profile.avator,
          description: `车牌号为${stock.number && stock.number.custom}的车辆上报到${stDetainedArea.name}扣押点`,
          detained: {
            // 被扣地点
            location: {
              lngLat: stDetainedArea.lngLat,
              address: stDetainedArea.address,
            },
            prevLocate: constants.BK_LOCATE.调度,
            nextLocate: constants.BK_LOCATE.扣押,
          },
        },
      });
    }
  });


  for (let stock of stocks) {
    try {
      // 更新车辆
      this.exec({
        c: 'ebike/stock/afterUpdate',
        params: {
          id: stock,
        },
      });
    } catch (error) {
      this.emit('error', error, 'controller.ebike.stockDetained.create');
    }
  }
};

module.exports = injectTransaction(exports, 'ebike.stockDetained.create');

