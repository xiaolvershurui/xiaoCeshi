const BKStock = require('../../../services/database/ebike/stock');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  stock: Joi.array().items(Joi.string().required()).required(),
};

exports.handler = async function ({ stock }) {
  const bkStocks = await BKStock.find({
    query: {
      'number.custom': {
        $in: stock,
      },
      // locate: { $ne: constants.BK_LOCATE.扣押 },
    },
    selector: '_id locate number.custom',
  });

  // isExist: true/false 存在/不存在  isDetained: true/false 扣押状态/非扣押状态
  return stock.reduce((memo, item) => {
    const s = bkStocks.find(i => i.number.custom === item);
    if (!s) {
      memo = [...memo, {
        number: item,
        isExist: false,
        canOp: false,
        shouldNotCommitReason: `车辆不存在`
      }];
    } else if (s.locate === constants.BK_LOCATE.扣押) {
      memo = [...memo, {
        number: item,
        isExist: true,
        canOp: false,
        shouldNotCommitReason: `车辆当前为扣押状态，请联系线上运营先解除扣押`
      }];
    } else {
      memo = [...memo, {
        number: item,
        isExist: true,
        canOp: true,
      }];
    }
    return memo;
  }, []);

};


