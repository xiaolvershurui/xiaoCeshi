const STDetainedArea = require('../../../services/database/setting/detainedArea');
const ACUser = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const BKStockRelieveDetained = require('../../../services/database/ebike/stockRelieveDetained');
const RCDetainedAreaLog = require('../../../services/database/record/detainedAreaLog');
const RCStockOp = require('../../../services/database/record/stockOp');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  detainedArea: Joi.string().required(),
  stock: Joi.array().items(Joi.string().required()).required(),
  handler: Joi.string().required(),
  penalty: Joi.number(),
  parkingFee: Joi.number(),
  operator: Joi.string().required(),
  regions: Joi.array().items(Joi.string())
};

exports.handler = async function({ detainedArea, stock, handler, penalty, parkingFee, operator, regions }, tid, Transaction) {

  const stDetainedArea = await STDetainedArea.findById({ id: detainedArea, selector: 'name lngLat address stocks region' });
  if (!stDetainedArea) throw new NotFoundError('暂无该扣押点');

  // 不在当前所在的权限大区内不能释放扣押
  if (!regions.includes(stDetainedArea.region._id)) throw new BadRequestError(`扣押点所在大区${stDetainedArea.region && stDetainedArea.region._id}不在您当前的权限大区内，请确保您拥有当前扣押点所在大区的权限`);

  const bkStocks = await BKStock.find({
    query: {
      'number.custom': {
        $in: stock,
      },
      locate: constants.BK_LOCATE.扣押,
    },
    selector: '_id locate number.custom region style',
  });

  bkStocks.map(item => item._id).forEach(item => {
    const s = stDetainedArea.stocks.map(i => i._id).find(i => i === item);
    if (!s) throw new BadRequestError(`车辆${item}不在当前扣押点${detainedArea}内`)
  });

  handler = await ACUser.findById({
    id: handler,
    selector: 'auth.tel cert.name profile',
  });

  const findCustom = [];
  const stocks = bkStocks.map(stock => {
    findCustom.push(stock.number.custom);
    return stock._id;
  });

  const wrongStocks = stock.filter(st => !findCustom.includes(st));

  if (wrongStocks.length) throw new NotFoundError(`${wrongStocks.toString()}不存在或未被扣押`);

  let bkEntities = [];
  bkEntities = stocks.map(stock => {
    return {
      id: stock,
      model: 'bk_stock',
    };
  });

  await Transaction.findAndLockEntity({
    tid,
    entities: [...[{
      id: detainedArea,
      model: 'st_detained_area',
    }, {
      model: 'bk_stock_relieve_detained',
    }, {
      model: 'rc_detained_area_log',
    }], ...bkEntities],
  });

  const stockRelieveDetainedId = await BKStockRelieveDetained.genId();
  const detainedAreaLogId = await RCDetainedAreaLog.genId();

  const now = new Date();
  const bkUpdates = stocks.map(stock => {
    return {
      _id: stock,
      $set: {
        locate: constants.BK_LOCATE.调度,
      },
      $unset: {
        detainedArea: true,
      },
    };
  });

  await Transaction.commit({
    tid,
    updates: [...[{
      _id: stDetainedArea._id,
      $pull: {
        stocks: {
          $in: stocks,
        },
      },
    }, {
      _id: stockRelieveDetainedId,
      detainedArea,
      stock: stocks,
      reportTime: now,
      handler: handler._id,
      penalty,
      parkingFee,
      operator,
    }, {
      _id: detainedAreaLogId,
      detainedArea,
      stock: stocks,
      logType: constants.ST_DETAINED_AREA_LOG_TYPE.减少扣押车辆,
      mark: '减少扣押车辆',
      operator,
    }], ...bkUpdates],
  });

  process.nextTick(async _ => {
    for (let stock of bkStocks) {
      await RCStockOp.create({
        data: {
          stock: stock._id,
          stockNo: stock.number && stock.number.custom,
          type: constants.RC_STOCK_OP_TYPE.被扣找回,
          region: stock.region._id,
          style: stock.style._id,
          operatedAt: now,
          operator: handler._id,
          operatorTel: handler.auth.tel,
          operatorName: handler.cert.name,
          operatorAvator: handler.profile.avator,
          description: `找回扣押在${stDetainedArea.name}扣押点的车牌号为${stock.number && stock.number.custom}的车辆`,
          // 被扣找回
          detainedFindBack: {
            // 找回地点
            location: {
              lngLat: [Number],
              address: String,
            },
            prevLocate: constants.BK_LOCATE.扣押,
            nextLocate: constants.BK_LOCATE.调度,
          },
        },
      });
    }
  });

  for (let stock of stocks) {
    try {
      // 更新车辆
      this.exec({
        c: 'ebike/stock/afterUpdate',
        params: {
          id: stock,
        },
      });
    } catch (error) {
      this.emit('error', error, 'controller.ebike.stockRelieveDetained.create');
    }
  }
};

module.exports = injectTransaction(exports, 'ebike.stockRelieveDetained.create');
