const BKStock = require('../../../services/database/ebike/stock');
const STDetainedArea = require('../../../services/database/setting/detainedArea');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  regions: Joi.array().items(Joi.string()),
  detainedArea: Joi.string(),
  stock: Joi.array().items(Joi.string().required()).required(),
};

exports.handler = async function({ regions, detainedArea, stock }) {
  const bkStocks = await BKStock.find({
    query: {
      'number.custom': {
        $in: stock,
      },
    },
    selector: '_id locate number.custom detainedArea',
  });

  const detainedAreas = await STDetainedArea.find({
    query: {
      region: {
        $in: regions,
      },
    },
    limit: 0,
    selector: 'address'
  });

  // isExist: true/false 存在/不存在  isDetained: true/false 解除扣押状态/扣押状态
  return stock.reduce((memo, item) => {
    const s = bkStocks.find(i => i.number.custom === item);
    if (!s) {
      memo = [...memo, {
        number: item,
        isExist: false,
        canOp: false,
        shouldNotCommitReason: `车辆不存在`,
      }];
    } else if (s.locate !== constants.BK_LOCATE.扣押 || !detainedAreas.map(i => i._id).includes(s.detainedArea) || (detainedArea && s.detainedArea !== detainedArea)) {
      memo = [...memo, {
        number: item,
        isExist: true,
        canOp: false,
        detainedAreaAddress: !detainedArea && s.detainedArea ? detainedAreas.find(i => i._id === s.detainedArea).address : undefined,
        shouldNotCommitReason: `
        ${ s.locate !== constants.BK_LOCATE.扣押 ? `车辆应当为扣押去向，当前为${constants.BK_LOCATE_MAP[s.locate]}去向，请联系线上运营，` : ''}
        ${ detainedAreas.map(i => i._id).includes(s.detainedArea) ? '' : '扣押点不在您的权限大区内，' }
        ${ detainedArea ? ((s.detainedArea === detainedArea) ? '' : `车辆不在当前扣押点${detainedArea}内`) : ''}`,
      }];
    } else {
      memo = [...memo, {
        number: item,
        isExist: true,
        canOp: true,
        detainedAreaAddress: !detainedArea ? detainedAreas.find(i => i._id === s.detainedArea).address : undefined,
      }];
    }
    return memo;
  }, []);

};


