const BTBKBox = require('../../../services/database/ebike/btBox');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
}).unknown();
exports.handler = async function ({ deviceId }) {
  BTBKBox.update({ id: deviceId, data: { isOnline: true } });
};