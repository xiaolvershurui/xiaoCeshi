const BKBTBox = require('../../../services/database/ebike/btBox');
const BKBattery = require('../../../services/database/ebike/battery');
const IoT = require('../../../services/iot');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
  ds: Joi.number().required(),
  deviceType: Joi.string(),
  appVersion: Joi.string(),
  imsi: Joi.string(),
}).unknown();
exports.handler = async function ({ deviceId, ds, deviceType, appVersion, imsi }) {
  await BKBTBox.findByIdAndGenerate({
    deviceId,
    dataSource: ds,
    selector: '_id',
  });
  BKBTBox.update({
    id: deviceId,
    data: {
      isOnline: true,
      latestOnlineAt: new Date(),
      dataSource: ds,
      deviceType,
      appVersion,
      'sim.imsi': imsi,
      'sim.powerOn': true,
    },
  });

  // 电池盒子登陆后，检测是否疑似丢失，如果丢失，设置其工作模式
  (async () => {
    const battery = await BKBattery.findByBox({
      box: deviceId,
      selector: 'isSuspectedLost locate',
    });

    const newConfig = {};
    if (battery &&
      (
        battery.locate === constants.BK_BATTERY_LOCATE.丢失 ||
        (battery.locate === constants.BK_BATTERY_LOCATE.安装于车辆 && battery.isSuspectedLost)
      )) {
      newConfig.gpstime = 300;
      newConfig.mode = 0;
    } else {
      newConfig.sleeptime = 3600;
      newConfig.mode = 2;
    }

    await IoT.sendCommand({
      type: 1,
      deviceId,
      command: 'setConfig',
      params: newConfig,
    });
  })().catch(error => {
    // console.error(error.message, 'BTBOX_LOGIN');
  });
};
