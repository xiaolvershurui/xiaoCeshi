const BKBattery = require('../../../services/database/ebike/battery');
const BKBTBox = require('../../../services/database/ebike/btBox');
const RCBattery = require('../../../services/database/record/batteryPoint');
const Joi = require('poolishark').Joi;
const coordtransform = require('coordtransform');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
  ds: Joi.number().required(),
  status: Joi.object({
    mode: Joi.number(),
    voltage: Joi.number(),
    signal: Joi.number()
  }).unknown(),
  gpsLocation: Joi.object({
    lngLat: validators.location, // wgs84
    speed: Joi.number(),
    direction: Joi.number(),
    time: Joi.date()
  }).default({}),
  cellLocation: Joi.object({
    mcc: Joi.number(),
    mnc: Joi.number(),
    cells: Joi.array().items({
      lac: Joi.number(),
      ci: Joi.number(),
      rxl: Joi.number()
    }),
    time: Joi.date()
  }),
  nId: Joi.string().empty('').allow(null),
  appVersion: Joi.string().empty('').allow(null)
}).unknown();
exports.handler = async function (data) {
  // find bt box.
  const btBox = await BKBTBox.findByIdAndGenerate({
    deviceId: data.deviceId,
    dataSource: data.ds,
    selector: 'updatedAt'
  });
  if (!btBox) return;

  const { mode, voltage, signal } = data.status;

  const btBoxUpdate = {
    isOnline: true,
    mode,
    signal,
    voltage,
  };

  if (data.gpsLocation && data.gpsLocation.lngLat) {
    const { lngLat } = data.gpsLocation;
    data.gpsLocation.gpsLngLat = lngLat;
    data.gpsLocation.lngLat = coordtransform.wgs84togcj02(lngLat[0], lngLat[1]);
    btBoxUpdate.gpsLocation = data.gpsLocation;
    // 查询绑定的电池信息
    const battery = await BKBattery.findByBox({
      box: btBox._id,
      selector: '_id updatedAt',
      cache: { enable: true }
    });
    if(battery) {
      // 更新电池的定位信息
      BKBattery.update({
        id: battery._id,
        updatedAt: battery.updatedAt,
        data: {
          location: {
            lngLat: data.gpsLocation.lngLat,
            time: data.gpsLocation.time,
            speed: data.gpsLocation.speed,
            direction: data.gpsLocation.direction,
          }
        }
      });
    }
  } else if (data.cellLocation) {
    data.cellLocation.time = new Date();
    btBoxUpdate.cellLocation = data.cellLocation;
  }

  // 存储点记录
  RCBattery.create(data);
  // 更新盒子状态
  // 更新盒子位置
  BKBTBox.update({
    id: data.deviceId,
    updatedAt: btBox.updatedAt,
    data: btBoxUpdate
  });

};
