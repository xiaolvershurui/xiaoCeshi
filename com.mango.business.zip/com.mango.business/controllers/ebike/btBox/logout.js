const BKBTBox = require('../../../services/database/ebike/btBox');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
}).unknown();
exports.handler = async function ({ deviceId }) {
  BKBTBox.update({ id: deviceId, data: { isOnline: false } });
};