const BKDamage = require('../../../services/database/ebike/damage');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');


exports.validate = Joi.object({
  id: Joi.string().required(),
  selector: Joi.string().default('_id').allow(''),
});

exports.handler = async ( { id } ) => {
  const damage = BKDamage.findById({ id });
  if (!damage) throw new NotFoundError('未找到该条车损记录');
  return damage;
};

