const BKStock = require('../../../services/database/ebike/stock');
const BKBattery = require('../../../services/database/ebike/battery');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const Joi = require('poolishark').Joi;
const { combineLngLats } = require('../../operation/inspectionOrder/_getLngLats');

exports.validate = Joi.object({
  id: Joi.string(),
  number: Joi.string(),
  now: Joi.date().required(),
  year: Joi.number().required(),
  month: Joi.string().required(),
  startTime: Joi.number().required(),
  endTime: Joi.number().required(),
}).unknown();

exports.handler = async function ({ id, code, now, year, month, startTime, endTime }) {
  if (!id && !code) throw new BadRequestError('请传入电池id或二维码');

  let battery;
  if (id) {
    battery = await BKBattery.findById({ id });
    if (!battery) throw new NotFoundError(`id为${id}的电池不存在`);
  }
  if (code) {
    battery = await BKBattery.findByCode({ code, selector: '_id' });
    if (!battery) throw new NotFoundError(`二维码为${code}的电池不存在`);
  }

  const stock = await BKStock.findByBattery({
    battery: battery._id,
    selector: 'number.custom box',
  });
  if (!stock) throw new NotFoundError(`电池${id}未绑定到车辆`);
  if (!stock.box) throw new NotFoundError(`电池${id}绑定的车牌号为${stock.number.custom}的车辆上无盒子`);

  if (stock.box) {
    return await combineLngLats({
      box: stock.box._id,
      battery: battery._id,
      now,
      year,
      month,
      startTime,
      endTime,
      type: 'batteryPoint',
    }, { earliestTime: new Date(startTime) });
  }
};