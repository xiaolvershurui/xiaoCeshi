const BKStock = require('../../../services/database/ebike/stock');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const injectTransaction = require('../../../utils/injectTransaction');
const ACUser = require('../../../services/database/account/user');
const RCStockOp = require('../../../services/database/record/stockOp');


exports.validate = Joi.object({
  stock: Joi.object().required(),
});

exports.handler = async function ({ stock }) {
  const inspector = await ACUser.findById({
    id: stock.inspector._id,
    selector: 'auth.tel _id cert.name'
  });
  await BKStock.update({
    id:stock._id,
    data:{
      inspector: null,
      inspectorName: null,
      inspectorTel: null,
    }
  });
  return  await RCStockOp.create({
    data:{
      stock: stock._id,
      type: constants.RC_STOCK_OP_TYPE.解除巡检人员,
      description: `解除巡检人员 ${inspector.cert.name}`,
      releaseInspector: {
        inspector: inspector._id,
        inspectorName: inspector.cert.name,
        inspectorTel: inspector.auth.tel
      },
      operatedAt: new Date()
    }
  })
};

