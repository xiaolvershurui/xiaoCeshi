const BKStock = require('../../../services/database/ebike/stock');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const OPRiderOrder = require('../../../services/database/operation/riderOrder');
const ACOperator = require('../../../services/database/account/operator');
const SSFinalStockState = require('../../../services/database/statistic/finalStockState');
const RCBatteryOp = require('../../../services/database/record/batteryOp');
const STInspectionIssueReason = require('../../../services/database/setting/inspectionIssueReason');
const RCStockInspectionIssue = require('../../../services/database/record/stockInspectionIssue');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = Joi.object({
  id: Joi.string().required(),
  uid: Joi.string().required(),
  hasFind: Joi.boolean().required(),
  remark: Joi.string(),
  failedReason: Joi.number(),
  photo: Joi.string(),
  location: Joi.object({
    lngLat: validators.location,
    address: Joi.string().allow(''),
  }).allow(null),
  failedAddress: Joi.string(),
  inspectionIssueReason: Joi.string(),
  inspectionIssueReasonExtra: Joi.string(),
}).unknown();

const findStockInInspectionOrder = async ({ inspectionOrder, inspectedStock, releasedTasks, inspectionOrderData, hasFinished, now, stock }, { uid, id, hasFind, remark, failedReason, photo, location }) => {
  if (inspectedStock) {
    // 后续更新打卡 部分数据更新
    inspectedStock.hasFound = hasFind;
    inspectedStock.lastTaskList = stock.taskList;
    inspectedStock.lastLocate = stock.locate;
    inspectedStock.finishedAt = now;
    inspectedStock.nextVoltage = stock.battery.voltage;
    addedTasks = stock.taskList.filter(task => !inspectedStock.prevTaskList.search({ code: task.code }));
    inspectedStock.isBatteryLock = stock.batteryLockOn;
    // 找车打卡图片
    inspectedStock.findStockPhoto = photo;
    // 是否拖回 是否换电 是否回栏 是否难寻找到 是否投放
    releasedTasks = inspectedStock.prevTaskList.filter(task => !stock.taskList.search({ code: task.code }));
    if ((inspectedStock.prevLocate === constants.BK_LOCATE.扣押 && stock.locate !== constants.BK_LOCATE.扣押)
      || (inspectedStock.prevLocate === constants.BK_LOCATE.疑似丢失 && stock.locate !== constants.BK_LOCATE.疑似丢失)
      || releasedTasks.search({ code: constants.BK_TASK_TYPE.高手未找到 })
      || releasedTasks.search({ code: constants.BK_TASK_TYPE.白班未找到 })
      || releasedTasks.search({ code: constants.BK_TASK_TYPE.司机未找到 })
    ) {
      // 难寻找到
      if (stock.locate === constants.BK_LOCATE.仓库) {
        inspectedStock.isHardToFindButFound = true;
      }
    } else if (
      inspectedStock.prevLocate !== constants.BK_LOCATE.仓库
      && inspectedStock.lastLocate === constants.BK_LOCATE.仓库) {
      // 拖回
      inspectedStock.isReturnedBack = true;
    } else {
      if (
        inspectedStock.prevLocate === constants.BK_LOCATE.仓库
        && ![constants.BK_LOCATE.仓库, constants.BK_LOCATE.调度].includes(stock.locate)) {
        // 是否投放
        inspectedStock.isPutOn = true;
      } else if (
        releasedTasks.search({ code: constants.BK_TASK_TYPE.围栏外免单 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.围栏外非免单 })) {
        // 回栏
        inspectedStock.isBackIntoRegion = inspectedStock.isValidTask;
      } else if (
        releasedTasks.search({ code: constants.BK_TASK_TYPE.低压预警 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.低电 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.高压预警 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.零电 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.困难换电 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.被盗断电 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.零电断电 })
      ) {
        // 换电
        inspectedStock.isExchangedBattery = inspectedStock.isValidTask;
      } else {
        inspectedStock.isNormal = inspectedStock.isValidTask;
      }
      // 电池仓锁并且无未完成低电类任务 换电首尾卡期间有换电操作 才有效
      const changeBatteryOp = await RCBatteryOp.findOne({
        query: {
          stock: stock._id,
          type: constants.RC_BATTERY_OP_RECORD_TYPE.电池更换下车,
          createdAt: { $gte: new Date(inspectedStock.startedAt) },
        },
      });
      inspectedStock.inValidTask = !!(stock.batteryLockOn && hasFinished(stock.taskList) && changeBatteryOp);
    }
  } else {
    // 初次打卡
    if (inspectionOrder.inspectedStocks.length === 0) {
      inspectionOrderData['times.firstInspectionStartedAt'] = now;
    }
    inspectionOrder.inspectedStocks.push({
      id,
      bikeNo: stock.number.custom,
      box: stock.box,
      prevTaskList: stock.taskList,
      lastTaskList: stock.taskList,
      hasFound: hasFind,
      startedAt: now,
      finishedAt: now,
      prevLocate: stock.locate,
      isSelfTask: stock.inspector === uid,
      isValidTask: stock.inspector === uid,
      prevVoltage: stock.battery.voltage,
      findStockPhoto: photo,
    });
  }
};

const findStockInRiderOrder = async ({ inspectionOrder, inspectedStock, releasedTasks, inspectionOrderData, hasFinished, now, stock }, { uid, id, hasFind, remark, failedReason, photo, location }) => {
  if (inspectedStock) {
    // // 后续更新打卡 部分数据更新
    inspectedStock.lastTaskList = stock.taskList;
    inspectedStock.lastLocate = stock.locate;
    inspectedStock.finishedAt = now;
    inspectedStock.nextVoltage = stock.battery.voltage;
    // addedTasks = stock.taskList.filter(task => !inspectedStock.prevTaskList.search({ code: task.code }));
    inspectedStock.isBatteryLock = stock.batteryLockOn;

    // 荆州大区增加 拖回, 换电,回栏,难寻,投放,普通,未完成拖回,错误换电,丢失电池 统计
    if (inspectionOrder.region === '1803250934853') {
      releasedTasks = inspectedStock.prevTaskList.filter(task => !stock.taskList.search({ code: task.code }));
      /*if ((inspectedStock.prevLocate === constants.BK_LOCATE.扣押 && stock.locate !== constants.BK_LOCATE.扣押)
        || (inspectedStock.prevLocate === constants.BK_LOCATE.疑似丢失 && stock.locate !== constants.BK_LOCATE.疑似丢失)
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.高手未找到 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.白班未找到 })
        || releasedTasks.search({ code: constants.BK_TASK_TYPE.司机未找到 })
      ) {
        // 难寻找到
        if (stock.locate === constants.BK_LOCATE.仓库) {
          inspectedStock.isHardToFindButFound = true;
        }
      } else*/
      if (
        inspectedStock.prevLocate !== constants.BK_LOCATE.仓库
        && inspectedStock.lastLocate === constants.BK_LOCATE.仓库) {
        // 拖回
        inspectedStock.isReturnedBack = true;
      } else {
        if (
          inspectedStock.prevLocate === constants.BK_LOCATE.仓库
          && ![constants.BK_LOCATE.仓库, constants.BK_LOCATE.调度].includes(stock.locate)) {
          // 是否投放
          inspectedStock.isPutOn = true;
        } else if (
          releasedTasks.search({ code: constants.BK_TASK_TYPE.围栏外免单 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.围栏外非免单 })) {
          // 回栏
          inspectedStock.isBackIntoRegion = inspectedStock.isValidTask;
        } else if (
          releasedTasks.search({ code: constants.BK_TASK_TYPE.低压预警 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.低电 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.高压预警 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.零电 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.困难换电 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.被盗断电 })
          || releasedTasks.search({ code: constants.BK_TASK_TYPE.零电断电 })
        ) {
          // 换电
          inspectedStock.isExchangedBattery = inspectedStock.isValidTask;
        } else {
          inspectedStock.isNormal = inspectedStock.isValidTask;
        }
      }
    }
  } else {
    // 初次打卡
    if (inspectionOrder.inspectedStocks.length === 0) inspectionOrderData['times.firstInspectionStartedAt'] = now;
    const inspectedStock = {
      id,
      bikeNo: stock.number.custom,
      box: stock.box,
      prevTaskList: stock.taskList,
      lastTaskList: stock.taskList,
      hasFound: hasFind,
      startedAt: now,
      finishedAt: now,
      prevLocate: stock.locate,
      isSelfTask: stock.inspector === uid,
      isValidTask: stock.inspector === uid,
      prevVoltage: stock.battery.voltage,
      findStockPhoto: photo,
    };
    if (photo) {
      if ((stock.locate === constants.BK_LOCATE.扣押)
        || (stock.locate === constants.BK_LOCATE.疑似丢失)
        || (stock.locate === constants.BK_LOCATE.丢失)
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.高手未找到 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.司机未找到 })
      ) {
        // 难寻巡检数
        inspectedStock.isHardToFind = true;
        inspectedStock.isHardToFindButFound = !!hasFind;

      } else if (stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天真离线 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内真离线 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天疑似离线 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内疑似离线 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.高压离线 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.无定位 })
      ) {
        // 离线巡检数
        inspectedStock.isOffline = true;
        inspectedStock.isOfflineButFound = !!hasFind;
      } else if (stock.taskList.search({ code: constants.BK_TASK_TYPE.零电 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.零电断电 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.被盗断电 })
      ) {
        // 断电巡检数
        inspectedStock.isPowerOff = true;
        inspectedStock.isPowerOffButFound = !!hasFind;
      } else if (stock.taskList.search({ code: constants.BK_TASK_TYPE.一天未唤醒 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.两天未唤醒 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.四天未唤醒 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.四天未巡检 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.围栏外免单 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.围栏外非免单 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.禁行区 })
        || stock.taskList.search({ code: constants.BK_TASK_TYPE.禁停区 })
      ) {
        // 挪车未唤醒
        inspectedStock.isMoveAndWakeUp = !!hasFind;
      } else {
        inspectedStock.otherFinished = !!hasFind;
      }
    }
    inspectionOrder.inspectedStocks.push(inspectedStock);
  }
};


exports.handler = async function({ uid, id, hasFind, remark, failedReason, photo, location, failedAddress, inspectionIssueReason, inspectionIssueReasonExtra }, tid, Transaction) {
  const operator = await ACOperator.findByUser({ user: uid, selector: 'inspectionType' });
  const isRider = operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行;

  const now = new Date();
  const stock = await BKStock.findById({
    id,
    selector: [].join(' '),
  });
  if (!stock) throw new NotFoundError(`不存在车辆${id}`);
  if (stock.locate === constants.BK_LOCATE.调度) throw new BadRequestError('调度中无法打卡');
  if (!stock.lockVin || (stock.lockVin && !stock.lockVin.isLocked)) throw new BadRequestError('请先锁定车架号，才能进行打卡操作');
  const inspectionOrder = await (isRider ? OPRiderOrder : OPInspectionOrder).findByUserAndState({
    user: uid,
    states: isRider ? [constants.OP_RIDER_ORDER_STATE.派单中] : [constants.OP_INSPECTION_ORDER_STATE.派单中],
    selector: 'region inspectedStocks user.id user.name user.tel user.type',
  });
  if (!inspectionOrder) throw new NotFoundError(`当前不存在派单中的单子`);
  const inspectionOrderData = {};
  const inspectedStock = inspectionOrder.inspectedStocks.search({ id });
  let releasedTasks = [];
  let addedTasks = [];
  const hasFinished = taskList => {
    return !taskList.some(item => {
      return [
        constants.BK_TASK_TYPE.低压预警,
        constants.BK_TASK_TYPE.高压预警,
        constants.BK_TASK_TYPE.低电,
        constants.BK_TASK_TYPE.困难换电,
        constants.BK_TASK_TYPE.零电,
        constants.BK_TASK_TYPE.被盗断电,
        constants.BK_TASK_TYPE.零电断电,
        constants.BK_TASK_TYPE.围栏外非免单,
        constants.BK_TASK_TYPE.围栏外免单,
      ].includes(item.code);
    });
  };

  // 巡检单和骑行单的任务判定区分
  if (isRider) {
    await findStockInRiderOrder({
      inspectionOrder,
      inspectedStock,
      releasedTasks,
      inspectionOrderData,
      now,
      stock,
      hasFinished,
    }, {
      uid,
      id,
      hasFind,
      remark,
      failedReason,
      photo,
      location,
    });
  } else {
    await findStockInInspectionOrder({
      inspectionOrder,
      inspectedStock,
      releasedTasks,
      inspectionOrderData,
      now,
      stock,
      hasFinished,
    }, {
      uid,
      id,
      hasFind,
      remark,
      failedReason,
      photo,
      location,
    });
  }


  inspectionOrderData['times.lastInspectionFinishedAt'] = now;
  inspectionOrderData.inspectedStocks = inspectionOrder.inspectedStocks;
  let stockData = {};
  if (hasFind) {
    // 车辆信息更新
    stockData = {
      _id: id,
      $set: {
        hasFind,
        latestFoundAt: now,
        latestFoundSucceedAt: now,
        notFindRecords: [],
        latestScannedAt: null,
        latestIllegalSpeedAt: null,
      },
    };
  } else {
    if (stock.hasFind) {
      // 新生成一个未找到
      const finalStockState = await SSFinalStockState.findByRegionAndDate({
        region: stock.region._id,
        date: 'today'.beginning,
        selector: 'updatedAt',
      });
      if (finalStockState) {
        this.exec({
          c: 'statistic/finalStockState/update',
          params: {
            id: finalStockState._id,
            data: {},
            arrayOp: {
              $addToSet: {
                difficultFind: stock._id,
              },
            },
          },
        }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.ssFinalStockStateUpdate'));
      }
    }
    // 车辆信息更新
    stockData = {
      _id: id,
      $set: {
        hasFind,
        latestFoundAt: now,
      },
      $push: {
        notFindRecords: {
          time: now,
          finder: inspectionOrder.user,
          location,
          failedReason,
          failedAddress,
        },
      },
    };
  }


  // 司机未找到或者离线 现在找到了
  const prevHasOfflineTask = [
    constants.BK_TASK_TYPE.一天内真离线,
    constants.BK_TASK_TYPE.超一天真离线,
    constants.BK_TASK_TYPE.一天内疑似离线,
    constants.BK_TASK_TYPE.超一天疑似离线,
    constants.BK_TASK_TYPE.高压离线,
  ].some(code => {
    return !!stock.taskList.search({ code });
  });

  if (stock.taskList.search({ code: constants.BK_TASK_TYPE.司机未找到 } || prevHasOfflineTask)) {
    const arrayOpToDay = {};
    const arrayOpYesterday = {};
    if (stock.taskList.search({ code: constants.BK_TASK_TYPE.司机未找到 })) {
      // 难寻找到/未找到
      const update = hasFind ? { difficultFindButFound: stock._id } : { difficultFindAndNotFound: stock._id };
      arrayOpToDay.$addToSet = update;
      arrayOpYesterday.$addToSet = update;
    } else {
      // 离线找到
      const update = hasFind ? { offlineButFound: stock._id } : { offlineAndNotFound: stock._id };
      arrayOpToDay.$addToSet = update;
      arrayOpYesterday.$addToSet = update;
      const isOffline = stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内疑似离线 }) ||
        stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内真离线 }) ||
        stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天真离线 }) ||
        stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天疑似离线 }) ||
        stock.taskList.search({ code: constants.BK_TASK_TYPE.高压离线 });
      const issuedAt = new Date(isOffline.issuedAt).getTime();
      // 昨天12点到今天12点的离线 此处相当于当天找到了离线12小时未上线的车辆 需要更新到当天离线12小时里
      if (issuedAt > '12 hours'.before('today'.beginning).getTime() && issuedAt < '12 hours'.after('today'.beginning).getTime()) {
        arrayOpToDay.$addToSet.offlineBeforeHours = stock._id;
      }
    }
    // 找出最近两天的车况记录
    const finalStockStateToDay = await SSFinalStockState.findByRegionAndDate({
      region: stock.region._id,
      date: 'today'.beginning,
      selector: 'updatedAt',
    });
    const finalStockStateYesterday = await SSFinalStockState.findByRegionAndDate({
      region: stock.region._id,
      date: '1 day'.before('today'.beginning),
      selector: 'updatedAt',
    });
    if (finalStockStateToDay) {
      this.exec({
        c: 'statistic/finalStockState/update',
        params: {
          id: finalStockStateToDay._id,
          data: {},
          arrayOp: arrayOpToDay,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.ssFinalStockStateUpdate'));
    }
    if (finalStockStateYesterday) {
      this.exec({
        c: 'statistic/finalStockState/update',
        params: {
          id: finalStockStateYesterday._id,
          data: {},
          arrayOp: arrayOpYesterday,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.ssFinalStockStateUpdate'));
    }
  }

  if (inspectionIssueReason) {
    await RCStockInspectionIssue.create({
      region: stock.region && stock.region._id,
      stock: stock._id,
      reason: inspectionIssueReason,
      reasonExtra: inspectionIssueReasonExtra,
      creator: uid,
      hasFound: hasFind,
      inspectionType: operator.inspectionType,
    });
  }


  // 更新巡检单 车辆信息
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: isRider ? 'op_rider_order' : 'op_inspection_order',
      id: inspectionOrder._id,
    }, {
      model: 'bk_stock',
      id,
    }],
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: inspectionOrder._id,
      $set: inspectionOrderData,
    }, stockData],
  });

  this.exec({
    c: 'ebike/stock/afterUpdate',
    params: {
      id,
    },
  }).catch(error => this.emit('error', error, 'controller.ebike.stock.findStock.stockAfterUpdate'));
  this.exec({
    c: 'record/stockOp/findStock',
    params: {
      stock: id,
      operateLocation: location,
      operator: uid,
      operateRemark: remark,
      releasedTasks,
      addedTasks,
      prevTaskList: stock.taskList,
      hasFind,
      photo,
      failedReason,
    },
  }).catch(error => this.emit('error', error, 'controller.ebike.stockOp.findStock'));
};

module.exports = injectTransaction(exports, 'ebike.stock.findStock');
