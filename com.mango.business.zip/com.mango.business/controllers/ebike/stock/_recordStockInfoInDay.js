const getCache = require('../../../utils/cache');
const moment = require('moment');

const cache = getCache('mg.cache.stockInfoInDay', 1);

module.exports = async ({ region, stockId, stockNo, voltage, powerUnlink, isOnline }) => {
  if (!region) return;
  const now = new Date();
  const hour = now.getHours();

  const key = `${region}_${moment().format('YYYYMMDD')}_${stockId}`;

  // 在早6点到7点间，记录电压值作为当天初始电压
  // 若已经记录过，则忽略
  if (hour === 6) {
    const info = await cache.getJSON(key);
    if (!info) {
      cache.setJSON(key, {
        voltageAtMorning: voltage,
        powerUnlinkAtMorning: powerUnlink,
        onlineAtMorning: isOnline,
        stockNo,
      }, 'EX', moment.duration(30, 'days').asSeconds());
    }
  } else if (hour >= 18 && hour < 22) {
    // 在晚上18点之后，记录电压
    // 在晚上22点前，若电压未上涨，每次刷新该电压记录
    const info = await cache.getJSON(key);
    if (!info) return;
    if (!info.voltageAtEvening || voltage < info.voltageAtEvening) {
      cache.setJSON(key, Object.assign(info, {
        voltageAtEvening: voltage,
        powerUnlinkAtEvening: powerUnlink,
        onlineAtEvening: isOnline,
      }), 'EX', moment.duration(30, 'days').asSeconds());
    }
  }
};