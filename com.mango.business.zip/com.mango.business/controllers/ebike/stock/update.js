const BKStock = require('../../../services/database/ebike/stock');
const ACUser = require('../../../services/database/account/user');
const BKIdentifier = require('../../../services/database/ebike/identifier');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const ObjectId = require('objectid');

exports.validate = {
  id: Joi.string(),
  type: Joi.number(),
  operator: Joi.string(),
  data: Joi.object({
    'number.vin': Joi.string(),
    'number.custom': Joi.string(),
    lockVin: Joi.object({
      isLocked: Joi.boolean(),
      operator: Joi.string(),
      lockedAt: Joi.date(),
    }),
  }).unknown(),
};

exports.handler = async function({ id, operator, type, data }, tid, transaction) {
  const stock = await BKStock.findById({
    id,
    selector: 'lockVin.isLocked number.custom number.vin region style ',
  });
  if (!stock) throw new NotFoundError('车辆不存在');

  if (operator || data.lockVin) {
    operator = await ACUser.findById({
      id: operator || (data.lockVin && data.lockVin.operator),
      selector: '_id cert.name auth.tel',
    });
  }
  const identifierUpdate = {};
  let shouldUpdateIdentifier = false;
  let rcUpdateDetail = {};
  let identifierData = {};
  switch (type) {
    case constants.RC_STOCK_OP_TYPE.锁定车架号 :
      if (stock.lockVin && stock.lockVin.isLocked) throw new BadRequestError(`该车架状态已经锁定`);
      break;
    case constants.RC_STOCK_OP_TYPE.解锁车架号 :
      if (!(stock.lockVin && stock.lockVin.isLocked)) throw new BadRequestError(`该车架状态已经解锁`);
      break;
    case constants.RC_STOCK_OP_TYPE.更新车架号 :
      if (stock.lockVin && stock.lockVin.isLocked) throw new BadRequestError(`该车架状态已经锁定, 无法更新车架号`);
      const vinStock = await BKStock.findByVin({ vin: data['number.vin'] });
      if (vinStock) throw new BadRequestError(`车架号${data['number.vin']}已经存在`);
      rcUpdateDetail = {
        updateVin: {
          prev: stock.number && stock.number.vin,
          next: data['number.vin'],
        },
      };
      identifierUpdate.vin = data['number.vin'];
      identifierData = await BKIdentifier.findOne({ stock: id });
      shouldUpdateIdentifier = true;
      break;
    case constants.RC_STOCK_OP_TYPE.更新定制车牌号 :
      const existStock = await BKStock.findByNumber({ number: data['number.custom'] });
      if (existStock) throw new BadRequestError(`车牌号${data['number.custom']}已经存在`);
      rcUpdateDetail = {
        updateCustomNumber: {
          prev: stock.number.custom,
          next: data['number.custom'],
        },
      };
      identifierUpdate.number = data['number.custom'];
      identifierData = await BKIdentifier.findOne({ stock: id });
      shouldUpdateIdentifier = true;
      break;
    default:
  }
  const lockEntities = {
    tid,
    entities: [{
      model: 'bk_stock',
      id: stock._id,
    }, {
      model: 'rc_stock_op',
    }],
  };
  const rcStockOpId = await ObjectId();

  const rcStockUpdate = Object.assign({}, {
    _id: rcStockOpId,
    stock: stock._id,
    stockNo: stock.number.custom,
    region: stock.region._id,
    style: stock.style._id,
    type,
    description: constants.RC_STOCK_OP_TYPE_MAP[type],
    operator: operator._id,
    operatorName: operator.cert.name,
    operatorTel: operator.auth.tel,
    operatedAt: new Date(),
  }, rcUpdateDetail);
  const updates = {
    tid,
    updates: [
      {
        _id: stock._id,
        $set: data,
      }, rcStockUpdate,
    ],
  };
  if (shouldUpdateIdentifier && identifierData) {
    lockEntities.entities.push({
      model: 'bk_bike_identifier',
      id: identifierData._id,
    });
    updates.updates.push({
      _id: identifierData._id,
      $set: identifierUpdate,
    });
  }
  await transaction.findAndLockEntity(lockEntities);


  await transaction.commit(updates);
  // this.exec({
  //   c: 'ebike/stock/afterUpdate',
  //   params: {
  //     id: stock._id
  //   }
  // })
};

module.exports = injectTransaction(exports, 'ebike.stock.update');
