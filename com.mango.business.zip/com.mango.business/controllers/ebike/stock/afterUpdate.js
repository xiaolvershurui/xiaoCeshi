const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const ODOrder = require('../../../services/database/order/order');
const BKBox = require('../../../services/database/ebike/box');
const ssKeyTargetInDay = require('../../../services/database/statistic/ssKeyTargetInDay');
const BKStock = require('../../../services/database/ebike/stock');
const { judgement } = require('xx-utils');
const constants = require('../../../com.mango.common/settings/constants');
const SSOfflineTime = require('../../../services/database/statistic/offlineTime');
const SSWakeTaskInDay = require('../../../services/database/statistic/wakeTaskInDay');
const dingRobot = require('../../../services/dingRobot');
const _recordStockInfoInDay = require('./_recordStockInfoInDay');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function({ id }) {
  const stock = await BKStock.findById({
    id,
    selector: [
      'updatedAt enable isOnline number.custom region style invalidReasons inspector',
      'powerUnlink state battery.isNoPower noGpsLocation isFree',
      'locate outsideRegion location.distanceWithRegionPath record.mileageInAll',
      'insideProhibitedArea taskGroup matchTaskGroupAt notFindRecords hasFind',
      'hasTask taskList sim.powerOn battery.voltage battery.isLowPower battery.id',
      'battery.isLowPowerWarning battery.isVeryLowPowerWarning latestUsedAt latestMovedAt latestFoundSucceedAt',
      'location.lngLat location.address location.intersectInspectionArea manualAssignTask signal',
      'battery.voltage lockDiscount discountRate box speed latestIllegalSpeedAt',
    ].join(' '),
    populateSelector: {
      region: 'enable name',
      style: 'enable',
      'battery.id': 'QRCode',
    },
  });
  const isNoPower = stock.battery.isNoPower;
  const stockUpdate = {};
  const now = new Date();
  const yesterday = '1 day'.before(now);
  const prevInvalidReasons = stock.invalidReasons;
  let isValid = true;
  let invalidReasons = [];
  let order;
  if (!stock.enable) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆未启用);
  }
  if (!stock.region || !stock.region.enable) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.大区未启用);
  }
  if (!stock.style || !stock.style.enable) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车型未启用);
  }
  if (!stock.isOnline) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆设备离线);
  }
  if (stock.powerUnlink) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆断电);
  }
  if (![constants.BK_STATE.完好, constants.BK_STATE.损坏可租].includes(stock.state)) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆损坏);
  }
  if (stock.battery.isLowPower) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆低电);
  }
  if (stock.noGpsLocation) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆无定位);
  }
  let canPutOn = isValid;
  if (stock.locate !== constants.BK_LOCATE.仓库) {
    canPutOn = false;
  }
  if (stock.locate === constants.BK_LOCATE.丢失) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆已丢失);
  } else if (stock.locate === constants.BK_LOCATE.疑似丢失) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆疑似丢失);
  } else if (stock.locate === constants.BK_LOCATE.在租) {
    if (stock.box) {
      order = await ODOrder.findProcessingByBox({ box: stock.box._id, selector: 'abnormalOrder updatedAt lock' });
    }
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆正在被租用);
  } else if (stock.locate === constants.BK_LOCATE.扣押) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆被扣);
  } else if (stock.locate === constants.BK_LOCATE.待拖回) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆待拖回);
  } else if (stock.locate !== constants.BK_LOCATE.空闲) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆未投放);
  }
  let isFreeValid = isValid;
  let isFree = false;
  if (stock.outsideRegion) {
    if (isFreeValid && stock.location.distanceWithRegionPath >= constants.BK_FREE_DISTANCE_OUTSIDE_REGION) {
      isFree = true;
    }
    if (!isFree) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆在围栏外);
    }
  }
  if (stock.insideProhibitedArea) {
    if (isFreeValid) isFree = true;
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆在禁行区);
  }

  if (stock.locate === constants.BK_LOCATE.预约) {
    isValid = false;
    invalidReasons.push(constants.BK_INVALID_REASON.车辆被预约);
  }

  invalidReasons = invalidReasons.map(code => prevInvalidReasons.search({ code }) || { issuedAt: now, code });
  // 车辆每日可用时间统计
  this.exec({
    c: 'statistic/stockInDay/trigger',
    params: {
      stock: stock._id,
      isValid,
      isRenting: stock.locate === constants.BK_LOCATE.在租,
      mileageInAll: stock.record.mileageInAll,
      isOnline: stock.isOnline,
    },
  }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.stockInDayTrigger'));
  stockUpdate['isValid'] = isValid;
  stockUpdate['invalidReasons'] = invalidReasons;
  stockUpdate['canPutOn'] = canPutOn;
  stockUpdate['isFree'] = isFree;
  // 推导巡检任务
  let matchTaskGroupAt = stock.matchTaskGroupAt || now;
  const prevTaskList = stock.taskList || [];
  let hasTask = false;
  let taskList = [];
  let taskGroups = [];
  const addTask = code => {
    hasTask = true;
    if (code === constants.BK_TASK_TYPE.离线复活) {
      taskList.push({ issuedAt: now, code });
    } else {
      taskList.push(prevTaskList.search({ code }) || { issuedAt: now, code });
    }
    taskGroups.push(constants.BK_GROUP_OF_TASK[code]);
  };
  // 电池编号核实任务
  if (stock && stock.battery && stock.battery.id && /^占/.test(stock.battery.id.QRCode)) addTask(constants.BK_TASK_TYPE.电池编号核实);
  // 去向任务
  if (stock.locate === constants.BK_LOCATE.待拖回) addTask(constants.BK_TASK_TYPE.待拖回);
  else if (stock.locate === constants.BK_LOCATE.调度) addTask(constants.BK_TASK_TYPE.调度中);
  else if (stock.locate === constants.BK_LOCATE.扣押) addTask(constants.BK_TASK_TYPE.被扣押);
  else if (stock.canPutOn) addTask(constants.BK_TASK_TYPE.待投放);
  // 未找到 之前无定位 现在有定位 不推导
  if (!stock.hasFind && !(prevTaskList.search({ code: constants.BK_TASK_TYPE.无定位 }) && !stock.noGpsLocation)) {
    if (stock.notFindRecords.find(v => v.finder.type === constants.AC_OPERATOR_TYPE.高手)) {
      addTask(constants.BK_TASK_TYPE.高手未找到);
    } else if (stock.notFindRecords.find(v => v.finder.type === constants.AC_OPERATOR_TYPE.白班)) {
      addTask(constants.BK_TASK_TYPE.白班未找到);
      // 生成白班难寻记录
      let operator;
      stock.notFindRecords.forEach(v => {
        if (v.finder.type === constants.AC_OPERATOR_TYPE.白班) {
          operator = v.finder.id;
          return false;
        }
      });
      if (operator) {
        this.exec({
          c: 'statistic/dayNoFound/create',
          params: {
            stock: stock._id,
            operator,
          },
        }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.dayNoFoundCreate'));
      }
    } else if (stock.notFindRecords.find(v => v.failedReason === constants.RC_STOCK_OP_FIND_FAILED_REASON.所在区域不能进入)) {
      // 增加无法进入未找到任务
      addTask(constants.BK_TASK_TYPE.无法进入未找到);
    } else {
      addTask(constants.BK_TASK_TYPE.司机未找到);
      // 生成司机难寻记录
      let operator;
      stock.notFindRecords.forEach(v => {
        if (v.finder.type === constants.AC_OPERATOR_TYPE.司机) {
          operator = v.finder.id;
          return false;
        }
      });
      if (operator) {
        this.exec({
          c: 'statistic/driverNoFound/create',
          params: {
            stock: stock._id,
            operator,
          },
        }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.driverNoFoundCreate'));
      }
    }
  }
  const prevHasOfflineTask = [
    constants.BK_TASK_TYPE.一天内真离线,
    constants.BK_TASK_TYPE.超一天真离线,
    constants.BK_TASK_TYPE.一天内疑似离线,
    constants.BK_TASK_TYPE.超一天疑似离线,
    constants.BK_TASK_TYPE.高压离线,
  ].some(code => {
    return !!prevTaskList.search({ code });
  });
  if (stock.isOnline && prevHasOfflineTask) {
    if (!stock.location) {
      stock.location = {};
    }
    SSOfflineTime.create({
      stock: stock._id,
      stockNo: stock.number.custom,
      type: constants.SS_OFFLINE_TIME.上线,
      location: {
        lngLat: stock.location && stock.location.lngLat,
        address: stock.location && stock.location.address,
      },
      locate: stock.locate,
      voltage: stock.battery.voltage,
      time: new Date(),
    });
  }
  // 离线
  if (!stock.isOnline) {
    // 记录离线信息
    SSOfflineTime.create({
      stock: stock._id,
      stockNo: stock.number.custom,
      type: constants.SS_OFFLINE_TIME.下线,
      location: {
        lngLat: stock.location && stock.location.lngLat,
        address: stock.location && stock.location.address,
      },
      locate: stock.locate,
      voltage: stock.battery.voltage,
      time: new Date(),
    });
    if (stock.sim && !stock.sim.powerOn) { // 不在线 sim卡关机
      const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内真离线 });
      const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天真离线 });
      if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
        addTask(constants.BK_TASK_TYPE.超一天真离线);
      } else {
        addTask(constants.BK_TASK_TYPE.一天内真离线);
      }
    } else if (stock.battery.isNoPower) {
      const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内疑似离线 });
      const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天疑似离线 });
      if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
        addTask(constants.BK_TASK_TYPE.超一天疑似离线);
      } else {
        addTask(constants.BK_TASK_TYPE.一天内疑似离线);
      }
    } else {
      addTask(constants.BK_TASK_TYPE.高压离线);
    }
    if (!prevHasOfflineTask) {
      this.exec({
        c: 'statistic/offlineStock/trigger',
        params: {
          locate: stock.locate,
          region: stock.region._id,
          isOnline: stock.isOnline,
          simPowerOn: stock.sim.powerOn,
          isNoPower,
          stock: stock._id,
          signal: stock.signal,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.offlineStockTrigger'));
      this.exec({
        c: 'statistic/noPowerStock/updateOfflineDate',
        params: {
          locate: stock.locate,
          simPowerOn: stock.sim.powerOn,
          isNoPower,
          isOnline: stock.isOnline,
          stock: stock._id,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.noPowerStockUpdateOfflineDate'));
    }
  }

// 扫码车
  if (stock.latestScannedAt) {
    if ([constants.BK_LOCATE.丢失, constants.BK_LOCATE.疑似丢失].includes(stock.locate)) {
      const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内丢失扫码车 });
      const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天丢失扫码车 });
      if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
        addTask(constants.BK_TASK_TYPE.超一天丢失扫码车);
      } else {
        addTask(constants.BK_TASK_TYPE.一天内丢失扫码车);
      }
    } else if (!stock.isOnline && (!stock.sim.powerOn || stock.battery.isNoPower)) {
      const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内离线扫码车 });
      const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天离线扫码车 });
      if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
        addTask(constants.BK_TASK_TYPE.超一天离线扫码车);
      } else {
        addTask(constants.BK_TASK_TYPE.一天内离线扫码车);
      }
    } else if (stock.noGpsLocation) {
      const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内无定位扫码车 });
      const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天无定位扫码车 });
      if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
        addTask(constants.BK_TASK_TYPE.超一天无定位扫码车);
      } else {
        addTask(constants.BK_TASK_TYPE.一天内无定位扫码车);
      }
    }
  }
// 换电
  if (stock.battery.isNoPower) {
    addTask(constants.BK_TASK_TYPE.零电);
    if (stock.style._id === '1706241658006' && stock.region._id === '1703152031003' && [constants.BK_LOCATE.空闲, constants.BK_LOCATE.预约, constants.BK_LOCATE.在租].includes(stock.locate)) {
      // 产生零电任务
      this.exec({
        c: 'statistic/noPowerStock/trigger',
        params: {
          locate: stock.locate,
          stock: stock._id,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.noPowerStockTrigger'));
    }
  } else if (stock.battery.voltage < 41) {
    addTask(constants.BK_TASK_TYPE.困难换电);
  } else if (stock.battery.isLowPower) {
    addTask(constants.BK_TASK_TYPE.低电);
  } else if (stock.battery.isVeryLowPowerWarning) {
    addTask(constants.BK_TASK_TYPE.低压预警);
  } else if (stock.battery.isLowPowerWarning) {
    addTask(constants.BK_TASK_TYPE.高压预警);
  }
// 断电
  if (stock.powerUnlink) {
    if (stock.battery.voltage >= 41) {
      addTask(constants.BK_TASK_TYPE.被盗断电);
    } else {
      addTask(constants.BK_TASK_TYPE.零电断电);
    }
    if (stock.style._id === '1706241658006' && stock.region._id === '1703152031003' && [constants.BK_LOCATE.空闲, constants.BK_LOCATE.预约, constants.BK_LOCATE.在租].includes(stock.locate)) {
      this.exec({
        c: 'statistic/noPowerStock/updatePowerOffDate',
        params: {
          locate: stock.locate,
          simPowerOn: stock.sim.powerOn,
          isNoPower,
          isOnline: stock.isOnline,
          stock: stock._id,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.noPowerStockUpdatePowerOffDate'));
    }
  }
// 无定位
  if (stock.noGpsLocation) {
    addTask(constants.BK_TASK_TYPE.无定位);
  }
  if (stock.style._id === '1706241658006' && stock.region._id === '1703152031003' && [constants.BK_LOCATE.空闲, constants.BK_LOCATE.预约, constants.BK_LOCATE.在租].includes(stock.locate)) {
    // 清除零电统计
    if (stock.battery.voltage > constants.BK_LOW_POWER_WARNING_VOLTAGE
      && !stock.powerUnlink
      && [constants.BK_LOCATE.空闲, constants.BK_LOCATE.在租, constants.BK_LOCATE.预约].includes(stock.locate)) {
      this.exec({
        c: 'statistic/noPowerStock/remove',
        params: {
          stock: stock._id,
        },
      }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.noPowerStockRemove'));
    }
  }
// 超速
  if (stock.latestIllegalSpeedAt && stock.locate === constants.BK_LOCATE.空闲) {
    addTask(constants.BK_TASK_TYPE.空闲超速);
  }
// 损坏
  if ([constants.BK_STATE.损坏不可租, constants.BK_STATE.报废].includes(stock.state)) {
    addTask(constants.BK_TASK_TYPE.损坏不可租);
  } else if (stock.state === constants.BK_STATE.损坏可租) {
    addTask(constants.BK_TASK_TYPE.损坏可租);
  }
// 唤醒
  let latestWakedUpAt = stock.latestUsedAt;
  // 判断是用户处理还是巡检处理
  let handleByUser = true;
  if (!latestWakedUpAt || (stock.latestMovedAt && stock.latestMovedAt.is.over(latestWakedUpAt))) {
    latestWakedUpAt = stock.latestMovedAt;
    handleByUser = false;
  }
  const randomDiscount = Math.random() > 0.5;
  let willDiscount = false;
  if ([constants.BK_LOCATE.预约, constants.BK_LOCATE.空闲].includes(stock.locate)) {
    if (!latestWakedUpAt || '4 days'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.四天未唤醒);
      willDiscount = true;
    } else if (!latestWakedUpAt || '2 days'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.两天未唤醒);
      willDiscount = true;
    } else if (!latestWakedUpAt || '1 day'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.一天未唤醒);
      const ssWakeTaskInDay = await SSWakeTaskInDay.findOne({ query: { region: stock.region._id, date: 'today'.beginning }, selector: 'updatedAt totalCount stocks' });
      if (ssWakeTaskInDay && !ssWakeTaskInDay.stocks.includes(id)) {
        SSWakeTaskInDay.update({
          id: ssWakeTaskInDay._id,
          updatedAt: ssWakeTaskInDay.updatedAt,
          data: {
            totalCount: ssWakeTaskInDay.totalCount + 1,
          },
          arrayOp: {
            $addToSet: {
              stocks: id,
            },
          },
        });
      }
      willDiscount = true;
    }
  }

  if (!stock.lockDiscount && willDiscount) {
    stockUpdate['lockDiscount'] = true;
    if (randomDiscount) stockUpdate['discountRate'] = 0.8;
  }

  if (!stock.latestFoundSucceedAt || '4 days'.before(now).is.over(stock.latestFoundSucceedAt)) {
    addTask(constants.BK_TASK_TYPE.四天未巡检);
  }
// 禁行区
  if (stock.insideProhibitedArea) {
    addTask(constants.BK_TASK_TYPE.禁行区);
  }
// 围栏外
  if (stock.outsideRegion) {
    if (stock.isFree) {
      addTask(constants.BK_TASK_TYPE.围栏外免单);
    } else {
      addTask(constants.BK_TASK_TYPE.围栏外非免单);
    }
  }
// 禁停区
  if (stock.insideForbiddenArea) {
    addTask(constants.BK_TASK_TYPE.禁停区);
  }
// 复活任务
  if (prevTaskList.search({ code: constants.BK_TASK_TYPE.高手未找到 }) && stock.locate === constants.BK_LOCATE.空闲 && ((prevHasOfflineTask && stock.isOnline) || prevTaskList.search({ code: constants.BK_TASK_TYPE.离线复活 }))) {
    addTask(constants.BK_TASK_TYPE.离线复活);
  }
// 将任务组排序，获得最高优先级组作为最终任务组
  taskGroups = taskGroups.sort((t1, t2) => constants.BK_TASK_GROUP_RATE[t2] - constants.BK_TASK_GROUP_RATE[t1]);
  const taskGroup = taskGroups.length > 0 ? taskGroups[0] : null;
// 将任务排序, 最高任务存下来
  taskList = taskList.sort((t1, t2) => constants.BK_TASK_TYPE_RATE[t2.code] - constants.BK_TASK_TYPE_RATE[t1.code]);
  stockUpdate['highestTask'] = taskList.length > 0 ? taskList[0].code : null;
// 计算任务权重
  let taskRate = 0;
  if (judgement.isNotEmpty(taskGroup) && judgement.isNotEmpty(constants.BK_COUNT_OF_GROUP[taskGroup])) {
    const taskCount = taskGroups.filter(group => group === taskGroup).length;
    taskRate = Math.round((constants.BK_TASK_GROUP_RATE[taskGroup] + (taskCount / constants.BK_COUNT_OF_GROUP[taskGroup])) * 100);
  }
  if (stock.taskGroup !== taskGroup) {
    matchTaskGroupAt = now;
  }
  stockUpdate['taskList'] = taskList;
  stockUpdate['hasTask'] = hasTask;
  stockUpdate['taskGroup'] = taskGroup;
  stockUpdate['taskRate'] = taskRate;
  stockUpdate['matchTaskGroupAt'] = matchTaskGroupAt;
// 分配巡检人员
  const releaseInspector = _ => {
    stockUpdate['inspector'] = null;
    stockUpdate['inspectorName'] = null;
    stockUpdate['inspectorTel'] = null;
    stockUpdate['manualAssignTask'] = false;
  };
  const distributeInspector = async _ => {
    // 在租在库丢失不分配，但是丢失扫码车要分配
    if ([
        constants.BK_LOCATE.仓库,
        constants.BK_LOCATE.在租,
        constants.BK_LOCATE.丢失,
        constants.BK_LOCATE.疑似丢失,
        constants.BK_LOCATE.内部使用,
        constants.BK_LOCATE.其他占用,
      ].includes(stock.locate)
      && !taskList.includes(constants.BK_TASK_TYPE.待投放)
      && !taskList.includes(constants.BK_TASK_TYPE.一天内丢失扫码车)
      && !taskList.includes(constants.BK_TASK_TYPE.超一天丢失扫码车)
    ) return;
    // 搜索最近的符合条件的巡检人员
    const inspector = await ACOperator.findMatchedInspector({
      lngLat: stock.location.lngLat,
      region: stock.region._id,
      taskGroup,
      inspectionArea: stock.location.intersectInspectionArea,
    });
    if (inspector) {
      stockUpdate['inspector'] = inspector.id;
      stockUpdate['inspectorName'] = inspector.name;
      stockUpdate['inspectorTel'] = inspector.tel;
    }
  };
// 在租、在库、无任务则强制取消分配
  if (([
      constants.BK_LOCATE.在租,
      constants.BK_LOCATE.仓库,
    ].includes(stock.locate) || !hasTask) && stock.inspector) {
    releaseInspector();
  } else if (!stock.manualAssignTask && hasTask && stock.location && stock.location.lngLat) { // 产生巡检任务，进行分配
    // 手动分配标记的任务不进行自动分配
    if (!stock.inspector) {
      await distributeInspector();
    } else {
      const operator = await ACOperator.findByUser({
        user: stock.inspector,
        selector: 'acceptTaskGroups inspectionAreas',
        cache: {
          enable: true,
        },
      });
      // const operatorLowestTaskGroup = operator.acceptTaskGroups.sort((t1, t2) => constants.BK_TASK_GROUP_RATE[t1] - constants.BK_TASK_GROUP_RATE[t2])[0];
      // const invalidTaskGroup = judgement.isNotEmpty(operatorLowestTaskGroup) && (constants.BK_TASK_GROUP_RATE[operatorLowestTaskGroup] > constants.BK_TASK_GROUP_RATE[taskGroup]);
      const invalidInspectionArea = !operator.inspectionAreas.search({ _id: stock.location.intersectInspectionArea });
      const invalidTaskGroup = !operator.acceptTaskGroups.includes(taskGroup);
      if ((invalidInspectionArea || invalidTaskGroup) && taskGroup !== constants.BK_TASK_GROUP.调度组) {
        releaseInspector();
        distributeInspector();
      }
    }
  }

  const hasUnWakeTask = taskList => {
    return taskList.search({ code: constants.BK_TASK_TYPE.一天未唤醒 }) || taskList.search({ code: constants.BK_TASK_TYPE.两天未唤醒 }) || taskList.search({ code: constants.BK_TASK_TYPE.四天未唤醒 });
  };
  if (!hasUnWakeTask(taskList)) {
    stockUpdate['lockDiscount'] = false;
    stockUpdate['discountRate'] = 1;
  }
  // 异常订单判断更新
  const orderUpdate = {};
  orderUpdate['abnormalOrder.lowSpeedStartedAt'] = null;
  if (order) {
    const box = await BKBox.findByIdAndGenerate({ deviceId: stock.box._id, selector: 'location.lastGpsLocatedAt' });
    const isLocked = order.lock && order.lock.isLocked;
    if (stock.speed < 2 && (!isLocked || (isLocked && Date.now() > new Date(order.lock.expires).getTime()))) {
      const now = Date.now();
      order.abnormalOrder = order.abnormalOrder || {};
      if (order.abnormalOrder.lowSpeedStartedAt) {
        orderUpdate['abnormalOrder.lowSpeedTime'] = parseInt((now - new Date(order.abnormalOrder.lowSpeedStartedAt).getTime()) / (60 * 1000));
        orderUpdate['abnormalOrder.lowSpeedStartedAt'] = order.abnormalOrder.lowSpeedStartedAt;
      } else {
        orderUpdate['abnormalOrder.lowSpeedTime'] = 0;
        orderUpdate['abnormalOrder.lowSpeedStartedAt'] = new Date();
      }
      // 持续20分钟 速度小于2km/h 并且1分钟内有定位 判断为长时间无异动 安全结束
      if (orderUpdate['abnormalOrder.lowSpeedTime'] > 15 && ((now - new Date(box.location.lastGpsLocatedAt).getTime()) / (60 * 1000) <= 1)) {
        this.exec({
          c: 'order/order/safeFinish',
          params: {
            id: order._id,
          },
        }).catch(error => this.emit('error', error, 'controller.ebike.stock.afterUpdate.safeFinish'));
      }
    }
    ODOrder.update({
      id: order._id,
      updatedAt: order.updatedAt,
      data: orderUpdate,
    });
  }

  // 异步更新车辆信息
  BKStock.update({
    id: stock._id,
    updatedAt: stock.updatedAt,
    data: stockUpdate,
  });
  // 发送钉钉消息
  const stockLocates = [
    constants.BK_LOCATE.空闲,
    constants.BK_LOCATE.预约,
    constants.BK_LOCATE.在租,
    constants.BK_LOCATE.待拖回,
    constants.BK_LOCATE.调度,
  ];
  const result = [];
  const dangerousScan = [];
  stockUpdate.taskList.forEach(task => {
    // if ((task.code === constants.BK_TASK_TYPE.空闲超速 || (stockLocates.includes(stock.locate) && task.code === constants.BK_TASK_TYPE.被盗断电)) && !stock.taskList.search({ code: task.code })) result.push({
    if (task.code === constants.BK_TASK_TYPE.空闲超速) result.push({
      region: stock.region.name,
      bikeId: stock.number.custom,
      taskType: constants.BK_TASK_TYPE_MAP[task.code],
      speed: stock.speed,
    });
    if ([constants.BK_TASK_TYPE.一天内离线扫码车, constants.BK_TASK_TYPE.超一天离线扫码车, constants.BK_TASK_TYPE.一天内无定位扫码车, constants.BK_TASK_TYPE.超一天无定位扫码车, constants.BK_TASK_TYPE.一天内丢失扫码车, constants.BK_TASK_TYPE.超一天丢失扫码车].includes(task.code)) {
      dangerousScan.push({
        region: stock.region.name,
        number: stock.number.custom,
        taskType: constants.BK_TASK_TYPE_MAP[task.code],
      });
    }
  });
  if (result.length) {
    dingRobot.sendEmergencyMonitoring(result);
  }
  if (dangerousScan.length) {
    dingRobot.sendScanMonitoring(dangerousScan);
  }

  if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.在租, constants.BK_LOCATE.预约].includes(stock.locate)) {
    _recordStockInfoInDay({
      region: stock.region && stock.region._id,
      stockId: stock._id,
      stockNo: stock.number.custom,
      voltage: stock.battery.voltage,
      powerUnlink: stock.powerUnlink,
      isOnline: stock.isOnline,
    }).catch(error => console.error(error, 'RECORD_STOCK_INFO_IN_DAY'));
  }
  if (prevTaskList.search({ code: constants.BK_TASK_TYPE.一天未唤醒 }) && !taskList.search({ code: constants.BK_TASK_TYPE.一天未唤醒 }) && stock.locate === constants.BK_LOCATE.调度) {
    // 解除了一天未唤醒任务
    const keyTarget = await ssKeyTargetInDay.findOne({
      query: {
        region: stock.region._id,
        date: now.getHours() > 6 ? 'today'.beginning : '1 day'.before('today'.beginning),
      },
      selector: 'updatedAt unWakeUpDispatched',
    });
    if (keyTarget) {
      try {
        const unWakeUpDispatched = keyTarget.unWakeUpDispatched ? (keyTarget.unWakeUpDispatched + 1) : 1;
        await ssKeyTargetInDay.update({
          id: keyTarget._id,
          updatedAt: keyTarget.updatedAt,
          data: {
            unWakeUpDispatched,
          },
        });
      } catch (error) {
        //
      }
    }
  }


  // 车辆被唤醒 更新对应日期大区的记录
  if (hasUnWakeTask(prevTaskList) && !hasUnWakeTask(taskList)) {
    this.exec({
      c: 'statistic/wakeTaskInDay/trigger',
      params: {
        issuedAt: new Date(hasUnWakeTask(prevTaskList).issuedAt),
        handleByUser,
        region: stock.region._id,
        stock: id,
        discountRate: stock.discountRate,
      },
    });
  }
};
