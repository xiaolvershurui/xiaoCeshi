const BKStock = require('../../../services/database/ebike/stock');
const ACUser = require('../../../services/database/account/user');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const injectTransaction = require('../../../utils/injectTransaction');
const validators = require('../../../com.mango.common/settings/validators');
const ObjectId = require('objectid');

exports.validate = Joi.object({
  number: Joi.string().required(),
  operator: Joi.string().required(),
  photo: Joi.string(),
  reason: Joi.string(),
}).unknown();

exports.handler = async function ({ number, operator, reason, photo }, tid, transaction) {
  const acOperator = await ACUser.findById({ id: operator, selector: 'auth.tel cert.name profile.avator' });
  const stock = await BKStock.findByNumber({ number, selector: 'stockNo region state locate style number.custom' });
  if(!stock) throw new NotFoundError('不存在该车辆');
  if (stock.locate !== constants.BK_LOCATE.仓库) throw new BadRequestError('车辆不在库无法设置为报废');
  if (stock.state === constants.BK_STATE.报废) throw new BadRequestError('车辆已报废');
  await transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'bk_stock',
      id: stock._id,
    }, {
      model: 'rc_stock_op'
    }, {
      model: 'bk_damage'
    }]
  });
  const rcStockOpId = await ObjectId();
  const bkDamageId = await ObjectId();
  await transaction.commit({
    tid,
    updates: [
      {
        _id: stock._id,
        $set: {
          state: constants.BK_STATE.报废
        }
      },
      {
        _id: rcStockOpId,
        stock: stock._id,
        stockNo: stock.number.custom,
        region: stock.region._id,
        style: stock.style._id,
        type: constants.RC_STOCK_OP_TYPE.添加损坏,
        description: `添加了损坏记录, 设置为报废`,
        operator,
        addDamage: {
          id: bkDamageId,
          description: reason,
          photo,
          prevStockState: stock.state,
          nextStockState: constants.BK_STATE.报废
        },
        operatorName: acOperator.cert.name,
        operatorTel: acOperator.auth.tel,
        operatedAt: new Date()
      }, {
        _id: bkDamageId,
        stock: stock._id,
        description: reason || '无',
        photo,
        submitter: operator,
        recordedAt: new Date(),
        stockState: constants.BK_STATE.报废
      }
    ]
  })
};

module.exports = injectTransaction(exports, 'ebike.stock.setScrap');