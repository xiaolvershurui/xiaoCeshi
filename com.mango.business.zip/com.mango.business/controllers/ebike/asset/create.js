const BKAsset = require('../../../services/database/ebike/asset');
const STAsset = require('../../../services/database/setting/asset');
const OPRegion = require('../../../services/database/operation/region');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  region: Joi.string().required(),
  station: Joi.string().required(),
  asset: Joi.string().required(),
  code: Joi.string().required(),
  totalCount: Joi.number().default(0),
  intactCount: Joi.number().default(0),
  damageCount: Joi.number().default(0),
  repairCount: Joi.number().default(0),
  scrapCount: Joi.number().default(0),
  operator: Joi.string(),
  group: Joi.number().required()
}).unknown();
exports.handler = async function ({ region, station, asset, code, totalCount, intactCount, damageCount, repairCount, scrapCount, operator, group }) {
  const sta = await OPBatteryStation.findById({ id: station, selector: '_id name' });
  if (!sta) throw new NotFoundError(`不存在仓库${station}`);
  const reg = await OPRegion.findById({ id: region, selector: '_id name' });
  if (!reg) throw new NotFoundError(`不存在大区${region}`);

  const stations = await OPBatteryStation.find({ query: {}, selector: '_id name region' });
  const stationMapRegion = stations.reduce((memo, item) => {
    memo[item._id] = item.region._id;
    return memo;
  }, {});
  const stAsset = await STAsset.findById({ id: asset, selector: '_id code' });
  if (!stAsset) throw new NotFoundError(`配件：${asset}未录入`);
  if (stAsset.code !== code) throw new BadRequestError(`配件二维码：${code}不存在`);

  if (stationMapRegion[station] !== region) throw new BadRequestError(`${reg.name}大区下未找到${sta.name}仓库`);
  return await BKAsset.create({
    region,
    station,
    asset,
    code,
    totalCount,
    intactCount,
    damageCount,
    repairCount,
    scrapCount,
    operator,
    group
  })
};