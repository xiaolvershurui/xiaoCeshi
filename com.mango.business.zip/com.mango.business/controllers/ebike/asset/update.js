const BKAsset = require('../../../services/database/ebike/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  id: Joi.string().required(),
  updatedAt: Joi.date(),
  data: Joi.object({
    totalCount: Joi.number(),
    intactCount: Joi.number(),
    damageCount: Joi.number(),
    repairCount: Joi.number(),
    scrapCount: Joi.number(),
    purchaseCount: Joi.number()
  })
}).unknown();
exports.handler = async function ({ id, updatedAt, data }) {
  const bkAsset = await BKAsset.findById({ id, selector: '_id purchaseCount needPurchase' });

  if (!bkAsset) throw new NotFoundError(`该配件记录不存在：${id}`);
  if (data.purchaseCount) {
    if (data.purchaseCount > bkAsset.purchaseCount) {
      data.needPurchase = true
    }else {
      data.needPurchase = false
    }
  }
  return await BKAsset.update({
    id,
    updatedAt: bkAsset.updatedAt,
    data
  })
};