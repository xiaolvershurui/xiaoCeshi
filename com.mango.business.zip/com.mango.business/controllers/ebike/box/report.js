const BKBox = require('../../../services/database/ebike/box');
const BKBattery = require('../../../services/database/ebike/battery');
const BKStock = require('../../../services/database/ebike/stock');
const OPStyle = require('../../../services/database/operation/style');
const OPRegion = require('../../../services/database/operation/region');
const OPPolygon = require('../../../services/database/operation/polygon');
const ODOrder = require('../../../services/database/order/order');
const STDetainedArea = require('../../../services/database/setting/detainedArea');
const ACOperator = require('../../../services/database/account/operator');
const Joi = require('poolishark').Joi;
const { judgement } = require('xx-utils');
const coordtransform = require('coordtransform');
const geolib = require('geolib');
const constants = require('../../../com.mango.common/settings/constants');
const calculateDistanceBetweenPointAndPolygon = require('../../../utils/calculateDistanceBetweenPointAndPolygon');
const validators = require('../../../com.mango.common/settings/validators');
const IoT = require('../../../services/iot');
const OTSStockPoint = require('../../../services/ots/stockPoint');
const OTSBatteryInStockPoint = require('../../../services/ots/batteryInStockPoint');
const Core = require('../../../services/core/shark');

const powerFunc = voltage => {
  return parseFloat(Math.min(1, Math.max(0, 0.09625 * voltage - 4.1975)).toFixed(4));
};

const resistPower = 0.1;

const calculatePower = async ({ dataSource, styleId, voltage }) => {
  let newPower = 0;
  let truePower = 0;
  const style = await OPStyle.findById({
    id: styleId,
    selector: 'maxMileage',
    cache: {
      enable: true,
    },
  });
  if (!style) return {};
  if (dataSource === constants.BK_BOX_DATA_SOURCE.小安宝) {
    truePower = powerFunc(voltage);
    newPower = Math.max(powerFunc(voltage) - resistPower, 0);
  } else {
    return this.emit('error', new Error(`暂不支持该数据源：${dataSource}`), 'controller.ebike.box.report.calculatePower');
  }
  return {
    power: newPower,
    truePower,
    mileage: Math.floor(style.maxMileage * newPower),
    trueMileage: Math.floor(style.maxMileage * truePower),
  };
};

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
  ds: Joi.number().required(),
  status: Joi.object(),
  gpsLocation: Joi.object({
    lngLat: validators.location,
    speed: Joi.number(),
    direction: Joi.number(),
    time: Joi.date(),
    transformed: Joi.boolean(),
  }).default({}).unknown(),
  cellLocation: Joi.object(),
  nId: Joi.string().empty('').allow(null),
  appVersion: Joi.string().empty('').allow(null),
}).unknown();
exports.handler = async function(data) {
  // find box.
  const box = await BKBox.findByIdAndGenerate({
    deviceId: data.deviceId,
    dataSource: data.ds,
    selector: 'updatedAt snappedAt voltage ecoMode powerUnlink accOn lockOn wheelLockOn batteryLockOn wheelRand location.lastLngLat latestSentCommandAt sim.imsi signal driver mileageInAll timeInAll',
  });
  if (!box) return;
  // find stock.
  const stock = await BKStock.findByBox({
    box: data.deviceId,
    selector: 'updatedAt record battery wrongControl powerUnlink accOn lockOn wheelLockOn batteryLockOn wheelRand locate region style location lastAccOffedAt inDetainedAt alt gpsSignal number.custom lastOutParkingLotTime',
  });

  const now = new Date();
  // spread params
  let {
    accOn = box.accOn, lockOn = box.lockOn,
    wheelLockOn = box.wheelLockOn, batteryLockOn = box.batteryLockOn,
    powerUnlink = box.powerUnlink, voltage = box.voltage,
    signal = box.signal, wheelRand = box.wheelRand, ecoMode = box.ecoMode,
  } = data.status;
  let { lngLat, speed, direction, time = now, transformed } = data.gpsLocation;

  // 位置点快照
  const stockPoint = {
    region: stock && stock.region && stock.region._id,
    stock: stock && stock._id,
    style: stock && stock.style && stock.style._id,
    box: box._id,
    dataSource: data.ds,
    isOnline: true,
    gps: {
      gpsLngLat: lngLat,
      speed,
      direction,
      alt: stock && stock.alt,
      gpsSignal: stock && stock.gpsSignal,
    },
    extra: {
      voltage,
      signal,
    },
    acc: accOn,
    lock: lockOn,
    batteryLock: batteryLockOn,
    powerUnlink,
    wheelLock: wheelLockOn,
    ecoMode,
    wheelRand,
    time,
    nodeId: data.nId,
    expired: false,
    lastSnappedAt: box.snappedAt,
    appVersion: data.appVersion,
  };
  const boxUpdate = {
    isOnline: true,
    snappedAt: box.snappedAt,
    accOn, lockOn, wheelLockOn, batteryLockOn, powerUnlink,
    voltage, signal, wheelRand,
    'sim.working': true,
    'sim.powerOn': true,
    mileageInAll: box.mileageInAll || (stock && stock.record.mileageInAll),
    timeInAll: box.timeInAll || (stock && stock.record.timeInAll),
  };
  let stockUpdate = {};
  if (stock) {
    stockUpdate = {
      isOnline: true,
      record: {
        mileageInAll: stock.record.mileageInAll,
        timeInAll: stock.record.timeInAll,
        phaseMileage: stock.record.phaseMileage,
      },
      battery: stock.battery,
      location: stock.location,
      latestIllegalSpeedAt: null,
      powerUnlink,
      signal,
      accOn,
      lockOn,
      batteryLockOn,
      wheelLockOn,
      wheelRand,
      speed,
      direction,
      boxAppVersion: data.appVersion,
      'sim.working': true,
      'sim.powerOn': true,
    };
    if (stock.accOn && !accOn) stockUpdate['lastAccOffedAt'] = now;
    else if (!stock.accOn && accOn) stockUpdate['lastAccOffedAt'] = null;
    if (speed >= 40) stockUpdate['latestIllegalSpeedAt'] = now;
    if (box.sim && box.sim.imsi) stockUpdate['sim.imsi'] = box.sim.imsi;
    if (wheelRand) stockUpdate.latestWheelRandAt = now;
    if (stock.battery && stock.battery.id && stock.battery.id._id) {
      // 更新绑定电池的疑似丢失标记
      BKBattery.update({
        id: stock.battery.id._id,
        data: {
          isSuspectedLost: powerUnlink,
        },
      });
    }
  }

  // 节能模式 在Core服务中实现
  // let shouldSetEcoMode = (!stock || stock.locate !== constants.BK_LOCATE.在租) && (voltage <= constants.BK_NO_POWER_VOLTAGE) && !box.driver;
  // if (shouldSetEcoMode && !ecoMode && box._id !== '865067025388755') {
  //   IoT.setEcoMode({ deviceId: box._id, ecoMode: true });
  //   boxUpdate.ecoMode = true;
  //   boxUpdate.setEcoModeAt = now;
  // } else if (!shouldSetEcoMode && ecoMode) {
  //   IoT.setEcoMode({ deviceId: box._id, ecoMode: false });
  //   boxUpdate.ecoMode = false;
  //   boxUpdate.setEcoModeAt = null;
  // }

  if (box.driver) {
    const operator = await ACOperator.findByUser({ user: box.driver, selector: 'isWorking' });
    if (operator && operator.isWorking) {
      IoT.sendCommand({
        deviceId: operator.box,
        command: 'setConfig',
        params: { freq_norm: 5 },
      }).catch(console.error);
    }
  }

  let lastLngLat = box.location.lastLngLat; // 车辆上一次计算使用的经纬度

  // 有卫星定位的情况下
  if (lngLat) {
    stockPoint.gps.gpsLngLat = lngLat;
    lngLat = transformed ? lngLat : coordtransform.wgs84togcj02(lngLat[0], lngLat[1]);
    if (!lastLngLat || lastLngLat.length !== 2) lastLngLat = lngLat;
    stockPoint.lastLngLat = lastLngLat;

    boxUpdate['location.type'] = constants.BK_BOX_LOCATION_TYPE.卫星;
    boxUpdate['location.gpsLngLat'] = lngLat;
    boxUpdate['location.lastGpsLocatedAt'] = time;
    if (stock && !(lngLat[0] === 0 && lngLat[1] === 0) && stock.locate !== constants.BK_LOCATE.扣押) {
      const area = await STDetainedArea.findOneInScope({
        point: lngLat,
        maxDistance: 100,
      });
      if (area) {
        stockUpdate['inDetainedAt'] = stock.inDetainedAt || now;
        // 持续时间大于 1天
        // TODO: 扣押日志
        if (Date.now() - new Date(stockUpdate['inDetainedAt']).getTime() > 24 * 3600 * 1000) {
          stockUpdate['detainedArea'] = area._id;
          stockUpdate['locate'] = constants.BK_LOCATE.扣押;
          // await STDetainedArea.update({
          //   id: area._id,
          //   data: {},
          //   arrayOp: {
          //     $push: {
          //       stocks: stock._id,
          //     },
          //   },
          // });
          const number = stock.number && stock.number.custom;
          await this.exec({
            c: 'ebike/stockDetained/create',
            params: {
              detainedArea: area._id,
              stock: [number],
              reporter: '1',
              operator: '1',
            },
          });
        }
      } else {
        stockUpdate['inDetainedAt'] = null;
      }
    } else {
      stockUpdate['inDetainedAt'] = null;
    }
    // 定位是否合法
    stockPoint.illegalLngLat = Math.abs(lngLat[0]) < 5 && Math.abs(lngLat[1]) < 5;
    // 是否过期
    if (!stockPoint.illegalLngLat) {
      stockPoint.expired = !!(box.snappedAt && box.snappedAt.getTime() > time.getTime());
      //延迟时间
      stockPoint.expires = now.getTime() - time.getTime();
      // 时间戳是未来5分钟后，则认为是异常点，不更新快照时间
      if (stockPoint.expires > -300000 && !stockPoint.expired) {
        boxUpdate.snappedAt = time;
      }
    }
    // 没有过期，则开始计算快照信息
    if (!stockPoint.expired && !stockPoint.illegalLngLat) {
      let lastPhaseLngLat = box.location.lastPhaseLngLat; // 上次计算相位里程用的经纬度

      if (stock) {
        // 计算里程
        stockPoint.mdis = stockPoint.deltaMileage = geolib.getDistance(lngLat, lastLngLat, 0, 3);
        if (stock.accOn && accOn) { // 连续两次电门开，则记录里程
          const lastRecordedAt = box.location.lastGpsLocatedAt || time;
          const deltaTime = (time.getTime() - lastRecordedAt.getTime()).msTo.minute;
          // 计算时速，如果时速或者两点间距离过大，则忽略本次里程
          stockPoint.sampleSpeed = deltaTime === 0 ? 0 : stockPoint.deltaMileage * 0.06 / deltaTime;
          if (stockPoint.sampleSpeed <= 30 && stockPoint.deltaMileage <= 500) {
            boxUpdate.mileageInAll += stockPoint.deltaMileage;
            boxUpdate.timeInAll += deltaTime;
            stockUpdate.record.mileageInAll = boxUpdate.mileageInAll;
            stockUpdate.record.timeInAll = boxUpdate.timeInAll;
          } else {
            stockPoint.mdis = 0;
          }
          lastLngLat = lngLat;
        } else {
          lastLngLat = null;
        }
        boxUpdate['location.lastLngLat'] = lastLngLat;
        stockPoint.extra.mileageInAll = stockUpdate.record.mileageInAll;
        stockPoint.extra.timeInAll = stockUpdate.record.timeInAll;

        // 计算相位里程
        if (!lastPhaseLngLat || lastPhaseLngLat.length !== 2) lastPhaseLngLat = lngLat;
        let deltaPhaseMileage = 0;
        const phaseDis = geolib.getDistance(lngLat, lastPhaseLngLat, 0, 3);
        if (speed > 3 || stockPoint.deltaMileage > 50) deltaPhaseMileage = phaseDis;
        lastPhaseLngLat = (_ => {
          if (deltaPhaseMileage > 0) return lngLat;
          else return lastPhaseLngLat;
        })();
        stockUpdate.record.phaseMileage += deltaPhaseMileage;

      }

    }
    stockPoint.gps.lngLat = lngLat;
    stockPoint.gps.locationType = boxUpdate['location.type'];
  }

  const deviceId = box._id;
  // 获取进行中的订单
  let order;
  let region;
  if (stock) {
    const lastOrder = await ODOrder.findLastOne({
      stock: stock._id,
      selector: '_id updatedAt state lease.startTime user lock',
    });
    region = await OPRegion.findById({
      id: stock.region._id,
      selector: 'path changeBatteryVoltage parkingPattern parkingLotRadius',
      cache: {
        enable: true,
      },
    });
    if (lastOrder && (lastOrder.state === constants.OD_ORDER_STATE.租用中)) order = lastOrder;
    // 计算电量
    if (!powerUnlink && judgement.isNotEmpty(voltage)) {
      const { power, truePower, mileage, trueMileage } = await calculatePower.bind(this)({
        dataSource: data.ds,
        voltage,
        styleId: stock.style._id,
      });
      if (judgement.isNotEmpty(power) && !Number.isNaN(power)) {
        const isNoPower = voltage <= constants.BK_NO_POWER_VOLTAGE;
        const isLowPower = voltage <= (stock.wrongControl ? constants.BK_TEMPORARY_LOW_POWER_VOLTATE : constants.BK_LOW_POWER_VOLTAGE);
        const isLowPowerWarning = voltage <= constants.BK_LOW_POWER_WARNING_VOLTAGE;
        // 临时修改 050 低电预警电压为47.97
        const isVeryLowPowerWarning = /^050/.test(stock.number.custom) ? voltage <= 48.1 : (region.changeBatteryVoltage ? (voltage <= region.changeBatteryVoltage) : (voltage <= constants.BK_VERY_LOW_POWER_WARNING_VOLTAGE));
        const isForcePowerOff = voltage <= (stock.wrongControl ? constants.BK_TEMPORARY_FORECE_OFF_VOLTATE : constants.BK_FORCE_POWER_OFF_VOLTAGE);
        const changeToForcePowerOff = !stock.battery.isForcePowerOff && isForcePowerOff;
        const changeToEnoughForcePowerOff = stock.battery.isForcePowerOff && !isForcePowerOff;
        let latestForcePowerOff = stock.battery.latestForcePowerOff;
        if (changeToForcePowerOff) latestForcePowerOff = now;
        else if (changeToEnoughForcePowerOff) latestForcePowerOff = null;
        // 发生电压区间跳跃 并且5分钟内 无订单 则认为是静态电压 更新
        if (!((isLowPower === stock.battery.isLowPower)
            && (isLowPowerWarning === stock.battery.isLowPowerWarning)
            && (isVeryLowPowerWarning === stock.battery.isVeryLowPowerWarning))
          && (!order || (lastOrder && (Date.now() - new Date(lastOrder.lease.endTime).getTime()) > 5 * 60 * 1000))) {
          stockUpdate.battery.isLowPower = isLowPower;
          stockUpdate.battery.isLowPowerWarning = isLowPowerWarning;
          stockUpdate.battery.isVeryLowPowerWarning = isVeryLowPowerWarning;
        }
        stockUpdate.battery.voltage = voltage;
        stockUpdate.battery.power = power;
        stockUpdate.battery.mileage = mileage;
        stockUpdate.battery.isNoPower = isNoPower;
        stockUpdate.battery.isForcePowerOff = isForcePowerOff;
        stockUpdate.battery.latestForcePowerOff = latestForcePowerOff;
        stockUpdate.battery.truePower = truePower;
        stockUpdate.battery.trueMileage = trueMileage;
        if (stock.battery) {
          if (isForcePowerOff && !stock.battery.firstForcePowerOff) {
            stockUpdate.battery.firstForcePowerOff = now;
          } else {
            stockUpdate.battery.firstForcePowerOff = null;
          }
        }
      }
    }

    // 新停车区吸附 修改车辆定位数据同时不能影响里程计算
    try {
      let parkingLot, point;
      if (lngLat && region && [constants.OP_REGION_PARKING_PATTERN.新旧停车区, constants.OP_REGION_PARKING_PATTERN.新停车区].includes(region.parkingPattern)) {
        let ret = await Core.send({
          c: 'operation/parkingLot/triggerIO.s.2',
          params: {
            stockId: stock._id,
            lngLat,
            radius: (region && region.parkingLotRadius) || 10,
          },
        });
        parkingLot = ret.parkingLot;
        point = ret.point;
        // 出了停车区 超过1分钟才更新
        if (!parkingLot) {
          stockUpdate['lastOutParkingLotTime'] = stock.lastOutParkingLotTime || new Date();
          if (Date.now() - new Date(stock.lastOutParkingLotTime).getTime() > 16 * 1000) {
            stockUpdate['parkingLot'] = null;
            // stockUpdate['lastOutParkingLotTime'] = null;
          }
        } else {
          stockUpdate['parkingLot'] = parkingLot;
          if (order) lngLat = point;
        }
      }
    } catch (error) {
      //
    }


    // 无定位
    if (boxUpdate['location.type'] === constants.BK_BOX_LOCATION_TYPE.卫星) {
      stockUpdate.noGpsLocation = false;
      stockUpdate.location = { lngLat, locatedAt: time };
    } else if (!stock.location.locatedAt || '30 minutes'.before(now).is.over(stock.location.locatedAt)) {
      stockUpdate.noGpsLocation = true;
    }
    // 更新车辆位置，没有位置则以上一次位置代替
    if (stockUpdate.location.lngLat) {
      const lngLat = stockUpdate.location.lngLat;
      const intersectRegion = await OPRegion.findIntersect({
        center: lngLat,
        query: { enable: true },
        selector: 'name path',
      });
      stockUpdate.location.distanceWithProhibitedArea = null;
      stockUpdate.location.distanceWithForbiddenArea = 0;
      stockUpdate.location.distanceWithPark = null;
      // 计算与大区，区块相关距离
      // 相交的所有区域
      const intersectPolygons = await OPPolygon.findIntersect({
        center: lngLat,
        query: {
          enable: true,
          isCleaned: false,
        },
        selector: 'name path type location neighborhood matchCount',
      });
      if (intersectRegion) {
        stockUpdate.location.intersectRegion = intersectRegion._id;
        stockUpdate.location.intersectRegionName = intersectRegion.name;
        let intersectPolygon;
        // 相交的禁行区
        const intersectProhibitedArea = intersectPolygons.search({
          type: constants.OP_POLYGON_TYPE.禁行区,
        });
        if (intersectProhibitedArea) {
          // 在禁行区，则报警并计算禁行区距离
          intersectPolygon = intersectProhibitedArea;
          const path = intersectPolygon.path.coordinates[0];
          stockUpdate.location.distanceWithProhibitedArea = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
        } else {
          // 不在禁行区，判断是否有相交停车区
          const intersectPark = intersectPolygons.search({
            type: constants.OP_POLYGON_TYPE.停车区,
          });
          if (intersectPark) {
            // 在停车区，则计算停车区的距离
            intersectPolygon = intersectPark;
            const path = intersectPolygon.path.coordinates[0];
            stockUpdate.location.distanceWithPark = calculateDistanceBetweenPointAndPolygon(path, lngLat);
          } else {
            // 计算最近停车区的距离
            const nearestParks = await OPPolygon.findNear({
              query: { enable: true, type: constants.OP_POLYGON_TYPE.停车区 },
              center: lngLat,
              searchRadius: 1000,
              limit: 1,
              selector: 'path',
            });
            let nearestPark;
            if (nearestParks[0]) nearestPark = nearestParks[0];
            if (nearestPark && nearestPark.path) {
              const path = nearestPark.path.coordinates[0];
              stockUpdate.location.distanceWithPark = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
            }
            // 不在停车区，则判断是否在禁停区
            const intersectForbiddenArea = intersectPolygons.search({
              type: constants.OP_POLYGON_TYPE.禁停区,
            });
            if (intersectForbiddenArea) {
              // 在禁停区，则计算到禁停区的距离
              intersectPolygon = intersectForbiddenArea;
              const path = intersectPolygon.path.coordinates[0];
              stockUpdate.location.distanceWithForbiddenArea = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
              // 在禁停区 禁停区计数加1
              OPPolygon.update({
                id: intersectForbiddenArea._id,
                data: {
                  matchCount: (intersectForbiddenArea.matchCount || 0) + 1,
                },
              });
            } else {
              const polygons = intersectPolygons.filter(polygon => ![constants.OP_POLYGON_TYPE.巡检区, constants.OP_POLYGON_TYPE.行政区].includes(polygon.type));
              intersectPolygon = polygons.length ? polygons[0] : null;
            }
          }
        }
        // 有相交区域，记录相交区域的信息
        if (intersectPolygon) {
          stockUpdate.location.intersectPolygon = intersectPolygon._id;
          stockUpdate.location.intersectPolygonType = intersectPolygon.type;
          stockUpdate.location.intersectPolygonNeighborhood = intersectPolygon.neighborhood;
          stockUpdate.location.intersectPolygonName = intersectPolygon.name;
        } else {
          stockUpdate.location.intersectPolygon = null;
          stockUpdate.location.intersectPolygonType = null;
          stockUpdate.location.intersectPolygonNeighborhood = null;
          stockUpdate.location.intersectPolygonName = null;
        }

        // 计算与围栏的距离
        const path = intersectRegion.path.coordinates[0];
        stockUpdate.location.distanceWithRegionPath = calculateDistanceBetweenPointAndPolygon(path, lngLat);
      } else {
        // 在围栏外则计算到所属大区围栏的距离
        // const region = await OPRegion.findById({
        //   id: stock.region._id,
        //   selector: 'path',
        //   cache: {
        //     enable: true,
        //   }
        // });
        if (region) {
          const path = region.path.coordinates[0];
          stockUpdate.location.distanceWithRegionPath = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
        }
      }
      // 记录相关巡检区
      let intersectInspectionArea = intersectPolygons.search({
        type: constants.OP_POLYGON_TYPE.巡检区,
      });
      // 如果没有相交巡检区 则搜索50km内最近的巡检区
      if (!intersectInspectionArea) {
        const nearInspectionAreas = await OPPolygon.findNear({
          center: lngLat,
          query: {
            enable: true,
            type: constants.OP_POLYGON_TYPE.巡检区,
          },
          searchRadius: constants.INSPECTOR_SEARCH_RADIUS,
          limit: 1,
          selector: 'name',
          cache: {
            enable: true,
          },
        });
        if (nearInspectionAreas[0]) intersectInspectionArea = nearInspectionAreas[0];
      }
      if (intersectInspectionArea) {
        stockUpdate.location.intersectInspectionArea = intersectInspectionArea._id;
        stockUpdate.location.intersectInspectionAreaName = intersectInspectionArea.name;
      }
      const intersectAdministrativeArea = intersectPolygons.search({
        type: constants.OP_POLYGON_TYPE.行政区,
      });
      if (intersectAdministrativeArea) {
        stockUpdate.location.intersectAdministrativeArea = intersectAdministrativeArea._id;
        stockUpdate.location.intersectAdministrativeAreaName = intersectAdministrativeArea.location.area;
      }
      stockUpdate.outsideRegion = !intersectRegion;
      stockUpdate.insideForbiddenArea = stockUpdate.location.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区;
      stockUpdate.insideProhibitedArea = stockUpdate.location.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
      stockUpdate.insidePark = stockUpdate.location.intersectPolygonType === constants.OP_POLYGON_TYPE.停车区;
    }

    if (order) { // 更新车辆最近使用信息
      stockUpdate.latestUsedAt = now;
      stockUpdate.latestIllegalOrderAt = null;
      stockUpdate.latestIllegalSpeedAt = null;
      stockUpdate.hasFind = true;
      stockUpdate.latestFoundAt = now;
      stockUpdate.latestFoundSucceedAt = now;
      stockUpdate.notFindRecords = [];
      stockUpdate.latestScannedAt = null;
    }
  }


  let forcePowerOff;
  // 向车辆发送指令
  // 判断是否可以向盒子发送指令
  if (!box.latestSentCommandAt || '5 seconds'.before(now).is.over(box.latestSentCommandAt)) {
    boxUpdate.latestSentCommandAt = now;
    if (order) {
      if (order.lock.isLocked) {
        if (!lockOn) {
          IoT.tryLock(deviceId)
        }
      } else {
        if (lockOn) { // 需要解锁
          IoT.unlockAsync(deviceId);
        }
        if (stockUpdate.outsideRegion) {
          if (accOn) { // 需要断电
            IoT.stopAsync(deviceId);
            setTimeout(_ => {
              IoT.playSoundAsync({ deviceId, sound: constants.BK_BOX_SOUND.驶出服务区提示 });
            }, 2000);
          }
        } else if (stockUpdate.insideProhibitedArea) {
          if (accOn) {
            IoT.stopAsync(deviceId);
            setTimeout(_ => {
              IoT.playSoundAsync({ deviceId, sound: constants.BK_BOX_SOUND.驶入禁行区提示 });
            }, 2000);
          }
        } else {
          // 延迟5分钟判断断电，避免瞬时低电压导致的误判
          const isForcePowerOff = stockUpdate.battery.isForcePowerOff && (stockUpdate.battery.firstForcePowerOff && '5 minute'.before(now).is.over(stockUpdate.battery.firstForcePowerOff));

          if (isForcePowerOff && accOn) { // 低电需要断电
            forcePowerOff = true;
            IoT.stopAsync(deviceId);
            // 锁定计费
            // ODOrder.update({
            //   id: order._id,
            //   updatedAt: order.updatedAt,
            //   data: {
            //     'payInfo.locked': true
            //   }
            // });
          } else if (!isForcePowerOff && !powerUnlink && !accOn) { // 不低电 不断电，需要启动
            IoT.startAsync(deviceId);
          } else if (accOn) { // 临近围栏和禁行区 播报语音
            const regionDis = stockUpdate.location.distanceWithRegionPath;
            const prohibitedDis = stockUpdate.location.distanceWithProhibitedArea;
            if (regionDis >= 0 && regionDis <= 100) {
              IoT.playSoundAsync({ deviceId, sound: constants.BK_BOX_SOUND.靠近服务边界提示 });
            } else if (judgement.isNotEmpty(prohibitedDis) && prohibitedDis >= 0 && prohibitedDis <= 100) {
              IoT.playSoundAsync({ deviceId, sound: constants.BK_BOX_SOUND.靠近禁行区提示 });
            }
          }
        }
      }
    } else {
      const isPutOn = stock && [
        constants.BK_LOCATE.空闲,
        constants.BK_LOCATE.预约,
        constants.BK_LOCATE.待拖回,
      ].includes(stock.locate);
      const isLowPower = voltage <= ((stock && stock.wrongControl) ? constants.BK_TEMPORARY_LOW_POWER_VOLTATE : constants.BK_LOW_POWER_VOLTAGE);
      // 投放中
      if (isPutOn) {
        if (accOn) IoT.stopAsync(deviceId);
        if (isLowPower) {
          // 低电强制撤防断电省电
          if (lockOn) IoT.unlockAsync(deviceId);
        } else {
          // 否则设防
          if (!lockOn && (Date.now() - new Date(stock.lastAccOffedAt).getTime() > 5 * 60 * 1000)) IoT.tryLock(deviceId);
        }
      }
    }
  }

  // 记录快照点
  // RCStockPoint.create(stockPoint);
  // 点数据记录到ots
  if (order) {
    try {
      // 订单开始五分钟后断电才算
      if (stock.accOn !== stockUpdate.accOn && (Date.now() - new Date(order.lease.startTime).getTime() > 5 * 60 * 1000)) {
        // powerUnlink true是电池断开 accOn false是电门关闭 这里写错了
        this.exec({
          c: 'record/userExperience/noPower',
          params: {
            stock: stock && stock._id,
            order: order._id,
            prevPowerUnlink: !stock.accOn,
            nextPowerUnlink: !stockUpdate.accOn,
            outsideRegion: stockUpdate.outsideRegion,
            prohibitionArea: stockUpdate.insideProhibitedArea,
            forcePowerOff,
            lngLat,
            speed,
            accOn: stock && stock.accOn,
            region: stock && stock.region._id,
            voltage,
          },
        }).catch(error => this.emit('error', error, 'controller.ebike.box.report.noPower'));
      }
    } catch (error) {
      //
    }
  }
  if (stockPoint.gps.gpsSignal === null) Reflect.deleteProperty(stockPoint.gps, 'gpsSignal');
  if (stockPoint.gps.gpsLngLat === null) Reflect.deleteProperty(stockPoint.gps, 'gpsLngLat');
  if (stockPoint.gps.speed === null) Reflect.deleteProperty(stockPoint.gps, 'speed');
  if (stockPoint.gps.alt === null) Reflect.deleteProperty(stockPoint.gps, 'alt');
  if (stockPoint.gps.direction === null) Reflect.deleteProperty(stockPoint.gps, 'direction');
  OTSStockPoint.create(Object.assign({}, stockPoint, {
    box_month: `${deviceId}_${time.format('yyyyMM')}`,
    time: time.getTime(),
  })).catch(console.error);

  // 如果车辆绑定了电池，记录
  if (stock && stock.battery && stock.battery.id) {
    const batteryPoint = Object.assign({}, {
      battery: stock.battery.id._id,
      box: stockPoint.box,
    }, {
      stock: stockPoint.stock,
      extra: stockPoint.extra,
      gps: stockPoint.gps,
      acc: stockPoint.acc,
      lock: stockPoint.lock,
    });
    OTSBatteryInStockPoint.create(Object.assign({}, batteryPoint, {
      battery_stock: `${stock.battery.id._id}_${stock._id}`,
      box: deviceId,
      time: time.getTime(),
    })).catch(err => console.error(err));
  }
  // 更新盒子状态
  // 更新盒子位置
  BKBox.update({
    id: data.deviceId,
    updatedAt: box.updatedAt,
    data: boxUpdate,
  });


  if (stock) {
    try {
      // 更新车辆状态
      await BKStock.updateSync({
        id: stock._id,
        updatedAt: stock.updatedAt,
        data: stockUpdate,
      }, this.exec.bind(this));
    } catch (error) {
      this.emit('error', error, 'controller.ebike.box.report.updateStock');
    }
  }

  if (order) {
    this.exec({
      c: 'order/order/snap',
      params: { id: order._id },
    }).catch(error => this.emit('error', error, 'controller.ebike.box.report.orderSnap'));
  }

};
