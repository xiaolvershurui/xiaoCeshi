const BKBox = require('../../../services/database/ebike/box');
const BKStock = require('../../../services/database/ebike/stock');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
  ds: Joi.number().required(),
  deviceType: Joi.string(),
  appVersion: Joi.string(),
  imsi: Joi.string(),
}).unknown();
exports.handler = async function ({ deviceId, ds, deviceType, appVersion, imsi }) {
  await BKBox.findByIdAndGenerate({
    deviceId,
    dataSource: ds,
  });
  BKBox.update({
    id: deviceId,
    data: {
      isOnline: true,
      'info.deviceType': deviceType,
      'info.appVersion': appVersion,
      'info.dataSource': ds,
      'sim.imsi': imsi,
      'sim.working': true,
      'sim.powerOn': true,
    }
  });
  const stock = await BKStock.findByBox({
    box: deviceId,
    cache: {
      enable: true,
    }
  });
  if (stock) {
    await BKStock.updateSync({ id: stock._id, data: { isOnline: true } }, this.exec.bind(this));
  }
};