const BKBox = require('../../../services/database/ebike/box');
const BKStock = require('../../../services/database/ebike/stock');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  deviceId: Joi.string().required(),
}).unknown();
exports.handler = async function ({ deviceId }) {
  BKBox.update({ id: deviceId, data: { isOnline: true } });
  const stock = await BKStock.findByBox({
    box: deviceId,
    cache: {
      enable: true,
    }
  });
  if (stock) {
    await BKStock.updateSync({ id: stock._id, data: { isOnline: true } }, this.exec.bind(this));
  }
};