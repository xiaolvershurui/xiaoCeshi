const Joi = require('poolishark').Joi;
const ACcoupon = require('../../../services/database/account/coupon');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  state: Joi.number().default(constants.AC_COUPON_STATE.可使用).description('状态'),
  user: Joi.string().required().description('user Id'),
  name: Joi.string().empty('').default('赔付补偿'),
  type: Joi.number().valid(constants.AC_COUPON_TYPE_ENUMS).default(constants.AC_COUPON_TYPE.租金抵扣券).empty('').description('优惠券名称'),
  amount: Joi.number().required().empty('').default(1).description('抵扣价值'),
  validDuration: Joi.number().empty('').default(7).description('有效时间'),
  count: Joi.number().empty('').default(1).description('优惠券数量'),
};

exports.handler = async ({ state, user, name, type, amount, count, validDuration }) => {
  const _user = await ACUser.findById({id:user});
  if(!_user){
    throw  new NotFoundError(`user [${user}] not found`);
  }
  const expires = Date.now() + validDuration * 86400*1000;
  for(let i=0; i<count; i++){
    await ACcoupon.create( {state, user, name, type, amount, expires } );
  }
};