const ACWallet = require('../../../services/database/account/wallet');
const validators = require('../../../com.mango.common/settings/validators');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const FNTicket = require('../../../services/database/finance/ticket');
const injectTransaction  = require('../../../utils/injectTransaction');

exports.validate = {
  user: validators.id.required()
};

exports.handler = async ({ user }, tid, Transaction) => {
  const originalWallet = await ACWallet.findByUser({
    user,
    selector: 'deposit.state _id updatedAt'
  });
  if(!originalWallet){
    throw new NotFoundError(' 该用户不存在');
  }
  if(originalWallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.退款中){
    throw new BadRequestError('还未申请退款，无法撤销');
  }
  const originalTicket = await FNTicket.findOne({
    query: {
      user,
      state: constants.FN_TICKET_STATE.退款中,
      type: constants.FN_TICKET_TYPE.支付押金
    },
    selector: '_id updatedAt'
  });
  if(!originalTicket){
    throw  new BadRequestError('退款申请已经到支付渠道,无法撤销')
  }
  const [ticket] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'fn_ticket',
      id: originalTicket._id,
      updatedAt:originalTicket.updatedAt,
      selector: 'amount _id'
    }]
  });
  const [wallet] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'ac_wallet',
      id: originalWallet._id,
      updatedAt:originalWallet.updatedAt,
      selector: 'amount _id'
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: ticket._id,
      $set: {
        state: constants.FN_TICKET_STATE.已支付,
        'refund.appliedAt': null,
        'refund.amount': null,
        'refund.reason': null,
        'refund.willProcessAt': null,
      }
    }, {
      _id: wallet._id,
      $set: {
        deposit: {
          paid: true,
          amount: ticket.amount,
          state: constants.FN_DEPOSIT_REFUND_STATE.可退款,
          ticket: ticket._id,
        }
      }
    }]
  });
};

module.exports = injectTransaction(exports, 'ticket.wallet.cancelRefound');
