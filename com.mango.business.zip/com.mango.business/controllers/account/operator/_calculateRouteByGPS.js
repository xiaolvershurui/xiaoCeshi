const geolib = require('geolib');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const OPRiderOrder = require('../../../services/database/operation/riderOrder');
const BKBox = require('../../../services/database/ebike/box');
const OTSStockPoint = require('../../../services/ots/stockPoint');
const constants = require('../../../com.mango.common/settings/constants');
const adjustPath = require('../../order/order/_adjustPath');

const getDistance = (lngLat1, lngLat2) => {
  return geolib.getDistance(lngLat1, lngLat2, 0, 3);
};

module.exports = async ({ id, type }) => {
  const inspectionOrder = await (type === 'rider' ? OPRiderOrder : OPInspectionOrder).findById({
    id,
    selector: '_id user.id updatedAt inspectedStocks times user.operator box',
    populateSelector: {
      'user.operator': 'box',
    },
  });
  // if (type === 'rider') {
  //   inspectionOrder = await OPInspectionOrder.findById({
  //     id,
  //     selector: '_id user.id updatedAt inspectedStocks times.startedAt times.stoppedAt user.operator',
  //     populateSelector: {
  //       'user.operator': 'box',
  //     },
  //   });
  // } else {
  //   inspectionOrder = await OPRiderOrder.findById({
  //     id,
  //     selector: '_id user.id updatedAt inspectedStocks times.startedAt times.finishedAt user.operator',
  //     populateSelector: {
  //       'user.operator': 'box',
  //     },
  //   });
  // }

  const route = {
    onDuty: {},
    inInspection: {
      distance: 0,
    },
    offDuty: {},
  };
  const inspectedStocks = inspectionOrder.inspectedStocks.filter(item => !item.isReturnedBack && !item.isPutOn);
  route.inInspection.startedAt = inspectionOrder.times.firstInspectionStartedAt;
  route.inInspection.finishedAt = inspectionOrder.times.lastInspectionFinishedAt;
  Object.assign(route, {
    onDuty: {
      distance: 0,
      startedAt: new Date(inspectionOrder.times.startedAt),
      finishedAt: route.inInspection.startedAt,
    },
    offDuty: {
      distance: 0,
      startedAt: route.inInspection.finishedAt,
      finishedAt: new Date(inspectionOrder.times.stoppedAt || inspectionOrder.times.finishedAt),
    },
  });

  /**
   * @param inspectionOrder
   * @param route
   * @param type -> onDuty, inInspection, offDuty
   */
    // TODO:box_month也用区间查询  查询这里要用递归查询
  const now = new Date();
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}0`.slice(-3, -1);
  const lastMonth = `0${now.getMonth()}0`.slice(-3, -1);
  const getLngLats = async (year, month, route, type) => {
    return await OTSStockPoint.find(
      {
        box_month: `${inspectionOrder.box}_${year}${month}`,
        time: [new Date(route[type].startedAt).getTime(), new Date(route[type].finishedAt).getTime()],
      },
      ['=', 'gps.locationType', constants.BK_BOX_LOCATION_TYPE.卫星],
      { select: ['gps.locationType', 'gps.lngLat', 'time'] });
  };
  const calculateDistance = async (inspectionOrder, route, type) => {
    const thisMonthLngLats = await getLngLats(year, month, route, type);

    let lastMonthLngLats = [];
    if (now.getDate() === 1 && route.onDuty.startedAt.getDate() !== 1) {
      lastMonthLngLats = await getLngLats(year, lastMonth, route, type);
    }

    let lngLats = [];
    if (thisMonthLngLats && thisMonthLngLats.length) {
      lngLats = [...lngLats, ...thisMonthLngLats];
    }
    if (lastMonthLngLats && lastMonthLngLats.length) {
      lngLats = [...lngLats, ...lastMonthLngLats];
    }
    // 校准
    const routePath = adjustPath(lngLats);
    if (routePath.length > 0) {
      const ret = routePath.reduce((memo, item) => {
        // 去掉巡检、骑行单据里的route.path字段
        // memo.ts.push(item.time);
        // memo.coordinates.push(item.gps.lngLat);
        route[type].distance += getDistance(memo.lngLat, item.gps.lngLat);
        memo.lngLat = item.gps.lngLat;
        return memo;
      }, {
        lngLat: routePath[0].gps.lngLat,
        ts: [],
        coordinates: [],
      });
      // route[type].path = {
      //   ts: ret.ts,
      //   coordinates: ret.coordinates,
      // };
    }
    route[type].distance = route[type].distance.toFixed(2);
    route[type].pph = (route[type].finishedAt && route[type].startedAt) ? parseFloat((lngLats.length / ((new Date(route[type].finishedAt).getTime() - new Date(route[type].startedAt).getTime()) / (60 * 60 * 1000))).toFixed(2)) : 0;
  };
  if (inspectionOrder.box) {
    // 上班路程
    if (route.onDuty.startedAt && route.onDuty.finishedAt) {
      await calculateDistance(inspectionOrder, route, 'onDuty');
    }
    // 巡检路程
    if (route.inInspection.startedAt && route.inInspection.finishedAt) {
      await calculateDistance(inspectionOrder, route, 'inInspection');
    }
    // 下班路程
    if (route.offDuty.startedAt && route.offDuty.finishedAt) {
      await calculateDistance(inspectionOrder, route, 'offDuty');
    }
    await (type === 'rider' ? OPRiderOrder : OPInspectionOrder).update({
      id: inspectionOrder._id,
      data: {
        route,
      },
    });
  }
};
