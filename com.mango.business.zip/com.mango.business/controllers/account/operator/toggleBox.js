const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const BKBox = require('../../../services/database/ebike/box');
const BKStock = require('../../../services/database/ebike/stock');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const Iot = require('../../../services/iot');

exports.validate = {
  id: Joi.string().required(),
  deviceId: Joi.string(),
};

exports.handler = async ({ id, deviceId }) => {
  const operator = await ACOperator.findById({ id, selector: 'updatedAt isWorking box' });
  if (!operator) throw new NotFoundError('不存在该运营账户');
  if (operator.isWorking) throw new BadRequestError('非下班状态下无法绑定盒子');
  const boxUpdate = {};
  const operatorUpdate = {};
  if (deviceId) {
    const box = await BKBox.findByIdAndGenerate({ deviceId, selector: 'driver' });
    if (!box) throw new NotFoundError('不存在该盒子');
    if (box.driver) throw new BadRequestError('该盒子已绑定其他司机');
    const stock = await BKStock.findByBox({ box: deviceId, selector: 'number.custom' });
    if (stock) throw new BadRequestError(`该盒子已绑定车辆${stock.number.custom}, 请到车辆列表页面解绑后尝试`);
    boxUpdate.driver = id;
    operatorUpdate.box = deviceId;
    // Iot.sendCommand({
    //   deviceId, command: 'setConfig', params: { freq_norm: 5 },
    // }).catch(console.error);
  } else {
    boxUpdate.driver = null;
    operatorUpdate.box = null;
    Iot.sendCommand({
      deviceId: operator.box, command: 'setConfig', params: { freq_norm: 300 },
    }).catch(console.error);
  }
  await BKBox.update({
    id: deviceId || operator.box,
    data: boxUpdate,
  });
  await ACOperator.update({
    id,
    data: operatorUpdate,
  });
};

