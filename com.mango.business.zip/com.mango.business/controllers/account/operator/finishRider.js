const Joi = require('poolishark').Joi;
const injectTransaction = require('../../../utils/injectTransaction');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const calculateProject = require('./_calculateProject');
// const calculateRoute = require('./_calculateRoute');
const _calculateRouteByGPS = require('./_calculateRouteByGPS');
const BKStock = require('../../../services/database/ebike/stock');
const ACOperator = require('../../../services/database/account/operator');
const Iot = require('../../../services/iot');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function({ id, deviceInfo }, tid, Transaction) {
  const operator = await ACOperator.findById({
    id,
    selector: 'riderOrder.id user wrongCount missCount wrongStock box',
  });

  const entities = [{
    model: 'ac_operator',
    id,
    selector: 'riderOrder.id user wrongCount missCount wrongStock box',
  }];

  const updates = [{
    _id: operator._id,
    $set: {
      isWorking: false,
      enableOffDuty: false,
      wrongCount: 0,
      missCount: 0,
      wrongStock: [],
      inspectionAreas: []
    },
    $unset: {
      riderOrder: 1,
      color: 1,
    },
  }];
  if (!operator) throw new NotFoundError('运营账户不存在');
  if (operator.riderOrder) {
    // throw new NotFoundError(`没有找到运营人员${id}的进行中的骑行订单`);
    // if (riderOrder.state !== constants.OP_RIDER_ORDER_STATE.派单中) {
    //   throw new BadRequestError(`骑行订单状态不正确:${riderOrder.state}`);
    // }

    // 记录未巡检的紧急任务车辆
    const urgencyTask = [
      constants.BK_TASK_TYPE.待拖回,
      constants.BK_TASK_TYPE.超一天真离线,
      constants.BK_TASK_TYPE.超一天疑似离线,
      constants.BK_TASK_TYPE.超一天离线扫码车,
      constants.BK_TASK_TYPE.超一天无定位扫码车,
      constants.BK_TASK_TYPE.超一天丢失扫码车,
      constants.BK_TASK_TYPE.一天内真离线,
      constants.BK_TASK_TYPE.一天内疑似离线,
      constants.BK_TASK_TYPE.一天内离线扫码车,
      constants.BK_TASK_TYPE.一天内无定位扫码车,
      constants.BK_TASK_TYPE.一天内丢失扫码车,
      constants.BK_TASK_TYPE.无定位,
      constants.BK_TASK_TYPE.零电断电,
      constants.BK_TASK_TYPE.被盗断电,
      constants.BK_TASK_TYPE.低电,
      constants.BK_TASK_TYPE.围栏外非免单,
      constants.BK_TASK_TYPE.高压离线,
    ];
    const unInspectedStocks = (await BKStock.find({
      query: {
        inspector: operator.user._id,
      },
      limit: 0,
      selector: 'number.custom taskList',
    })).reduce((memo, stock) => {
      urgencyTask.forEach(task => {
        const t = stock.taskList.search({ code: task });
        const s = memo.find(i => i.id === stock._id);
        if (t && ((t.code === constants.BK_TASK_TYPE.高压离线 && (Date.now() - new Date(t.issuedAt).getTime() > 2 * 60 * 60 * 1000)) || t.code !== constants.BK_TASK_TYPE.高压离线)) {
          if (!s) {
            memo.push({
              id: stock._id,
              stockNo: stock.number.custom,
              urgentTask: [{ code: t.code, issuedAt: t.issuedAt }],
            });
          } else {
            s.urgentTask.push({ code: t.code, issuedAt: t.issuedAt });
          }
        }
      });
      return memo;
    }, []);

    entities.push({
      model: 'op_rider_order',
      id: operator.riderOrder.id,
      selector: 'state inspectedStocks user.dispatchAbility',
    });
    updates.push({
      _id: operator.riderOrder.id,
      $set: {
        state: constants.OP_RIDER_ORDER_STATE.待审核,
        'times.finishedAt': new Date(),
        wrongStock: operator.wrongStock,
        unInspectedStocks,
      },
    });
  } else {
    throw new NotFoundError(`没有找到运营人员${id}的进行中的骑行订单`);
  }
  // const [riderOrder] = await Transaction.findAndLockEntity({
  //   tid,
  //   entities: [{
  //     model: 'op_rider_order',
  //     id: operator.riderOrder.id,
  //     selector: 'state inspectedStocks user.dispatchAbility',
  //   }],
  // });
  // if (!riderOrder) throw new NotFoundError('骑行订单不存在');

  await Transaction.findAndLockEntity({
    tid,
    entities,
  });

  await Transaction.commit({
    tid,
    updates,
  });

  // 统计巡检距离和巡检轨迹
  _calculateRouteByGPS({ id: operator.riderOrder.id, type: 'rider' }).catch(console.error);

  const stocks = await BKStock.findByInspector({ inspector: operator.user._id, selector: '_id updatedAt' });

  for (let stock of stocks) {
    try {
      // 更新车辆
      this.exec({
        c: 'ebike/stock/afterUpdate',
        params: {
          id: stock._id,
        },
      });
    } catch (error) {
      this.emit('error', error, 'controller.account.operator.finishInspection');
    }
  }
  // 司机下班 对应盒子频率改变
  if (operator.box) {
    Iot.sendCommand({
      deviceId: operator.box, command: 'setConfig', params: { freq_norm: 300 },
    }).catch(console.error);
  }
};
module.exports = injectTransaction(exports, 'account.operator.finishRider');
