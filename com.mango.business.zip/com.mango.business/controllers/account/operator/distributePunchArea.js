const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const OPPunchArea = require('../../../services/database/operation/punchArea');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');


exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  const operator = await ACOperator.findById({
    id,
    selector: '_id distributePunchArea inspectionAreas updatedAt'
  });
  if (operator.distributePunchArea) throw new BadRequestError(`巡检人员${id}已经分配了打卡点`);

  // 通过巡检区获取打卡点 id
  const punchAreas = await OPPunchArea.find({
    query: {
      enable: true,
      polygon: {
        $in: operator.inspectionAreas.map(item => item._id),
      }
    },
    selector: '_id'
  });

  return await ACOperator.update({
    id: operator._id,
    updatedAt: operator.updatedAt,
    data: {
      distributePunchArea: true,
      punchAreas: punchAreas.map(item => item._id)
    },
  })
};
