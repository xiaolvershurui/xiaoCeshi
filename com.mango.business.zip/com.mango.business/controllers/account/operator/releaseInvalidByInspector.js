const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACOperator = require('../../../services/database/account/operator');
const BKStock = require('../../../services/database/ebike/stock');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async (id)=>{
  const acOperator = await ACOperator.findById({
    id,
    selector: ' regions acceptTaskGroups inspectionAreas'
  });
 const stocks = await BKStock.find({
    query: {
      inspector: id,
      $or: [{
        region: { $nin: acOperator.regions },
      }, {
        taskGroup: { $nin: acOperator.acceptTaskGroups },
      }, {
        'location.intersectInspectionArea': { $nin: acOperator.inspectionAreas }
      }]
    },
   limit: 0,
   selector:' inspector taskList'
  });
 for (let stock of stocks ){
    await this.exec({
       c: 'ebike/stock/releaseInspector',
       params: {
         stock
       }
     })
   }
};