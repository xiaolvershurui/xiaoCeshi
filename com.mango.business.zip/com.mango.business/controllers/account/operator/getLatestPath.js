const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACOperator = require('../../../services/database/account/operator');
const RCCheckIn = require('../../../services/database/record/checkIn');
const RCOperatorCapture = require('../../../services/database/record/operatorCapture');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async({id})=>{
  const acOperator = await ACOperator.findOne({
    query: {
      _id: params.id,
      regions: { $in: regionIds }
    },
    selector:'user'
  });
  if(!acOperator){
    throw new Error('运营账户不存在或者无权限');
  }
  const rcCheckIn = await RCCheckIn.findOne({
    query: {
      user: acOperator.user._id,
      type: constants.RC_CHECK_IN_TYPE.签到
    },
    sort: {
      checkedAt: -1
    },
    selector: 'checkedAt'
  });
  const rcCheckOut = await RCCheckIn.findOne({
    query: {
      user: acOperator.user._id,
      type: constants.RC_CHECK_IN_TYPE.签退
    },
    sort: {
      checkedAt: -1
    },
    selector: 'checkedAt'
  });
  const checkTime = {};
  if (rcCheckIn && rcCheckOut && rcCheckIn.checkedAt.is.over(rcCheckOut.checkedAt)) {
    checkTime.checkIn = rcCheckIn;
  } else  {
    checkTime.checkIn = rcCheckIn;
    checkTime.checkOut = rcCheckOut;
  }
  const { checkIn, checkOut } = checkTime;
  const query ={ user: acOperator.user._id };
  if(checkIn){
    query.snappedAt = {};
    query.snappedAt.$gte = startTime;
  }
  if(checkOut){
    query.snappedAt = query.snappedAt || {};
    query.snappedAt.$lte = endTime;
  }
  if (checkIn) {
    query.snappedAt = {};
    query.snappedAt.$gte = startTime;
  }
  if (checkOut) {
    query.snappedAt = query.snappedAt || {};
    query.snappedAt.$lte = endTime;
  }
  const captures =  await RCOperatorCapture.find({
    query,
    sort:{
      snappedAt: -1
    },
    limit:0,
    selector: 'lngLat'
  });
  return captures.map(point => point.lngLat);
};

