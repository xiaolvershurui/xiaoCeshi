const Joi = require('poolishark').Joi;
const injectTransaction = require('../../../utils/injectTransaction');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const calculateProject = require('./_calculateProject');
// const calculateRoute = require('./_calculateRoute');
const _calculateRouteByGPS = require('./_calculateRouteByGPS');
const BKStock = require('../../../services/database/ebike/stock');
const BKBattery = require('../../../services/database/ebike/battery');
const Iot = require('../../../services/iot');

exports.validate = {
  id: Joi.string().required(),
  deviceInfo: Joi.object(),
};
exports.handler = async function({ id, deviceInfo }, tid, Transaction) {
  const [operator] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'ac_operator',
      id,
      selector: 'inspectionOrder.id user inspectionType wrongCount missCount wrongStock box batteryBag',
    }],
  });
  if (!operator) throw new NotFoundError('运营账户不存在');
  if (!operator.inspectionOrder) throw new NotFoundError('没有找到进行中的巡检订单');
  const [inspectionOrder] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'op_inspection_order',
      id: operator.inspectionOrder.id,
      selector: 'state inspectedStocks user.dispatchAbility needCast times',
    }],
  });
  if (!inspectionOrder) throw new NotFoundError('巡检订单不存在');
  if (![
      constants.OP_INSPECTION_ORDER_STATE.派单中,
      constants.OP_INSPECTION_ORDER_STATE.暂停派单,
    ].includes(inspectionOrder.state)) {
    throw new BadRequestError(`巡检订单状态不正确:${inspectionOrder.state}`);
  }
  if (!inspectionOrder.times.backToStationAt) throw new BadRequestError('巡检人员还没有回仓，请先回仓再下班');
  // const statistic = inspectionOrder.inspectedStocks.filter(item => item.isValidTask).reduce((memo, item) => {
  const statistic = inspectionOrder.inspectedStocks.reduce((memo, item) => {
    memo.total += 1;
    // 寻到
    if (item.hasFound) memo.found += 1;
    // 未锁
    if (!item.isBatteryLock && operator.inspectionType !== constants.AC_OPERATOR_INSPECTION_TYPE.骑行) {
      if (!item.isReturnedBack) memo.batteryUnLock += 1;
      else memo.returnBack += 1;
    }
    // 难寻找到
    else if (item.isHardToFindButFound) memo.hardToFindButFound += 1;
    // 投放
    else if (item.isPutOn) memo.putOn += 1;
    // 拖回
    else if (item.isReturnedBack) memo.returnBack += 1;
    // 回栏
    else if (item.isBackIntoRegion) memo.backIntoRegion += 1;
    // 换电
    else if (item.isExchangedBattery) memo.exchangeBattery += 1;
    else if (item.isNormal) memo.normal += 1;
    else {
      const addedTasks = item.lastTaskList.filter(task => !item.prevTaskList.search({ code: task.code }));
      const releasedTasks = item.prevTaskList.filter(task => !item.lastTaskList.search({ code: task.code }));
      if (!(releasedTasks.length > 0 && addedTasks.length === 0)) {
        // 未完成的任务
        if (item.hasFound && item.lastTaskList.search({ code: constants.BK_TASK_TYPE.待拖回 })) {
          // 未完成的拖回任务
          memo.returnBackUnfinished += 1;
        }
        //未完成的其他任务
        memo.unfinished[item.taskGroup] = memo.unfinished[item.taskGroup] || 0;
        memo.unfinished[item.taskGroup] += 1;
      }
    }
    return memo;
  }, {
    total: 0,
    found: 0,
    returnBack: 0,
    exchangeBattery: 0,
    batteryUnLock: 0,
    backIntoRegion: 0,
    hardToFindButFound: 0,
    putOn: 0,
    normal: 0,
    unfinished: {},
    returnBackUnfinished: 0,
  });
  // 根据调度能力重计未完成拖回任务数
  statistic.returnBackUnfinished = Math.max(0, Math.min(statistic.returnBackUnfinished, inspectionOrder.user.dispatchAbility - statistic.returnBack));
  statistic.mileage = 0;
  statistic.wrongChange = operator.wrongCount;
  statistic.lostBattery = operator.missCount;
  await Transaction.commit({
    tid,
    updates: [{
      _id: operator._id,
      $set: {
        isWorking: false,
        enableOffDuty: false,
        wrongCount: 0,
        missCount: 0,
        wrongStock: [],
        'batteryBag.total': 0,
        'batteryBag.batteries': [],
        'batteryBag.available': 0,
        'batteryBag.unavailable': 0,
      },
      $unset: {
        inspectionOrder: 1,
        color: 1,
      },
    }, {
      _id: inspectionOrder._id,
      $set: {
        state: constants.OP_INSPECTION_ORDER_STATE.待确认,
        'times.finishInspectionAt': new Date(),
        wrongStock: operator.wrongStock,
        statistic,
        fixedStatistic: statistic,
      },
    }],
  });
  // 统计巡检距离和巡检轨迹
  // calculateRoute({ id: inspectionOrder._id, deviceInfo }).catch(console.error);
  _calculateRouteByGPS({ id: inspectionOrder._id }).catch(console.error);
  if (inspectionOrder.needCast) {
    calculateProject({ id: inspectionOrder._id }).catch(console.error);
  }
  const stocks = await BKStock.findByInspector({ inspector: operator.user, selector: '_id inspector updatedAt' });
  for (let stock of stocks) {
    try {
      // 更新车辆
      this.exec({
        c: 'ebike/stock/afterUpdate',
        params: {
          id: stock._id,
        },
      });
      // BKStock.updateSync({
      //   id: stock._id,
      //   updatedAt: stock.updatedAt,
      //   data: {
      //     inspector: null,
      //     inspectorName: null,
      //     inspectorTel: null,
      //     manualAssignTask: false
      //   }
      // }, this.exec.bind(this));
    } catch (error) {
      this.emit('error', error, 'controller.account.operator.finishInspection');
    }
  }
  if (operator.box) {
    // 司机下班 对应盒子频率改变
    Iot.sendCommand({
      deviceId: operator.box, command: 'setConfig', params: { freq_norm: 300 },
    }).catch(console.error);
  }
};
module.exports = injectTransaction(exports, 'account.operator.finishInspection');
