const Joi = require('poolishark').Joi;
const injectTransaction = require('../../../utils/injectTransaction');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async ({ id }, tid, Transaction) => {
  const [operator] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'ac_operator',
      id,
      selector: 'inspectionOrder.id',
    }]
  });
  if (!operator) throw new NotFoundError('运营账户不存在');
  const [inspectionOrder] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'op_inspection_order',
      id: operator.inspectionOrder.id,
      selector: 'state',
    }]
  });
  if (!inspectionOrder) throw NotFoundError('巡检订单不存在');
  if (![
      constants.OP_INSPECTION_ORDER_STATE.派单中,
      constants.OP_INSPECTION_ORDER_STATE.暂停派单
    ].includes(inspectionOrder.state)) {
    throw new BadRequestError(`巡检订单状态不正确:${inspectionOrder.state}`);
  }
  await Transaction.commit({
    tid,
    updates: [{
      _id: operator._id,
      $set: {
        isWorking: false,
        'inspectionOrder.state': constants.OP_INSPECTION_ORDER_STATE.暂停派单,
      }
    }, {
      _id: inspectionOrder._id,
      $set: {
        state: constants.OP_INSPECTION_ORDER_STATE.暂停派单,
      }
    }]
  });
};
module.exports = injectTransaction(exports, 'account.operator.pauseInspection');