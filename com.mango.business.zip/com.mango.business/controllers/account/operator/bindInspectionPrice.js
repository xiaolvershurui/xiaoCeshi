const Joi = require('poolishark').Joi;
const STInspectionPrice = require('../../../services/database/setting/inspectionPrice');
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  inspectionPriceId: Joi.string().required()
};

exports.handler = async ({ id, inspectionPriceId }) => {
  const inspectionPrice = await STInspectionPrice.findById({ id: inspectionPriceId, selector: '_id' });
  if (!inspectionPrice) throw new NotFoundError(`不存在计价规则${inspectionPriceId}`);
  const operator = await ACOperator.findById({ id, selector: '_id updatedAt' });
  if (!operator) throw new NotFoundError(`不存在运营账户${id}`);
  return await ACOperator.update({
    id,
    updatedAt: operator.updatedAt,
    data: {
      inspectionPrice: inspectionPriceId
    }
  })
};