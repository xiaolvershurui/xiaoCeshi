const geolib = require('geolib');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const RCOperatorCapture = require('../../../services/database/record/operatorCapture');

const getDistance = (lngLat1, lngLat2) => {
  return geolib.getDistance(lngLat1, lngLat2, 0, 3);
};

module.exports = async ({ id, deviceInfo }) => {
  const inspectionOrder = await OPInspectionOrder.findById({
    id,
    selector: '_id user.id updatedAt inspectedStocks times.startedAt times.stoppedAt',
  });
  const route = {
    onDuty: {},
    inInspection: {
      distance: 0,
    },
    offDuty: {},
  };
  const inspectedStocks = inspectionOrder.inspectedStocks.filter(item => !item.isReturnedBack && !item.isPutOn);
  route.inInspection.startedAt = new Date(Math.min(...inspectedStocks.map(item => new Date(item.startedAt).getTime())));
  route.inInspection.finishedAt = new Date(Math.max(...inspectedStocks.map(item => new Date(item.finishedAt).getTime())));
  Object.assign(route, {
    onDuty: {
      distance: 0,
      startedAt: new Date(inspectionOrder.times.startedAt),
      finishedAt: route.inInspection.startedAt,
    },
    offDuty: {
      distance: 0,
      startedAt: route.inInspection.finishedAt,
      finishedAt: new Date(inspectionOrder.times.stoppedAt),
    },
  });


  // 上班路程
  const rcOnDutyOperatorCaptures = await RCOperatorCapture.find({
    query: {
      user: inspectionOrder.user.id,
      snappedAt: {
        $gte: route.onDuty.startedAt,
        $lte: route.onDuty.finishedAt,
      },
      'deviceInfo.udid': deviceInfo.udid,
    },
    limit: 0,
    selector: 'lngLat snappedAt',
  });
  const onDutyPaths = rcOnDutyOperatorCaptures.reduce((memo, item) => {
    memo.ts = [...memo.ts, item.snappedAt];
    memo.coordinates = [...memo.coordinates, item.lngLat];
    return memo;
  }, {
    ts: [],
    coordinates: [],
  });
  if (onDutyPaths.coordinates) {
    onDutyPaths.coordinates.reduce((memo, item) => {
      route.onDuty.distance += getDistance(memo, item);
      memo = item;
      return memo;
    });
  }
  route.onDuty.distance = parseFloat(route.onDuty.distance.toFixed(2));
  route.onDuty.pph = parseFloat((rcOnDutyOperatorCaptures.length / ((new Date(route.onDuty.finishedAt).getTime() - new Date(route.onDuty.startedAt).getTime()) / (60 * 60 * 1000))).toFixed(2));
  route.onDuty.path = onDutyPaths;


  // 巡检路程
  const rcInInspectionOperatorCaptures = await RCOperatorCapture.find({
    query: {
      user: inspectionOrder.user.id,
      snappedAt: {
        $gte: route.inInspection.startedAt,
        $lte: route.inInspection.finishedAt,
      },
      'deviceInfo.udid': deviceInfo.udid,
    },
    limit: 0,
    selector: 'lngLat snappedAt',
  });

  const onInInspectionPaths = rcInInspectionOperatorCaptures.reduce((memo, item) => {
    memo.ts = [...memo.ts, item.snappedAt];
    memo.coordinates = [...memo.coordinates, item.lngLat];
    return memo;
  }, {
    ts: [],
    coordinates: [],
  });
  if (onInInspectionPaths.coordinates) {
    onInInspectionPaths.coordinates.reduce((memo, item) => {
      route.inInspection.distance += getDistance(memo, item);
      memo = item;
      return memo;
    });
  }
  route.inInspection.distance = parseFloat(route.inInspection.distance.toFixed(2));

  route.inInspection.pph = parseFloat((rcInInspectionOperatorCaptures.length / ((new Date(route.inInspection.finishedAt).getTime() - new Date(route.inInspection.startedAt).getTime()) / (60 * 60 * 1000))).toFixed(2));
  route.inInspection.path = onInInspectionPaths;

  // 下班路程
  const rcOffDutyOperatorCaptures = await RCOperatorCapture.find({
    query: {
      user: inspectionOrder.user.id,
      snappedAt: {
        $gte: route.offDuty.startedAt,
        $lte: route.offDuty.finishedAt,
      },
      'deviceInfo.udid': deviceInfo.udid,
    },
    limit: 0,
    selector: 'lngLat snappedAt',
  });
  const onOffDutyPaths = rcOffDutyOperatorCaptures.reduce((memo, item) => {
    memo.ts = [...memo.ts, item.snappedAt];
    memo.coordinates = [...memo.coordinates, item.lngLat];
    return memo;
  }, {
    ts: [],
    coordinates: [],
  });
  if (onOffDutyPaths.coordinates.length) {
    onOffDutyPaths.coordinates.reduce((memo, item) => {
      route.offDuty.distance += getDistance(memo, item);
      memo = item;
      return memo;
    });
  }
  route.offDuty.distance = parseFloat(route.offDuty.distance.toFixed(2));

  route.offDuty.pph = parseFloat((rcOffDutyOperatorCaptures.length / ((new Date(route.offDuty.finishedAt).getTime() - new Date(route.offDuty.startedAt).getTime()) / (60 * 60 * 1000))).toFixed(2));
  route.offDuty.path = onOffDutyPaths;

  await OPInspectionOrder.update({
    id: inspectionOrder._id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      route,
    },
  });
};