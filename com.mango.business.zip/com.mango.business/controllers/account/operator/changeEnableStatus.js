const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');


exports.validate = {
  id: Joi.string().required(),
  enable: Joi.boolean().required()
};

exports.handler = async ({ id, enable }) => {
  const operator = await ACOperator.findById({
    id: id,
    selector: 'enable'
  });
  if (operator === null) {
    throw new NotFoundError('未找到该用户!')
  }
  await ACOperator.update({
    id: id,
    data: {
      enable
    },
  });
};