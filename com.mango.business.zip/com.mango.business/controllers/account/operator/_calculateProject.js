const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const calculateAmount = require('./_calculateAmount');

module.exports = async ({ id }) => {
  const inspectionOrder = await OPInspectionOrder.findById({ id, selector: 'payment updatedAt fixedStatistic ' });
  if (!inspectionOrder) throw new NotFoundError(`不存在巡检单${id}`);
  const { payment, fixedStatistic } = inspectionOrder;
  payment.projects = [];
  payment.projects.push({
    name: '拖回',
    unit: payment.unit.returnBack,
    count: fixedStatistic.returnBack,
    value: payment.unit.returnBack * fixedStatistic.returnBack
  }, {
    name: '换电',
    unit: payment.unit.exchangeBattery,
    count: fixedStatistic.exchangeBattery,
    value: payment.unit.exchangeBattery * fixedStatistic.exchangeBattery
  }, {
    name: '回栏',
    unit: payment.unit.backIntoRegion,
    count: fixedStatistic.backIntoRegion,
    value: payment.unit.backIntoRegion * fixedStatistic.backIntoRegion
  }, {
    name: '难寻',
    unit: payment.unit.hardToFindButFound,
    count: fixedStatistic.hardToFindButFound,
    value: payment.unit.hardToFindButFound * fixedStatistic.hardToFindButFound
  }, {
    name: '投放',
    unit: payment.unit.putOn,
    count: fixedStatistic.putOn,
    value: payment.unit.putOn * fixedStatistic.putOn
  }, {
    name: '普通',
    unit: payment.unit.normal,
    count: fixedStatistic.normal,
    value: payment.unit.normal * fixedStatistic.normal
  }, {
    name: '拖回未完成',
    unit: payment.unit.returnBackUnfinished,
    count: Math.max(0, fixedStatistic.returnBackUnfinished),
    value: -payment.unit.returnBackUnfinished * Math.max(0, fixedStatistic.returnBackUnfinished)
  }, {
    name: '错误换电',
    unit: payment.unit.wrongChange,
    count: fixedStatistic.wrongChange,
    value: -payment.unit.wrongChange * (fixedStatistic.wrongChange || 0)
  }, {
    name: '丢失电池',
    unit: payment.unit.lostBattery,
    count: Math.max(0, fixedStatistic.lostBattery),
    value: -payment.unit.lostBattery * Math.max(0, (fixedStatistic.lostBattery || 0))
  });
  await OPInspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      'payment.projects': payment.projects
    }
  });
  // 触发重新计算金额
  calculateAmount(id)
};
