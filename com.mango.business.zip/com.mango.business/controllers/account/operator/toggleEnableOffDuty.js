const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  const operator = await ACOperator.findById({ id, selector: 'updatedAt enableOffDuty' });
  if (!operator) throw new NotFoundError('不存在该运营账户');
  return await ACOperator.update({
    id,
    updatedAt: operator.updatedAt,
    data: {
      enableOffDuty: !operator.enableOffDuty
    }
  })
};