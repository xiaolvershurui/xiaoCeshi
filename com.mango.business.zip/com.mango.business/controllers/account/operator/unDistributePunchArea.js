const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  id: Joi.string().required(),
};

exports.handler = async ({ id }) => {
  const operator = await ACOperator.findById({
    id,
    selector: 'distributePunchArea'
  });
  if (!operator.distributePunchArea) throw new BadRequestError(`巡检人员${id}已经取消了分配打卡点`);

  return await ACOperator.update({
    id: operator._id,
    updatedAt: operator.updatedAt,
    data: {
      distributePunchArea: false,
      punchAreas: []
    },
  })
};
