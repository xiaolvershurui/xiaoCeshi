const Joi = require('poolishark').Joi;
const ACOperator = require('../../../services/database/account/operator');
const ACUser = require('../../../services/database/account/user');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');
const InspectionPrice = require('../../../services/database/setting/inspectionPrice');
const STConfig = require('../../../services/database/setting/config');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
const Iot = require('../../../services/iot');

exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async ({ id }, tid, Transaction) => {
  // 判断运营账户是否存在
  const operator = await ACOperator.findById({
    id,
    selector: 'user type stockInfo.type stockInfo.dispatchAbility stockInfo.source regions inspectionPrice inspectionType checkStatus needCast box',
    populateSelector: {
      user: 'cert.name auth.tel box',
    },
  });
  if (!operator) throw new NotFoundError('运营账户不存在');
  if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机 && operator.checkStatus !== constants.AC_DRIVER_STATUS.已审核) throw new BadRequestError('该司机还未通过审核');
  if (!operator.inspectionPrice) throw new NotFoundError('未指定计价规则');
  const inspectionPrice = await InspectionPrice.findById({ id: operator.inspectionPrice._id, selector: 'unit' });
  if (!inspectionPrice) throw new NotFoundError('指定计价规则无效');
  // 判断用户是否存在
  const user = await ACUser.findById({
    id: operator.user._id,
    selector: 'auth.tel cert.name profile.avator',
    cache: { enable: true },
  });
  if (!user) throw new NotFoundError('用户不存在');
  // 判断是否已经存在进行中的巡检订单
  const inspectionOrder = await OPInspectionOrder.findByUserAndState({
    user: user._id,
    states: [
      constants.OP_INSPECTION_ORDER_STATE.暂停派单,
      constants.OP_INSPECTION_ORDER_STATE.派单中,
    ],
  });
  if (inspectionOrder) throw new BadRequestError(`手机号为${operator.user.auth.tel}的${operator.user.cert.name}有正在进行中的巡检订单`);
  // 更新运营账户
  // 获取颜色分配
  const usedColors = await ACOperator.findUsedColors(operator.regions.map(region => region._id));
  const colors = (await STConfig.get({ key: 'ac.operator.colors', cache: { enable: true } })) || [];
  if (colors.length <= usedColors) throw new BadRequestError('没有可分配的颜色，请添加后重试');
  const unusedColors = colors.filter(color => !usedColors.includes(color));
  if (operator.box) {
    Iot.sendCommand({
      deviceId: operator.box, command: 'setConfig', params: { freq_norm: 5 },
    }).catch(console.error);
  }
  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'ac_operator',
      id: operator._id,
    }, {
      model: 'op_inspection_order',
    }],
  });
  const inspectionOrderId = await OPInspectionOrder.genId();
  await Transaction.commit({
    tid,
    updates: [{
      _id: operator._id,
      $set: {
        isWorking: true,
        color: unusedColors[parseInt(Math.random() * unusedColors.length)],
        inspectionOrder: {
          id: inspectionOrderId,
          state: constants.OP_INSPECTION_ORDER_STATE.派单中,
        },
      },
    }, {
      _id: inspectionOrderId,
      region: operator.regions[0],
      box: operator.box,
      user: {
        id: user._id,
        name: user.cert.name,
        tel: user.auth.tel,
        avator: user.profile.avator,
        operator: operator._id,
        type: operator.type,
        inspectionType: operator.inspectionType,
        carType: operator.stockInfo && operator.stockInfo.type,
        source: operator.stockInfo && operator.stockInfo.source,
        dispatchAbility: (_ => {
          if (!operator.stockInfo) return 0;
          if (operator.stockInfo.dispatchAbility) return operator.stockInfo.dispatchAbility;
          switch (operator.stockInfo.type) {
            case constants.AC_STOCK_TYPE.面包车:
              return 2;
            case constants.AC_STOCK_TYPE.平板车:
            case constants.AC_STOCK_TYPE.箱货:
            case constants.AC_STOCK_TYPE.金杯:
              return 7;
            default:
              return 0;
          }
        })(),
      },
      needCast: operator.needCast,
      state: constants.OP_INSPECTION_ORDER_STATE.派单中,
      'payment.unit': inspectionPrice.unit,
      'times.startedAt': new Date(),
    }],
  });

};
module.exports = injectTransaction(exports, 'account.operator.create');
