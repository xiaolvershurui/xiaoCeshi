const Joi = require('poolishark').Joi;
const injectTransaction = require('../../../utils/injectTransaction');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const ACOperator = require('../../../services/database/account/operator');

exports.validate = {
  user: Joi.string().required(),
};
exports.handler = async function ({ user }) {
  const operator = await ACOperator.findByUser({ user });
  if (!operator) throw new NotFoundError('不存在运营账户');
  await this.exec({
    c: 'account/operator/finishInspection',
    params: {
      id: operator._id
    }
  })
};
module.exports = injectTransaction(exports, 'account.operator.finishInspectionOrderSelf');