const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const ACOperator = require('../../../services/database/account/operator');


exports.validate = {
  id: Joi.string().required(),
};
exports.handler = async function ({ id }) {
  const operator = await ACOperator.findById({ id, selector: "showAmount　updatedAt" });
  if(!operator){
    throw new NotFoundError('未找到该巡检员');
  }
  return await ACOperator.update({
    id,
    updatedAt: operator.updatedAt,
    data: {
      "showAmount": !operator.showAmount
    }
  })
};
