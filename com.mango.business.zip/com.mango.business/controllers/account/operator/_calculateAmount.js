const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const OPInspectionOrder = require('../../../services/database/operation/inspectionOrder');

module.exports = async (id) => {
  const inspectionOrder = await OPInspectionOrder.findById({ id, selector: 'payment updatedAt fixedStatistic' });
  if (!inspectionOrder) throw new NotFoundError(`不存在巡检单${id}`);
  const { payment, fixedStatistic } = inspectionOrder;
  const totalAmount = [...inspectionOrder.payment.projects, ...inspectionOrder.payment.extraProjects].reduce((memo, item) => {
    return memo + item.value;
  }, 0);
  await OPInspectionOrder.update({
    id,
    updatedAt: inspectionOrder.updatedAt,
    data: {
      'payment.totalAmount': totalAmount
    }
  })
};
