const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  id: Joi.string().required(),
  permission: Joi.string().required()
};

exports.handler = async ({ id, permission }) => {
  return await ACUser.update({
    id,
    arrayOp:{
      $addToSet: {
        'auth.permissions': permission
      }
    },
    selector: '_id'
  })
};