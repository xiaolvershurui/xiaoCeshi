const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const validators = require('../../../com.mango.common/settings/validators');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  userId: validators.id.required(),
  tel: validators.tel.required()
};

exports.handler = async ({ userId, tel }) => {

  const acUserById = await ACUser.findById({ id: userId, selector: 'cert.hasVerified auth.tel' });
  if (!acUserById.cert || !acUserById.cert.hasVerified) throw new BadRequestError(`您还未实名认证，请先去实名认证`);
  if (tel === (acUserById.auth && acUserById.auth.tel)) throw new BadRequestError('手机号不能当前手机号一样');

  const acUserByTel = await ACUser.findByTel({ tel });
  if (acUserByTel) throw new BadRequestError(`手机号${tel}已经存在，请联系客服`);

  await ACUser.update({
    id: acUserById._id,
    data: {
      'auth.tel': tel,
    },
  });
};
