const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');

exports.validate = {
  id: Joi.string().required(),
  role: Joi.string().required()
};

exports.handler = async ({ id, role }) => {
  return await ACUser.update({
    id,
    arrayOp: {
      $addToSet: {
        'auth.roles': role
      }
    },
    selector: '_id'
  })
};