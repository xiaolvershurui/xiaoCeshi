const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  unset: Joi.boolean().required()
};

exports.handler = async ({ id, unset }, tid, Transaction) => {
  let result;
  // TODO: token销毁
  if (unset) {
    result = await this.exec({
      c: 'account/user/removeRole',
      params: { id, role: '数据采集' }
    }).catch(error => this.emit('error', error, 'controller.account.user.setCollectRole.removeRole'));
  }else{
    result = await this.exec({
      c: 'account/user/addRole',
      params: { id, role: '数据采集' }
    }).catch(error => this.emit('error', error, 'controller.account.user.setCollectRole.addRole'));
  }
  if (result === null) {
    return new NotFoundError('未找到该用户!');
  }
  return result
};


