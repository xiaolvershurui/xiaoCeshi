const Joi = require('poolishark').Joi;
const RCStockOp = require('../../../services/database/record/stockOp');
const ACOperator = require('../../../services/database/account/operator');
const ACUser = require('../../../services/database/account/user');
const BKStock = require('../../../services/database/ebike/stock');
const OPPolygon = require('../../../services/database/operation/polygon');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  stock: Joi.string().required(),
  operateLocation: Joi.object().allow(null),
  operator: Joi.string().required(),
  operateRemark: Joi.string().allow(null),
  releasedTasks: Joi.array().allow(null),
  addedTasks: Joi.array().allow(null),
  prevTaskList: Joi.array().allow(null),
  hasFind: Joi.boolean().required(),
  photo: Joi.string().allow(null),
  failedReason: Joi.number().allow(null)
};

exports.handler = async ({ stock, operateLocation, operator, operateRemark, releasedTasks, addedTasks, prevTaskList, hasFind, photo, failedReason }) => {
  const stockData = await BKStock.findById({
    id: stock,
    selector: 'number location region style locate accOn lockOn battery batteryLockOn inspector',
  });
  const user = await ACUser.findById({ id: operator, selector: 'auth.tel cert.name profile.avator' });
  let inspector;
  if (stockData.inspector) {
    inspector = await ACOperator.findById({
      id: stockData.inspector, selector: 'user', populateSelector: {
        user: 'auth.tel cert.name profile.avator'
      }
    });
  }
  let inspectionArea;
  if (stockData.location && stockData.location.intersectInspectionArea) {
    inspectionArea = await OPPolygon.findById({ id: stockData.location.intersectInspectionArea, selector: 'name' });
  }
  const baseInfo = {
    stock,
    stockNo: stockData.number && stockData.number.custom,
    stockLocation: stockData.location,
    region: stockData.region._id,
    style: stockData.style._id,
    type: constants.RC_STOCK_OP_TYPE.找车打卡,
    description: hasFind ? '进行了巡检,找到了车辆' : `进行了巡检,但未找到车辆，${constants.RC_STOCK_OP_FIND_FAILED_REASON_MAP[failedReason]}${operateRemark}`,
    operator,
    releasedTasks,
    addedTasks,
    prevTaskList,
    operatedAt: new Date(),
    operatorName: user && user.cert.name,
    operatorTel: user && user.auth.tel,
    operatorAvator: (user && user.profile.avator) || constants.AC_DEFAULT_AVATOR,
    inspector: inspector && inspector.user._id,
    inspectorName: inspector && inspector.user.cert.name,
    inspectorTel: inspector && inspector.user.auth.tel,
    inspectorAvator: (inspector && inspector.profile.avator) || constants.AC_DEFAULT_AVATOR,
    inspectionArea: inspectionArea && inspectionArea._id,
    inspectionAreaName: inspectionArea && inspectionArea.name,
    operateLocation,
    operateRemark,
  };
  await RCStockOp.createStockOp(Object.assign(baseInfo, {
    findStock: {
      hasFind,
      photo,
      failedReason,
      locate: stockData.locate,
      accOn: stockData.accOn,
      lockOn: stockData.lockOn,
      voltage: stockData.battery.voltage,
      batteryLockOn: stockData.batteryLockOn
    }
  }))
}
;