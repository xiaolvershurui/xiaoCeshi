const Joi = require('poolishark').Joi;
const RCBatteryOp = require('../../../services/database/record/batteryOp');
const BKBattery = require('../../../services/database/ebike/battery');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  battery: Joi.string().required(),
  operator: Joi.string().required(),
  operatorName: Joi.string().required(),
  operatorTel: Joi.string().required(),
  nextRegion: Joi.string().required(),
};

exports.handler = async function ({ battery, operator, operatorName, operatorTel, nextRegion }) {
  const batteryData = await BKBattery.findById({ id: battery, selector: 'QRCode region mark station stock' });
  await RCBatteryOp.create({
    battery,
    QRCode: batteryData.QRCode,
    mark: batteryData.mark,
    stock: batteryData.stock._id,
    region: batteryData.region._id,
    description: '下班清除携带占位电池',
    type: constants.RC_BATTERY_OP_RECORD_TYPE.更换大区,
    operator,
    operatorName,
    operatorTel,
    updateRegion: {
      prev: batteryData.region._id,
      next: nextRegion,
    },
  });
};
