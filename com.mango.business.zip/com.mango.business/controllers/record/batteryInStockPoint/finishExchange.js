const Joi = require('poolishark').Joi;
const RCBatteryInStock = require('../../../services/database/record/batteryInStockPoint');
const OPRegion = require('../../../services/database/operation/region');
const validators = require('../../../com.mango.common/settings/validators');
const OTSBatterInStockPoint = require('../../../services/ots/batteryInStockPoint');
const oss = require('../../../services/oss');
const uuid = require('node-uuid');

exports.validate = {
  stock: Joi.string().required(),
  battery: Joi.string().required(),
  newBattery: Joi.string().required(),
  region: Joi.string().required(),
  box: Joi.string().required(),
};

const fetchData = async ({ stock, battery, start, end, _id }) => {
  let ret = await OTSBatterInStockPoint.find({ battery_stock: `${battery}_${stock}`, time: [start, end], _id });
  let lastRecordId = ret[ret.length - 1] && ret[ret.length - 1]._id;
  if (ret.length === 5000) {
    const newRet = await fetchData({ battery_stock: `${battery}_${stock}`, start: ret[ret.length - 1].time, end, _id: lastRecordId._id + 1 });
    ret = ret.concat(newRet);
  }
  return ret;
};

exports.handler = async function ({ stock, battery, region, box }) {
  const now = Date.now();
  const lastRecord = await RCBatteryInStock.findOne({ query: { battery, stock }, sort: { _id: -1 }, selector: [].join(' ') });
  const fileName = uuid.v4();
  const regionData = await OPRegion.findById({ id: region, selector: 'name' });
  if (lastRecord) {
    const otsPoints = await fetchData({ stock, battery, start: new Date(lastRecord.startTime).getTime(), end: now });
    const ret = {
      battery,
      stock,
      box: lastRecord.box,
      region: lastRecord.region,
      startTime: lastRecord.starTime,
      endTime: new Date(),
      points: [],
    };
    otsPoints.forEach(item => {
      ret.points.push({
        acc: item.acc,
        lock: item.lock,
        voltage: item.extra.voltage,
        mileageInAll: item.extra.mileageInAll,
        lngLat: item.gps && item.gps.gpsLngLat,
        time: item.time,
      });
    });
    oss.private.putData('电池换电周期', `${lastRecord.url}`, JSON.stringify(ret));
    await RCBatteryInStock.update({
      id: lastRecord._id,
      updatedAt: lastRecord.updatedAt,
      data: {
        endTime: now,
        finished: true
      },
    });
  }
  await RCBatteryInStock.create({
    battery: newBattery,
    stock,
    region,
    box,
    startTime: now,
    finished: false,
    url: `${regionData.name}/${fileName}.json`,
  });
};
