const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const TFVideo = require('../../../services/database/traffic/video');
const StudyTFVideo = require('../../../services/database/record/studyTfVideo');
const TFHistoryVideo = require('../../../services/database/traffic/historyVideo');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = {
  user: Joi.string().required(),
  video: validators.ObjectId.required(),
  creditLimits: Joi.object()
};

exports.handler = async function ({ user, video, creditLimits }) {
  const deadLine = parseFloat(creditLimits.deadLine);
  const _video = await TFVideo.findById({ id: video, selector: '_id additionPeriod' });
  if (!_video) throw new NotFoundError('该视频不存在');
  const _user = await ACUser.findById({ id: user, selector: '_id credit' });
  if (!_user) throw new NotFoundError('该用户不存在');

  const historyVideo = await TFHistoryVideo.findByUserAndVideo({
    user,
    video,
    selector: '_id updatedAt expiryTime'
  });
  const ret = {};
  ret.date = new Date();
  ret.scoreBefore = _user.credit;
  ret.scoreAfter = Math.max(_user.credit, deadLine);
  ret.scoreCount = ret.scoreAfter - ret.scoreBefore;
  ret.expiryTime = new Date(new Date().getTime() + (_video.additionPeriod * 24 * 60 * 60 * 1000));
  if (_user.credit < deadLine) {
    await ACUser.update({
      id: user,
      data: {
        credit: deadLine
      }
    });
    ret.scoreAfter = deadLine;
  }
  if (historyVideo && (new Date().getTime() < historyVideo.expiryTime.getTime() )) {
    // 有观看记录但未过期
    ret.scoreBefore = _user.credit;
    await StudyTFVideo.create(Object.assign({}, ret, {
      user,
      video
    }))
  } else if (historyVideo && (new Date().getTime() > historyVideo.expiryTime.getTime())) {
    // 有观看记录但已过期
    await TFHistoryVideo.update({
      id: historyVideo._id,
      updatedAt: historyVideo.updatedAt,
      data: { expiryTime: ret.expiryTime }
    });
    if (_user.credit > deadLine) {
      await this.exec({
        c: 'account/coupon/issueByUser',
        params: Object.assign({}, constants.AC_COUPON_INFO.studyFinished, {
          user
        })
      });
    }
    await StudyTFVideo.create(Object.assign({}, ret, {
      user,
      video
    }))
  } else {
    // 无观看历史记录，创建观看记录
    await TFHistoryVideo.create({ user, video, expiryTime: ret.expiryTime });
    await StudyTFVideo.create(Object.assign({}, ret, {
      user,
      video
    }))
  }

};