const Joi = require('poolishark').Joi;
const ACUser = require('../../../services/database/account/user');
const constants = require('../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  user: Joi.string().required(),
  creditLimits: Joi.object()
};

exports.handler = async function ({ user, creditLimits }) {
  const warningLine = parseFloat(creditLimits.warningLine);

  const _user = await ACUser.findById({ id: user, selector: '_id credit' });
  if (!_user) throw new NotFoundError('该用户不存在');

  await ACUser.update({
    id: user,
    data: {
      credit: warningLine
    }
  });
  await this.exec({
    c: 'account/coupon/issueByUser',
    params: Object.assign({}, constants.AC_COUPON_INFO.offlineStudyFinished, {
      user
    })
  });

};
