const Joi = require('poolishark').Joi;
const RCBikeBatteryNumber = require('../../../services/database/record/bikeBatteryNumber');
const BKStock = require('../../../services/database/ebike/stock');
const BKBattery = require('../../../services/database/ebike/stock');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = {
  region: Joi.string().required(),
  inputNumbers: Joi.object().required(),
};

exports.handler = async function ({ region, inputNumbers }) {
  const stocks = await BKStock.find({ query: { region, enable: true }, limit: 0, selector: 'state locate' });
  const batteries = await BKBattery.find({ query: { region }, limit: 0, selector: 'state locate' });
  const bike = stocks.reduce((memo, item) => {
    if (item.locate === 5 || item.locate === 10) {
      memo.lost++;
    } else if (item.locate === 8) {
      memo.detention++;
    } else if (item.state === 3) {
      memo.scrap++;
    }
    memo.total++;
    return memo;
  }, {
    total: 0,
    lost: 0,
    detention: 0,
    scrap: 0
  });

  const battery = batteries.reduce((memo, item) => {
    if (item.state === 2) {
      memo.damage++;
    } else if (item.state === 3) {
      memo.scrap++;
    } else if (item.locate === 3) {
      memo.lost++;
    }
    memo.total++;
    return memo;
  }, {
    total: 0,
    damage: 0,
    scrap: 0,
    lost: 0
  });
  return await RCBikeBatteryNumber.create(Object.assign({}, { region, inputNumbers }, {
    actual: {
      bike,
      battery
    }
  }))
};