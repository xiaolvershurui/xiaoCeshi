const Joi = require('poolishark').Joi;
const RCUserExperience = require('../../../services/database/record/userExperience');
const RCPowerUnlink = require('../../../services/database/record/powerUnlink');
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../com.mango.common/settings/validators');

exports.validate = {
  order: Joi.string().required(),
  prevPowerUnlink: Joi.boolean().required(),
  nextPowerUnlink: Joi.boolean().required(),
  outsideRegion: Joi.boolean(),
  prohibitionArea: Joi.boolean(),
  forcePowerOff: Joi.boolean(),
  lngLat: validators.location,
  speed: Joi.number(),
  accOn: Joi.boolean(),
  region: Joi.string(),
  stock: Joi.string(),
  voltage: Joi.number(),
};

exports.handler = async function ({ order, prevPowerUnlink, nextPowerUnlink, outsideRegion, prohibitionArea, forcePowerOff, lngLat, speed, accOn, region, stock, voltage }) {
  const record = await RCUserExperience.findByOrder({ order, selector: 'updatedAt noPoweredAt lastPowerUnlink outsideRegion prohibitionArea normalRide' });
  // powerUnlink是电池断开 accOn是电门关闭 这里写错了
  if (record) {
    const now = Date.now();
    const data = { forcePowerOff };
    if (!prevPowerUnlink && nextPowerUnlink) {
      // 电门开 -> 电门关
      if (lngLat && lngLat.length) {
        data.lngLat = lngLat
      }
      data.lastPowerUnlink = outsideRegion ? 'outsideRegion' : (prohibitionArea ? 'prohibitionArea' : 'normalRide');
      data[`${data.lastPowerUnlink}.noPower`] = true;
      data[`${data.lastPowerUnlink}.lastNoPoweredAt`] = now;

      let type = null;
      switch (data.lastPowerUnlink) {
        case 'outsideRegion' :
          type = constants.RC_POWER_UNLINK_TYPE.围栏外断电;
          break;
        case 'prohibitionArea' :
          type = constants.RC_POWER_UNLINK_TYPE.禁行区断电;
          break;
        case 'normalRide' :
          type = constants.RC_POWER_UNLINK_TYPE.正常骑行断电;
          break;
      }
      if (forcePowerOff) type = constants.RC_POWER_UNLINK_TYPE.低电断电;

      await RCPowerUnlink.create({
        region,
        stock,
        order,
        lngLat,
        type,
        speed,
        accOn,
        voltage
      });

    } else if (prevPowerUnlink && !nextPowerUnlink) {
      // 电门关 -> 电门开 根据断电类型 结算对应时间
      if (record.lastPowerUnlink && record[record.lastPowerUnlink].lastNoPoweredAt) {
        data.lastPowerUnlink = null;
        data[`${record.lastPowerUnlink}.noPowerForSeconds`] = Math.max(record[record.lastPowerUnlink].noPowerForSeconds || 0, now - new Date(record[record.lastPowerUnlink].lastNoPoweredAt).getTime());
      }
    }
    if (Object.keys(data).length) {
      await RCUserExperience.update({
        id: record._id,
        updatedAt: record.updatedAt,
        data,
      });
    }
  }
};
