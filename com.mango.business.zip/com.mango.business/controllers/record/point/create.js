const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');
const RCPoint = require('../../../services/database/record/point');
const ACWallet = require('../../../services/database/account/wallet');
const STCommodity = require('../../../services/database/setting/commodity');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const Cache = require('../../../com.mango.common/utils/cache');

exports.validate = {
  user: Joi.string().required(),
  approach: Joi.number().required(),
};

exports.handler = async ({ user, approach }, tid, Transaction) => {
  const wallet = await ACWallet.findByUser({ user, selector: 'balance' });

  const lastPointRecord = await RCPoint.findLastByUser({ user, selector: 'date' });
  if (lastPointRecord && lastPointRecord.date.beginning === 'today'.beginning) throw new BadRequestError('今天已经签过到啦');
  let stCommodities = await STCommodity.find({
    query: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
    },
    selector: '',
    populateSelector: {
      'commodity.id': 'type points money littleMango coupon'
    },
  });

  stCommodities = stCommodities[0] || [];

  const commodity = stCommodities.commodity.find(item => item.day === new Date().getDate());
  if (!commodity) throw new BadRequestError('签到奖励不存在');

  const [acUser] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id: user,
      model: 'ac_user',
      selector: 'points',
    }, {
      model: 'ac_coupon'
    }, {
      model: 'rc_point',
    }],
  });
  const time = new Date();
  await Transaction.commit({
    tid,
    updates: [{
      _id: user,
      $inc: {
        points: commodity.id.littleMango,
      },
    }, {
      user,
      name: commodity.id.coupon.name,
      amount: commodity.id.coupon.amount,
      expires: new Date(Date.now() + commodity.id.coupon.expires * 24 * 3600 * 1000)
    }, {
      user,
      date: time,
      month: time.getMonth() + 1,
      approach,
      points: commodity.id.littleMango,
      prevPoints: acUser.points,
    }],
  });
};

module.exports = injectTransaction(exports, 'record.point.create');