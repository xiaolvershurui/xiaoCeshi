const STDetainedArea = require('../../../services/database/setting/detainedArea');
const RCDetainedAreaLog = require('../../../services/database/record/detainedAreaLog');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  detainedArea: Joi.string().required(),
  logType: Joi.number().required(),
  mark: Joi.string()
};

exports.handler = async ({ detainedArea, logType, mark }) => {
  await RCDetainedAreaLog.create({
    detainedArea,
    logType,
    mark
  })
};