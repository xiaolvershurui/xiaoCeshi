const Joi = require('poolishark').Joi;
const STBoxUpgrade = require('../../../services/database/setting/boxUpgrade');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  version: Joi.string().required(),
  packVersion: Joi.string().required(),
  enable: Joi.boolean(),
};

exports.handler = async ({ version, packVersion, enable }) => {
  // 判断version是否存在
  const bu = await STBoxUpgrade.findByVersion({ version });
  if (bu) throw new BadRequestError(`版本号：${version}的升级路径已经设置`);
  return await STBoxUpgrade.create({ version, packVersion, enable });
};