const Joi = require('poolishark').Joi;
const STBoxUpgrade = require('../../../services/database/setting/boxUpgrade');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  enable: Joi.boolean().required(),
};
exports.handler = async ({ id, enable }) => {
  const bu = await STBoxUpgrade.findById({ id, selector: 'updatedAt enable' });
  if (!bu) throw new NotFoundError('未找到对应的配置');
  if (bu.enable === enable) return;
  await STBoxUpgrade.update({
    id,
    updatedAt: bu.updatedAt,
    data: {
      enable
    }
  });
};