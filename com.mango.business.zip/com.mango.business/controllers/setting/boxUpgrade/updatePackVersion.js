const Joi = require('poolishark').Joi;
const STBoxUpgrade = require('../../../services/database/setting/boxUpgrade');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  packVersion: Joi.string().required(),
};
exports.handler = async ({ id, packVersion }) => {
  const bu = await STBoxUpgrade.findById({ id, selector: 'updatedAt packVersion' });
  if (!bu) throw new NotFoundError('未找到对应的配置');
  if(bu.packVersion === packVersion) return;
  await STBoxUpgrade.update({
    id,
    updatedAt: bu.updatedAt,
    data: {
      packVersion
    }
  });
};