const STDetainedArea = require('../../../services/database/setting/detainedArea');
const ACOperator = require('../../../services/database/account/operator');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  principal: Joi.string().required()
};
exports.handler = async ({ id, principal }) => {
  const detainedArea = await STDetainedArea.findById({ id, selector: 'updatedAt enable' });
  if (!detainedArea) throw new NotFoundError('不存在该扣押点');

  const acOperator = await ACOperator.findByUser({ user: principal });
  if (!acOperator) throw new NotFoundError('该运营人员不存在');
  return STDetainedArea.update({
    id,
    updatedAt: detainedArea.updatedAt,
    data: {
      principal
    }
  })
};