const STDetainedArea = require('../../../services/database/setting/detainedArea');
const RCDetainedAreaLog = require('../../../services/database/record/detainedAreaLog');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  number: Joi.string().required(),
  region: Joi.string().required(),
  name: Joi.string().required(),
  lngLat: Joi.array().items(Joi.number()),
  address: Joi.string(),
  contact: Joi.string(),
  tel: Joi.string(),
  unit: Joi.string(),
};

exports.handler = async ({ number, region, name, lngLat, address, contact, tel, unit }, tid, Transaction) => {

  await Transaction.findAndLockEntity({
    tid,
    entities: [{
      model: 'st_detained_area',
    }, {
      model: 'rc_detained_area_log',
    }],
  });

  const detainedAreaId = await STDetainedArea.genId();
  const detainedAreaLogId = await RCDetainedAreaLog.genId();

  await Transaction.commit({
    tid,
    updates: [{
      _id: detainedAreaId,
      number,
      region,
      name,
      lngLat,
      address,
      contact,
      tel,
      unit
    }, {
      _id: detainedAreaLogId,
      detainedArea: detainedAreaId,
      logType: constants.ST_DETAINED_AREA_LOG_TYPE.创建扣押点,
      mark: '创建扣押点'
    }],
  });
};

module.exports = injectTransaction(exports, 'setting.detainedArea.create');