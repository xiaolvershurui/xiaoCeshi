const STDetainedArea = require('../../../services/database/setting/detainedArea');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object({
    name: Joi.string(),
    lngLat: Joi.array().items(Joi.number()),
    address: Joi.string(),
    contact: Joi.string(),
    tel: Joi.string(),
    unit: Joi.string(),
  })
};
exports.handler = async ({ id, data }) => {
  const detainedArea = await STDetainedArea.findById({ id, selector: 'updatedAt enable' });
  if (!detainedArea) throw new NotFoundError('不存在该扣押点');
  return STDetainedArea.update({
    id,
    updatedAt: detainedArea.updatedAt,
    data
  })
};