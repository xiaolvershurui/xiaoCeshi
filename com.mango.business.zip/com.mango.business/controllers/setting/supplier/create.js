const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const STSupplier = require('../../../services/database/setting/supplier');

exports.validate = {
  code: Joi.string().required(),
  name: Joi.string(),
  contact: Joi.string(),
  tel: Joi.string(),
};

exports.handler = async function ({ code, name, contact, tel }) {
  return await STSupplier.create({
    code,
    name,
    contact,
    tel,
  });
};