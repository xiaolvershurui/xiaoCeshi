const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const STSupplier = require('../../../services/database/setting/supplier');

exports.validate = {
  id: Joi.string().required(),
  data: {
    name: Joi.string(),
    contact: Joi.string(),
    tel: Joi.string(),
  },
};

exports.handler = async function ({ id, data }) {

  const supplier = await STSupplier.findById({ id, selector: '_id' });
  if (!supplier) throw new NotFoundError('未录入该供应商信息');

  return await STSupplier.update({
    id,
    data,
  });
};