const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const STCommodity = require('../../../services/database/setting/commodity');

exports.validate = {
  id: Joi.string().required(),
  data: {
    enable: Joi.boolean(),
    commodity: Joi.object({
      id: Joi.string(),
      day: Joi.number()
    })
  },
};

exports.handler = async function ({ id, data }) {

  const stCommodity = await STCommodity.findById({ id, selector: '_id' });
  if (!stCommodity) throw new NotFoundError('没有该条签到奖励记录');

  if (data.commodity) {
    const key = `commodity.${data.commodity.day - 1}.id`;
    data = {
      $set: {
        [key]: data.commodity.id
      }
    };
  }
  return await STCommodity.update({
    id,
    data,
  });
};