const STOCommodity = require('../../../services/database/store/commodity');
const STCommodity = require('../../../services/database/setting/commodity');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  user: Joi.string(),
  year: Joi.number().required(),
  month: Joi.number().required(),
  commodity: Joi.array().items(Joi.object({
    id: Joi.string(),
    day: Joi.number(),
  }).required()),
};

exports.handler = async ({ user, year, month, commodity }) => {
  const stCommodity = await STCommodity.find({ query: { year, month }, selector: '_id' });
  if (stCommodity.length) throw new BadRequestError('当月已存在签到奖励');

  // 判断当月天数
  const days = new Date(year, month, 0).getDate();
  if (commodity.length !== days) throw new BadRequestError(`此月应有${days}天`);


  let commodityDay = [...new Set(commodity.map(item => item.day))];
  if (commodityDay.length !== commodity.length) throw new BadRequestError('天数存在重复');
  commodityDay.forEach(item => {
    if (item < 1 || item > days) throw new BadRequestError('天数非法');
  });

  // 商品是否都存在
  let commodityCopy = [...new Set(commodity.map(item => item.id))];
  const commodities = await STOCommodity.find({
    query: {
      _id: {
        $in: commodityCopy,
      },
    },
  });
  if (commodities.length !== commodityCopy.length) throw new BadRequestError('有不存在的商品');

  if (month > 12 || month < 1) throw new BadRequestError('月份输入错误');

  return await STCommodity.create({
    user,
    year: parseInt(year),
    month: parseInt(month),
    commodity,
  });

};