const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const STAsset = require('../../../services/database/setting/asset');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const OPRegion = require('../../../services/database/operation/region');

exports.validate = {
  id: Joi.string().required(),
  data: {
    type: Joi.string(),
    image: Joi.string(),
    description: Joi.string(),
    group: Joi.number()
  }
};

exports.handler = async function ({ id, data })  {

  const asset = await STAsset.findById({ id, selector: '_id updatedAt' });
  if (!asset) throw new NotFoundError('未录入该配件');

  return await STAsset.update({
    id,
    updatedAt: asset.updatedAt,
    data
  });
};