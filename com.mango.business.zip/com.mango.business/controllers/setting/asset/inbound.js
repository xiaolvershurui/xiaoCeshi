const Joi = require('poolishark').Joi;
const STAsset = require('../../../services/database/setting/asset');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string(),
  intactCount: Joi.number().required(),
  scrapCount: Joi.number().default(0)
};

exports.handler = async ({ id, intactCount, scrapCount }) => {
  const stAsset = await STAsset.findById({ id, selector: 'updatedAt' });
  if (!stAsset) throw new NotFoundError('未录入该配件');
  await STAsset.update({
    id,
    updatedAt: stAsset.updatedAt,
    data: {
      $inc: {
        intactCount,
        scrapCount
      }
    }
  })
};