const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const STAsset = require('../../../services/database/setting/asset');
const OPBatteryStation = require('../../../services/database/operation/batteryStation');
const OPRegion = require('../../../services/database/operation/region');

exports.validate = {
  type: Joi.string().required(),
  code: Joi.string().required(),
  image: Joi.string(),
  description: Joi.string(),
  operator: Joi.string(),
  group: Joi.number().required()
};

exports.handler = async function ({ code, type, image, description, operator, group }) {
  const stations = await OPBatteryStation.find({
    query: {},
    selector: '_id region name'
  });

  const assetIsExist = await STAsset.findByCode({ code, selector: '_id' });
  if (assetIsExist) throw new BadRequestError('该二维码已经存在');

  const asset = await STAsset.create({
    code, type, image, description, group
  });
  process.nextTick(_ => {
    (async _ => {
      for (let station of stations) {
        try {
          await this.exec({
            c: 'ebike/asset/create',
            params: {
              region: station.region._id,
              station: station._id,
              asset: asset._id,
              code: asset.code,
              operator: operator,
              group: asset.group
            }
          })
        } catch (err) {
          console.error(err)
        }
      }
    })()
  });
};