const STInspectionPrice = require('../../../services/database/setting/inspectionPrice');
const Joi = require('poolishark').Joi;

exports.validate = {
  name: Joi.string().required(),
  enable: Joi.boolean().required(),
  unit: Joi.object({
    returnBack: Joi.number().min(0).required(),
    exchangeBattery: Joi.number().min(0).required(),
    backIntoRegion: Joi.number().min(0).required(),
    hardToFindButFound: Joi.number().min(0).required(),
    putOn: Joi.number().min(0).required(),
    normal: Joi.number().min(0).required(),
    returnBackUnfinished: Joi.number().min(0).required(),
    wrongChange: Joi.number().min(0).required(),
    lostBattery: Joi.number().min(0).required(),
    actualExchangeUnit: Joi.number().min(0).required(),
  }).unknown()
};
exports.handler = async data => {
  await STInspectionPrice.create(data);
};
