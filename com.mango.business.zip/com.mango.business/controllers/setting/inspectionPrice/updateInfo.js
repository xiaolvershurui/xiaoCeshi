const STInspectionPrice = require('../../../services/database/setting/inspectionPrice');
const Joi = require('poolishark').Joi;
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object({
    name: Joi.string(),
    enable: Joi.boolean(),
    'unit.returnBack': Joi.number(),
    'unit.backIntoRegion': Joi.number(),
    'unit.hardToFindButFound': Joi.number(),
    'unit.exchangeBattery': Joi.number(),
    'unit.putOn': Joi.number(),
    'unit.normal': Joi.number(),
    'unit.returnBackUnfinished': Joi.number(),
    'unit.wrongChange': Joi.number(),
    'unit.lostBattery': Joi.number()
  }).unknown()
};
exports.handler = async ({ id, data }) => {
  const inspectionPrice = await STInspectionPrice.findById({ id, selector: 'updatedAt enable' });
  if (!inspectionPrice) throw new NotFoundError('不存在该巡检价格');
  return STInspectionPrice.update({
    id,
    updatedAt: inspectionPrice.updatedAt,
    data
  })
};
