const Joi = require('poolishark').Joi;
const FNInvoice = require('../../../services/database/finance/invoice');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  email: Joi.string().required(),
};

exports.handler = async function ({ user, email }) {
  // TODO: 创建发票申请
  await FNInvoice.create({
    user,
    email
  })
};