const Joi = require('poolishark').Joi;
const FNInvoice = require('../../../services/database/finance/invoice');
const FNBalanceBill = require('../../../services/database/finance/balanceBill');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../com.mango.common/settings/constants');
const injectTransaction = require('../../../utils/injectTransaction');

exports.validate = {
  id: Joi.string().required()
};

exports.handler = async function ({ id }, tid, transaction) {
  const invoice = await FNInvoice.findById({ id, selector: 'user amount state' });
  if (!invoice) throw new NotFoundError('不存在该发票申请');
  if (invoice.state !== constants.FN_INVOICE_STATE.申请中) throw new BadRequestError('该发票申请状态不在审核中');
  const bills = await FNBalanceBill.find({
    query: {
      user: invoice.user._id, invoiced: false, signal: {
        $in: [constants.FN_BALANCE_BILL_SIGNAL.支付订单租金, constants.FN_BALANCE_BILL_SIGNAL.支付订单保险, constants.FN_BALANCE_BILL_SIGNAL.订单免单]
      }
    },
    limit: 0,
    selector: 'signal amount'
  });
  let amount = 0;
  let updates = [];
  bills.forEach(bill => {
    if ([constants.FN_BALANCE_BILL_SIGNAL.支付订单租金, constants.FN_BALANCE_BILL_SIGNAL.支付订单保险].includes(bill.signal)) {
      amount += bill.amount
    } else {
      amount -= bill.amount
    }
    updates.push({ _id: bill._id, $set: { invoiced: true } })
  });
  if (amount < constants.FN_INVOICE_AMOUNT_STANDARD) throw new BadRequestError(`该用户发票金额不足${constants.FN_INVOICE_AMOUNT_STANDARD.toCNY()}`)

  // TODO: 调用开票服务 存储到开票申请中
  await transaction.findAndLockEntity({
    tid,
    entities: [
      { model: 'fn_invoice' },
      ...bills.map(bill => {
        return {
          id: bill._id,
          model: 'fn_balance_bill'
        }
      })
    ]
  });
  await transaction.commit({
    tid,
    updates: [{
      _id: id,
      $set: {
        state: constants.FN_INVOICE_STATE.已完成
      }
    }, ...updates]
  })
};

module.exports = injectTransaction(exports, 'finance.invoice.pass');
