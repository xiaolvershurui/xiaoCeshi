const Joi = require('poolishark').Joi;
const FNTicket = require('../../../services/database/finance/ticket');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');
const FNBalanceBill = require('../../../services/database/finance/balanceBill');

exports.validate = {
  id: Joi.string().required()
};
exports.handler = async function ({ id }) {
  const fnTicket = await FNTicket.findById({
    id,
    selector: 'apiChannel pingpp'
  })
};