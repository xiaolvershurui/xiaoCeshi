const Joi = require('poolishark').Joi;
const FNTicket = require('../../../services/database/finance/ticket');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');
const ACWallet = require('../../../services/database/account/wallet');
const FNBalanceBill = require('../../../services/database/finance/balanceBill');

exports.validate = {
  id: Joi.string().required()
};
exports.handler = async function ({ id, willProcessAt }, tid, Transaction) {
  let refundReason;
  const updates = [];
   let fnTicket = await FNTicket.findById({
    id,
     selector: 'amount user refund'
  });
   let amount = fnTicket.amount;
  if(!fnTicket){
    throw new NotFoundError('未找到此支付凭据');
  }
  if(![constants.FN_TICKET_STATE.已支付, constants.FN_TICKET_STATE.已取消].includes(fnTicket.state)){
    throw new Error('当前账单无法申请退款');
  }
  if (fnTicket.state === constants.FN_TICKET_STATE.已支付) {
  if(fnTicket.type === constants.FN_TICKET_TYPE.支付押金){
    refundReason = '申请退款押金';
  }else{
  const acWallet = await ACWallet.findByUser({
      user: fnTicket.user._id,
      selector: 'balance'
    });
    amount = Math.min(acWallet.balance, amount);
    if(amount<=0){
      throw new Error('余额不足');
    }
    const fnBalanceBillId = await FNBalanceBill.genId();
    Transaction.findAndLockEntity({
      tid,
      entities:[{
        model: 'fn_balance_bill'
      }]
    });
    updates.push({
      _id: fnBalanceBillId,
      $set: {
        user: ticket.user,
        signal: constants.FN_BALANCE_BILL_SIGNAL.充值退款,
        ticket: id,
        amount
      }
    });
    refundReason = '申请退换余额';
  }}else{
    refundReason = '交易关闭';
  }
  const now = new Date();
  // 如果是秒退就秒退
  if(now.is.over(willProcessAt)){
    // switch (fnTicket.apiChannel) {
    //   case constants.FN_TICKET_PAYMENT_API_CHANNEL.支付宝: {
    //     if (!ticket) throw new Error('Alipay渠道需要凭据号');
    //     // return  alipay.queryPayment(ticket);
    //   }
    //   case constants.FN_TICKET_PAYMENT_API_CHANNEL.pingxx: {
    //     if (!chargeId) throw new Error('Ping++渠道需要Ping++凭据号');
    //     // return pingpp.retrieve(chargeId);
    //   }
    //   case constants.FN_TICKET_PAYMENT_API_CHANNEL.微信:
    //     if (!ticket) throw new Error('微信渠道需要凭据号');
    //     // return  wx.queryOrder(ticket);
    //   default:
    //     throw new Error('渠道接口升级，暂无法使用！');
    // }
  }

};