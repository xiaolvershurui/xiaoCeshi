const STOCommodity = require('../../../services/database/store/commodity');
const Joi = require('poolishark').Joi;
const constants = require('../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');

exports.validate = {
  name: Joi.string().required(),
  enable: Joi.boolean(),
  description: Joi.string().required(),
  type: Joi.number(),
  practicalNotice: Joi.string(),
  notice: Joi.string(),
  points: Joi.number(),
  money: Joi.number(),
  coupon: Joi.object({
    name: Joi.string(),
    amount: Joi.number(),
    expires: Joi.number(),
  }),
};

exports.handler = async ({ name, description, type, practicalNotice, notice, points, money, coupon }) => {
  await STOCommodity.create({
    name,
    description,
    type,
    practicalNotice,
    notice,
    points,
    money,
    coupon
  })

};