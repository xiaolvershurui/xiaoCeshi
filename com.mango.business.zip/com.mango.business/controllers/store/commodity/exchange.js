const STOCommodity = require('../../../services/database/store/commodity');
const ACUser = require('../../../services/database/account/user');
const ACWallet = require('../../../services/database/account/wallet');
const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  user: Joi.string().required(),
  id: Joi.string().required()
};
exports.handler = async function ({ user, id }) {
  const commodity = await STOCommodity.findById({ id, selector: '' });
  if (!commodity || !commodity.enable) throw new NotFoundError('不可兑换该优惠券');
  const acUser = await ACUser.findById({ id: user, selector: 'points' });
  if (!acUser.points || acUser.points < commodity.points) throw new BadRequestError('您的积分不足');
  const wallet = await ACWallet.findByUser({ user, selector: 'money' });
  if (commodity.money > 0) {
    if (wallet.money < commodity.money) throw new BadRequestError('您的余额不足');
  }
  switch (commodity.type) {
    case constants.STO_COMMODITY_TYPE.优惠券:
      await this.exec({
        c: 'store/commodity/exchangeCoupon',
        params: {
          id,
          user
        }
      });
      break;
    default:
      break
  }
};