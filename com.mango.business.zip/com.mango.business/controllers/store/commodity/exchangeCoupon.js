const STOCommodity = require('../../../services/database/store/commodity');
const ACUser = require('../../../services/database/account/user');
const ACWallet = require('../../../services/database/account/wallet');
const Joi = require('poolishark').Joi;
const injectTransaction = require('../../../utils/injectTransaction');
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  user: Joi.string().required(),
  id: Joi.string().required()
};
exports.handler = async ({ user, id }, tid, Transaction) => {
  const commodity = await STOCommodity.findById({ id, selector: '' });
  if (!commodity || !commodity.enable) throw new NotFoundError('不可兑换该优惠券');
  const acUser = await ACUser.findById({ id: user, selector: 'points' });
  if (!acUser.points || acUser.points < commodity.points) throw new BadRequestError('您的积分不足');
  const wallet = await ACWallet.findByUser({ user, selector: 'balance' });
  if (commodity.money > 0) {
    if (wallet.balance < commodity.money) throw new BadRequestError('您的余额不足');
  }
  const [userResult, walletResult] = await Transaction.findAndLockEntity({
    tid,
    entities: [{
      id: user,
      model: 'ac_user',
      selector: 'points'
    }, {
      id: wallet._id,
      model: 'ac_wallet',
      selector: 'balance'
    }, {
      model: 'ac_coupon'
    }, {
      model: 'rc_commodity_exchange'
    }]
  });
  await Transaction.commit({
    tid,
    updates: [{
      _id: user,
      $inc: {
        points: -commodity.points
      }
    }, {
      _id: wallet._id,
      $inc: {
        balance: -commodity.money
      }
    }, {
      user,
      name: commodity.coupon.name,
      amount: commodity.coupon.amount,
      expires: new Date(Date.now() + commodity.coupon.expires * 24 * 3600 * 1000)
    }, {
      user,
      commodity,
      beforePoints: userResult.points,
      beforeMoney: walletResult.balance
    }]
  })
};

module.exports = injectTransaction(exports, 'sto_commodity_exchange');
