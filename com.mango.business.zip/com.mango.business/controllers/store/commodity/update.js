const STOCommodity = require('../../../services/database/store/commodity');
const Joi = require('poolishark').Joi;
const BadRequestError = require('../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../com.mango.common/settings/constants');

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object({
    name: Joi.string(),
    enable: Joi.boolean(),
    description: Joi.string(),
    type: Joi.number(),
    practicalNotice: Joi.string(),
    notice: Joi.string(),
    points: Joi.number(),
    money: Joi.number(),
    littleMango: Joi.number(),
    coupon: {
      name: Joi.string(),
      amount: Joi.string(),
      expires: Joi.string(),
    }
  }).required()
};
exports.handler = async function ({ id, data }) {
  const stoCommodity = await STOCommodity.findById({ id, selector: '_id' });
  if (!stoCommodity) throw new NotFoundError('商品不存在');

  return await STOCommodity.update({ id, data })
};