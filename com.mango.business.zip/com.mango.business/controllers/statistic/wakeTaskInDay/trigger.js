const SSWakeTaskInDay = require('../../../services/database/statistic/wakeTaskInDay');
const Joi = require('poolishark').Joi;

exports.validate = {
  issuedAt: Joi.date().required(),
  handleByUser: Joi.boolean().required(),
  region: Joi.string(),
  stock: Joi.string().required(),
  discountRate: Joi.number().required()
};
exports.handler = async ({ issuedAt, handleByUser, region, stock, discountRate }) => {
  const ssWakeTaskInDay = await SSWakeTaskInDay.findOne({
    query: {
      region,
      date: issuedAt.beginning
    },
    selector: 'updatedAt handleByInspection handleByUser stocks'
  });
  if (ssWakeTaskInDay && ssWakeTaskInDay.stocks.includes(stock)) {
    // 解除任务所花时长
    const timeInterval = parseInt((Date.now() - issuedAt.getTime()) / (60 * 60 * 1000));
    let key;
    if (timeInterval <= 24) {
      key = 'inOneDay'
    } else if (timeInterval > 24 && timeInterval <= 48) {
      key = 'inTwoDays'
    } else if (timeInterval > 48 && timeInterval <= 72) {
      key = 'inThreeDays'
    } else if (timeInterval > 72 && timeInterval <= 96) {
      key = 'inFourDays'
    } else if (timeInterval > 96) {
      key = 'moreThenFourDays'
    }
    const prefix = handleByUser ? 'handleByUser' : 'handleByInspection';
    const suffix = discountRate === 1 ? 'normalStock' : 'discountStock';
    await SSWakeTaskInDay.update({
      id: ssWakeTaskInDay._id,
      updatedAt: ssWakeTaskInDay.updatedAt,
      data: {
        [`${prefix}.${key}.${suffix}`]: ssWakeTaskInDay[prefix][key][suffix] ? ssWakeTaskInDay[prefix][key][suffix] + 1 : 1
      }
    })
  }

};