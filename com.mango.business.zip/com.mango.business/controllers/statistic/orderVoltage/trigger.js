const SSOrderVoltage = require('../../../services/database/statistic/orderVoltage');
const Joi = require('poolishark').Joi;
const ODOrder = require('../../../services/database/order/order');
const OTSStockPoint = require('../../../services/ots/stockPoint');

exports.validate = {
  order: Joi.string().required(),
};
exports.handler = async ({ order }) => {
  const { box, lease, startVoltage, endVoltage, region } = await ODOrder.findById({ id: order, selector: 'box lease startVoltage endVoltage region' });
  if (!box) return;
  const startTime = new Date(lease.startTime);
  const endTime = new Date(lease.endTime);
  const startMonth = `0${startTime.getMonth() + 1}0`.slice(-3, -1);
  const startYear = `${startTime.getFullYear()}`;
  const endMonth = `0${endTime.getMonth() + 1}0`.slice(-3, -1);
  const endYear = `${endTime.getFullYear()}`;
  let points = [];
  const boxId = box._id;
  if (startYear !== endYear) {
    const prevPoints = await OTSStockPoint.find({ box_month: `${boxId}_${startYear}12`, time: [startTime, endTime] }, null, { select: ['extra.voltage', 'time'] });
    const nextPoints = await OTSStockPoint.find({ box_month: `${boxId}_${endYear}01`, time: [startTime, endTime] });
    points = prevPoints.concat(nextPoints);
  } else if (startMonth !== endMonth) {
    const prevPoints = await OTSStockPoint.find({ box_month: `${boxId}_${startYear}${startMonth}`, time: [startTime, endTime] }, null, { select: ['extra.voltage', 'time'] });
    const nextPoints = await OTSStockPoint.find({ box_month: `${boxId}_${startYear}${endMonth}`, time: [startTime, endTime] }, null, { select: ['extra.voltage', 'time'] });
    points = prevPoints.concat(nextPoints);
  } else {
    points = await OTSStockPoint.find({ box_month: `${boxId}_${startYear}${startMonth}`, time: [startTime, endTime] }, null, { select: ['extra.voltage', 'time'] });
  }

  const result = points.reduce((memo, item, index) => {
    // 最大电压
    memo.maxVoltage = Math.max(memo.maxVoltage, item.extra.voltage);
    // 最小电压
    memo.minVoltage = Math.min(memo.minVoltage, item.extra.voltage);
    // 改变电压
    let changeVoltage = 0;
    if (index > 0) {
      changeVoltage = item.extra.voltage - points[index - 1].extra.voltage;
    }
    // 电压下降
    if (changeVoltage < 0) {
      if (memo.maxDeclineVoltage.declineVoltage < -changeVoltage) {
        memo.maxDeclineVoltage.declineVoltage = -changeVoltage;
        memo.maxDeclineVoltage.prevVoltage = points[index - 1].extra.voltage;
        memo.maxDeclineVoltage.prevTime = points[index - 1].time;
        memo.maxDeclineVoltage.nextVoltage = item.extra.voltage;
        memo.maxDeclineVoltage.nextTime = item.time;
      }
    } else {
      if (memo.maxRiseVoltage.riseVoltage < changeVoltage) {
        memo.maxRiseVoltage.riseVoltage = changeVoltage;
        memo.maxRiseVoltage.prevVoltage = points[index - 1].extra.voltage;
        memo.maxRiseVoltage.prevTime = new Date(points[index - 1].time);
        memo.maxRiseVoltage.nextVoltage = item.extra.voltage;
        memo.maxRiseVoltage.nextTime = new Date(item.time);
      }
    }
    return memo;
  }, {
    maxVoltage: startVoltage,
    minVoltage: endVoltage,
    maxDeclineVoltage: {
      declineVoltage: 0,
      prevVoltage: 0,
      prevTime: startTime,
      nextVoltage: 0,
      nextTime: startTime,
    },
    // 最大回升电压
    maxRiseVoltage: {
      riseVoltage: 0,
      prevVoltage: 0,
      prevTime: startTime,
      nextVoltage: 0,
      nextTime: startTime,
    },
  });

  await SSOrderVoltage.create({
    data: Object.assign(result, {
      region: region._id,
      date: new Date(lease.startTime),
      order,
      box: boxId,
      startVoltage,
      endVoltage,
    }),
  });
};
