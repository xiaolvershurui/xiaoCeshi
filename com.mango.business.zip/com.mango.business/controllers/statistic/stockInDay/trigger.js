const SSStockInDay = require('../../../services/database/statistic/stockInDay');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
  isValid: Joi.boolean().required(),
  isRenting: Joi.boolean().required(),
  mileageInAll: Joi.number().default(0).required(),
  isOnline: Joi.boolean().required(),
};
exports.handler = async ({ stock, isValid, isRenting, mileageInAll, isOnline }) => {
  const stockInDay = await SSStockInDay.findAndGenerate({
    stock,
    selector: [
      'latestSetInvalidAt latestSetValidAt',
      'latestSetUsingAt latestSetNotUsingAt',
      'latestSetOnlineAt latestSetOfflineAt setOfflineTimes updatedAt',
      'validTime usingTime usingMileage latestSetUsingMileage onlineTime'
    ].join(' ')
  });
  const earliest = new Date(0);
  const {
    latestSetInvalidAt = earliest,
    latestSetValidAt = earliest,
    latestSetUsingAt = earliest,
    latestSetNotUsingAt = earliest,
    latestSetOnlineAt = earliest,
    latestSetOfflineAt = earliest,
    validTime,
    usingTime,
    usingMileage,
    latestSetUsingMileage,
    onlineTime,
    setOfflineTimes
  } = stockInDay;
  const now = new Date();
  const data = {};
  if (isValid) { // 车辆可用
    data.latestSetValidAt = now;
    if (latestSetValidAt.is.over(latestSetInvalidAt)) { // 上次记录可用时间晚于记录不可用时间
      // 则从上次记录可用时间之后，到现在为止都是可用的
      data.validTime = validTime + (now.getTime() - latestSetValidAt.getTime()).msTo.minute;
      data.validTime = data.validTime.toFixed(2);
    }
  } else { // 车辆不可用，则更新记录不可用时间，直到下次可用为止，validTime都不增长
    data.latestSetInvalidAt = now;
  }
  if (isRenting) {
    data.latestSetUsingAt = now;
    data.latestSetUsingMileage = mileageInAll;
    if (latestSetUsingAt.is.over(latestSetNotUsingAt)) {
      data.usingTime = usingTime + (now.getTime() - latestSetUsingAt.getTime()).msTo.minute;
      data.usingMileage = usingMileage + (mileageInAll - latestSetUsingMileage);
      data.usingTime = data.usingTime.toFixed(2);
    }
  } else {
    data.latestSetNotUsingAt = now;
  }
  // 车辆在线
  if (isOnline) {
    data.latestSetOnlineAt = now;
    if (latestSetOnlineAt.is.over(latestSetOfflineAt)) {
      data.onlineTime = onlineTime + (now.getTime() - latestSetOnlineAt.getTime()).msTo.minute;
      data.onlineTime = data.onlineTime.toFixed(2);
    }
  } else {
    data.latestSetOfflineAt = now;
    data.setOfflineTimes = setOfflineTimes || 0;
    if (latestSetOnlineAt.is.over(latestSetOfflineAt)) {
      data.setOfflineTimes += 1;
    }
  }
  await SSStockInDay.update({
    id: stockInDay._id,
    updatedAt: stockInDay.updatedAt,
    data
  });
};