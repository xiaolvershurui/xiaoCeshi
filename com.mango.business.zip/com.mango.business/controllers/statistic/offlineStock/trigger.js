const SSOfflineStock = require('../../../services/database/statistic/offlineStock');
const Joi = require('poolishark').Joi;

exports.validate = Joi.object({
  stock: Joi.string().required(),
  signal: Joi.number().required(),
  simPowerOn: Joi.boolean(),
  isNoPower: Joi.boolean(),
  locate: Joi.number(),
  region: Joi.string(),
}).unknown();

exports.handler = async ({ stock, isOnline, region, signal, simPowerOn, isNoPower, locate }) => {
  const offlineStock = await SSOfflineStock.findAndGenerate({
    stock,
    selector:'offlineCount'
  });
  offlineStock.offlineCount += 1;
  await SSOfflineStock.update({
    id: offlineStock._id,
    updatedAt: offlineStock.updatedAt,
    data: {
      offlineCount: offlineStock.offlineCount,
      isOnline,
      region,
      simPowerOn,
      isNoPower,
      locate
    },
    arrayOp: {
      $push: {
        'offlineSignal': signal
      }
    }
  });
};