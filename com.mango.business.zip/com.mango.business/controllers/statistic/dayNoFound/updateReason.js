const DayNoFound = require('../../../services/database/statistic/dayNoFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  id: Joi.string().required(),
  reason: Joi.string().required()
};
exports.handler = async ({ id, reason }) => {
  return await DayNoFound.update({
    id,
    data: {
      reason
    }
  });
};