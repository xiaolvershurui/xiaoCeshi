const DayNoFound = require('../../../services/database/statistic/dayNoFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
  operator: Joi.string().required()
};

exports.handler = async ({ stock, operator }) => {
  return await DayNoFound.create({
    stock,
    operator
  })
};