const DayFound = require('../../../services/database/statistic/dayFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  id: Joi.string().required(),
  description: Joi.string().required()
};
exports.handler = async ({ id, description }) => {
  return await DayFound.update({
    id,
    data: {
      description
    }
  });
};