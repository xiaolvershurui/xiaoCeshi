const DayFound = require('../../../services/database/statistic/dayFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
  operator: Joi.string().required(),
  noFoundOperator: Joi.string().required()
};
exports.handler = async ({ stock, operator, noFoundOperator }) => {
  return await DayFound.create({
    stock,
    operator,
    noFoundOperator
  })
};