const FinalStockState = require('../../../services/database/statistic/finalStockState');
const Joi = require('poolishark').Joi;

exports.validate = {
  id: Joi.string().required(),
  data: Joi.object(),
  arrayOp: Joi.object().required()
};
exports.handler = async ({ id, data, arrayOp }) => {
  await FinalStockState.update({
    id,
    data,
    arrayOp,
  })
};