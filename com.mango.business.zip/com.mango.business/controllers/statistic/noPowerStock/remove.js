const NoPowerStock = require('../../../services/database/statistic/noPowerStock');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
};
exports.handler = async ({ stock }) => {
  const noPowerStock = await NoPowerStock.findOneByStock({ stock });
  if (noPowerStock) {
    await NoPowerStock.remove({id: noPowerStock._id});
  }
};