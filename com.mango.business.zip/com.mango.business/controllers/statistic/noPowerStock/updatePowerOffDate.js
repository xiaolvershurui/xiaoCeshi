const SSNoPowerStock = require('../../../services/database/statistic/noPowerStock');
const Joi = require('poolishark').Joi;

exports.validate = {
  locate: Joi.number(),
  stock: Joi.string().required(),
  simPowerOn: Joi.boolean(),
  isNoPower: Joi.boolean(),
  isOnline: Joi.boolean(),
};

exports.handler = async ({ stock, powerOffDate, simPowerOn, isNoPower, isOnline, locate }) => {
  const noPowerStock = await SSNoPowerStock.findOneByStock({
    stock,
    selector: 'powerOffDate updatedAt'
  });
  if (noPowerStock && !noPowerStock.powerOffDate) {
    await SSNoPowerStock.update({
      id: noPowerStock._id,
      updatedAt: noPowerStock.updatedAt,
      data: {
        powerOffDate: Date.now(),
        simPowerOn,
        isNoPower,
        isOnline,
        locate
      }
    });
  }
};