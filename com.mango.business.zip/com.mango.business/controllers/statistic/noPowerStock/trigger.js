const NoPowerStock = require('../../../services/database/statistic/noPowerStock');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
  locate: Joi.number().required(),
};
exports.handler = async ({ stock, locate }) => {
  const noPowerStock = await NoPowerStock.findOneByStock({ stock });
  if (!noPowerStock) {
    await NoPowerStock.create({ stock, locate })
  }
};