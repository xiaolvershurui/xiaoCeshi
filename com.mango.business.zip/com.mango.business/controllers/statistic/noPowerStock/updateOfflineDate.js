const SSNoPowerStock = require('../../../services/database/statistic/noPowerStock');
const Joi = require('poolishark').Joi;

exports.validate = {
  locate: Joi.number(),
  stock: Joi.string().required(),
  simPowerOn: Joi.boolean(),
  isNoPower: Joi.boolean(),
  isOnline: Joi.boolean(),
};

exports.handler = async ({ stock, offlineDate, simPowerOn, isNoPower, isOnline, locate }) => {
  const noPowerStock = await SSNoPowerStock.findOneByStock({
    stock,
    selector: 'offlineDate updatedAt'
  });
  if (noPowerStock && !noPowerStock.offlineDate) {
    await SSNoPowerStock.update({
      id: noPowerStock._id,
      updatedAt: noPowerStock.updatedAt,
      data: {
        locate,
        simPowerOn,
        isNoPower,
        isOnline,
        offlineDate: Date.now(),
      }
    });
  }
};