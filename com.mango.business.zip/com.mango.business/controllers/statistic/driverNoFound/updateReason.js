const DriverNoFound = require('../../../services/database/statistic/driverNoFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  id: Joi.string().required(),
  reason: Joi.string().required()
};
exports.handler = async ({ id, reason }) => {
  return await DriverNoFound.update({
    id,
    data: {
      reason
    }
  });
};