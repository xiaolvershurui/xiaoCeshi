const DriverNoFound = require('../../../services/database/statistic/driverNoFound');
const Joi = require('poolishark').Joi;

exports.validate = {
  stock: Joi.string().required(),
  operator: Joi.string().required()
};
exports.handler = async ({ stock, operator }) => {
  return await DriverNoFound.create({
    stock,
    operator
  })
};