const Joi = require('poolishark').Joi;
const TFVideo = require('../../../services/database/traffic/video');
const StudyTFVideo = require('../../../services/database/record/studyTfVideo');
const TFHistoryVideo = require('../../../services/database/traffic/historyVideo');
const NotFoundError = require('../../../com.mango.common/errors/NotFoundError');

exports.validate = {
  user: Joi.string().description('用户'),
  query: Joi.object().description('查询参数'),
  limit: Joi.number().empty('').description('查询条数'),
  sort: Joi.object().empty('').description('查询条件'),
  skip: Joi.number().empty('').description('跳过条数'),
  selector: Joi.string().empty('').description('字段选择器'),
};

exports.handler = async ({ user, query, limit, sort, skip, selector }) => {

  const videos = await TFVideo.find({ query, limit, sort, skip, selector });
  if (!user) {
    return videos
  } else {
    let historyVideos = await TFHistoryVideo.find({
      query: Object.assign({}, query, { user }),
      limit,
      sort,
      skip,
      selector: 'video expiryTime'
    });
    const historyVideosMap = historyVideos.reduce((memo, item) => {
      if (Date.now() < item.expiryTime.getTime()) {
        memo[item.video] = item.video;
      }
      return memo;
    }, {});
    videos.forEach(video => {
      video.isWatched = !!historyVideosMap[video._id]
    });
    return videos
  }
};