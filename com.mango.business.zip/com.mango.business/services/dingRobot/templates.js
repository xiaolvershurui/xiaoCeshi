const constants = require('../../com.mango.common/settings/constants');

const divider = '\n-=-=-=-=-=-=-=-=-=-';

const renderLocation = ({ lngLat, address }) => `[${address}](http://m.amap.com/?q=${lngLat[1]},${lngLat[0]})`;

module.exports = {
  emergencyMonitoringNotice: data => {
    const text = data.map(item => {
      return `
        大区：${item && item.region}
        车辆编号：${item && item.bikeId}
        任务类型：${item && item.taskType}
        速度: ${item && item.speed} km/h
        时间：${new Date().format('yyyyMMdd hh:mm:ss')}`;
    }).join('');
    return {
      msgtype: 'markdown',
      markdown: {
        title: '超速警报群',
        text,
      },
    };
  },
  sendScanMonitoring: data => {
    const text = data.map(item => {
      return `
        大区：${item && item.region}
        车辆编号：${item && item.number}
        任务类型：${item && item.taskType}
        时间：${new Date().format('yyyyMMdd hh:mm:ss')}`;
    }).join('');
    return {
      msgtype: 'markdown',
      markdown: {
        title: '离线/无定位/丢失扫码',
        text,
      },
    };
  },
};
