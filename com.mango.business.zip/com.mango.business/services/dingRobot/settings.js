const constants = require('../../com.mango.common/settings/constants');

module.exports.hooks = {
  [constants.RC_NOTIFICATION_TYPE.其他警报]: {
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=b52f72ace54f89ae98792e023d5191ea0da651006f82e472aecc456480f2a803',
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=4c25a4a24c9bd63eb2b20fd7275d76ae0eb95f320972d7461dcc469a31f00eb6',
  },
  [constants.RC_NOTIFICATION_TYPE.巡检预警]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=f42dd4d76424d3f4fd87f42a9440b986fa48c9094080d95b5ffac88d44ef055f',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=d18d8ee8b10aafd28f1cc60f3b9605617c4f52076c52a1f83145bd3572178398'
  },
  [constants.RC_NOTIFICATION_TYPE.低电警报]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=49aca3dd9a99a202b61b578b911ee02d1256aa866e18dc8180896f262448e033',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=7d9a6f08dfc3b3ea5d1eff9ae325b412b607f24e12ab5b9c23a90a09fea15316'
  },
  [constants.RC_NOTIFICATION_TYPE.离线警报]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=a3e379f87835fb272869a612174f1093b43446ecea8dc265685f15c02dde570b',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=e823b6525a027453ec3261802b506dac2eff7759015c9548bba13c4b5060d947'
  },
  [constants.RC_NOTIFICATION_TYPE.断电警报]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=90844d852624a3025b92792c9cc3901b7cf82f2b579eaf5e0be6b7fb64144a46',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=361b8fd3b53363799b94cab0b2795a3de4481da47d06ede74ad173b5b17dec38'
  },
  [constants.RC_NOTIFICATION_TYPE.位移警报]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=aa97bd54b4a9b27b7160fa07866d200fb585b4243364177f4dedccaf99ff7991',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=6fb5615fce66dc4bbc80b51515c613a751a982952d83dc6d61aff730f0ec3035',
  },
  [constants.RC_NOTIFICATION_TYPE.围栏警报]: {
    绵阳大区: 'https://oapi.dingtalk.com/robot/send?access_token=d646cb0e7277f60227598431a947de4a66bcae7d6d7b5e92bd018428417e6513',
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=17293a19182e300783939113a7dad3cc5b588bb7d4f5a69c3cc7dafb43bbf306',
  },
  开发通知: 'https://oapi.dingtalk.com/robot/send?access_token=b8da65f2fc2f73730425b24896d96c38076534019db74378f197e2e4be12069a',
  支付通知: 'https://oapi.dingtalk.com/robot/send?access_token=6c8a3320a5a6fb5468aec3d8b9ca03c5ff8e31172e58bf7c68ca6bf277a12fd6',
  订单通知: 'https://oapi.dingtalk.com/robot/send?access_token=6a6eaba21c7d84bda770debf64aebdc378360f1b7a658094c1afb4ae8ec32937',
  服务器异常: 'https://oapi.dingtalk.com/robot/send?access_token=8aa6f521e13f6d55dbd4dab655c49d198e51c485d9c71f7bea350a41fc250234',
  异常车辆清单: 'https://oapi.dingtalk.com/robot/send?access_token=d3881889b9d3e2652aa04334e4fef5aecaa07b90161c998d7a88bc3013bdba25',
  车辆操作日志: 'https://oapi.dingtalk.com/robot/send?access_token=cfe61dd10bc22ae6d720593aec07ec0b408dee6d6aa71d87243d783dd924774a',
  用户反馈: 'https://oapi.dingtalk.com/robot/send?access_token=19ff367e0ef67983199d54d295a80fe551f9a49f6c2f9bad9c4a18d7559a6960',
  车辆复活: 'https://oapi.dingtalk.com/robot/send?access_token=23338decca9a453cfe804106708f6c548105c4d596a8543433f8055c9aec4ea0',
  任务监控: {
    北京大区: 'https://oapi.dingtalk.com/robot/send?access_token=7dca95433b6ad088a95f328ace6d3cb0f0423abe61c390e9310fa9267cd91534',
    秦皇岛: 'https://oapi.dingtalk.com/robot/send?access_token=becad21c4f62c85fca6e5476a75f6aac5b84ed02579e4f049fe9c22a6371c540',
    武汉大区: 'https://oapi.dingtalk.com/robot/send?access_token=2d74cfbb1288098f8b069c962154e67c8a31be4e9601e76f58c4b39978addc6b',
    中卫市: 'https://oapi.dingtalk.com/robot/send?access_token=359a0796278ce87e7666178ab7dc5e1d126be45db92a2748d1bacbbddc26be24',
    湖州市: 'https://oapi.dingtalk.com/robot/send?access_token=1257dfcf6fb9b7c2124d7054f03893b599224d325396b8e2c1c76e6b994e404c'
  },
  电池监控: 'https://oapi.dingtalk.com/robot/send?access_token=72f26e14ef5437a8ab35252519b4c0bd4633758000dd812667d4702a0903f591',
  电池丢失: 'https://oapi.dingtalk.com/robot/send?access_token=0b25799f53e1cb954855bb7e3a9b5a18dd525d3d69dc67c59d8f72646f12dc12',
  武汉巡检提示: 'https://oapi.dingtalk.com/robot/send?access_token=67dd0296957963a9a0551f27c150f6bee755f47071cea8a9c610f2e4d02ef66e',
  武汉线下打卡: 'https://oapi.dingtalk.com/robot/send?access_token=5787a41376b57c95ff29acfff7f4571bb1f5b90fa382023554c984da45515a9d',
  北京正规巡检群: 'https://oapi.dingtalk.com/robot/send?access_token=154c94f4ecf7ed2668df8c96ec479626327e65bc45aaf16644f281f7c875ab51',
  运营监控: 'https://oapi.dingtalk.com/robot/send?access_token=1fcf7c187e7e85b4c23ea0023e3a3ad156a83df233cfeebe56dac61458911142',
  车辆任务监控: 'https://oapi.dingtalk.com/robot/send?access_token=495372b79fdf518c423a3c859ae55480ac22424dee67bb86a73787abf47637b1',
  出围栏及断电监控: 'https://oapi.dingtalk.com/robot/send?access_token=05adcb7d3d3c5cafe819328e6568c8e9c1f654696903654c8e3dc6a54b6e041c'
};

const testAlarmHook = 'https://oapi.dingtalk.com/robot/send?access_token=12e29c1be368e9ad89acbb2bf1d5cef232e64444284be831ece6178bd3dbb69a';

module.exports.testHooks = {
  [constants.RC_NOTIFICATION_TYPE.其他警报]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.巡检预警]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.低电警报]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.离线警报]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.断电警报]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.位移警报]: {
    武汉大区: testAlarmHook,
  },
  [constants.RC_NOTIFICATION_TYPE.围栏警报]: {
    武汉大区: testAlarmHook,
  },
  支付通知: 'https://oapi.dingtalk.com/robot/send?access_token=21a3f864ab54d1da67fa068539fd4fca084a875686780cdf3fc3c5798315df15',
  订单通知: 'https://oapi.dingtalk.com/robot/send?access_token=cd4ba02e311e91589e6af1f6bddeb242301ba6465bda3a01dc2b2bbb8ebdd015',
  服务器异常: testAlarmHook,
  异常车辆清单: testAlarmHook,
  车辆操作日志: testAlarmHook,
  用户反馈: testAlarmHook,
  车辆复活: testAlarmHook,
  任务监控: {
    北京大区: testAlarmHook,
    秦皇岛: testAlarmHook,
    武汉大区: testAlarmHook
  },
  电池监控: testAlarmHook,
  车辆监控: testAlarmHook,
  电池丢失: testAlarmHook,
  武汉线下打卡: testAlarmHook,
  武汉巡检提示: testAlarmHook,
  运营监控: testAlarmHook,
  车辆任务监控: 'https://oapi.dingtalk.com/robot/send?access_token=495372b79fdf518c423a3c859ae55480ac22424dee67bb86a73787abf47637b1',
  出围栏及断电监控: 'https://oapi.dingtalk.com/robot/send?access_token=05adcb7d3d3c5cafe819328e6568c8e9c1f654696903654c8e3dc6a54b6e041c',
  离线扫码: 'https://oapi.dingtalk.com/robot/send?access_token=575debe30d4abb3d04c3a4f1a9bb900af3d8d7b2331fccde92b1f7106f701669',
};
