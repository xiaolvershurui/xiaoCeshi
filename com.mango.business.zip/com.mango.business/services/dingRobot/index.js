const axios = require('axios');
const instance = axios.create();
const settings = require('./settings');
const isDev = process.env.NODE_ENV !== 'production';
const { asyncTask } = require('xx-utils');
const logger = require('../logger').dingRobot;
const constants = require('../../com.mango.common/settings/constants');
const templates = require('./templates');

class DingRobot {
  send (to, data) {
    if (!to) {
      logger.warn('robot has not initialized');
      return;
    }
    asyncTask(function * () {
      yield instance({
        method: 'post',
        url: to,
        data
      });
    }, error => logger.error({
      error: {
        message: error.message,
        stack: error.stack
      }
    }));
  }

  static get hooks () {
    return isDev ? settings.testHooks : settings.hooks;
  }

  sendEmergencyMonitoring (data) {
    this.send(DingRobot.hooks.出围栏及断电监控, templates.emergencyMonitoringNotice(data))
  }
  sendScanMonitoring (data) {
    this.send(DingRobot.hooks.离线扫码, templates.sendScanMonitoring(data))
  }
}

DingRobot.templates = templates;
module.exports = new DingRobot();
