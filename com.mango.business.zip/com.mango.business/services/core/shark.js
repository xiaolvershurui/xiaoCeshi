const PoolishClient = require('poolish-client').default;

const host = (_ => {
  if (process.env.NODE_ENV === 'production') {
    return '192.168.1.161';
  } else if (process.env.NODE_ENV === 'staging') {
    return '119.23.230.199';
  } else {
    return '119.23.230.199';
  }
})();

const client = new PoolishClient({
  connOptions: `poolish://${host}:4010`,
  poolOptions: {
    maxBorrowTimes: 10000,
    max: 100,
  },
  secret: 'ZeWmsMwsw8eFTSMpndkkaBJNeBRyp3BCtKt6BarahkCre5TtFKxzR8BwYTJ6KdM3',
  sync: true,
});

client.on('error', (error, tag) => {
  console.error(`[CORE] ${error.message}`, tag);
});

module.exports = client;
