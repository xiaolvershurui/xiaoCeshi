const OTS = require('@mangoebike/ots');
// protocol, auth, host, query, pathname
module.exports = new OTS(
  'https://LTAI6WtHRhXW2bBG:n7iaAdjXNXGcOGTtHRC0kILPIUbHaR@mango-point.cn-shenzhen.ots.aliyuncs.com/battery_stock_point',
  {
    battery_stock: { type: String, required: true },
    time: { type: Number, required: true },
    box: { type: String, required: true },
    _id: { type: Number, required: true, autoIncrement: true },
    createdAt: Date,
    updatedAt: Date,
    region: [String, null],
    stock: [String, null],
    acc: Boolean,
    lock: Boolean,
    extra: Object,
    gps: Object,
  },
  ['battery_stock', 'time', 'box', '_id']);

// 时间 time
// 电池ID battery
// GPS编号（车辆上的车机的imei）box
// 车辆ID stock
// 电压  extra.voltage
// 里程  extra.mileageInAll
// 速度  gps.speed
// acc（电门） acc
// 设防（lock）lock
// 位置  gps.gpsLngLat
// 朝向  gps.direction
