const StockPoint = require('../stockPoint');
const fs = require('fs');
const moment = require('moment');

(async () => {
  const ret = await StockPoint.find({
    box_month: '868183030912096_201806',
    time: [new Date('2018-06-06 14:15:35').getTime(), new Date('2018-06-06 14:35:18').getTime()],
  }, undefined, {
    select: [
      'time',
      'acc',
      'extra.voltage',
      'gps.speed',
      'powerUnlink',
      'lock',
      'wheelLock',
    ],
  });

  let data = [
    'time',
    'acc',
    'speed',
    'voltage',
    'lock',
    'wheelLock',
    '\n',
  ].join(',');
  ret.forEach(item => {
    data += [
      moment(item.time).format('MM:DD HH:mm:ss.SSS'),
      item.acc,
      item.gps && item.gps.speed,
      item.extra && item.extra.voltage,
      item.lock,
      item.wheelLock,
      '\n',
    ].join(',');
  });
  fs.writeFileSync('data.csv', data);
})();
