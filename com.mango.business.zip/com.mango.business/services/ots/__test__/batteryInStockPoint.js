const BatteryInStockPoint = require('../batteryInStockPoint');
const fs = require('fs');
const moment = require('moment');

(async () => {
  const ret = await BatteryInStockPoint.find({
    battery_month: ['1803230958482_201804', '1803230958482_201804'],
  }, undefined, {
    select: ['time', 'acc', 'extra.voltage', 'extra.mileageInAll'],
  });

  fs.writeFileSync('data_array_acc_false', JSON.stringify(ret.filter(v => v.extra && v.extra.mileageInAll >= 185493.87300000043 && v.extra.voltage > 40 && !v.acc).map(row => {
    return [row.extra.voltage, (row.extra.mileageInAll - 185493.87300000043) / 1000];
  })))

  // fs.writeFileSync('data.csv', ret.map(row => [
  //   moment(row.time).format('MM-DD_HH:mm:ss.SSS'),
  //   row.acc,
  //   row.extra && row.extra.voltage,
  //   row.extra && row.extra.mileageInAll,
  // ].join(',')).join('\n'));
  // console.log(ret);
})();
