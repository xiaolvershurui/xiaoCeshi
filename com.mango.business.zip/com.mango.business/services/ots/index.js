const OTSBatteryInStockPoint = require('./batteryInStockPoint');
const OTSStockPoint = require('./stockPoint');
const BadRequestError = require('../../com.mango.common/errors/BadRequestError');

class RecursionEnhancer {

  constructor (otsEntity) {
    this._otsEntity = otsEntity;
    this._autoIncrementKey = this._getAutoIncrementKey();
  }

  _getAutoIncrementKey () {
    const autoIncrementKey = Object.keys(this._otsEntity.__schema).find(item => !!this._otsEntity.__schema[item].autoIncrement);
    if (!autoIncrementKey) throw new BadRequestError('no valid autoIncrementKey');
    return autoIncrementKey;
  }

  async find ({ primaryQuery, query, select, limit = 500 }) {
    let ret = await this._otsEntity.find(primaryQuery, query, { select, limit });
    if (ret.length === limit) {
      const lastItem = ret[ret.length - 1];
      const nextRet = await this.find({
        primaryQuery: this._otsEntity.__pk.reduce((memo, key) => {
          memo[key] = [lastItem[key], primaryQuery[key] ? primaryQuery[key][1] : undefined];
          if (key === this._autoIncrementKey) {
            memo[key][0] += 1;
          }
          return memo;
        }, {}), query, select, limit,
      });
      ret = ret.concat(nextRet);
    }
    return ret;
  }
}

module.exports = {
  batteryInStockPoint: new RecursionEnhancer(OTSBatteryInStockPoint),
  stockPoint: new RecursionEnhancer(OTSStockPoint),
};
