const shark = require('../shark');

exports.update = ({ id, updatedAt, data }) => {
  shark.send({
    c: 'record/userExperience/update',
    params: { id, updatedAt, data }
  });
};
exports.findByOrder = async ({ order, selector }) => {
  return await shark.sendSync({
    c: 'record/userExperience/findOne',
    params: {
      query: { order },
      selector
    }
  });
};