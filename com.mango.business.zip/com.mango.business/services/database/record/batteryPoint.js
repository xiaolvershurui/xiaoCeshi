const shark = require('../shark');

exports.create = data => {
  return shark.send({
    c: 'record/batteryPoint/create',
    params: data
  });
};