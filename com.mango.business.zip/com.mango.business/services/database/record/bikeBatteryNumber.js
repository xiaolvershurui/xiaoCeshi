const shark = require('../shark');

exports.create = ({ region, inputNumbers, actual }) => {
  return shark.sendSync({
    c: 'record/bikeBatteryNumber/create',
    params: { region, inputNumbers, actual }
  });
};