const shark = require('../shark');

exports.create = data => {
  shark.send({
    c: 'record/stockPoint/create',
    params: data
  });
};

exports.findPathWithGPSInfo = async ({ box, startTime, endTime }) => {
  return await shark.sendSync({
    c: 'record/stockPoint/findPathWithGPSInfo',
    params: {
      box, startTime, endTime
    }
  });
};

exports.findPath = async ({ box, startTime, endTime }) => {
  return await shark.sendSync({
    c: 'record/stockPoint/findPath',
    params: {
      box, startTime, endTime
    }
  });
};