const shark = require('../shark');

exports.genId = async _ =>{
  return await shark.sendSync({
    c: 'record/polygonOp/genId'
  });
};