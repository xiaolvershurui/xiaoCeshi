const shark = require('../shark');

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'record/stockRepair/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};
