const shark = require('../shark');

exports.create = async ({ region, stock, order, lngLat, type, speed, accOn, voltage }) => {
  return await shark.sendSync({
    c: 'record/powerUnlink/create',
    params: { region, stock, order, lngLat, type, speed, accOn, voltage }
  });
};
