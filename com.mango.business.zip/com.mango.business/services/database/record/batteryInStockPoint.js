const shark = require('../shark');

exports.create = async data => {
  return await shark.sendSync({
    c: 'record/batteryInStockPoint/create',
    params: data,
  });
};

exports.findOne = async ({ query, sort, skip, selector }) => {
  return await shark.sendSync({
    c: 'record/batteryInStockPoint/findOne',
    params: {
      query,
      sort,
      skip,
      selector,
    },
  });
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'record/batteryInStockPoint/update',
    params: {
      id,
      updatedAt,
      data,
      arrayOp
    },
  });
};
