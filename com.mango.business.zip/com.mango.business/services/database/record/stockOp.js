const shark = require('../shark');

exports.create = async ({ data }) => {
  return await shark.send({
    c: 'record/stockOp/create',
    params: { data },
  });
};

exports.createStockOp = async (data) => {
  return await shark.send({
    c: 'record/stockOp/create',
    params: {
      data,
    },
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'record/stockOp/genId',
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'record/stockOp/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};

exports.findNewest = async ({ query, selector }) => {
  return await shark.sendSync({
    c: 'record/stockOp/findNewest',
    params: { query, selector },
  });
};
