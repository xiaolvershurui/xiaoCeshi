const shark = require('../shark');

exports.find = async ({query, sort, skip, limit, selector, populateSelector }) => {
   return await shark.sendSync({
    c: 'record/operatorCapture/find',
    params: { query, sort, skip, limit, selector, populateSelector }
  });
};
