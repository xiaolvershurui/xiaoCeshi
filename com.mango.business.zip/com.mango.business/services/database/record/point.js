const shark = require('../../database/shark');

exports.findLastByUser = async ({ user, selector }) => {
  return await shark.sendSync({
    c: 'record/point/findOne',
    params: {
      query: {
        user
      },
      sort: { _id: -1 },
      selector
    }
  });
};
