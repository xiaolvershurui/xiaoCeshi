const shark = require('../shark');

exports.findOne = async params => {
  return await shark.sendSync({
    c: 'record/userCapture/findOne',
    params
  });
};
