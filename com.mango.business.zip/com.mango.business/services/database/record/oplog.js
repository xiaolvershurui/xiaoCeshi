const shark = require('../shark');

exports.createStockOp = ({
  operator,
  stockId,
  description,
  params,
  code
}) => {
  shark.send({
    c: 'record/oplog/createStockOp',
    params: {
      operator,
      stockId,
      description,
      params,
      code
    }
  });
};