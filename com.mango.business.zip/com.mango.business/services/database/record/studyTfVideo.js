const shark = require('../shark');

exports.create = ({ date, user, video, scoreBefore, scoreAfter, scoreCount, expiryTime }) => {
  shark.send({
    c: 'record/studyTfVideo/create',
    params: { date, user, video, scoreBefore, scoreAfter, scoreCount, expiryTime }
  });
};