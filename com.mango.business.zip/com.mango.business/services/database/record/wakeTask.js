const shark = require('../shark');

exports.findOne = async ({ query, sort, selector }) => {
  return await shark.sendSync({
    c: 'record/wakeTask/findOne',
    params: { query, sort, selector }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'record/wakeTask/update',
    params: { id, updatedAt, data }
  });
};