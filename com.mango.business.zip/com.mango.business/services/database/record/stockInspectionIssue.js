const shark = require('../shark');

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'record/stockInspectionIssue/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'record/stockInspectionIssue/findById',
    params: { id, selector, populateSelector },
  });
};

exports.create =  async ({ region, stock, reason, reasonExtra, creator, hasFound, inspectionType  }) => {
  return await shark.sendSync({
    c: 'record/stockInspectionIssue/create',
    params: { region, stock, reason, reasonExtra, creator, hasFound, inspectionType  },
  });
};
