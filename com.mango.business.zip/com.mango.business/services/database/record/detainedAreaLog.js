const shark = require('../shark');

exports.create = async ({ detainedArea, logType, mark }) => {
  return await shark.sendSync({
    c: 'record/detainedAreaLog/create',
    params: { detainedArea, logType, mark },
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'record/detainedAreaLog/genId',
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'record/detainedAreaLog/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  });
};
