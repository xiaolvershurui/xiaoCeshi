const shark = require('../shark');

exports.create = (user, operator, checkedAt, type, location ,isForceCheckIn) => {
  shark.send({
    c: 'record/checkIn/create',
    params: { data:{user, operator, checkedAt, type, location ,isForceCheckIn} }
  });
};

exports.findOne = ({ query, sort, selector }) => {
  shark.send({
    c: 'record/checkIn/findOne',
    params: { query, sort, selector }
  });
};