const shark = require('../shark');

exports.create = async data => {
  return await shark.sendSync({
    c: 'record/batteryOp/create',
    params: data,
  });
};

exports.findOne = async data => {
  return await shark.sendSync({
    c: 'record/batteryOp/findOne',
    params: data,
  });
};
