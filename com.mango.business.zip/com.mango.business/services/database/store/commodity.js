const shark = require('../shark');

exports.findById = async ({ id, selector }) => {
  return await shark.sendSync({
    c: 'store/commodity/findById',
    params: { id, selector },
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'store/commodity/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};

exports.create = async ({ name, description, type, practicalNotice, notice, points, money, coupon }) => {
  return await shark.sendSync({
    c: 'store/commodity/create',
    params: { name, description, type, practicalNotice, notice, points, money, coupon },
  });
};

exports.update = async ({ id, data, updatedAt }) => {
  return await shark.sendSync({
    c: 'store/commodity/update',
    params: { id, data, updatedAt },
  });
};