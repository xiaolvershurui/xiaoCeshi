const shark = require('./shark');

exports.initialize = async ({ action, biz }) => {
  return await shark.sendSync({
    c: 'transaction/initialize',
    params: { action, biz }
  });
};

exports.cancel = ({ tid, error }) => {
  shark.send({
    c: 'transaction/cancel',
    params: { tid, error }
  });
};

exports.commit = async ({ tid, updates }) => {
  await shark.sendSync({
    c: 'transaction/commit',
    params: { tid, updates }
  });
};

exports.findAndLockEntity = async ({ tid, entities }) => {
  return await shark.sendSync({
    c: 'transaction/findAndLockEntity',
    params: { tid, entities }
  });
};