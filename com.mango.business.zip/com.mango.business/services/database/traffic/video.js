const shark = require('../shark');

exports.findById = async ({ id, selector }) => {
  return await shark.sendSync({
    c: 'traffic/video/findById',
    params: { id, selector }
  })
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'traffic/video/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  })
};