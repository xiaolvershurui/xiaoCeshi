const shark = require('../shark');

exports.findByUserAndVideo = async ({ user, video, selector }) => {
  return await shark.sendSync({
    c: 'traffic/historyVideo/findByUserAndVideo',
    params: { user, video, selector }
  })
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'traffic/historyVideo/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  })
};

exports.create = async ({ user, video, expiryTime }) => {
  return await shark.sendSync({
    c: 'traffic/historyVideo/create',
    params: { user, video, expiryTime}
  })
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'traffic/historyVideo/update',
    params: { id, updatedAt, data }
  })
};