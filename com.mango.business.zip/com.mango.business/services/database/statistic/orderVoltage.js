const shark = require('../shark');

exports.create = async (data) => {
  return await shark.sendSync({
    c: 'statistic/orderVoltage/create',
    params: data
  });
};
