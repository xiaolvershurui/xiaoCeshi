const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.findAndGenerate = async ({ stock, selector }) => {
  return await shark.sendSync({
    c: 'statistic/offlineStock/findAndGenerate',
    params: { stock, selector }
  });
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  await shark.sendSync({
    c: 'statistic/offlineStock/update',
    params: { id, updatedAt, data, arrayOp }
  });
};