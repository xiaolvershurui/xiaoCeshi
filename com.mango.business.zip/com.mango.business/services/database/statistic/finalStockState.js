const shark = require('../shark');

exports.find = async ({ query, sort, limit, skip, selector }) => {
  return await shark.sendSync({
    c: 'statistic/finalStockState/find',
    params: {
      query,
      sort,
      limit,
      skip,
      selector
    }
  });
};

exports.findByRegionAndDate = async ({ region, date, selector }) => {
  return await shark.sendSync({
    c: 'statistic/finalStockState/findOne',
    params: {
      query: {
        region,
        date
      },
      selector
    }
  });
};


exports.update = async ({ id, data, updatedAt, arrayOp }) => {
  return await shark.sendSync({
    c: 'statistic/finalStockState/update',
    params: {
      id, data, updatedAt, arrayOp
    }
  });
};
