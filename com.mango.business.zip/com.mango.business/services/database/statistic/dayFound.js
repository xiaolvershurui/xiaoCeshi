const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.create = async ({ stock, operator, noFoundOperator }) => {
  return await shark.sendSync({
    c: 'statistic/dayNoFound/create',
    params: { stock, operator, noFoundOperator }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'statistic/dayNoFound/update',
    params: { id, updatedAt, data }
  });
};