const shark = require('../shark');

exports.create = async ({ stock, locate }) => {
  return await shark.sendSync({
    c: 'statistic/noPowerStock/create',
    params: { stock, locate }
  });
};


exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'statistic/noPowerStock/update',
    params: {
      id,
      updatedAt,
      data
    }
  });
};


exports.remove = async ({ id }) => {
  await shark.sendSync({
    c: 'statistic/noPowerStock/remove',
    params: { id }
  });
};

exports.findOneByStock = async ({ stock, selector }) => {
  return await shark.sendSync({
    c: 'statistic/noPowerStock/findOneByStock',
    params: { stock, selector }
  });
};