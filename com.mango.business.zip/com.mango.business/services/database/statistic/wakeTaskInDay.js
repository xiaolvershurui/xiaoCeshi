const shark = require('../shark');

exports.findOne = async ({ query, sort, selector }) => {
  return await shark.sendSync({
    c: 'statistic/wakeTaskInDay/findOne',
    params: { query, sort, selector }
  });
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  await shark.sendSync({
    c: 'statistic/wakeTaskInDay/update',
    params: { id, updatedAt, data, arrayOp }
  });
};