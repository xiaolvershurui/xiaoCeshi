const shark = require('../shark');

exports.create = async ({ stock, stockNo, type, location, locate, voltage, time }) => {
  return await shark.sendSync({
    c: 'statistic/offlineTime/create',
    params: { stock, stockNo, type, location, locate, voltage, time }
  });
};