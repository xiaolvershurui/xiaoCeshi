const shark = require('../shark');

exports.findAndGenerate = async ({ stock, selector }) => {
  return await shark.sendSync({
    c: 'statistic/stockInDay/findAndGenerate',
    params: { stock, selector }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'statistic/stockInDay/update',
    params: { id, updatedAt, data }
  });
};