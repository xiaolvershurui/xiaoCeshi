const shark = require('../shark');

exports.findOne = async ({ query, selector }) => {
  return await shark.sendSync({
    c: 'statistic/keyTarget/findOne',
    params: { query, selector }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'statistic/keyTarget/update',
    params: { id, updatedAt, data }
  });
};