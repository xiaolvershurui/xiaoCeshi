const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.create = async ({ stock, operator }) => {
  return await shark.sendSync({
    c: 'statistic/driverNoFound/create',
    params: { stock, operator }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'statistic/driverNoFound/update',
    params: { id, updatedAt, data }
  });
};