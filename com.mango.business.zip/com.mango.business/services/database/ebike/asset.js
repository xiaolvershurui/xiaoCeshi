const shark = require('../shark');

exports.find = async ({ query, selector, limit, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/asset/find',
    params: { query, selector, limit, populateSelector }
  });
};

exports.findAndGenerate = async ({ station, region, asset, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/asset/findAndGenerate',
    params: { station, region, asset, selector, populateSelector }
  });
};

exports.create = async (data) => {
  return await shark.sendSync({
    c: 'ebike/asset/create',
    params: data
  })
};

exports.count = async ({ query }) => {
  return await shark.sendSync({
    c: 'ebike/asset/count',
    params: {
      query
    }
  })
};

exports.findByCodeAndStation = async ({ code, station, selector }) => {
  return await shark.sendSync({
    c: 'ebike/asset/findByCodeAndStation',
    params: { code, station, selector }
  });
};

exports.findByStationAssets = async ({ station, assets, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/asset/findByStationAssets',
    params: { station, assets, selector, populateSelector }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'ebike/asset/update',
    params: {
      id,
      updatedAt,
      data
    }
  })
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/asset/findById',
    params: { id, selector, populateSelector }
  });
};