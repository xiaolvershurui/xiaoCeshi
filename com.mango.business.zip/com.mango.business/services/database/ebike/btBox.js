const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.findByIdAndGenerate = async ({ deviceId, dataSource, selector, cache }) => {
  return await shark.sendSync({
    c: 'ebike/btBox/findByIdAndGenerate',
    params: { deviceId, dataSource, selector, cache }
  });
};

exports.update = ({ id, updatedAt, data }) => {
  shark.send({
    c: 'ebike/btBox/update',
    params: { id, updatedAt, data }
  });
};

exports.updateSync = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'ebike/btBox/update',
    params: { id, updatedAt, data }
  });
};