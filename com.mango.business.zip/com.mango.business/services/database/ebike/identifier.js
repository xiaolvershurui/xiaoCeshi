const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');
const hookoo = require('../../../com.mango.common/utils/hookoo');

exports.findOne = async ({ query, selector, cache }) => {
  return await shark.sendSync({
    c: 'ebike/identifier/findOne',
    params: { query, selector, cache }
  });
};
