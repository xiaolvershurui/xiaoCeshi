const shark = require('../shark');

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'ebike/stockDetained/genId',
  });
};

exports.find = async ({ query, limit, sort, skip }) => {
  return await shark.sendSync({
    c: 'ebike/stockDetained/find',
    params: { query, limit, sort, skip }
  });
};
