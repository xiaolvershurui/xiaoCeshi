const shark = require('../shark');

exports.updateSync = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'ebike/battery/update',
    params: { id, updatedAt, data }
  });
};

exports.update = ({ id, updatedAt, data }) => {
  shark.send({
    c: 'ebike/battery/update',
    params: { id, updatedAt, data }
  });
};

exports.findByBox = async ({ box, selector, cache }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findByBox',
    params: {
      box,
      selector,
      cache
    }
  });
};

exports.findByCode = async ({ code, selector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findByCode',
    params: {
      code,
      selector,
    }
  });
};

exports.findByCodes = async ({ codes, selector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findByCodes',
    params: {
      codes,
      selector,
    }
  });
};

exports.findByCodesAndStation = async ({ codes, station, selector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findByCodesAndStation',
    params: {
      codes,
      station,
      selector,
    }
  });
};

exports.findByIds = async ({ ids, selector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findByIds',
    params: {
      ids,
      selector,
    }
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/findById',
    params: {
      id, selector, populateSelector
    }
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/battery/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'ebike/battery/genId',
  });
};
