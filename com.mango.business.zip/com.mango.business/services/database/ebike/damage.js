const shark = require('../shark');

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/damage/findById',
    params: { id, selector, populateSelector }
  });
};