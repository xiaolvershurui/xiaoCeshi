const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');
const hookoo = require('../../../com.mango.common/utils/hookoo');

exports.findByBox = async ({ box, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/findByBox',
    params: { box, selector, cache, populateSelector },
  });
};

exports.count = async ({ query }) => {
  return await shark.sendSync({
    c: 'ebike/stock/count',
    params: { query },
  });
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/findById',
    params: { id, selector, cache, populateSelector },
  });
};

exports.findByNumber = async ({ number, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/findByNumber',
    params: { number, selector, cache, populateSelector },
  });
};

exports.findByVin = async ({ vin, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/findByVin',
    params: { vin, selector, cache, populateSelector },
  });
};

exports.find = async ({ query, limit, sort, selector, populateSelector, skip }) => {
  return await shark.sendSync({
    c: 'ebike/stock/find',
    params: { query, limit, sort, selector, populateSelector, skip },
  });
};

exports.findByInspector = async ({ inspector, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/find',
    params: {
      query: {
        inspector,
      },
      limit: 0,
      selector,
      cache,
      populateSelector,
    },
  });
};

// update方法不做更新后钩子，避免循环
exports.update = ({ id, updatedAt, data }) => {
  shark.send({
    c: 'ebike/stock/update',
    params: {
      id, data, updatedAt,
    },
  });
};

exports.updateSync = async ({ id, updatedAt, data }, exec) => {
  await shark.sendSync({
    c: 'ebike/stock/update',
    params: { id, updatedAt, data },
  });
  // hookoo.emit('ebike/stock/afterUpdate', { id });
  await exec({
    c: 'ebike/stock/afterUpdate',
    params: { id },
  });
};

exports.findByBattery = async ({ battery, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'ebike/stock/findByBattery',
    params: { battery, selector, populateSelector },
  });
};
