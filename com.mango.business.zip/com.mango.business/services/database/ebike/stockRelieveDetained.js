const shark = require('../shark');

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'ebike/stockRelieveDetained/genId',
  });
};

