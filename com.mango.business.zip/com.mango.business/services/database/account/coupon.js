const shark = require('../shark');

exports.findValid = async ({ user, amount, type, selector }) => {
  return await shark.sendSync({
    c: 'account/coupon/findValid',
    params: { user, amount, type, selector }
  });
};

exports.create = async ({ state, user, name, type, amount, expires }) => {
  return await shark.sendSync({
    c: 'account/coupon/create',
    params: { state, user, name, type, amount, expires }
  });
};