const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.findMatchedInspector = async ({ lngLat, region, taskGroup, inspectionArea }) => {
  return await shark.sendSync({
    c: 'account/operator/findMatchedInspector',
    params: { lngLat, region, taskGroup, inspectionArea }
  });
};

exports.findByUser = async ({ user, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'account/operator/findByUser',
    params: { user, selector, cache, populateSelector }
  });
};

exports.findById = async ({ id, selector, populateSelector, cache }) => {
  return await shark.sendSync({
    c: 'account/operator/findById',
    params: { id, selector, populateSelector, cache }
  });
};

exports.findByUsedColors = async ({ regions }) => {
  return await shark.sendSync({
    c: 'account/operator/findByUsedColors',
    params: { regions }
  });
};


exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'account/operator/update',
    params: { id, updatedAt, data }
  });
};

exports.findUsedColors = async regions => {
  return await shark.sendSync({
    c: 'account/operator/findUsedColors',
    params: { regions }
  });
};

exports.update = async ( {id, updatedAt, data} ) => {
  return await shark.sendSync({
    c: 'account/operator/update',
    params: { id, updatedAt, data }
  });
};

exports.find = async ( {query, selector, limit ,sort} ) => {
  return await shark.sendSync({
    c: 'account/operator/find',
    params: { query, selector, limit ,sort }
  });
};