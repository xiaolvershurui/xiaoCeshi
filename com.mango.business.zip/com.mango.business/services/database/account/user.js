const shark = require('../shark');

exports.findByTel = async ({ tel, selector, cache }) => {
  return await shark.sendSync({
    c: 'account/user/findByTel',
    params: { tel, selector, cache }
  });
};

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'account/user/findById',
    params: { id, selector, cache }
  });
};

exports.update = async ({ id, data, arrayOp, cache, selector}) => {
  return await shark.sendSync({
    c: 'account/user/update',
    params: { id, arrayOp, data , cache, selector }
  });
};