const shark = require('../shark');

exports.findByUser = async ({ user,selector }) => {
  return await shark.sendSync({
    c: 'account/wallet/findByUser',
    params: { user, selector, cache:{
     enable: false
    }}
  });
};