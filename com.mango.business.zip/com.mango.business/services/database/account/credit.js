const shark = require('../shark');

exports.find = async ({ query, selector, limit ,populateSelector }) => {
  return await shark.sendSync({
    c: 'account/credit/find',
    params: {  query, selector, limit ,populateSelector }
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'account/credit/findById',
    params: { id, selector, populateSelector, cache:{
      enable: false
    }}
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'account/credit/genId',
  });
};