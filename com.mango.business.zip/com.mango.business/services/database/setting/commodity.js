const shark = require('../shark');

exports.create = async ({ user, year, month, commodity }) => {
  return await shark.sendSync({
    c: 'setting/commodity/create',
    params: { user, year, month, commodity }
  })
};

exports.update = async ({ id, data, updatedAt }) => {
  return await shark.sendSync({
    c: 'setting/commodity/update',
    params: { id, data, updatedAt }
  })
};

exports.findById = async ({ id, selector }) => {
  return await shark.sendSync({
    c: 'setting/commodity/findById',
    params: { id, selector }
  })
};

exports.find = async ({ query, limit ,sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/commodity/find',
    params: { query, limit ,sort, skip, selector, populateSelector }
  })
};

