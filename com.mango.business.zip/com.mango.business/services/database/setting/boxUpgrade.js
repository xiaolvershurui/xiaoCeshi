const shark = require('../shark');

exports.findByVersion = async ({ version, selector }) => {
  return await shark.sendSync({
    c: 'setting/boxUpgrade/findByVersion',
    params: {
      version,
      selector
    }
  });
};

exports.findById = async ({ id, selector }) => {
  return await shark.sendSync({
    c: 'setting/boxUpgrade/findById',
    params: {
      id,
      selector
    }
  });
};

exports.create = async ({ version, packVersion, enable }) => {
  return await shark.sendSync({
    c: 'setting/boxUpgrade/create',
    params: {
      version,
      packVersion,
      enable
    }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'settings/boxUpgrade/update',
    params: {
      id,
      updatedAt,
      data
    }
  });
};