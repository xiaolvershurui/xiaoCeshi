const STSUrl = require('../surl');

(async _ => {
  const url = 'http://192.168.1.181:4004/orderIllegal/1710241223005?selector=';
  const surl = await STSUrl.findSUrl(url);
  console.log(surl);
  console.log(await STSUrl.findUrl(surl));
})().catch(console.error);