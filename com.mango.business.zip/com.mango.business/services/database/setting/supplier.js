const shark = require('../shark');

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'setting/supplier/findById',
    params: { id, selector, cache },
    cache: { enable: true }
  });
};

exports.create = async ({ code, name, contact, tel }) => {
  return await shark.sendSync({
    c: 'setting/supplier/create',
    params: {
      code, name, contact, tel
    },
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'setting/supplier/update',
    params: { id, updatedAt, data },
  });
};

