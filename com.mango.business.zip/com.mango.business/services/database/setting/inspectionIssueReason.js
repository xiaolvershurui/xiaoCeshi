const shark = require('../shark');

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/inspectionIssueReason/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/inspectionIssueReason/findById',
    params: { id, selector, populateSelector },
  });
};
