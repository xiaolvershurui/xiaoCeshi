const shark = require('../shark');

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'setting/inspectionPrice/findById',
    params: { id, selector, cache },
    cache: { enable: true }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'setting/inspectionPrice/update',
    params: { id, updatedAt, data }
  });
};

exports.create = async ({ enable, name, unit }) => {
  return await shark.sendSync({
    c: 'setting/inspectionPrice/create',
    params: { enable, name, unit }
  });
};

