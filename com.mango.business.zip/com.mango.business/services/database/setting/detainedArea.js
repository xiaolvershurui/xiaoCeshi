const shark = require('../shark');

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'setting/detainedArea/findById',
    params: { id, selector, cache },
    cache: { enable: true },
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/detainedArea/find',
    params: { query, limit, sort, skip, selector, populateSelector },
    cache: { enable: true },
  });
};

exports.findOneInScope = async ({ point, minDistance, maxDistance }) => {
  return await shark.sendSync({
    c: 'setting/detainedArea/findOneInScope',
    params: { point, minDistance, maxDistance },
  });
};

exports.create = async ({ number, name, lngLat, address, contact, tel, unit }) => {
  return await shark.sendSync({
    c: 'setting/detainedArea/create',
    params: { number, name, lngLat, address, contact, tel, unit },
  });
};

exports.update = async ({ id, data, updatedAt, arrayOp }) => {
  return await shark.sendSync({
    c: 'setting/detainedArea/update',
    params: { id, data, updatedAt, arrayOp },
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'setting/detainedArea/genId',
  });
};

