const shark = require('../shark');

exports.findSUrl = async url => {
  return await shark.sendSync({
    c: 'setting/surl/findSUrl',
    params: {
      url,
      cache: {
        enable: true,
        extra: ['EX', 3600]
      }
    }
  });
};

exports.findUrl = async surl => {
  return await shark.sendSync({
    c: 'setting/surl/findUrl',
    params: {
      surl,
      cache: {
        enable: true,
        extra: ['EX', 3500]
      }
    }
  });
};