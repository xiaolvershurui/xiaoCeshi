const shark = require('../shark');

exports.find = async ({ query, sort, limit, skip, selector }) => {
  return await shark.sendSync({
    c: 'setting/asset/find',
    params: { query, sort, limit, skip, selector },
    cache: { enable: false }
  })
};

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'setting/asset/findById',
    params: { id, selector, cache },
    cache: { enable: true }
  });
};

exports.findByCodes = async ({ codes, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/asset/findByCodes',
    params: { codes, selector, populateSelector },
    cache: { enable: false }
  });
};

exports.findByCode = async ({ code, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/asset/findByCode',
    params: { code, selector, populateSelector },
    cache: { enable: false }
  });
};


exports.create = async ({ region, station, type, code, count, image, description, group }) => {
  return await shark.sendSync({
    c: 'setting/asset/create',
    params: {
      region, station, type, code, count, image, description, group
    },
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'setting/asset/update',
    params: { id, updatedAt, data },
  });
};

