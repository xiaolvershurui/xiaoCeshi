const shark = require('../shark');

exports.get = async ({ key, cache }) => {
  return await shark.sendSync({
    c: 'setting/config/get',
    params: { key, cache },
    cache: { enable: true }
  });
};

exports.set = async ({ key, value }) => {
  return await shark.sendSync({
    c: 'setting/config/set',
    params: { key, value }
  });
};