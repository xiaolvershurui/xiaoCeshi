const shark = require('../shark');

exports.find = async ({ query, sort, limit, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/repairTeam/find',
    params: { query, sort, limit, skip, selector, populateSelector },
  });
};

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'setting/repairTeam/findById',
    params: { id, selector, cache },
  });
};

exports.findByGroupMember = async ({ groupMember, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'setting/repairTeam/findByGroupMember',
    params: { groupMember, selector, populateSelector },
  });
};
