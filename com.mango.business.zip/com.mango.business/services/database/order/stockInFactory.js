const shark = require('../shark');

exports.findByStoreManager = async ({ storeManager, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/stockInFactory/findByStoreManager',
    params: { storeManager, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/stockInFactory/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ region, station, storeManager, stocks, date, nextTry  }) => {
  return await shark.sendSync({
    c: 'order/stockInFactory/create',
    params: { region, station, storeManager, stocks, date, nextTry }
  })
};

exports.update = async ( { id, updatedAt, data } ) => {
  return await shark.sendSync({
    c: 'order/stockInFactory/update',
    params: { id, updatedAt, data }
  })
};
