const shark = require('../shark');

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetInbound/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetInbound/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, station, region, assets, unitCost }) => {
  return await shark.sendSync({
    c: 'order/assetInbound/create',
    params: { user, station, region, assets, unitCost }
  })
};

exports.update = async ( { id, updatedAt, data } ) => {
  return await shark.sendSync({
    c: 'order/assetInbound/update',
    params: { id, updatedAt, data }
  })
};