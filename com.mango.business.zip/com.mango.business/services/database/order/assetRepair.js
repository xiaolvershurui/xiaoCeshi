const shark = require('../shark');

exports.create = async ({ remark,nextTry, station, region, status, dispenser, assets, createFailed }) => {
  return await shark.sendSync({
    c: 'order/assetRepair/create',
    params: { remark ,nextTry, station, region, dispenser, status, assets, createFailed}
  })
};

exports.findById = async ({ id, selector, populateSelector}) => {
  return await shark.sendSync({
    c: 'order/assetRepair/findById',
    params: { id, selector, populateSelector }
  })
};

exports.update = async ({ id, updatedAt, data}) => {
  return await shark.sendSync({
    c: 'order/assetRepair/update',
    params: { id, updatedAt, data }
  })
};
