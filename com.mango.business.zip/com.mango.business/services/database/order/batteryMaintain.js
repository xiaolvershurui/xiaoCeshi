const shark = require('../shark');

exports.genId = async () => {
  return await shark.sendSync({
    c: 'order/batteryMaintain/genId',
    params: {}
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryMaintain/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryMaintain/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, region, station, batteries }) => {
  return await shark.sendSync({
    c: 'order/batteryMaintain/create',
    params: { user, region, station, batteries }
  })
};

exports.update = async ( { id, updatedAt, data, arrayOp } ) => {
  return await shark.sendSync({
    c: 'order/batteryMaintain/update',
    params: { id, updatedAt, data, arrayOp }
  })
}
