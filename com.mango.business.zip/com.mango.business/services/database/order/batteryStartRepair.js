const shark = require('../shark');

exports.create = async ({ user, region, station, status, nextTry, unknownCount, outboundFailed }) => {
  return await shark.sendSync({
    c: 'order/batteryStartRepair/create',
    params: { user, region, station, status, nextTry, unknownCount, outboundFailed }
  })
};

exports.findById = async ({ id, selector, populateSelector}) => {
  return await shark.sendSync({
    c: 'order/batteryStartRepair/findById',
    params: { id, selector, populateSelector }
  })
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'order/batteryStartRepair/update',
    params: { id, updatedAt, data, arrayOp }
  })
};
