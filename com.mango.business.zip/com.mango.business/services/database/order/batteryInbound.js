const shark = require('../shark');

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryInbound/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryInbound/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, region, station, inboundedAt, unitCost }) => {
  return await shark.sendSync({
    c: 'order/batteryInbound/create',
    params: { user, region, station, inboundedAt, unitCost }
  })
};

exports.update = async ( { id, updatedAt, data } ) => {
  return await shark.sendSync({
    c: 'order/batteryInbound/update',
    params: { id, updatedAt, data }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/batteryInbound/genId',
  });
};
