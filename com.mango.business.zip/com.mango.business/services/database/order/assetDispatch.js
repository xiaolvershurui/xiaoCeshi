const shark = require('../shark');

exports.create = async ({  startStation, endStation, region, dispenser, assets , status, createFailed, nextTry}) => {
  return await shark.sendSync({
    c: 'order/assetDispatch/create',
    params: { startStation, endStation, region, dispenser, assets , status, createFailed, nextTry }
  })
};

exports.find = async ({  query, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetDispatch/find',
    params: { query, selector, populateSelector }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/assetDispatch/genId',
  })
};

exports.findById = async ({  id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetDispatch/findById',
    params: { id, selector, populateSelector }
  })
};

exports.update = async ({ id, data }) => {
  return await shark.sendSync({
    c: 'order/assetDispatch/update',
    params: { id, data}
  })
};