const shark = require('../shark');

exports.create = async ({ user, region, station, status, nextTry, unknownCount, inboundFailed }) => {
  return await shark.sendSync({
    c: 'order/batteryEndRepair/create',
    params: { user, region, station, status, nextTry, unknownCount, inboundFailed }
  })
};

exports.findById = async ({ id, selector, populateSelector}) => {
  return await shark.sendSync({
    c: 'order/batteryEndRepair/findById',
    params: { id, selector, populateSelector }
  })
};

exports.findByUser = async ({ user, status, selector, populateSelector}) => {
  return await shark.sendSync({
    c: 'order/batteryEndRepair/findByUser',
    params: { user, status, selector, populateSelector }
  })
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'order/batteryEndRepair/update',
    params: { id, updatedAt, data, arrayOp }
  })
};
