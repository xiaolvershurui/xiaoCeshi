const shark = require('../shark');

exports.create = async ({station, region, operator, nextTry, status, batteries, user}) => {
  return await shark.sendSync({
    c: 'order/batteryInspect/create',
    params: {station, region, operator, nextTry, status, batteries, user}
  })
};

exports.findById = async ({id, selector, populateSelector}) => {
  return await shark.sendSync({
    c: 'order/batteryInspect/findById',
    params: { id, selector, populateSelector }
  })
};

exports.update = async ({id, data}) => {
  return await shark.sendSync({
    c: 'order/batteryInspect/update',
    params: { id, data }
  })
};