const shark = require('../shark');

exports.create = async ({ receiver, dispenser, startStation, endStation, region, status, nextTry, outboundFailed }) => {
  return await shark.sendSync({
    c: 'order/batteryDispatch/create',
    params: { receiver, dispenser, startStation, endStation, region, status, nextTry, outboundFailed }
  })
};

exports.find = async ({ query, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryDispatch/find',
    params: { query, selector, populateSelector }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/batteryDispatch/genId',
  })
};

exports.findById = async ({  id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryDispatch/findById',
    params: { id, selector, populateSelector }
  })
};

exports.update = async ({ id, data, updatedAt, arrayOp }) => {
  return await shark.sendSync({
    c: 'order/batteryDispatch/update',
    params: { id, data, updatedAt, arrayOp }
  })
};