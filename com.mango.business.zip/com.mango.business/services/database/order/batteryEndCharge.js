const shark = require('../shark');

exports.genId = async () => {
  return await shark.sendSync({
    c: 'order/batteryEndCharge/genId',
    params: {}
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryEndCharge/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryEndCharge/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, region, station, batteries }) => {
  return await shark.sendSync({
    c: 'order/batteryEndCharge/create',
    params: { user, region, station, batteries }
  })
};

exports.update = async ( { id, updatedAt, data, arrayOp } ) => {
  return await shark.sendSync({
    c: 'order/batteryEndCharge/update',
    params: { id, updatedAt, data, arrayOp }
  })
};