const shark = require('../shark');

exports.create = async data => {
  return await shark.sendSync({
    c: 'order/illegal/create',
    params: data
  });
};

exports.findById = async ({ id, selector, read, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/illegal/findById',
    params: { id, selector, read, populateSelector, cache: { enable: true, extra: ['EX', 3600] } }
  });
};

exports.findByOrder = async ({ order, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/illegal/findByOrder',
    params: { order, selector, populateSelector, cache: { enable: true, extra: ['EX', 3600] } }
  });
};