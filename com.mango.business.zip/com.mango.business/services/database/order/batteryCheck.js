const shark = require('../shark');

exports.create = async ({  dispenser, startStation, status, region, fullCharge, inCharge, needCharge, damage, unknownCount }) => {
  return await shark.sendSync({
    c: 'order/batteryCheck/create',
    params: { dispenser, startStation, status, region, fullCharge, inCharge, needCharge, damage, unknownCount }
  })
};

exports.findById = async ({ id, selector,populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryCheck/findById',
    params: { id, selector, populateSelector}
  })
};

exports.update = async ({ id, data, updatedAt }) => {
  return await shark.sendSync({
    c: 'order/batteryCheck/update',
    params: { id, data, updatedAt }
  })
};