const shark = require('../shark');

exports.genId = async () => {
  return await shark.sendSync({
    c: 'order/batteryRepair/genId',
    params: {}
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryRepair/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryRepair/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, region, station, batteries }) => {
  return await shark.sendSync({
    c: 'order/batteryRepair/create',
    params: { user, region, station, batteries }
  })
};

exports.update = async ( { id, updatedAt, data, arrayOp } ) => {
  return await shark.sendSync({
    c: 'order/batteryRepair/update',
    params: { id, updatedAt, data, arrayOp }
  })
}
