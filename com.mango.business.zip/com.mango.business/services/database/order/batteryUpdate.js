const shark = require('../shark');

exports.create = async ({ user, region, station, battery, prevInfo, nextInfo }) => {
  return await shark.sendSync({
    c: 'order/batteryUpdate/create',
    params: { user, region, station, battery, prevInfo, nextInfo }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/batteryUpdate/genId',
    params: {}
  })
};