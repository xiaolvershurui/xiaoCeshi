const shark = require('../shark');

exports.genId = async () => {
  return await shark.sendSync({
    c: 'order/assetScrap/genId',
    params: {}
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetScrap/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetScrap/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ dispenser, station, region, assets }) => {
  return await shark.sendSync({
    c: 'order/assetScrap/create',
    params: { dispenser, station, region, assets }
  })
};

exports.update = async ( { id, updatedAt, data } ) => {
  return await shark.sendSync({
    c: 'order/assetScrap/update',
    params: { id, updatedAt, data }
  })
}