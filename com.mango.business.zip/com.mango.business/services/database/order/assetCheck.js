const shark = require('../shark');

exports.create = async ({  user, station, status, region, assets }) => {
  return await shark.sendSync({
    c: 'order/assetCheck/create',
    params: { user, station, status, region, assets }
  })
};

exports.findById = async ({ id, selector,populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetCheck/findById',
    params: { id, selector, populateSelector}
  })
};

exports.update = async ({ id, data, updatedAt }) => {
  return await shark.sendSync({
    c: 'order/assetCheck/update',
    params: { id, data, updatedAt }
  })
};