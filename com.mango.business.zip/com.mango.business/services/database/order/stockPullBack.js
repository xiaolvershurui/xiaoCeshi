const shark = require('../shark');

exports.findByStoreManager = async ({ storeManager, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/stockPullBack/findByStoreManager',
    params: { storeManager, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/stockPullBack/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ region, station, storeManager, driver, stocks, date  }) => {
  return await shark.sendSync({
    c: 'order/stockPullBack/create',
    params: { region, station, storeManager, driver, stocks, date }
  })
};

exports.update = async ( { id, updatedAt, data } ) => {
  return await shark.sendSync({
    c: 'order/stockPullBack/update',
    params: { id, updatedAt, data }
  })
};