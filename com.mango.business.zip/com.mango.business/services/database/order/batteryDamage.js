const shark = require('../shark');

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryDamage/findByUser',
    params: { user, status, selector, cache, populateSelector },
  });
};

exports.create = async ({ user, region, station }) => {
  return await shark.sendSync({
    c: 'order/batteryDamage/create',
    params: { user, region, station },
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryDamage/findById',
    params: { id, selector, populateSelector },
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'order/batteryDamage/update',
    params: { id, updatedAt, data },
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/batteryDamage/genId',
  });
};
