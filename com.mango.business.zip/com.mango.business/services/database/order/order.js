const shark = require('../shark');
const InternalServerError = require('../../../com.mango.common/errors/InternalServerError');

exports.findProcessingByBox = async ({ box, selector }) => {
  return await shark.sendSync({
    c: 'order/order/findProcessingByBox',
    params: { box, selector }
  });
};

exports.findLastOne = async ({ stock, selector }) => {
  return await shark.sendSync({
    c: 'order/order/findOne',
    params: {
      query: {
        stock
      },
      sort: { createdAt: -1 },
      selector
    }
  })
};

exports.update = ({ id, updatedAt, data }) => {
  shark.send({
    c: 'order/order/update',
    params: { id, data, updatedAt }
  });
};

exports.updateSync = async ({ id, updatedAt, data }) => {
  await shark.sendSync({
    c: 'ebike/order/update',
    params: { id, updatedAt, data }
  });
};

exports.findById = async ({ id, selector, populateSelector, cache }) => {
  return await shark.sendSync({
    c: 'order/order/findById',
    params: { id, selector, cache, populateSelector }
  });
};