const shark = require('../shark');

exports.create = async ({ user, station, region, dispenser, nextTry }) => {
  return await shark.sendSync({
    c: 'order/assetReceive/create',
    params: { user, station, dispenser, region, nextTry }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetReceive/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetReceive/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  })
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'order/assetReceive/update',
    params: { id, updatedAt, data, arrayOp }
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetReceive/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/assetReceive/genId',
  });
};
