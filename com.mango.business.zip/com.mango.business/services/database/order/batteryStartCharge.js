const shark = require('../shark');

exports.genId = async () => {
  return await shark.sendSync({
    c: 'order/batteryStartCharge/genId',
    params: {}
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryStartCharge/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/batteryStartCharge/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.create = async ({ user, region, station, batteries }) => {
  return await shark.sendSync({
    c: 'order/batteryStartCharge/create',
    params: { user, region, station, batteries }
  })
};

exports.update = async ( { id, updatedAt, data, arrayOp } ) => {
  return await shark.sendSync({
    c: 'order/batteryStartCharge/update',
    params: { id, updatedAt, data, arrayOp }
  })
};