const shark = require('../shark');

exports.create = async ({ user, supplier, contractFile, assets }) => {
  return await shark.sendSync({
    c: 'order/assetPurchase/create',
    params: { user, supplier, contractFile, assets }
  })
};

exports.findById = async ({ id, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetPurchase/findById',
    params: { id, selector, cache, populateSelector }
  })
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetPurchase/find',
    params: { query, limit, sort, skip, selector, populateSelector }
  })
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'order/assetPurchase/update',
    params: { id, updatedAt, data, arrayOp }
  })
};

exports.findByUser = async ({ user, status, selector, cache, populateSelector }) => {
  return await shark.sendSync({
    c: 'order/assetPurchase/findByUser',
    params: { user, status, selector, cache, populateSelector }
  })
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'order/assetPurchase/genId',
  });
};
