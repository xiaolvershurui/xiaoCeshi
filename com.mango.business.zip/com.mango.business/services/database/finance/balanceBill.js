const shark = require('../shark');

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'finance/balanceBill/genId',
  });
};

exports.find = async ({ query, sort, limit, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'finance/balanceBill/find',
    params: {
      query, sort, limit, skip, selector, populateSelector
    }
  });
};
