const shark = require('../shark');

exports.findOne = async ({ query, selector }) => {
  return await shark.sendSync({
    c: 'finance/ticket/findOne',
    params: { query, selector }
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'finance/ticket/findById',
    params: { id, selector, populateSelector }
  });
};