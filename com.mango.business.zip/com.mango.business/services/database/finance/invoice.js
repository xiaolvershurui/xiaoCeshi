const shark = require('../shark');

exports.find = async ({ query, sort, skip, limit, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'finance/invoice/find',
    params: { query, sort, skip, limit, selector, populateSelector }
  });
};


exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'finance/invoice/findById',
    params: { id, selector, populateSelector }
  });
};