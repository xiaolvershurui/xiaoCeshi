const Poolishark = require('poolishark');
const { Client } = require('poolish');
const logger = require('../../com.mango.common/utils/logger');
const ports = require('../../com.mango.common/settings/ports');
const hosts = require('../../com.mango.common/settings/hosts');

logger.info(`Try connecting database service at [${hosts.SERVICE_DATABASE}:${ports.SERVICE_DATABASE}]`);

const shark = new Poolishark(new Client({
  host: hosts.SERVICE_DATABASE,
  port: ports.SERVICE_DATABASE
}), {
  maxBorrowTimes: 10000
});

shark.on('error', (error, tag) => logger.error(tag, error.message));

module.exports = shark;
