const shark = require('../shark');

exports.findById = async ({ id, selector, populateSelector, cache }) => {
  return await shark.sendSync({
    c: 'operation/parkingLot/findById',
    params: { id, selector, populateSelector, cache }
  });
};
