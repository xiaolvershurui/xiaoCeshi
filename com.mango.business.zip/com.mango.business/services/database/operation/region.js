const shark = require('../shark');

exports.findIntersect = async ({ center, query, selector }) => {
  return await shark.sendSync({
    c: 'operation/region/findIntersect',
    params: { center, query, selector }
  });
};

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/region/findById',
    params: { id, selector, cache }
  });
};

exports.find = async ({ query, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/region/find',
    params: { query, selector, cache }
  });
};
