const shark = require('../shark');


exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/findById',
    params: { id, selector, cache }
  });
};

exports.find = async ({ query, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/find',
    params: { query, selector, cache }
  });
};