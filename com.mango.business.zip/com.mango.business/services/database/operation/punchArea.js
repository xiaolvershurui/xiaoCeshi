const shark = require('../shark');

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/punchArea/findById',
    params: {
      id, selector, populateSelector
    }
  });
};

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/punchArea/find',
    params: {
      query, limit, sort, skip, selector ,populateSelector
    }
  });
};
