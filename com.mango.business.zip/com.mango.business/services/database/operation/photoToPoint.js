const shark = require('../shark');

exports.findById = async ({ id, selector, populateSelector, cache }) => {
  return await shark.sendSync({
    c: 'operation/photoToPoint/findById',
    params: { id, selector, populateSelector, cache }
  });
};

exports.update = async ({ id, data }) => {
  return await shark.sendSync({
    c: 'operation/photoToPoint/update',
    params: { id, data }
  });
};
