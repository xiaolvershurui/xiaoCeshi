const shark = require('../shark');

exports.find = async ({ query, selector, sort, skip, limit, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/workOrder/find',
    params: { query, selector, sort, skip, limit, populateSelector,cache: {
      enable: false
    }}
  });
};

exports.update = async ({ id, data, updatedAt }) => {
  return await shark.sendSync({
    c: 'operation/workOrder/update',
    params: { id, data, updatedAt}
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/workOrder/update',
    params: { id, selector, populateSelector }
  });
};