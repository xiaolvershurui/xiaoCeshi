const shark = require('../shark');

exports.findById = async ({ id, selector, populatedSelector }) => {
  return await shark.sendSync({
    c: 'operation/reportedAbuse/findById',
    params: { id, selector, populatedSelector }
  });
};