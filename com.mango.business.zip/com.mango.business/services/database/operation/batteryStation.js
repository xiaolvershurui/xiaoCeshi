const shark = require('../shark');

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/findById',
    params: { id, selector, cache }
  });
};

exports.find = async ({ query, limit, skip, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/find',
    params: { query, selector, limit, skip, cache }
  });
};

exports.create = async ({ region, name, director, enable, location }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/create',
    params: { region, name, director, enable, location }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/update',
    params: { id, updatedAt, data }
  });
};

exports.findByDirector = async ({ director, selector }) => {
  return await shark.sendSync({
    c: 'operation/batteryStation/findByDirector',
    params: { director, selector }
  });
};