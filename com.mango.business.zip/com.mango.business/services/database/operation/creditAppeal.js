const shark = require('../shark');

exports.findById = async ({  id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/creditAppeal/findById',
    params: { id, selector, populateSelector }
  });
};

exports.update = async ({  id, data }) => {
  return await shark.sendSync({
    c: 'operation/creditAppeal/update',
    params: { id, data }
  });
};
