const shark = require('../shark');

exports.findIntersect = async ({ center, query, selector, limit }) => {
  return await shark.sendSync({
    c: 'operation/polygon/findIntersect',
    params: { center, query, selector, limit }
  });
};

exports.findNear = async ({ center, query, searchRadius, limit, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/polygon/findNear',
    params: { center, query, searchRadius, limit, selector, cache }
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/polygon/findById',
    params: { id, selector, populateSelector }
  });
};

exports.update = async ({ id, data ,updatedAt }) => {
  return await shark.sendSync({
    c: 'operation/polygon/update',
    params: { id, data, updatedAt }
  });
};

exports.update = async ({ id, data ,updatedAt }) => {
  return await shark.sendSync({
    c: 'operation/polygon/update',
    params: { id, data, updatedAt }
  });
};
