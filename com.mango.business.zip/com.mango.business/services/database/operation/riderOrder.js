const shark = require('../shark');

exports.findByUser = async ({ user, selector, limit, skip, sort }) => {
  return await shark.sendSync({
    c: 'operation/riderOrder/findByUser',
    params: { user, selector, limit, skip, sort }
  });
};

exports.findByUserAndState = async ({ user, states, selector }) => {
  return await shark.sendSync({
    c: 'operation/riderOrder/findByUserAndState',
    params: { user, states, selector }
  });
};

exports.update = async ({ id, updatedAt, data }) => {
  return await shark.sendSync({
    c: 'operation/riderOrder/update',
    params: { id, updatedAt, data }
  });
};

exports.genId = async _ => {
  return await shark.sendSync({
    c: 'operation/riderOrder/genId',
  });
};

exports.findById = async ({ id, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/riderOrder/findById',
    params: { id, selector, populateSelector }
  });
};