const shark = require('../shark');

exports.find = async ({ query, limit, sort, skip, selector, populateSelector }) => {
  return await shark.sendSync({
    c: 'operation/repairWorkOrder/find',
    params: { query, limit, sort, skip, selector, populateSelector },
  });
};

exports.create = async data => {
  return await shark.sendSync({
    c: 'operation/repairWorkOrder/create',
    params: data,
  });
};

exports.update = async ({ id, updatedAt, data, arrayOp }) => {
  return await shark.sendSync({
    c: 'operation/repairWorkOrder/update',
    params: { id, updatedAt, data, arrayOp },
  });
};

exports.findByTeam = async ({ team, selector, populateSelector }) => {
    return await shark.sendSync({
        c: 'operation/repairWorkOrder/findByTeam',
        params: { team, selector, populateSelector },
    });
};

exports.findByRepairMembers = async ({ repairMembers, selector, populateSelector }) => {
    return await shark.sendSync({
        c: 'operation/repairWorkOrder/findByRepairMembers ',
        params: { repairMembers, selector, populateSelector },
    });
};