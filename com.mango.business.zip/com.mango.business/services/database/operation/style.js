const shark = require('../shark');

exports.findById = async ({ id, selector, cache }) => {
  return await shark.sendSync({
    c: 'operation/style/findById',
    params: { id, selector, cache }
  });
};