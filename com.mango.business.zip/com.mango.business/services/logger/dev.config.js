const qs = require('querystring');
const util = require('util');

module.exports = {
  appenders: [
    {
      type: "console",
      layout: {
        type: "pattern",
        pattern: "%[%r %p %c -%] %x{content}",
        tokens: {
          content: ({ data }) => {
            if (util.isObject(data[0])) {
              return Object.keys(data[0]).reduce((memo, key) => {
                if (key === 'deviceInfo') return memo;
                let value = data[0][key];
                if (util.isObject(value)) value = JSON.stringify(value);
                memo += `${key}=${value}; `;
                return memo;
              }, '');
            } else {
              return data;
            }
          }
        }
      }
    }
  ],
  levels: {
    "[all]": "TRACE"
  }
};