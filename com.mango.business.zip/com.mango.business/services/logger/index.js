const path = require('path');
const log4js = require('log4js');

log4js.configure({
  development: require('./dev.config'),
  staging: require('./dev.config'),
  production: require('./pro.config'),
}[process.env.NODE_ENV || 'development']);

module.exports.dingRobot = log4js.getLogger('DingRobot');