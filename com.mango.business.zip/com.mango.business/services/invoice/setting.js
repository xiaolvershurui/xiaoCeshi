module.exports = {
  clientId: '1',
  clientSecret: '2'
};