const shark = require('./shark');

const timeout = 60000;

exports.sendCommand = async ({ deviceId, command, params, type }) => {
  return await shark.sendSync({
    c: 'sendCommand',
    params: {
      deviceId,
      command,
      params,
      type,
    },
  }, { timeout });
};

exports.setEcoMode = ({ deviceId, ecoMode }) => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'setEcoMode',
      params: ecoMode,
    },
  }, { timeout });
};

exports.unlockAsync = deviceId => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'unlockAsync',
    },
  }, { timeout });
};

exports.stopAsync = deviceId => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'stopAsync',
    },
  }, { timeout });
};

exports.playSoundAsync = ({ deviceId, sound }) => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'playSoundAsync',
      params: sound,
    },
  }, { timeout });
};

exports.startAsync = deviceId => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'startAsync',
    },
  }, { timeout });
};

exports.tryLock = deviceId => {
  shark.send({
    c: 'sendCommand',
    params: {
      deviceId,
      command: 'tryLock',
    },
  }, { timeout });
};
