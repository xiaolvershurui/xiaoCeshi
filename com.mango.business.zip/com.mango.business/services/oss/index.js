const Bucket = require('@mangoebike/oss');
const settings = require('./settings');
const path = require('path');
const uuid = require('node-uuid');

class OSS {
  constructor (options, cdn) {
    this._bucket = new Bucket(options, cdn);
    this._cdn = cdn;
  }

  async putData (prefix, base, data, name = uuid.v4(), ext, options) {
    return await this._bucket.putRawData(path.format({
      dir: prefix,
      name,
      ext,
      base,
    }), data, options);
  }

  getUrls (object) {
    return this._bucket.getUrls(object);
  }

}

module.exports.public = new OSS(settings.public.url, settings.public.cdn);
module.exports.private = new OSS(settings.private.url, settings.public.cdn);
