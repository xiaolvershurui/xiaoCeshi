module.exports = {
  'public': {
    url: 'https://wqIamDTjWjDNoef9:EDqGomWlqAVM1fmFemgoFeOfKJmqy1@mangoebike.oss-cn-shenzhen',
    cdn: 'https://mangoebike.com/',
  },
  'private': {
    url: 'https://wqIamDTjWjDNoef9:EDqGomWlqAVM1fmFemgoFeOfKJmqy1@8ddao-private.oss-cn-shenzhen',
  },
};
