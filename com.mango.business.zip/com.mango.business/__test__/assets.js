process.env.NODE_ENV = 'development';

const shark = require('./shark');

// shark.sendSync({
//   c: 'order/batteryInspect/create',
//   params: {
//     station: '1708031649002',
//     operator: '1706031548364',
//     receiver: '1706031548364',
//     batteries: [{
//       id: '1708302132059',
//     }]
//   }
// }).then(console.log).catch(console.error);

// shark.sendSync({
//   c: 'order/batteryInspect/retry',
//   params: {
//     id: '1712181544025'
//   }
// }).then(console.log).catch(console.error);

shark.sendSync({
  c: 'record/userExperience/noPower',
  params: {
    order: '1801172016546',
    powerUnlink: false,
    outsideRegion: false,
    prohibitionArea: false
  }
}).then(console.log).catch(console.error);