process.env.NODE_ENV = 'development';

const shark = require('./shark');

shark.sendSync({
  c: 'setting/asset/create',
  params: {
    code: "XR3105M2-01",
    type: "棒槌",
    description: '2×1.5mm2×1300黑色电源线/带400金属软管/带维护接口'
  }
}).then(console.log).catch(console.error);