const _calculateRoute = require('../controllers/account/operator/_calculateRoute');
process.env.NODE_ENV = 'development';

_calculateRoute({
  id: '1801181848126',
  deviceInfo: {
    udid: 'BC997A80B5440F10D7A3E6A6D911EDF9'
  }
});
