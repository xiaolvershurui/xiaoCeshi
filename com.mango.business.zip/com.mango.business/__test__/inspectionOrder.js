process.env.NODE_ENV = 'development';

const shark = require('./shark');

(async _ => {
  // 创建巡检订单
  await shark.sendSync({
    c: 'account/operator/createInspectionOrder',
    params: {
      id: '1706211158059',
      inspectionAreas: ['1709131459001'],
      acceptTaskGroups: [2, 5],
    }
  });
  // 找车打卡
  // await shark.sendSync({
  //   c: 'ebike/stock/findStock',
  //   params: {
  //     id: '1709300953519',
  //     uid: "1703110906004",
  //     hasFind: false,
  //     failedReason: 1
  //   }
  // });
  // await shark.sendSync({
  //   c: 'account/operator/pauseInspection',
  //   params: {
  //     id: '1709162002002'
  //   }
  // });
  // await shark.sendSync({
  //   c: 'account/operator/startInspection',
  //   params: {
  //     id: '1709162002002'
  //   }
  // });

  // await shark.sendSync({
  //   c: 'account/operator/cancelInspection',
  //   params: {
  //     id: '1709162002002'
  //   }
  // });
  // await shark.sendSync({
  //   c: 'account/operator/finishInspection',
  //   params: {
  //     id: '1709162002002'
  //   }
  // });
})().then(result => {
  console.log(result);
  process.exit();
}).catch(error => {
  console.error(error);
  process.exit(1);
});