const Poolishark = require('poolishark');
const { Client } = require('poolish');
const logger = require('../com.mango.common/utils/logger');
const ports = require('../com.mango.common/settings/ports');

const shark = new Poolishark(new Client({
  host: 'localhost',
  port: ports.SERVICE_BUSINESS
}, {
  max: 10,
  min: 2,
}));

shark.on('connected', client => logger.info(`Client [${client.id}] connected.`));
shark.on('error', (error, tag) => logger.error(tag, error));

module.exports = shark;