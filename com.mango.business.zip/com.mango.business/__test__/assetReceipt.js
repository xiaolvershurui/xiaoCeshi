process.env.NODE_ENV = 'development';
const shark = require('./shark');
(async _ => {
// 创建调度单
  await shark.sendSync({
    c: 'order/assetDispatch/create',
    params: {
      dispenser: '1703110057001',
      startStation: '1711141741073',
      endStation: '1708042043004',
      region: '1703110248001',
      assets:[{
        code: 'M001',
        startIntactCount: '1',
        startBadCount: '1',
      },{
        code: 'M002',
        startIntactCount: '1',
        startBadCount: '1',
      }]
    }
  });
  // 领用单
  // await shark.sendSync({
  //   c: 'order/assetDispatch/returnBack',
  //   params: {
  //     receiver: '1703110057001',
  //     id: '1711162004044',
  //     endAssets:[{
  //       code: 'M001',
  //       endIntactCount: '1',
  //       endBadCount: '1',
  //     }]
  //   }
  // });
  // 创建反修单
  // await shark.sendSync({
  //   c: 'order/assetRepair/create',
  //   params: {
  //     dispenser: '1703131447010',
  //     region: '1703110248001',
  //     station: '1711141741073',
  //     assets: [ { code: 'M002', outboundCount: 3 },
  //       { code: 'M001', outboundCount: 3 } ]
  //   }
  // });
  // 返修回库
  // await shark.sendSync({
  //   c: 'order/assetRepair/returnBack',
  //   params: {
  //     receiver: '1703131447010',
  //     isFinished: false,
  //     id:'1711171634106',
  //     assets: [ { id:'1711141743064', code: 'M002', damageCount: 3,intactCount:2 },
  //       { id:'1711141743063',code: 'M001', damageCount: 3,intactCount:2  } ]
  //   }
  // });
})().then(result => {
  console.log(result);
  process.exit();
}).catch(error => {
  console.error(error);
  process.exit(1);
});