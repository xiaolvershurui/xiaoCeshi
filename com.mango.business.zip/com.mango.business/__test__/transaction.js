process.env.NODE_ENV = 'development';

const shark = require('./shark');
const injectTransaction = require('../utils/injectTransaction');


(async () => {
  await shark.sendSync({
    c: 'order/assetCheck/create',
    params: {
      user: '1703110057001',
      station: '1708031649002',
      region: '1703152031003',
      assets: [{
        code: 'M1',
        damageCount: 1000,
        intactCount: 1000,
        scrapCount: 1000,
      }]
    }
  });
})().then(result => {
  console.log(result);
  process.exit();
}).catch(error => {
  console.error(error);
  process.exit(1);
});

