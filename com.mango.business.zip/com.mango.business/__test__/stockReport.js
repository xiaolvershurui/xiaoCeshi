process.env.NODE_ENV = 'development';

// const shark = require('./shark');
const Core = require('../services/core/shark');

(async _ => {
  const result = await Core.send({
    c: 'operation/parkingLot/triggerIO.s.2',
    params: {
      stockId: '1706301349691',
      lngLat: [116.45359465771585,
        39.96871966774371],
    },
  })
  console.log(result);
})().catch(error => console.error(error));;
