const Joi = require('koa-joi-router').Joi;
const STConfig = require('../../../../../../services/database/setting/config');
// const Cache = require('../../../../../../com.mango.common/utils/cache');

// const cache = new Cache('mg.setup.client');

exports.permissions = ['admin.st.config.put'];

exports.validate = {
    params: {
        key: Joi.string().required().description('配置 key'),
    },
    type: 'json',
    body: {
        value: [Joi.number(), Joi.date(), Joi.object(), Joi.array(), Joi.string(), Joi.boolean()],
        description: Joi.string().empty('').description('配置描述'),
    },
    output: {
        200: {
            body: Joi.object(),
        },
    },
};

exports.handler = async ({params, body, ctx}) => {
    let prev;
    if (params.key === 'st_android_version'){
        prev = await STConfig.get(Object.assign(params));
    }
    const ret = await STConfig.set(Object.assign(params, body, {
        operator: ctx.state.user.id,
        prev,
    }));
    // if (params.key === 'st_android_version') {
    //     ret.key = 'st_android_cl_version';
    //     ret.value.current.updateMessage = ret.value.current.updateMessage.split('；').join(';\n');
    //     cache.setJSON('st_android_cl_version', ret);
    // }
    return ret;
};
