const Joi = require('koa-joi-router').Joi;
const STConfig = require('../../../../../../services/database/setting/config');
const stConfigValidator = require('../../../../../../com.mango.common/validators/index').st_config;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.config.getMany'];

exports.validate = {
  params: {
    key: Joi.string().required().description('配置 key'),
  },
  output: {
    200: {
      body: stConfigValidator
    },
  },
};

exports.handler = async ({ params }) => {
  return await STConfig.get(params);
};
