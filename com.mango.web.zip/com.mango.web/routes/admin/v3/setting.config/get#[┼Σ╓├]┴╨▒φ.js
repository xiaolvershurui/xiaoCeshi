const Joi = require('koa-joi-router').Joi;
const STConfig = require('../../../../services/database/setting/config');
const stConfigValidator = require('../../../../com.mango.common/validators/index').st_config;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.config.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(stConfigValidator)
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await STConfig.find(query);
  const count = await STConfig.count({
    query: query.query,
  });
  return { items, count };
};
