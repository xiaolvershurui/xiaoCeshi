const RCUserExperience = require('../../../../services/database/record/userExperience');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const userExperienceValidator = require('../../../../com.mango.common/validators/index').rc_user_experience;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.user_experience.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(userExperienceValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  return await RCUserExperience.find(query);
};