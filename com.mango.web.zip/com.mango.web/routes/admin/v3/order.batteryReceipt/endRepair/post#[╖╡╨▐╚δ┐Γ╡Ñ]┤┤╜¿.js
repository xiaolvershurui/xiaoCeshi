const Joi = require('koa-joi-router').Joi;
const ODBatteryEndRepair = require('../../../../../services/business/order/batteryEndRepair');

exports.permissions = ['admin.od.battery_end_repair.post'];

exports.validate = {
  params: {},
  query: {},
  type:'json',
  body:{
    batteries: Joi.array().items(Joi.string()).description('电池 二维码'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryEndRepair.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
