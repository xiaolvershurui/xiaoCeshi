const Joi = require('koa-joi-router').Joi;
const ODBatteryEndStartRepair = require('../../../../../../services/database/order/batteryEndRepair');
const odBatteryEndStartRepairValidator = require('../../../../../../com.mango.common/validators').od_battery_end_repair;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_end_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(odBatteryEndStartRepairValidator),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  query.query = {
    $and: [query.query, {
      station: ctx.state.user.stationId,
    }],
  };
  return await ODBatteryEndStartRepair.find(query);
};
