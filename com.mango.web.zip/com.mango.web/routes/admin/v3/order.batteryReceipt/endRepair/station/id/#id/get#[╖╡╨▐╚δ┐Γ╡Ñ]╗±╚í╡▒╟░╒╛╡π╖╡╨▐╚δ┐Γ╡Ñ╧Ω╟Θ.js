const ODBatteryEndRepair = require('../../../../../../../../services/database/order/batteryEndRepair');
const odBatteryEndRepairValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_end_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_end_repair.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('返修入库单 id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryEndRepairValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryEndRepair.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
