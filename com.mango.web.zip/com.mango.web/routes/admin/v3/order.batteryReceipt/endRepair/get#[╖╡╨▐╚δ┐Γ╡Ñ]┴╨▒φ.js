const Joi = require('koa-joi-router').Joi;
const ODBatteryEndRepair = require('../../../../../services/database/order/batteryEndRepair');
const odBatteryEndRepairValidator = require('../../../../../com.mango.common/validators').od_battery_end_repair;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_end_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryEndRepairValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryEndRepair.find(query);
  const count = await ODBatteryEndRepair.count({
    query: query.query,
  });
  return { items, count };
};
