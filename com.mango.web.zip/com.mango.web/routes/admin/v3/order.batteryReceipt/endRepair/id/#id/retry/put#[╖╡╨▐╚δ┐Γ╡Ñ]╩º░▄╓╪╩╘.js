const Joi = require('koa-joi-router').Joi;
const ODBatteryEndRepair = require('../../../../../../../../services/business/order/batteryEndRepair');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_end_repair.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('返修单 id')
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ query, params }) => {
  return await ODBatteryEndRepair.retry({
    id: params.id,
  })
};
