const Joi = require('koa-joi-router').Joi;
const ODBatteryEndRepair = require('../../../../../../services/business/order/batteryEndRepair');

exports.permissions = ['admin.od.battery_end_repair.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 二维码'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body }) => {
  return await ODBatteryEndRepair.check(body);
};
