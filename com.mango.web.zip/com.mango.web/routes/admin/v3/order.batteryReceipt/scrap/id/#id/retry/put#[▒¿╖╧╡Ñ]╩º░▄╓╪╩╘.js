const Joi = require('koa-joi-router').Joi;
const ODBatteryScrap = require('../../../../../../../../services/business/order/batteryScrap');
const odBatteryScrapValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_scrap;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_scrap.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odBatteryScrapValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODBatteryScrap.retry({
    id: params.id
  })
};
