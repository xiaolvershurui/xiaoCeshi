const Joi = require('koa-joi-router').Joi;
const ODBatteryScrap = require('../../../../../../../services/database/order/batteryScrap');
const odBatteryScrapValidator = require('../../../../../../../com.mango.common/validators/index').od_battery_scrap;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_scrap.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryScrapValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODBatteryScrap.findById(Object.assign(params, query))
};
