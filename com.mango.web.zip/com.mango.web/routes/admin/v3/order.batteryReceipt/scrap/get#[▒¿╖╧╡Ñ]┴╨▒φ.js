const Joi = require('koa-joi-router').Joi;
const ODBatteryScrap = require('../../../../../services/database/order/batteryScrap');
const odBatteryScrapValidator = require('../../../../../com.mango.common/validators').od_battery_scrap;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_scrap.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryScrapValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryScrap.find(query);
  const count = await ODBatteryScrap.count({
    query: query.query
  })
  return { items, count };
};
