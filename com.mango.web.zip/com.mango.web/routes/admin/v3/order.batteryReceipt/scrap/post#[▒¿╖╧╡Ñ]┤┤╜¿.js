const Joi = require('koa-joi-router').Joi;
const ODBatteryScrap = require('../../../../../services/business/order/batteryScrap');

exports.permissions = ['admin.od.battery_scrap.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryScrap.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
