const Joi = require('koa-joi-router').Joi;
const ODBatteryScrap = require('../../../../../../../../services/database/order/batteryScrap');
const odBatteryScrapValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_scrap;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_scrap.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODBatteryScrap Id')
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
      'scrapSuccess.id': Joi.string().allow(''),
      'scrapFailed.id': Joi.string().allow(''),
      'nextTryRecords.operator': Joi.string().allow(''),
      'auditor': Joi.string().allow('')
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: odBatteryScrapValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryScrap.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
