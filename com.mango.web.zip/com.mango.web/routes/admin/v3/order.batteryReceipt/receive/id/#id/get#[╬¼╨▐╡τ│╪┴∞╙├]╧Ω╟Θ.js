const Joi = require('koa-joi-router').Joi;
const ODBatteryReceive = require('../../../../../../../services/database/order/batteryReceive');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const odBatteryReceiveValidator  = require('../../../../../../../com.mango.common/validators/index').od_battery_receive;

exports.permissions = ['admin.od.battery_receive.get'];

exports.validate = {
  query: {
    id: validators.id.description('BatteryReceive Id'),
    selector: Joi.string().description('查询条件'),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'station': Joi.string(),
      'region': Joi.string(),
      'receiveSuccess.station': Joi.string(),
      'receiveSuccess.dispenser': Joi.string(),
      'returnSuccess.station': Joi.string(),
      'returnSuccess.receiver': Joi.string(),
    }).description('连表选项'),
  },
  output: {
    200: {
      body: odBatteryReceiveValidator
    }
  }
};

exports.handler = async ({ query }) => {
  return await ODBatteryReceive.findById({
    id: query.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};