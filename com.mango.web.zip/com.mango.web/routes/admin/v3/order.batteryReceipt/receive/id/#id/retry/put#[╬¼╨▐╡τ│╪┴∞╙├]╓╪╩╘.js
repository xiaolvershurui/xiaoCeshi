const Joi = require('koa-joi-router').Joi;
const ODBatteryReceive = require('../../../../../../../../services/database/order/batteryReceive');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_receive.put'];

exports.validate = {
  params: {
    id: validators.id.description('ODBatteryReceive Id')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() })
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODBatteryReceive.retry({
    id: params.id,
  });
};
