const Joi = require('koa-joi-router').Joi;
const ODBatteryReceive = require('../../../../../../../../services/database/order/batteryReceive');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_receive.put'];

exports.validate = {
  params: {
    id: validators.id.description('ODBatteryReceive Id')
  },
  type: 'json',
  body: {
    batteries: Joi.array().items({
      id: validators.id.required().description('Battery Id')
    }).description('电池'),
    unknownCount: Joi.number().required().description('无码数量')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() })
    }
  }
};

exports.handler = async ({ body, ctx, params }) => {
 return await ODBatteryReceive.returnBack({
    id: params.id,
    batteries: body.batteries,
    unknownCount: body.unknownCount,
    station: ctx.state.user.stationId,
    receiver: ctx.state.user.id,
  });
};
