const Joi = require('koa-joi-router').Joi;
const ODBatteryRepair = require('../../../../../services/business/order/batteryRepair');

exports.permissions = ['admin.od.battery_repair.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 二维码'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryRepair.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
