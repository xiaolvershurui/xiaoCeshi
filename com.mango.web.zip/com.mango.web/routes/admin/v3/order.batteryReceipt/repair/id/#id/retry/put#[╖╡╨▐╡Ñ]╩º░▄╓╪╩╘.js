const Joi = require('koa-joi-router').Joi;
const ODBatteryRepair = require('../../../../../../../../services/business/order/batteryRepair');
const odBatteryRepairValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_repair.put'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  output: {
    200: {
      body: odBatteryRepairValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODBatteryRepair.retry({
    id: params.id,
  })
};
