const Joi = require('koa-joi-router').Joi;
const ODBatteryRepair = require('../../../../../services/database/order/batteryRepair');
const odBatteryRepairValidator = require('../../../../../com.mango.common/validators').od_battery_repair;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryRepairValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryRepair.find(query);
  const count = await ODBatteryRepair.count({
    query: query.query,
  });
  return { items, count };
};
