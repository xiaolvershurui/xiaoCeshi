const Joi = require('koa-joi-router').Joi;
const ODBatteryRepair = require('../../../../../../../../services/database/order/batteryRepair');
const odBatteryRepairValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_repair.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODBatteryScrap Id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryRepairValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryRepair.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
