const Joi = require('koa-joi-router').Joi;
const ODBatteryInspect = require('../../../../../services/database/order/batteryInspect');
const validators = require('../../../../../com.mango.common/settings/validators');
const odBatteryInspectValidator  = require('../../../../../com.mango.common/validators/index').od_battery_inspect;

exports.permissions = ['admin.od.battery_inspect.getMany'];

exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'station': Joi.string(),
      'region': Joi.string(),
      'receiveSuccess.station': Joi.string(),
      'receiveSuccess.dispenser': Joi.string(),
      'returnSuccess.station': Joi.string(),
      'returnSuccess.receiver': Joi.string(),
    }).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.array().items(odBatteryInspectValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  return await ODBatteryInspect.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
