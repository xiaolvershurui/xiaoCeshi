const Joi = require('koa-joi-router').Joi;
const ODBatteryInspect = require('../../../../../services/database/order/batteryInspect');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inspect.post'];

exports.validate = {
  type: 'json',
  body: {
    receiver: Joi.string().description('接收人'),
    batteries: Joi.array().items(Joi.object({
      id: validators.id.required().description('电池Id')
    })).description('电池')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() })
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryInspect.create({
     station: ctx.state.user.stationId,
     operator: ctx.state.user.id,
     receiver: body.receiver,
     batteries: body.batteries
   });
};
