const Joi = require('koa-joi-router').Joi;
const ODBatteryInspect = require('../../../../../../../../services/database/order/batteryInspect');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inspect.put'];

exports.validate = {
  params: {
    id: validators.id.description('OdBatteryInspect Id')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() })
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODBatteryInspect.retry({
    id: params.id,
  });
};
