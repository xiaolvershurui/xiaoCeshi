const Joi = require('koa-joi-router').Joi;
const ODBatteryInspect = require('../../../../../../../../services/database/order/batteryInspect');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inspect.put'];

exports.validate = {
  params: {
    id: validators.id.description('OdBatteryInspect Id')
  },
  type: 'json',
  body: {
    batteries: Joi.array().items({
      id: validators.id.required().description('Battery Id')
    }).description('电池'),
    unknownCount: Joi.number().required().description('无码数量')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() })
    }
  }
};

exports.handler = async ({ body, ctx, params }) => {
 return await ODBatteryInspect.returnBack({
    id: params.id,
    batteries: body.batteries,
    unknownCount: body.unknownCount,
    station: ctx.state.user.stationId,
    receiver: ctx.state.user.id,
  });
};
