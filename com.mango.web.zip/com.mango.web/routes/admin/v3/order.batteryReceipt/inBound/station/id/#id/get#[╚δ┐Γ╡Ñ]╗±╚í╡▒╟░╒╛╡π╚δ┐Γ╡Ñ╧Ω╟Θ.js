const Joi = require('koa-joi-router').Joi;
const ODBatteryInbound = require('../../../../../../../../services/database/order/batteryInbound');
const odBatteryInboundValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_inbound;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inbound.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odBatteryInboundValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODBatteryInbound.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
