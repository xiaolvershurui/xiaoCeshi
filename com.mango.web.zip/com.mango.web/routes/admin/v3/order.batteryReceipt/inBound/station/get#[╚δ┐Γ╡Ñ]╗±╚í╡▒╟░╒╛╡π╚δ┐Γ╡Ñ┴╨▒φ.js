const Joi = require('koa-joi-router').Joi;
const ODBatteryInbound = require('../../../../../../services/database/order/batteryInbound');
const odBatteryInboundValidator = require('../../../../../../com.mango.common/validators').od_battery_inbound;

exports.permissions = ['admin.od.battery_inbound.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().default({}).description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
      'inboundBatteries.battery': Joi.string().allow(''),
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.array().items(odBatteryInboundValidator),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  return await ODBatteryInbound.find({
    query: {
      station: ctx.state.user.stationId
    },
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
