const Joi = require('koa-joi-router').Joi;
const ODBatteryInbound = require('../../../../../../../../services/business/order/batteryInbound');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inbound.post'];

exports.validate = {
  params: {
    id: validators.id
  },
  query: {},
  type: 'json',
  body: {
    status: Joi.number().description('入库电池信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body }) => {
  return await ODBatteryInbound.finishInboundOrder({
    id: params.id,
    status: body.status
  });
};
