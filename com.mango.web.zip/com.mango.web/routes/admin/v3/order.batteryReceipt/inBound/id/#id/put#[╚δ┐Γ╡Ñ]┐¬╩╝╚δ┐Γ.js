const Joi = require('koa-joi-router').Joi;
const ODBatteryInbound = require('../../../../../../../services/business/order/batteryInbound');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_inbound.post'];

exports.validate = {
  params: {
    id: validators.id
  },
  query: {},
  type: 'json',
  body: {
    mark: Joi.string().required().description('编号'),
    code: Joi.string().required().description('二维码'),
    gps: Joi.string().required().description('GPS'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODBatteryInbound.startInbound({
    id: params.id,
    station: ctx.state.user.stationId,
    battery: {
      code: body.code,
      mark: body.mark,
      gps: body.gps,
    }
  });
};
