const Joi = require('koa-joi-router').Joi;
const ODBatteryInbound = require('../../../../../services/business/order/batteryInbound');

exports.permissions = ['admin.od.battery_inbound.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    unitCost: Joi.number().description('电池单价')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryInbound.createInboundOrder({
    user: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    station: ctx.state.user.stationId,
    unitCost: body.unitCost,
  });
};
