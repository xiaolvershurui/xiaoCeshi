const Joi = require('koa-joi-router').Joi;
const ODBatteryEndCharge = require('../../../../../services/business/order/batteryEndCharge');

exports.permissions = ['admin.od.battery_end_charge.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    batteries: Joi.array().items({
      code: Joi.string().required().description('二维码'),
    }).description('报废物料信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryEndCharge.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
