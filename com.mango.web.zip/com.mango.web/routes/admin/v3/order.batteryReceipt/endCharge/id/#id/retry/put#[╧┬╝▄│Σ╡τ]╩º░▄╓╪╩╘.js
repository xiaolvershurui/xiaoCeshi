const Joi = require('koa-joi-router').Joi;
const ODBatteryEndCharge = require('../../../../../../../../services/business/order/batteryEndCharge');
const odBatteryEndChargeValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_end_charge;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_end_charge.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odBatteryEndChargeValidator,
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  return await ODBatteryEndCharge.retry({
    id: params.id,
    user: ctx.state.user.id
  })
};
