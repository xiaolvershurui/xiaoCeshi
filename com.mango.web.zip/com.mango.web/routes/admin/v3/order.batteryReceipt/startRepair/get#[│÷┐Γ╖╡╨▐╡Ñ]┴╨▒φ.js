const Joi = require('koa-joi-router').Joi;
const ODBatteryStartRepair = require('../../../../../services/database/order/batteryEndRepair');
const odBatteryStartRepairValidator = require('../../../../../com.mango.common/validators').od_battery_start_repair;

exports.permissions = ['admin.od.battery_start_repair.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: Joi.array().items(odBatteryStartRepairValidator),
    }
  }
};

exports.handler = async ({ query }) => {
  return await ODBatteryStartRepair.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
