const Joi = require('koa-joi-router').Joi;
const ODBatteryStartRepair = require('../../../../../../../../services/database/order/batteryStartRepair');
const odBatteryStartRepairValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_start_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_start_repair.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('返修单 id')
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: odBatteryStartRepairValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryStartRepair.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
