const Joi = require('koa-joi-router').Joi;
const ODBatteryStartRepair = require('../../../../../services/business/order/batteryStartRepair');

exports.permissions = ['admin.od.battery_start_repair.post'];

exports.validate = {
  params: {},
  query: {},
  type:'json',
  body:{
    batteries: Joi.array().items(Joi.object({
      code: Joi.string().required().description('二维码'),
    }))
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryStartRepair.createOrder({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
