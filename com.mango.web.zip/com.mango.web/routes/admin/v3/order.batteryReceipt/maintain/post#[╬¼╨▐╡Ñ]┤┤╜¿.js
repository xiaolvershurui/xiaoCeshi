const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../services/business/order/batteryMaintain');

exports.permissions = ['admin.od.battery_maintain.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryMaintain.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
