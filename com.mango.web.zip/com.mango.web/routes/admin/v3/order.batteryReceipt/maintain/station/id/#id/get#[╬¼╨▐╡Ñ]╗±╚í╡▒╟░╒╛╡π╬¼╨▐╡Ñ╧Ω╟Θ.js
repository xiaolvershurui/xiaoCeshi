const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../../../../services/database/order/batteryMaintain');
const odBatteryMaintainValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_maintain;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_maintain.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('维修单 Id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryMaintainValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryMaintain.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
