const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../../services/database/order/batteryMaintain');
const odBatteryMaintainValidator = require('../../../../../../com.mango.common/validators').od_battery_maintain;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_maintain.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(odBatteryMaintainValidator)
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  Object.assign(query.query, {
    station: ctx.state.user.stationId
  });
  return await ODBatteryMaintain.find(query);
};
