const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../../services/business/order/batteryMaintain');

exports.permissions = ['admin.od.battery_maintain.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.object({
      QRCode: Joi.string().empty('').description('电池二维码'),
      mark: Joi.string().empty('').description('电池标记号'),
    })).description('电池 二维码'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryMaintain.check({
    batteries: body.batteries,
    station: ctx.state.user.stationId,
  });
};
