const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../../../services/database/order/batteryMaintain');
const odBatteryMaintainValidator = require('../../../../../../../com.mango.common/validators/index').od_battery_maintain;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_maintain.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryMaintainValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODBatteryMaintain.findById(Object.assign(params, query))
};
