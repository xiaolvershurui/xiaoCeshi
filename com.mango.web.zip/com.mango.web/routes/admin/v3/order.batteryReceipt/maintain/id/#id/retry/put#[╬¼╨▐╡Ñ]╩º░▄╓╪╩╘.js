const Joi = require('koa-joi-router').Joi;
const ODBatteryMaintain = require('../../../../../../../../services/business/order/batteryMaintain');
const odBatteryMaintainValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_maintain;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_maintain.put'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  output: {
    200: {
      body: odBatteryMaintainValidator,
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  return await ODBatteryMaintain.retry({
    id: params.id,
  })
};
