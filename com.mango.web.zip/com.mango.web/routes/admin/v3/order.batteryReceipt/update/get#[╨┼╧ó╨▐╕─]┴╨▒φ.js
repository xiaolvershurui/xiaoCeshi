const Joi = require('koa-joi-router').Joi;
const ODBatteryUpdate = require('../../../../../services/business/order/batteryUpdate');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_update.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    uery: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODBatteryUpdate.create({
    id: params.id,
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    // user: '1709170841941',
    // station: '1708031649002',
    code: body.code,
    updateInfo: body.updateInfo,
  });
};
