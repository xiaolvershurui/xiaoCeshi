const Joi = require('koa-joi-router').Joi;
const ODBatteryUpdate = require('../../../../../services/business/order/batteryUpdate');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_update.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    code: Joi.string().required().description('二维码'),
    updateInfo: Joi.object({
      code: Joi.string().required().description('二维码'),
      mark: Joi.string().description('二维码'),
      gps: Joi.string().description('二维码'),
    }).description('电池修改信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODBatteryUpdate.create({
    id: params.id,
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    // user: '1709170841941',
    // station: '1708031649002',
    code: body.code,
    updateInfo: body.updateInfo,
  });
};
