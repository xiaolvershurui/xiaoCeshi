const Joi = require('koa-joi-router').Joi;
const ODBatteryStartCharge = require('../../../../../../../../services/database/order/batteryStartCharge');
const odBatteryStartChargeValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_start_charge;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_start_charge.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('报废单 id')
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: odBatteryStartChargeValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryStartCharge.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
