const Joi = require('koa-joi-router').Joi;
const ODBatteryStartCharge = require('../../../../../../../services/database/order/batteryStartCharge');
const odBatteryStartChargeValidator = require('../../../../../../../com.mango.common/validators/index').od_battery_start_charge;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_start_charge.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odBatteryStartChargeValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODBatteryStartCharge.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
