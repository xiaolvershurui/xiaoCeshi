const Joi = require('koa-joi-router').Joi;
const ODBatteryStartCharge = require('../../../../../../../../services/business/order/batteryStartCharge');
const odBatteryStartChargeValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_start_charge;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_start_charge.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odBatteryStartChargeValidator,
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  return await ODBatteryStartCharge.retry({
    id: params.id,
    user: ctx.state.user.id
  })
};
