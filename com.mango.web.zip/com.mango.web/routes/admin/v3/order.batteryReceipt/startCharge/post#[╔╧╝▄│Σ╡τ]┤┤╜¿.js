const Joi = require('koa-joi-router').Joi;
const ODBatteryStartCharge = require('../../../../../services/business/order/batteryStartCharge');

exports.permissions = ['admin.od.battery_start_charge.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    batteries: Joi.array().items({
      code: Joi.string().required().description('二维码'),
    }).description('报废物料信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryStartCharge.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
