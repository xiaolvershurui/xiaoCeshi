const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../services/database/order/batteryCheck');
const odBatteryCheckValidator = require('../../../../../com.mango.common/validators').od_battery_check;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_check.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryCheckValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryCheck.find(query);
  const count = await ODBatteryCheck.count({
    query: query.query,
  });
  return { items, count };
};
