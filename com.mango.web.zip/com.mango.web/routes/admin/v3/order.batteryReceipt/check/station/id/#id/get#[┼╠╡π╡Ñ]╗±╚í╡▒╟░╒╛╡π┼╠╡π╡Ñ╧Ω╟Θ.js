const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../../../../services/database/order/batteryCheck');
const odBatteryCheckValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_check;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_check.get'];

exports.validate = {
  params: {
    id: Joi.string().required().description('电池盘点单 Id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryCheckValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODBatteryCheck.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
