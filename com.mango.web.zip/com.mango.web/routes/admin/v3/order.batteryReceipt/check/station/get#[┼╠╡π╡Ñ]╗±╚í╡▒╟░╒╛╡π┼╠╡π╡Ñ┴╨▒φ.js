const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../../services/database/order/batteryCheck');
const odBatteryCheckValidator = require('../../../../../../com.mango.common/validators').od_battery_check;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_check.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(odBatteryCheckValidator),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  Object.assign(query.query, {
    station: ctx.state.user.stationId
  });
  return await ODBatteryCheck.find(query);
};
