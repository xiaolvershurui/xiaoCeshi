const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../services/database/order/batteryCheck');
const OPBatteryStation = require('../../../../../services/database/operation/batteryStation');
const BadRequestError = require('../../../../../com.mango.common/errors/BadRequestError');
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.od.battery_check.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.object({
      inCharge: Joi.number().default(0),
      fullCharge: Joi.number().default(0),
      lowPower: Joi.number().default(0),
      damageCount: Joi.number().default(0),
      repairReceivedCount: Joi.number().default(0),
      inspectorReceivedCount: Joi.number().default(0),
      ridingReceivedCount: Joi.number().default(0),
      noSealOffCount: Joi.number().default(0),
    }),
    remark: Joi.string().empty(''),
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const { stationId, id } = ctx.state.user;
  const opBatteryStation = await OPBatteryStation.findById({ id: stationId, selector: 'region' });
  const odBatteryCheck = await ODBatteryCheck.find({
    query: {
      storeManager: id,
      status: constants.OD_BATTERY_CHECK_STATUS.审核中,
    },
  });
  if (odBatteryCheck.length) throw new BadRequestError(`用户${id}有审核中的盘点单，暂时无法创建新的盘点单`);

  const totalCount = eval(Object.values(body.batteries).join('+'));
  Object.assign(body.batteries, { totalCount });

  return await ODBatteryCheck.create({
    date: new Date(),
    region: opBatteryStation.region._id,
    station: stationId,
    storeManager: id,
    batteries: body.batteries,
    remark: body.remark,
  });
};
