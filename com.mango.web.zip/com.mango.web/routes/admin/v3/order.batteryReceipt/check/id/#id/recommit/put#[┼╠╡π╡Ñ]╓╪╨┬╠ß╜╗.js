const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../../../../services/database/order/batteryCheck');
const odBatteryCheckValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_check;
const validators = require('../../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.od.battery_check.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('电池盘点单 id'),
  },
  type: 'json',
  body: {
    batteries: Joi.object({
      inCharge: Joi.number().default(0),
      fullCharge: Joi.number().default(0),
      lowPower: Joi.number().default(0),
      damageCount: Joi.number().default(0),
      repairReceivedCount: Joi.number().default(0),
      inspectorReceivedCount: Joi.number().default(0),
      ridingReceivedCount: Joi.number().default(0),
      noSealOffCount: Joi.number().default(0),
    }),
    remark: Joi.string().empty('')
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};

exports.handler = async ({ params, body, ctx }) => {
  const odBatteryCheck = await ODBatteryCheck.findById({
    id: params.id,
    selector: '_id status storeManager updatedAt',
  });
  if (!odBatteryCheck) throw new NotFoundError(`盘点单${params.id}不存在`);
  if (odBatteryCheck.status !== constants.OD_BATTERY_CHECK_STATUS.审核失败) throw new BadRequestError(`非审核失败的盘点单不可重新提交`);
  if (odBatteryCheck.storeManager !== ctx.state.user.id) throw new BadRequestError(`非本人盘点单不可重新提交`);

  const totalCount = eval(Object.values(body.batteries).join('+'));
  Object.assign(body.batteries, { totalCount });

  return await ODBatteryCheck.recommit({
    id: params.id,
    updatedAt: odBatteryCheck.updatedAt,
    data: {
      status: constants.OD_BATTERY_CHECK_STATUS.审核中,
      batteries: body.batteries,
      remark: body.remark,
    },
  });
};
