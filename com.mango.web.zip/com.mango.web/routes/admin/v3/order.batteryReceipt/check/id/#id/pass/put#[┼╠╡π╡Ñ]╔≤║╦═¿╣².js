const Joi = require('koa-joi-router').Joi;
const ODBatteryCheck = require('../../../../../../../../services/database/order/batteryCheck');
const odBatteryCheckValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_check;
const validators = require('../../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.od.battery_check.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('电池盘点单 id'),
  },
  type: 'json',
  body: {
    auditRemark: Joi.string().empty('').description('审核备注'),
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};

exports.handler = async ({ params, body, ctx }) => {
  const odBatteryCheck = await ODBatteryCheck.findById({
    id: params.id,
    selector: '_id status updatedAt',
  });
  if (!odBatteryCheck) throw new NotFoundError(`盘点单${params.id}不存在`);
  if (odBatteryCheck.status !== constants.OD_BATTERY_CHECK_STATUS.审核中) throw new BadRequestError(`非审核中状态盘点单不可审核`);
  return await ODBatteryCheck.auditPass({
    id: params.id,
    updatedAt: odBatteryCheck.updatedAt,
    data: {
      status: constants.OD_BATTERY_CHECK_STATUS.审核成功,
      auditedAt: new Date(),
      auditor: ctx.state.user.id,
      auditRemark: body.auditRemark,
    },
  });
};
