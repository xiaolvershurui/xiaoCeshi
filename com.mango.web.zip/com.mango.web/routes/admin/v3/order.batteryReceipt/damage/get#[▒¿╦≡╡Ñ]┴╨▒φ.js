const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../services/database/order/batteryDamage');
const odBatteryDamageValidator = require('../../../../../com.mango.common/validators').od_battery_damage;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_damage.getMany'];

exports.validate = {
  params: {},
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryDamageValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryDamage.find(query);
  const count = await ODBatteryDamage.count({
    query: query.query
  });
  return { items, count };
};
