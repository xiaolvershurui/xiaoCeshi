const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../../services/business/order/batteryDamage');

exports.permissions = ['admin.od.battery_damage.post'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 二维码'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body }) => {
  return await ODBatteryDamage.check(body);
};
