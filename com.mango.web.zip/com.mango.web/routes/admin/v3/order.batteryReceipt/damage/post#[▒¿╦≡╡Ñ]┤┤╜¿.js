const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../services/business/order/batteryDamage');

exports.permissions = ['admin.od.battery_damage.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.string()).description('电池 二维码')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODBatteryDamage.create({
    user: ctx.state.user.id,
    station: ctx.state.user.stationId,
    batteries: body.batteries,
  });
};
