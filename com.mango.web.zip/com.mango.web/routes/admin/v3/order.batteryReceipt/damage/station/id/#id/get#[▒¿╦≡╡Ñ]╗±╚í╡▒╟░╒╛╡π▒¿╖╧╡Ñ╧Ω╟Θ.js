const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../../../../services/database/order/batteryDamage');
const odBatteryDamageValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_damage;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_damage.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('报废单 id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odBatteryDamageValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODBatteryDamage.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
