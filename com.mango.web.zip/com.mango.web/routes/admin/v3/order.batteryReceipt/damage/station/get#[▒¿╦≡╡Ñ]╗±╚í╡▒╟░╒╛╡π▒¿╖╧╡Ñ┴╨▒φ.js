const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../../services/database/order/batteryDamage');
const odBatteryDamageValidator = require('../../../../../../com.mango.common/validators').od_battery_damage;
const validatos = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_damage.getMany'];

exports.validate = {
  query: validatos.findlist,
  output: {
    200: {
      body: Joi.array().items(odBatteryDamageValidator),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  Object.assign(query.query, {
    station: ctx.state.user.stationId,
  });
  return await ODBatteryDamage.find(query);
};
