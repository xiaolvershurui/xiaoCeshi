const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../../../../services/business/order/batteryDamage');
const odBatteryDamageValidator = require('../../../../../../../../com.mango.common/validators/index').od_battery_damage;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_damage.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odBatteryDamageValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODBatteryDamage.retry({
    id: params.id,
  })
};
