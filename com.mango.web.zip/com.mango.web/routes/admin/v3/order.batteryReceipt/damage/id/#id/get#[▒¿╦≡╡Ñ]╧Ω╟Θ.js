const Joi = require('koa-joi-router').Joi;
const ODBatteryDamage = require('../../../../../../../services/database/order/batteryDamage');
const odBatteryDamageValidator = require('../../../../../../../com.mango.common/validators/index').od_battery_damage;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_damage.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odBatteryDamageValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODBatteryDamage.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
