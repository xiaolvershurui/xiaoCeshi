const Joi = require('koa-joi-router').Joi;
const ODBatteryNumberCheck = require('../../../../../services/database/order/batteryNumberCheck');
const BKBattery = require('../../../../.././services/database/ebike/battery');
const OPBatteryStation = require('../../../../.././services/database/operation/batteryStation');

// exports.permissions = ['admin.od.battery_number_check.post'];
exports.permissions = ['public'];

exports.validate = {
  type: 'json',
  body: {
    batteries: Joi.array().items(Joi.object()).description('电池 二维码或标记'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const station = ctx.state.user.stationId;

  const region = (await OPBatteryStation.findById({
    id: station,
    selector: 'region'
  })).region._id;

  const bkBatteries = (await BKBattery.find({
    query: {
      station,
    },
    limit: 0,
    selector: 'QRCode mark'
  }));

  const onlineBatteryIds = bkBatteries.reduce((memo, item) => {
    if (!body.batteries.find(i => i.QRCode === item.QRCode || i.mark === item.mark)) {
      memo = [...memo, item];
    }
    return memo;
  }, []).map(item => item._id);

  const offlineBatteryCodes = body.batteries.reduce((memo, item) => {
    if (item.QRCode) {
      if (!bkBatteries.find(i => i.QRCode === item.QRCode)) {
        memo = [...memo, item.QRCode];
      }
    }
    return memo;
  }, []);

  const offlineBatteryMarks = body.batteries.reduce((memo, item) => {
    if (item.mark) {
      if (!bkBatteries.find(i => i.mark === item.mark)) {
        memo = [...memo, item.mark];
      }
    }
    return memo;
  }, []);

  return await ODBatteryNumberCheck.create({
    user: ctx.state.user.id,
    region,
    station,
    reportBatteries: body.batteries,
    onlineBatteryIds,
    offlineBatteryCodes,
    offlineBatteryMarks,
  });
};
