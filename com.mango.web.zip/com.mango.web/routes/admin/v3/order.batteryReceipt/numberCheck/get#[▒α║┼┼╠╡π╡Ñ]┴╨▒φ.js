const ODBatteryNumberCheck = require('../../../../../services/database/order/batteryNumberCheck');
const odBatteryNumberCheckValidator = require('../../../../../com.mango.common/validators/index').od_battery_number_check;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_number_check.post'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odBatteryNumberCheckValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await ODBatteryNumberCheck.find(query);
  const count = await ODBatteryNumberCheck.count({ query: query.query });
  return { items, count };
};
