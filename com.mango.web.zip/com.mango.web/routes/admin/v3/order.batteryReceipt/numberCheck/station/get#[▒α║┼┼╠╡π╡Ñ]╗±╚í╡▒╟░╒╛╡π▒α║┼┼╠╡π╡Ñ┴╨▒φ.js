const Joi = require('koa-joi-router').Joi;
const ODBatteryNumberCheck = require('../../../../../../services/database/order/batteryNumberCheck');
const odBatteryNumberCheckValidator = require('../../../../../../com.mango.common/validators').od_battery_number_check;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_number_check.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(odBatteryNumberCheckValidator)
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  Object.assign(query.query, {
    station: ctx.state.user.stationId
  });
  return await ODBatteryNumberCheck.find(query);
};
