const Joi = require('koa-joi-router').Joi;
const ODBatteryDispatch = require('../../../../../../../../services/database/order/batteryDispatch');
const odBatteryDispatchValidator = require('../../../../../../../../com.mango.common/validators').od_battery_dispatch;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.battery_dispatch.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('调度单 id')
  },
  query: {
    selector: Joi.string().empty('').default('_id').description('字段选择器'),
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: odBatteryDispatchValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODBatteryDispatch.findInEndStation({
    id: params.id,
    endStation: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
