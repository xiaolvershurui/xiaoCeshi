const Joi = require('koa-joi-router').Joi;
const ODBatteryDispatch = require('../../../../../services/business/order/batteryDispatch');
const validators = require('../../../../../com.mango.common/settings/validators');

// exports.permissions = ['admin.od.battery_dispatch.post'];
exports.permissions = ['public'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    endStation: validators.id.description('Station Id'),
    batteries: Joi.array().items(Joi.object({
      code: Joi.string().required().description('二维码'),
    }))
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ query, body, ctx }) => {
  return await ODBatteryDispatch.createDispatchOrder({
    // dispenser: ctx.state.user.id,
    // startStation: ctx.state.user.stationId,
    dispenser: '1709170841941',
    startStation: '1708031649002',
    endStation: body.endStation,
    batteries: body.batteries
  });
};
