const Joi = require('koa-joi-router').Joi;
const ODBatteryDispatch = require('../../../../../services/database/order/batteryDispatch');
const odBatteryDispatchValidator = require('../../../../../com.mango.common/validators').od_battery_dispatch;

exports.permissions = ['admin.od.battery_dispatch.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').default('_id').description('字段选择器'),
    populateSelector: Joi.object().unknown().description('连表选项'),
  },
  output: {
    200: {
      body: Joi.array().items(odBatteryDispatchValidator),
    }
  }
};

exports.handler = async ({ query }) => {
  return await ODBatteryDispatch.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
