const Joi = require('koa-joi-router').Joi;
const ODBatteryDispatch = require('../../../../../../../../services/business/order/batteryDispatch');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

// exports.permissions = ['admin.od.battery_dispatch.put'];
exports.permissions = ['public'];

exports.validate = {
  params: {
    id: validators.id.required().description('调度单 id')
  },
  type: 'json',
  body:{
    endBatteries: Joi.array().items({
      code: Joi.string().required().description('二维码'),
    }).required().description('接收配件单')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  await ODBatteryDispatch.endDispatchOrder({
    id: params.id,
    // receiver: ctx.state.user.id,
    receiver: '1709170841941',
    endBatteries: body.endBatteries
  });
};
