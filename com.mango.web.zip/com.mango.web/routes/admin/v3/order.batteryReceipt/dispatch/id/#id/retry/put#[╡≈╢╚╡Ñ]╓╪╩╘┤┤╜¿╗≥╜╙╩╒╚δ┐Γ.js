const Joi = require('koa-joi-router').Joi;
const ODBatteryDispatch = require('../../../../../../../../services/business/order/batteryDispatch');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

// exports.permissions = ['admin.od.battery_dispatch.put'];
exports.permissions = ['public'];

exports.validate = {
  params: {
    id: validators.id.required().description('调度单 id')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  await ODBatteryDispatch.retry({
    id: params.id,
    // operator: ctx.state.user.id
    operator: '1709170841941',
  })
};
