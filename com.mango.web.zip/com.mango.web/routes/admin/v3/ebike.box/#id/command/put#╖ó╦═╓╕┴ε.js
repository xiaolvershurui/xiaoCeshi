const Joi = require('koa-joi-router').Joi;
const IoT = require('../../../../../../services/iot');

exports.permissions = ['admin.bk.box.put', 'inspection'];
exports.validate = {
  params: {
    id: Joi.string().required().example('866100033148348').description('设备号'),
  },
  type: 'json',
  body: {
    /*
    [
      'lock', 'unlock', 'start', 'stop', 'welcome', 'stopAsync', 'unlockAsync',
      'lockAsync', 'startAsync', 'welcomeAsync', 'getInfo', 'reboot', 'shutdown',
      'playSound', 'unlockBattery', 'changeServer', 'playSoundAsync', 'remoteUpgrade',
      'setSound', 'kick', 'status', 'setConfig', 'setEcoMode', 'lockBattery', 'getBMSSnap',
      'getBMSInfo', 'upgradeBMS', 'getControllerInfo', 'setSpeed', 'lightOn', 'lightOff',
    ]
     */
    command: Joi.string().required().description('指令名'),
    params: Joi.object().description('指令参数'),
  },
};
exports.handler = async ({ body, params }) => {
  return await IoT.sendCommand({
    type: 0,
    command: body.command,
    params: body.params || {},
    deviceId: params.id,
  });
};
