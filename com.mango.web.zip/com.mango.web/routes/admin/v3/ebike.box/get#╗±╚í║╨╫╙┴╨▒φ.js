const Joi = require('koa-joi-router').Joi;
const BKBox = require('../../../../services/database/ebike/box');
const validators = require('../../../../com.mango.common/settings/validators');
const bkBoxValidator = require('../../../../com.mango.common/validators/index').bk_box;

exports.permissions = ['admin.bk.box.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: validators.selector
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(bkBoxValidator),
        count: Joi.number().description('总条目数')
      })
    }
  }
};

exports.handler = async ( { query } ) => {
  const items = await BKBox.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector
  });
  const count = await BKBox.count({
    query: query.query
  });
  return { items, count }
}