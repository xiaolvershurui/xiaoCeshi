const Joi = require('koa-joi-router').Joi;
const ACWallet = require('../../../../../../services/database/account/wallet');
const walletValidator = require('../../../../../../com.mango.common/validators/index').ac_wallet;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.wallet.get'];

exports.validate = {
  params: {
    user: validators.id.required().description('User Id'),
  },
  query: {
    selector: Joi.string().empty('').description('返回字段'),
    populateSelector:Joi.object({
      user: Joi.string().empty('')
    }).empty('').description('连表选项')
  },
  output: {
    200: {
      body: walletValidator
    }
  }
};

exports.handler = async ({ params , query }) => {
 return await ACWallet.findByUser({
   user: params.user,
   selector: query.selector,
   populateSelector: query.populateSelector
 });
};