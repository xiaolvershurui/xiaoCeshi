const Joi = require('koa-joi-router').Joi;
const ACWallet = require('../../../../../../../services/business/account/wallet');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.ac.wallet.put'];

exports.validate = {
  params: {
    user: validators.id.required().description('用户ID'),
  },
  query: {
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params , query }) => {
  await ACWallet.cancelRefund({
    user: params.user
  })
};