const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../services/business/account/operator');
const validators = require('../../../../../com.mango.common/settings/validators');
const operatorValidators = require('../../../../../com.mango.common/validators/index').ac_operator;

exports.permissions = ['operation'];

exports.validate = {
  output: {
    200: {
      body: operatorValidators
    }
  }
};

exports.handler = async ({ ctx }) => {
  return await ACOperator.finishInspectionOrderSelf({ user: ctx.state.user.id })
};