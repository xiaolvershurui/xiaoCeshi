const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const ACOperator = require('../../../../../../../services/business/account/operator');

exports.permissions = ['admin.ac.operator.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('运营 ID')
  },
  output: {
    200: {
      body: Joi.array().items(Joi.number()).description('经纬度')
    }
  }
};

exports.handler = async ({ params }) => {
  return await ACOperator.getLatestPath({
    id: params.id
  })
};