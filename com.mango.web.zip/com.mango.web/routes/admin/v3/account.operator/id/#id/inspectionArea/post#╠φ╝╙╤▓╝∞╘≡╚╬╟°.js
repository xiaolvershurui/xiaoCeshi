const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../../../services/database/account/operator');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.operator.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('Operator Id'),
  },
  type:'json',
  body:{
    inspectionArea: validators.id.required().description('巡检责任区ID')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ params, body }) => {
  return await ACOperator.update({
    id: params.id,
    arrayOp:{
      $addToSet: {
        inspectionAreas: body.inspectionArea
      }
    }
  });
};