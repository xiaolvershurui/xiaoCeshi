const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../../../services/database/account/operator');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.ac.operator.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('运营 ID')
  },
  type: 'json',
  body: {
    checkStatus: Joi.number().valid(constants.AC_DRIVER_STATUS_ENUMS).required().description('审核状态')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params, body }) => {
  const operator = ACOperator.findByUser({
    user: params.id
  });
  if(!operator){
    throw new NotFoundError("运营账户不存在!")
  }
  return ACOperator.update({
    id: params.id,
    data: { checkStatus: body.checkStatus },
  });
};