const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');
const OPRiderOrder = require('../../../../../../../services/business/operation/riderOrder');
const ACOperator = require('../../../../../../../services/database/account/operator');
const BKBattery = require('../../../../../../../services/database/ebike/battery');
const BKStock = require('../../../../../../../services/database/ebike/stock');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const constants = require('../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.inspection_order.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('Operator Id'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};
exports.handler = async ({ params, ctx }) => {
  const operator = await ACOperator.findById({
    id: params.id,
    selector: 'updatedAt user isWorking inspectionType batteryBag.batteries',
  });
  if (!operator) throw new NotFoundError(`运营人员${params.id}不存在`);
  if (!operator.isWorking) throw new BadRequestError(`运营人员${params.id}已下班`);

  // const taskCount = await BKStock.count({
  //   query: {
  //     inspector: operator.user._id,
  //   },
  // });
  // if (taskCount > 0) throw new BadRequestError('您身上还有任务未完成,当前无法下班');

  if (operator.inspectionType !== constants.AC_OPERATOR_INSPECTION_TYPE.骑行 && operator.batteryBag.batteries.length > 0) {
    const batteries = await BKBattery.find({ query: { _id: { $in: operator.batteryBag.batteries } }, limit: 0, selector: 'QRCode' });
    if (batteries.some(battery => /^[^占]/.test(battery.QRCode))) throw new BadRequestError(`您身上携带电池发生异常,请发送本错误截图给线上运营.`);
    else {
      for (let battery of batteries) {
        await BKBattery.update({
          id: battery, data: {
            region: '1710190829842',
          },
        });
        await this.exec({
          c: 'record/batteryOp/updateRegion',
          params: {
            battery,
            operator: '1',
            operatorTel: '10086',
            operatorName: '系统',
            nextRegion: '1710190829842',
          },
        });
      }
    }
  }
  if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机) {
    return await OPInspectionOrder.finishInspection({
      id: params.id,
      deviceInfo: ctx.state.deviceInfo || {},
    });
  } else if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行) {

    return await OPRiderOrder.finishRider({
      id: params.id,
    });
  } else {
    // TODO: 非司机和骑手，仅下班
    return await ACOperator.update({
      id: params.id,
      updatedAt: operator.updatedAt,
      data: {
        isWorking: false,
        enableOffDuty: false,
        wrongCount: 0,
        missCount: 0,
        wrongStock: [],
        'batteryBag.total': 0,
        'batteryBag.batteries': [],
        'batteryBag.available': 0,
        'batteryBag.unavailable': 0,
        color: null,
      },
    });
  }
};
