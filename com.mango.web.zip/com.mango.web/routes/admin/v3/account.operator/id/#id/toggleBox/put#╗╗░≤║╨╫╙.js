const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../../../services/business/account/operator');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.ac.operator.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('运营 ID'),
  },
  type: 'json',
  body: {
    deviceId: Joi.string().description('盒子'),
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};

exports.handler = async ({ params, body }) => {
  return await ACOperator.toggleBox({
    id: params.id,
    deviceId: body.deviceId,
  });
};
