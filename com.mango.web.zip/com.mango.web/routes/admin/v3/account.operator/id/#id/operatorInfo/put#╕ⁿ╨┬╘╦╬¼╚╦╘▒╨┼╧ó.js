const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../../../services/business/account/operator');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.ac.operator.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('运营 ID')
  },
  type: 'json',
  body: {
    data: Joi.object({
      user: validators.id.empty('').description('绑定User账户'),
      enable: Joi.boolean().empty('').description('是否启用'),
      workEmail: Joi.string().empty('').description('工作邮箱'),
      type : Joi.number().empty('').description('司机类型'),
      inspectionPrice: Joi.string().empty('').description('计价规则'),
    }).required().description('修改信息')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params, body }) => {
  return ACOperator.updateInfo({
    id: params.id,
    data: body.data
  });
};