const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../../../services/business/account/operator');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const acOperatorValidator = require('../../../../../../../com.mango.common/validators').ac_operator;

exports.permissions = ['admin.ac.operator.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('运营 ID')
  },
  query: {},
  type: 'json',
  body: {},
  output: {
    200: {
      body: acOperatorValidator
    }
  }
};

exports.handler = async ({ params, query, body }) => {
  return await ACOperator.toggleEnableOffDuty({ id: params.id })
};