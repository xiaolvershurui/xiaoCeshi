const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../services/database/account/user');
const OPRegion = require('../../../../services/database/operation/region');
const ACOperator = require('../../../../services/database/account/operator');
const validators = require('../../../../com.mango.common/settings/validators');
const operatorValidators = require('../../../../com.mango.common/validators/index').ac_operator;

exports.permissions = ['admin.ac.operator.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(operatorValidators),
    },
  },
};

exports.handler = async ({ query }) => {
  if (query.query.name) {
    const users = await ACUser.find({
      query: {
        'cert.name': query.query.name
      },
      limit: 0
    });
    Reflect.deleteProperty(query.query, 'name');
    Object.assign(query.query, {
      user: { $in: users.map(user => user._id) },
    });
  }
  if (query.query.tel) {
    const user = await ACUser.findByTel({ tel: query.query.tel });
    Reflect.deleteProperty(query.query, 'tel');
    Object.assign(query.query, {
      user: user._id,
    });
  }
  const items = await ACOperator.find(query);
  const count = await ACOperator.count({
    query: query.query,
  });
  return { items, count };
};
