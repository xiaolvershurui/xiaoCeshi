const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../services/database/account/operator');
const validators = require('../../../../../com.mango.common/settings/validators');
const operatorValidators = require('../../../../../com.mango.common/validators/index').ac_operator;

exports.permissions = ['admin.ac.operator.get'];

exports.validate = {
  query : {
    user: validators.id.required().description('User ID'),
    selector: Joi.string().empty('').description('返回字段'),
    populateSelector: Joi.object({
      inspectionAreas: Joi.string().empty('').description('polygon'),
      user: Joi.string().empty('').description('User'),
      regions: validators.id.empty('').description('region')
    }).description('连表选项'),
  },
  output: {
    200: {
      body: operatorValidators
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ACOperator.findByUser({
    user: params.user,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};