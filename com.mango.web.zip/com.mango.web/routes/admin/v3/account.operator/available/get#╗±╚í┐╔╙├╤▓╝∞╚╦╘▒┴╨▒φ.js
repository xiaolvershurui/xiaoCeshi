const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../services/database/account/operator');
const validators = require('../../../../../com.mango.common/settings/validators');
const operatorValidators = require('../../../../../com.mango.common/validators/index').ac_operator;
const NotFoundError =require('../../../../../com.mango.common/errors/NotFoundError');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.ac.operator.getMany'];

exports.validate = {
  query:{
    region: validators.id.required().description('region'),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数')
  },
  output: {
    200: {
      body: operatorValidators
    }
  }
};

exports.handler = async ({ ctx, query }) => {
  const { regionIds } = ctx.state.user;
  if (!regionIds.includes(query.region)){
    throw new NotFoundError('无大区权限');
  }
  return await ACOperator.findAvailableInspectorByRegion({
    region: query.region,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip
  })
};