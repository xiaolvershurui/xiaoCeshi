const RCBatteryOp = require('../../../../../services/database/record/batteryOp');
const BKBattery = require('../../../../../services/database/ebike/battery');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['operation'];
exports.validate = {
  query: {
    QRCode: Joi.string().required().description('二维码').error(new Error('二维码不正确')),
    selector: Joi.string(),
    populateSelector: Joi.object({
      battery: Joi.string(),
      inStation: Joi.string(),
      fromAccount: Joi.string(),
    }).description('联表选项')
  },
  output: {
    200:{
      body: Joi.array().items(Joi.object()),
    }
  }
};

exports.handler = async ({ query }) => {
  const battery = await BKBattery.findById({
    query: {
      QRCode: query.QRCode
    }
  });
  return await RCBatteryOp.find({
    query: {
      battery: battery._id
    },
    limit: query.limit,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
