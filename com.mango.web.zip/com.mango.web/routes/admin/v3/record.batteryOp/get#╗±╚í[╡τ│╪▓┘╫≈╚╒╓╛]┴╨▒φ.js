const RCBatteryOp = require('../../../../services/database/record/batteryOp');
const Joi = require('koa-joi-router').Joi;
const rcBatteryOpValidator = require('../../../../com.mango.common/validators/index').rc_battery_op;

exports.permissions = ['admin.rc.battery_op.getMany'];

exports.validate = {
  query: {
    query: Joi.object(),
    limit: Joi.number(),
    skip: Joi.number(),
    sort: Joi.object(),
    selector: Joi.string(),
    populateSelector: Joi.object({
      battery: Joi.string(),
      inStation: Joi.string(),
      fromAccount: Joi.string(),
    }).description('联表选项')
  },
  output: {
    200: {
      body: Joi.array().items(rcBatteryOpValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  return await RCBatteryOp.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};