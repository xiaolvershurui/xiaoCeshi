const Joi = require('koa-joi-router').Joi;
const ACCoupon = require('../../../../../../services/database/account/coupon');
const couponValidator = require('../../../../../../com.mango.common/validators/index').ac_coupon;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.coupon.getMany'];

exports.validate = {
  params: {
    user: Joi.string().required().description('用户'),
  },
  query: validators.findlist,
  output: {
    200: {
      body:validators.tableListOutput(couponValidator)
    }
  }
};

exports.handler = async ({ params, query }) => {
  return {
    items: await ACCoupon.find({
      query: { user: params.user },
      limit: query.limit,
      sort: query.sort,
      selector: query.selector,
      populateSelector: query.populateSelector
    }),
    count: await  ACCoupon.count({ user: params.user })
  };
};
