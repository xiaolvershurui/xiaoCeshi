const Joi = require('koa-joi-router').Joi;
const ACCoupon = require('../../../../../services/business/account/coupon');
const NotFoundError = require('../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.ac.coupon.post'];

exports.validate = {
  params: {
    user: validators.id.required().description('用户ID')
  },
  query: {

  },
  type: 'json',
  body: Joi.object({
    state: Joi.number().empty().description('使用状态'),
    name: Joi.string().empty('').default('赔付补偿').description('优惠券名称'),
    amount: validators.amount.required().description('优惠券面额'),
    type: Joi.number().valid(constants.AC_COUPON_TYPE_ENUMS).default(constants.AC_COUPON_TYPE.租金抵扣券),
    count: Joi.number().required().min(1).default(1).description('优惠券数量'),
    validDuration: Joi.number().required().min(7).default(7).description('有效期天数')
  }),
  output: {
    200: {
      body: Joi.object({})
    }
  }
};

exports.handler = async ({ body, params }) => {
  return await ACCoupon.issueByUser({
    user: params.user,
    name: body.name,
    amount: body.amount,
    type: body.type,
    count: body.count,
    validDuration: body.validDuration,
    state: body.state
  });
};