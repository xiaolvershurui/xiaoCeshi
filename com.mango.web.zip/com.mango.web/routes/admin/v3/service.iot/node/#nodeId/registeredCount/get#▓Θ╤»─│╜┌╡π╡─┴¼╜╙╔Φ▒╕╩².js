const { askNode } = require('../../../../../../../services/iot/index');

exports.permissions = ['admin'];

exports.handler = async ({ params }) => {
  return await askNode(params.nodeId, 'registered_count');
};
