const { ask } = require('../../../../../services/iot/index');

exports.permissions = ['admin'];

exports.handler = async () => {
  const result = await ask('registered_count');
  if(result.reduce) {
    const sum = result.reduce((memo, item) => {
      memo += item.count;
      return memo;
    }, 0);
    return {
      sum,
      result,
    };
  } else {
    return result;
  }
};
