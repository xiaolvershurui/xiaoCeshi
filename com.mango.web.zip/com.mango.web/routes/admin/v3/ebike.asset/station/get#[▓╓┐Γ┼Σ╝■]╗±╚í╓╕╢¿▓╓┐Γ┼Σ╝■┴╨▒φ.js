const Joi = require('koa-joi-router').Joi;
const BKAsset = require('../../../../../services/database/ebike/asset');
const validators = require('../../../../../com.mango.common/settings/validators');
const stAssetValidators = require('../../../../../com.mango.common/validators').st_asset;

exports.permissions = ['admin.st.asset.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector:Joi.object({
      region: Joi.string().allow('').description('大区'),
      station: Joi.string().allow('').description('仓库'),
      asset: Joi.string().allow('').description('物料'),
    }).empty('').description('连表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(stAssetValidators),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  const items = await BKAsset.find({
    query: {
      station: ctx.state.user.stationId
    },
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await BKAsset.count({
    query: {
      station: ctx.state.user.stationId
    }
  });
  return { items, count };
};
