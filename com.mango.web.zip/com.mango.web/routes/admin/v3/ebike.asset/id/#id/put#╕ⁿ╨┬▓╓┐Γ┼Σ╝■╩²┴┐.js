const Joi = require('koa-joi-router').Joi;
const BKAsset = require('../../../../../../services/business/ebike/asset');
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.asset.put'];

exports.validate = {
  params: {
    id: validators.id
  },
  query: {},
  type: 'json',
  body: {
    data: {
      totalCount: Joi.number().description('配件总量'),
      intactCount: Joi.number().description('完好数量'),
      damageCount: Joi.number().description('损坏数量'),
      repairCount: Joi.number().description('返修数量'),
      scrapCount: Joi.number().description('报废数量'),
      purchaseCount: Joi.number().description('是否需要进货阈值(警戒数量)')
    }
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body }) => {
  return await BKAsset.update({
    id: params.id,
    data: body.data
  })
};
