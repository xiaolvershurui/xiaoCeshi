const Joi = require('koa-joi-router').Joi;
const BKAsset = require('../../../../services/business/ebike/asset');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.asset.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    region: Joi.string().required().description('物料类型'),
    station: Joi.string().required().description('二维码'),
    asset: Joi.string().required().description('二维码'),
    code: Joi.string().required().description('二维码'),
    totalCount: Joi.number(),
    intactCount: Joi.number(),
    damageCount: Joi.number(),
    repairCount: Joi.number(),
    scrapCount: Joi.number(),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ query, body }) => {
  return await BKAsset.create({
    region: body.region,
    station: body.station,
    asset: body.asset,
    code: body.code,
    totalCount: body.totalCount,
    intactCount: body.intactCount,
    damageCount: body.damageCount,
    repairCount: body.repairCount,
    scrapCount: body.scrapCount,
  })
};
