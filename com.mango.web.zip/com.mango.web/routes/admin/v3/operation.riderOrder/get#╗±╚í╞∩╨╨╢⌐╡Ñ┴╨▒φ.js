const Joi = require('koa-joi-router').Joi;
const OPRiderOrder = require('../../../../services/database/operation/riderOrder');
const validators = require('../../../../com.mango.common/settings/validators');
const riderOrderValidator = require('../../../../com.mango.common/validators/index').op_rider_order;

exports.permissions = ['admin.op.rider_order.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(riderOrderValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  const items = await OPRiderOrder.find(query);
  const count = await OPRiderOrder.count({
    query: query.query
  });
  return { items, count }
};
