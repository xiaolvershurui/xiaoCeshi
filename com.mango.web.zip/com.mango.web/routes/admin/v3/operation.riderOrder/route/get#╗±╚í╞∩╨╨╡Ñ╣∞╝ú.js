const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const getDistance = require('../../../../../utils/calculateDistanceBetweenPointAndPoint');

exports.permissions = ['admin.op.rider_order.getMany'];

exports.validate = {
  query: {
    startTime: Joi.date().required(),
    endTime: Joi.date().required(),
    box: Joi.string().required(),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ query }) => {
  const coordinates = await RCStockPoint.findPathWithGPSInfo(query);
  const points = [];
  coordinates.forEach(coordinate => {
    if (coordinate && coordinate.gps && coordinate.gps.lngLat) {
      points.push(coordinate);
    }
  });
  let distance = 0;
  if (points.length > 0) {
    distance = getDistance(points);
  }
  return {
    coordinates,
    distance,
  };
};
