const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPRiderOrder = require('../../../../../../../services/database/operation/riderOrder');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
exports.permissions = ['admin.op.rider_order.put'];

exports.validate = {
  params: {
    id: validators.id.required(),
  },
  type: 'json',
  body: {
    distance: Joi.number().min(0).required().description('巡检里程')
  }
};

exports.handler = async ({ params, body, ctx }) => {
  const opRiderOrder = await OPRiderOrder.findById({ id: params.id });
  if (!opRiderOrder) throw new NotFoundError('骑手订单不存在');

  return await OPRiderOrder.update({
    id: params.id,
    data: {
      'route.inInspection.distance': body.distance
    },
  })
};
