const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPRiderOrder = require('../../../../../../../services/business/operation/riderOrder');

exports.permissions = ['admin.op.rider_order.put'];

exports.validate = {
  params: {
    id: validators.id.required(),
  },
  type: 'json',
  body: {
    remark: Joi.string(),
    auditedBikes: Joi.array().items(Joi.object({
      id: Joi.string().required(),
      isPassed: Joi.boolean().required(),
    }))
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await OPRiderOrder.audit(Object.assign(params, body, {
    auditor: ctx.state.user.id
  }))
};