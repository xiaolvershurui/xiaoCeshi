const Joi = require('koa-joi-router').Joi;
const OPRiderOrder = require('../../../../../../services/database/operation/riderOrder');
const riderOrderValidator = require('../../../../../../com.mango.common/validators').op_rider_order;
const validators = require('../../../../../../com.mango.common/settings/validators');
const moment = require('moment');
const oss = require('../../../../../../services/oss');

exports.permissions = ['admin.op.rider_order.get'];

exports.validate = {
  params: {
    id: validators.id.required(),
  },
  query: validators.findOne,
  output: {
    200: {
      body: riderOrderValidator,
    },
  },
};
exports.handler = async ({ params, query }) => {
  return await OPRiderOrder.findById(Object.assign({
    id: params.id,
  }, query));
};
