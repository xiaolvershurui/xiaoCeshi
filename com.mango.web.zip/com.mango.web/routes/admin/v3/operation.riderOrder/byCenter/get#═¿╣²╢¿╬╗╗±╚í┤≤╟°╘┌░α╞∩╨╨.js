const Joi = require('koa-joi-router').Joi;
const ACOperator = require('../../../../../services/database/account/operator');
const OPRegion = require('../../../../../services/database/operation/region');
const OPInspectionOrder = require('../../../../../services/database/operation/inspectionOrder');
const OPRiderOrder = require('../../../../../services/database/operation/riderOrder');
const validators = require('../../../../../com.mango.common/settings/validators');
const riderOrderValidators = require('../../../../../com.mango.common/validators/index').op_rider_order;
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.ac.operator.get'];

exports.validate = {
  query: {
    center: validators.location.required(),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ query }) => {
  const region = await OPRegion.findIntersect({
    center: query.center,
    query: { enable: true },
    maxDistance: 10000,
    minDistance: 0,
  });
  if (!region) return [];
  const riderOrders = await OPRiderOrder.find({
    query: {
      state: constants.OP_RIDER_ORDER_STATE.派单中,
      region: region._id,
    },
    limit: 0,
    selector: 'user.tel user.name times box',
  });
  const inspectionOrders = await OPInspectionOrder.find({
    query: {
      state: constants.OP_INSPECTION_ORDER_STATE.派单中,
      region: region._id,
    },
    limit: 0,
    selector: 'user.tel user.name times box',
  });
  return riderOrders.concat(inspectionOrders);
};
