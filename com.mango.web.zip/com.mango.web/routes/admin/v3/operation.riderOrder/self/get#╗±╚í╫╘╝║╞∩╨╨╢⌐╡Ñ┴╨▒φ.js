const Joi = require('koa-joi-router').Joi;
const OPRiderOrder = require('../../../../../services/database/operation/riderOrder');
const validators = require('../../../../../com.mango.common/settings/validators');
const riderOrderValidator = require('../../../../../com.mango.common/validators').op_rider_order;

exports.permissions = ['admin.op.inspection_order.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(riderOrderValidator)
    }
  }
};
exports.handler = async ({ query, ctx }) => {
  return await OPRiderOrder.findByUser(Object.assign({
    user: ctx.state.user.id,
  }, query));
};