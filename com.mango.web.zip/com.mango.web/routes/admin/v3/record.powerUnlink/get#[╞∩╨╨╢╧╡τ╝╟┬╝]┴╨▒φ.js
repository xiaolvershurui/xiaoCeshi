const RCPowerUnlink = require('../../../../services/database/record/powerUnlink');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const powerUnlinkValidator = require('../../../../com.mango.common/validators/index').rc_power_unlink;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.power_unlink.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(powerUnlinkValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  return await RCPowerUnlink.find(query);
};