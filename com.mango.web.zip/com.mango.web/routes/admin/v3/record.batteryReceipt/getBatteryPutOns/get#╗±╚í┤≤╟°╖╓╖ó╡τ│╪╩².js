const Joi = require('koa-joi-router').Joi;
const RCBatteryReceipt = require('../../../../../services/database/record/batteryReceipt');
const OPBatteryStation = require('../../../../../services/database/operation/batteryStation');

exports.permissions = ['admin.rc.battery_receipt.get'];

exports.validate = {
  query: {
    region: Joi.string().required(),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ query }) => {
  // 获取分发电池数
  let stations = await OPBatteryStation.find({
    query: { region: query.region },
    limit: 0,
    selector: '_id',
  });
  stations = stations.map(item => item._id);
  let putOnBatteries = await RCBatteryReceipt.find({
    query: {
      createdAt: {
        $gte: 'today'.beginning,
        $lt: 'today'.ending,
      },
      isInBound: false,
      sourceStation: {
        $in: stations,
      },
    },
    limit: 0,
    selector: 'batteries',
  });
  putOnBatteries = putOnBatteries.reduce((memo, item) => {
    memo += item.batteries.length;
    return memo;
  }, 0);
  return {
    date: 'today'.beginning,
    putOnBatteries
  };
};
