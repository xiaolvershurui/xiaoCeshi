const RCDpositRefund = require('../../../../services/database/record/depositRefund');
const Joi = require('koa-joi-router').Joi;
const rcDepositRefundValidator = require('../../../../com.mango.common/validators/index').rc_deposit_refund;

exports.permissions = ['admin.rc.deposit_refund.getMany'];

exports.validate = {
  query: {
    query: Joi.object(),
    limit: Joi.number(),
    skip: Joi.number(),
    sort: Joi.object(),
    selector: Joi.string().empty(''),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'region': Joi.string()
    }).empty('').description('联表选项')
  },
  output: {
    200: {
      body: Joi.array().items(rcDepositRefundValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  return await RCDpositRefund.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};