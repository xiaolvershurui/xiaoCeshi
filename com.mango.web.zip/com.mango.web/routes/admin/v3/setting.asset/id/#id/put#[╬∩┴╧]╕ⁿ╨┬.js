const Joi = require('koa-joi-router').Joi;
const STAsset = require('../../../../../../services/business/setting/asset');
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.asset.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('STAsset Id')
  },
  type: 'json',
  body: {
    data: {
      type: Joi.string().empty('').description('物料类型'),
      image: Joi.string().empty('').description('图片'),
      description: Joi.string().empty('').description('描述'),
      group: Joi.number().empty('').description('类型')
    }
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body }) => {
  return await STAsset.update({
    id: params.id,
    data: body.data
  })
};
