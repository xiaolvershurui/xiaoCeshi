const Joi = require('koa-joi-router').Joi;
const STAsset = require('../../../../services/business/setting/asset');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.asset.post'];

exports.validate = {
  type: 'json',
  body: {
    type: Joi.string().required().description('物料类型'),
    code: Joi.string().required().description('二维码'),
    image: Joi.string().empty('').description('图片'),
    description: Joi.string().empty('').description('备注'),
    group: Joi.number().description('类型')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body,ctx }) => {
  return await STAsset.create({
    type: body.type,
    code: body.code,
    image: body.image,
    description: body.description,
    operator:  ctx.state.user.id,
    group: body.group
  })
};
