const Joi = require('koa-joi-router').Joi;
const STAsset = require('../../../../services/database/setting/asset');
const validators = require('../../../../com.mango.common/settings/validators');
const stAssetValidators = require('../../../../com.mango.common/validators').st_asset;

exports.permissions = ['admin.st.asset.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(stAssetValidators),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await STAsset.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector
  });
  const count = await STAsset.count({
    query: query.query
  });
  return { items, count };
};
