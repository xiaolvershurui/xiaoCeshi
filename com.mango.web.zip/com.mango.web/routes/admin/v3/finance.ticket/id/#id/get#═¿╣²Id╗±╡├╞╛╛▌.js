const FNTicket = require('../../../../../../services/database/finance/ticket');
const validators = require('../../../../../../com.mango.common/settings/validators');
const Joi = require('poolishark').Joi;

exports.permission = ['admin.fn.ticket.get'];

exports.validate = {
  params:{
    id: validators.id.required().description('支付凭据Id')
  },
  query: {
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      user: Joi.string()
    }).description('连表选项')
  },
  output:{
    200:{
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async({ params, query }) => {
  return await FNTicket.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};