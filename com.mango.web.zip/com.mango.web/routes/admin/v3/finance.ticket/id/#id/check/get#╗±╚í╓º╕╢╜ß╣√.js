const FNTicket = require('../../../../../../../services/business/finance/ticket');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const Joi = require('poolishark').Joi;

exports.permission = ['admin.fn.ticket.get'];

exports.validate = {
  params:{
    id: validators.id.required().description('支付凭据Id')
  },
  output:{
    200:{
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async({ params }) => {
  return await FNTicket.check({
    id: params.id
  })
};