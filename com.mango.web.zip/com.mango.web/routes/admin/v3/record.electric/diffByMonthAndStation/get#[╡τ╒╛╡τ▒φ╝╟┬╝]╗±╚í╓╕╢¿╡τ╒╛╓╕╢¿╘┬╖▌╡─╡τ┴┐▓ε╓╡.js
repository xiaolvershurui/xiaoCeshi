const RCElectric = require('../../../../../services/database/record/electric');
const Joi = require('koa-joi-router').Joi;
const rcElectricValidators = require('../../../../../com.mango.common/validators/index').rc_electric;
const validators = require('../../../../../com.mango.common/settings/validators');

// exports.permissions = ['admin.rc.electric.get'];
exports.permissions = ['public'];

exports.validate = {
  query: {
    year: Joi.number().required().description('年份'),
    month: Joi.number().required().description('月份'),
    station: Joi.string().required().description('站点 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ query }) => {
  const rcElectrics = await RCElectric.find({
    query,
    limit: 0,
    selector: 'electricQuantity'
  });
  let diffElectric = 0;
  if (rcElectrics.length) {
    diffElectric = Math.abs(parseFloat((rcElectrics[0].electricQuantity - rcElectrics[rcElectrics.length - 1].electricQuantity).toFixed(1)));
  } else {
    diffElectric = null;
  }

  return { diffElectric };
};
