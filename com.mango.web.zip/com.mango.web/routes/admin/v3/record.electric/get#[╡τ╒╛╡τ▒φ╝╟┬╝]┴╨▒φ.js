const RCElectric = require('../../../../services/database/record/electric');
const Joi = require('koa-joi-router').Joi;
const rcElectricValidators = require('../../../../com.mango.common/validators/index').rc_electric;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.rc.electric.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(rcElectricValidators)
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await RCElectric.find(query);
  const count = await RCElectric.count({
    query: query.query
  });
  return { items, count }
};
