const ODOrder = require('../../../../services/database/order/order');
const Joi = require('koa-joi-router').Joi;
const odOrderValidator = require('../../../../com.mango.common/validators/index').od_order;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.order.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odOrderValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  const items = await ODOrder.find(query);
  const count = await ODOrder.count({
    query: query.query
  });
  return { items, count }
};
