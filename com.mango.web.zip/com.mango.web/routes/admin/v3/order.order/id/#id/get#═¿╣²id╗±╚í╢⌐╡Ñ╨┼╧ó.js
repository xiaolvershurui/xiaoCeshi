const ODOrder = require('../../../../../../services/database/order/order');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.order.get'];
exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  query: {
    selector: Joi.string().empty(''),
    populateSelector: Joi.object({
      user: Joi.string().empty(''),
      stock: Joi.string().empty(''),
      region: Joi.string().empty(''),
      style: Joi.string().empty(''),
      reservation: Joi.string().empty(''),
      'payInfo.coupon.ref': Joi.string().empty(''),
    }).allow(null),
    cache: validators.cache,
  }
  // TODO: output
};
exports.handler = async ({ params, query }) => {
  return await ODOrder.findById(Object.assign({}, params, query));
};