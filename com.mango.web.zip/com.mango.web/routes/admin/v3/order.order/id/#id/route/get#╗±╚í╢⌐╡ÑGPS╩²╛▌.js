const BKStock = require('../../../../../../../services/database/ebike/stock');
const BKBattery = require('../../../../../../../services/business/ebike/battery');
const RCBatteryPoint = require('../../../../../../../services/database/record/batteryPoint');
const ODOrder = require('../../../../../../../services/database/order/order');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const OTSBatteryInStockPoint = require('../../../../../../../services/ots/batteryInStockPoint');

exports.permissions = ['admin.od.order.getMany'];

exports.validate = {
  params: {
    id: validators.id.required().description('订单 Id'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};
exports.handler = async ({ params, query }) => {
  const order = await ODOrder.findById({
    id: params.id,
    selector: 'lease.startTime lease.endTime box'
  });

  if(!order) throw new NotFoundError(`订单${params.id}不存在`);
  if(!order.box) throw new NotFoundError(`订单${params.id}盒子不存在`);

  const now = new Date(order.endTime);
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}0`.slice(-3, -1);

  return await ODOrder.getOrderPoint({
    now,
    box: order.box._id,
    year,
    month,
    startTime: order.startTime && order.startTime.getTime(),
    endTime: order.endTime && order.endTime.getTime(),
  });
};