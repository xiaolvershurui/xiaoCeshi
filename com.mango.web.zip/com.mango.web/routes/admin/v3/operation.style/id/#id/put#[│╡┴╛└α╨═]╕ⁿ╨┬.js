const OPStyle = require('../../../../../../services/database/operation/style');
const constants = require('../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../com.mango.common/settings/validators');
const styleValidator = require('../../../../../../com.mango.common/validators/index').op_style;
const Joi = require('poolishark').Joi;

exports.permissions = ['admin.op.style.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Style Id')
  },
  type: 'json',
  body: {
    data: Joi.object({
      name: Joi.string().description('车型名称'),
      number: Joi.string().description('车型编号'),
      thumbnail: Joi.string().description('车辆缩略图'),
      level: Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS).description('车型等级'),
      maxMileage: Joi.number().description('最大续航里程'),
      ratedVoltage: Joi.number().description('电池额定电压')
    })
  },
  query: {
    selector: Joi.string().description('返回字段')
  },
  output: {
    200: {
      body: styleValidator
    }
  }
};

exports.handler = async ({ params, data }) => {
  return await OPStyle.update({
      id: params.id,
      data
  });
};