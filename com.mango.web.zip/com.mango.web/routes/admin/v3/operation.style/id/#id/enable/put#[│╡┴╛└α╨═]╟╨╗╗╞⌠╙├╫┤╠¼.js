const OPStyle = require('../../../../../../../services/database/operation/style');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

const Joi = require('poolishark').Joi;

exports.permissions = ['admin.op.style.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Style Id')
  },
  type: 'json',
  body:{
    enable: Joi.boolean().required().description('启用状态')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({params, body}) => {
  return await OPStyle.update({
    id: params.id,
    data:{
      enable : body.enable
    }
  });
};