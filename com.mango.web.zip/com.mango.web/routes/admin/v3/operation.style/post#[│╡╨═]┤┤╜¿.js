const OPStyle = require('../../../../services/database/operation/style');
const validators = require('../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.style.post'];

exports.validate = {
  type: 'json',
  body: {
    name: Joi.string().required().description('车型名称'),
    number: Joi.string().required().description('车型编号'),
    thumbnail: Joi.string().required().description('车型缩略图'),
    level: Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS).required().description('车型等级'),
    maxMileage: Joi.number().required().description('最大续航里程'),
    ratedVoltage: Joi.number().required().description('电池额定电压')
  },
  output: {
    200: {
      body: Joi.object({})
    }
  }
};

exports.handler = async ({ body }) => {
  return await OPStyle.create({
    name: body.name,
    number: body.number,
    thumbnail: body.thumbnail,
    level: body.level,
    maxMileage: body.maxMileage,
    ratedVoltage: body.ratedVoltage
  });
};
