const OPRegion = require('../../../../../../../services/database/operation/region');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.region.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Region id'),
  },
  type: 'json',
  body: {
    offHire: Joi.boolean().required().description('是否停租'),
    offHireDescription: Joi.string().empty('').description('停租描述'),
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await OPRegion.update({
    id: params.id,
    data: body,
  });
};