const OPRegion = require('../../../../../../../services/database/operation/region');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.op.region.put'];
exports.validate = {
  params: {
    id: validators.id.required().description('Region id')
  },
  type: 'json',
  body: {
    level: Joi.number().required().valid(constants.OP_STYLE_LEVEL_ENUMS).description('需要修改的车型等级'),
    price: Joi.object({
      timeUnit: validators.amount.required().description('时间单价 元/分钟'),
      mileageUnit: validators.amount.required().description('里程单价 元/公里'),
      floorCost: validators.amount.required().description('最低消费 元'),
      enableInsurance: Joi.boolean().required().description('是否开通保险服务'),
      insurance: validators.amount.required().description('保费 元'),
      parkingRate: Joi.number().min(0).max(1).required().description('停车区停车折扣率'),
      dayCeilingCost: validators.amount.required().description('日封顶 元'),
      nightCeilingCost: validators.amount.required().description('夜封顶 元')
    }).unknown()
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({params, body}) => {
  return await OPRegion.update({
    id: params.id,
    data: {
      [`prices.${body.level}`]: body.price
    }
  });
};