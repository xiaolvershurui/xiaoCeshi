const OPRegion = require('../../../../../../../services/database/operation/region');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.op.region.put'];
exports.validate = {
  params: {
    id: validators.id.required().description('Region id')
  },
  type: 'json',
  body: {
    path: Joi.array().items(Joi.string()).required().description('大区围栏'),
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({params, body}) => {
  return await OPRegion.update({
    id: params.id,
    data: {
      path: {
        type: 'Polygon',
        coordinates: body.path
      }
    }
  });
};