const OPRegion = require('../../../../../../../services/database/operation/region');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.region.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Region id'),
  },
  type: 'json',
  body: {
    dispatchCost: Joi.number().required().description('调度费用')
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await OPRegion.update({
    id: params.id,
    data: body,
  });
};
