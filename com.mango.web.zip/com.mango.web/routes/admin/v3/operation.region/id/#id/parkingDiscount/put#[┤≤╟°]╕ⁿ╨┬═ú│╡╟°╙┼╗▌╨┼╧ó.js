const OPRegion = require('../../../../../../../services/database/operation/region');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin'];

exports.validate = {
  params: {
    id: validators.id.required().description('Region id'),
  },
  type: 'json',
  body: {
    parkingDiscount: Joi.object({
      rate: Joi.number().description('折率'),
      content: Joi.string().description('折率内容描述')
    }).required().description('停车区优惠信息')
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await OPRegion.update({
    id: params.id,
    data: body,
  });
};
