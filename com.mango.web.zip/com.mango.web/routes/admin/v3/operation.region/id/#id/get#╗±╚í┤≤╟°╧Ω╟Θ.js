const OPRegion = require('../../../../../../services/database/operation/region');
const Joi = require('joi');
const constants = require('../../../../../../com.mango.common/settings/constants');
const opRegionValidator = require('../../../../../../com.mango.common/validators/index').op_region;
const validators = require('../../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.op.region.get'];
exports.validate = {
  params: {
    id: validators.id.required().description('Region Id')
  },
  query: {
    selector: Joi.string().description('返回对象'),
    populateSelector: Joi.object({
      'owner': Joi.string(),
      'managers': Joi.string()
    }).default({}).description('连表选项')
  },
  output: {
    200: {
      body: opRegionValidator
    }
  }
};
exports.handler = async ({params, query}) => {
  return await OPRegion.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};