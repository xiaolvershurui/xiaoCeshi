const OPRegion = require('../../../../services/database/operation/region');
const validators = require('../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.region.post'];

exports.validate = {
  type: 'json',
  body: {
    name: Joi.string().required().description('大区名称'),
    city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('大区所在城市'),
    path: Joi.array().items(Joi.object()).description('围栏轨迹')
  }
};

exports.handler = async ({ body }) => {
  // TODO： 创建对应的物料配件
  return await OPRegion.create({
    name: body.name,
    city: body.city,
    path: body.path
  });
};
