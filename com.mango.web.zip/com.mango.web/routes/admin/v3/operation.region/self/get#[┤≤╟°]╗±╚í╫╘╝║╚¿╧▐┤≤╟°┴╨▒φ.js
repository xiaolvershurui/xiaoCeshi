const OPRegion = require('../../../../../services/database/operation/region');
const validators = require('../../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const opRegionValidator = require('../../../../../com.mango.common/validators/index').op_region;

exports.permissions = ['admin.op.region.getMany'];

exports.validate = {
  output: {
    200: {
      body: Joi.array().items(opRegionValidator),
    },
  },
};
exports.handler = async ({ query, ctx }) => {
  return await OPRegion.find({
    query: {
      _id: {
        $in: ctx.state.user.regionIds
      }
    },
    limit: 0,
    selector: 'name'
  });
};
