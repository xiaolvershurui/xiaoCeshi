const OPRegion = require('../../../../services/database/operation/region');
const validators = require('../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const opRegionValidator = require('../../../../com.mango.common/validators/index').op_region;

exports.permissions = ['admin.op.region.getMany'];

exports.validate = {
  query: {
    limit: Joi.number().description('限制条目'),
    sort: Joi.object().description('排序选项'),
    skip: Joi.number().description('跳过条目'),
    query: Joi.object().description('查询参数'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'owner': Joi.string(),
      'managers': Joi.string()
    }).default({})
  },
  output: {
    200: {
       body: {
         items: Joi.array().items(opRegionValidator),
         count: Joi.number().description('总页数')
       }
    }
  }
};
exports.handler = async ({query}) => {
  const items = await OPRegion.find({
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    query: query.query,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await OPRegion.count({
    query: query.query
  });
  return { items, count };
};
