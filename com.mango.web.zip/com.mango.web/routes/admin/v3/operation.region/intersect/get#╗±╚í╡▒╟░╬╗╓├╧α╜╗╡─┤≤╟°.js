const OPRegion = require('../../../../../services/database/operation/region');
const validators = require('../../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;

exports.permissions = ['admin.op.region.get'];

exports.validate = {
  query: {
    center: validators.location.required(),
    query: Joi.object(),
    selector: validators.selector,
    cache: validators.cache
  }
};

exports.handler = async ({ query }) => {
  return await OPRegion.findIntersect(Object.assign({
    query: {
      enable: true
    }
  }, query));
};