const Joi = require('koa-joi-router').Joi;
const STCommodity = require('../../../../services/business/setting/commodity');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.commodity.post'];

exports.validate = {
  type: 'json',
  body: {
    year: Joi.number().required().description('年份'),
    month: Joi.number().required().description('月份'),
    commodity: Joi.array().items(Joi.object({
      id: Joi.string().description('商品id'),
      day: Joi.number().description('当月的第几天')
    })).description('每月签到奖励'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body, ctx }) => {
  const { id } = ctx.state.user;
  return await STCommodity.create(Object.assign({ user: id }, body));
};