const Joi = require('koa-joi-router').Joi;
const STCommodity = require('../../../../services/database/setting/commodity');
const commodityValidator = require('../../../../com.mango.common/validators/index').st_commodity;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.commodity.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(commodityValidator),
        count: Joi.number().description('总页数'),
      }),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await STCommodity.find(query);
  const count = await STCommodity.count({
    query: query.query,
  });
  return { items, count };
};