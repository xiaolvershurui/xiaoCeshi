const Joi = require('koa-joi-router').Joi;
const STCommodity = require('../../../../../../../services/business/setting/commodity');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.commodity.put'];

exports.validate = {
  params: {
    id: validators.id.required(),
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('商品是否可用'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body }) => {
  return await STCommodity.update({
    id :params.id,
    data: body
  });
};