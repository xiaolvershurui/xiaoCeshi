const OPReportedDamage = require('../../../../../../services/database/operation/reportedDamage');
const validators =  require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const reportedDamageValidator = require('../../../../../../com.mango.common/validators/index').op_reported_damage;
const Joi = require('poolishark').Joi;

exports.permissions = ['admin.od.reportedAbuse.get'];
exports.validate = {
  params: {
    id: validators.id.required().description('举报记录编号')
  },
  query: {
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'bike': Joi.string().allow(''),
      'reporter': Joi.string().allow(''),
      'processor': Joi.string().allow(''),
    }).default({}).description('连表查询字段')
  },
  output: {
    200:{
      body: reportedDamageValidator
    }
  }
};

exports.handler = async ({ query, params }) => {
  return await OPReportedDamage.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};