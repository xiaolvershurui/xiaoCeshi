const OPReportedDamage = require('../../../../../../../services/business/operation/reportedDamage');
const validators =  require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const Joi = require('poolishark').Joi;

exports.permissions = ['admin.od.reportedDamage.put'];
exports.validate = {
  params: {
    id: validators.id.required().description('举报记录编号')
  },
  type: 'json',
  body: {
    result: Joi.number().valid(constants.OP_REPORTED_ABUSE_RESULT_ENUMS).required().description('处理结果'),
    remark: Joi.string().required().description('处理结果备注')
  },
  output: {
    200:{
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ body, ctx, params }) => {
  return await OPReportedDamage.process({
    id: params.id,
    result: body.result,
    processor: ctx.state.user.id,
    remark: body.remark
  });
};