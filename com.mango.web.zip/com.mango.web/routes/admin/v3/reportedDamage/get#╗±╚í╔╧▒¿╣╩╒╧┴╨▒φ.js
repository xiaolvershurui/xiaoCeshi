const OPReportedDamage = require('../../../../services/database/operation/reportedDamage');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const reportedDamageValidator = require('../../../../com.mango.common/validators/index').op_reported_damage;

exports.permissions = ['admin.od.reportedDamage.getMany'];
exports.validate = {
  query: {
    query: Joi.object().default({}),
    limit: Joi.number(),
    sort: Joi.object().description('排序选项'),
    skip: Joi.number(),
    selector: Joi.string().description('连表选项'),
    populateSelector: Joi.object({
      'bike': Joi.string().allow(''),
      'reporter': Joi.string().allow(''),
      'processor': Joi.string().allow(''),
    }).default({}).description('连表查询字段')
  },
  output: {
    200:{
      body: {
        items: Joi.array().items(reportedDamageValidator),
      }
    }
  }
};
exports.handler = async ({ query }) => {
  const items = await OPReportedDamage.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skop,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  return { items };
};