const ODIllegal = require('../../../../services/database/order/illegal');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.illegal.getMany'];
exports.validate = {
  query: {
    query: Joi.object(),
    limit: Joi.number(),
    skip: Joi.number(),
    sort: Joi.object(),
    selector: Joi.string().empty(''),
    populateSelector: Joi.object({
      user: Joi.string().empty(''),
      region: Joi.string().empty(''),
      order: Joi.string().empty(''),
    }).empty('').description('联表选项')
  }
  // TODO: output
};
exports.handler = async ({ query }) => {
  return await ODIllegal.find(query);
};