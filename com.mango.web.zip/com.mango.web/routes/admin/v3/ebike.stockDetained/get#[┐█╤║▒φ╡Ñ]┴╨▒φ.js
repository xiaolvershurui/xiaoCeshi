const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const BKStockDetained = require('../../../../services/database/ebike/stockDetained');
const stockDetainedValidator = require('../../../../com.mango.common/validators').bk_stock_detained;

exports.permissions = ['admin.bk.stock_detained.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(stockDetainedValidator),
        count: Joi.number()
      })
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await BKStockDetained.find(query);
  const count = await BKStockDetained.count({
    query: query.query,
  });
  return { items, count };
};