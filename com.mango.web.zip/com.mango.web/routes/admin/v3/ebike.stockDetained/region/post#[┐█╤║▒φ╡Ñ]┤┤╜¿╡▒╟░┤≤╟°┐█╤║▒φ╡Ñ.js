const Joi = require('koa-joi-router').Joi;
const BKStockDetained = require('../../../../../services/business/ebike/stockDetained');
const STDetainedArea = require('../../../../../services/database/setting/detainedArea');
const BadRequestError = require('../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.bk.stock_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().required().description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const stDetainedArea = await STDetainedArea.findById({
    id: body.detainedArea,
    selector: 'region name',
    populateSelector: {
      region: 'name',
    },
  });
  const region = ctx.state.user.regionIds;
  if (!region.includes(stDetainedArea.region._id)) {
    throw new BadRequestError(`扣押点${stDetainedArea.name}不在您的权限大区${region}内`);
  }
  return await BKStockDetained.create({
    detainedArea: body.detainedArea,
    stock: body.stock,
    reporter: ctx.state.user.id,
    operator: ctx.state.user.id,
  });
};
