const Joi = require('koa-joi-router').Joi;
const BKStockDetained = require('../../../../../../services/business/ebike/stockDetained');
const STDetainedArea = require('../../../../../../services/database/setting/detainedArea');
const BadRequestError = require('../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.bk.stock_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body }) => {
  return await BKStockDetained.check({
    stock: body.stock
  });
};