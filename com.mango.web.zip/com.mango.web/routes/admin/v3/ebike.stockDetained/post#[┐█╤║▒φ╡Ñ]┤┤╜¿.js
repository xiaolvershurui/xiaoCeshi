const Joi = require('koa-joi-router').Joi;
const BKStockDetained = require('../../../../services/business/ebike/stockDetained');

exports.permissions = ['admin.bk.stock_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().required().description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
    reporter: Joi.string().required().description('上报人')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await BKStockDetained.create({
    detainedArea: body.detainedArea,
    stock: body.stock,
    reporter: body.reporter,
    operator: ctx.state.user.id
  });
};