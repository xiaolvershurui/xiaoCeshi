const Joi = require('koa-joi-router').Joi;
const RCStudyTfVideo = require('../../../../services/business/record/studyTfVideo');
const validators = require('../../../../com.mango.common/settings/validators');
const Cache = require('../../../../com.mango.common/utils/cache');

exports.permissions = ['admin.rc.study.put'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    user: Joi.string().description('用户')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

const cache = new Cache('mg.setup.client');

exports.handler = async ({ body }) => {
  const creditLimits = await cache.getJSON("creditLimits");
  return await RCStudyTfVideo.finishOfflineLearning({
    user: body.user,
    creditLimits
  })
};
