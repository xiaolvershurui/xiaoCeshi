const Joi = require('koa-joi-router').Joi;
const RCBikeBatteryNumber = require('../../../../services/business/record/bikeBatteryNumber');

exports.permissions = ['admin.rc.bike_battery_number.post'];

exports.validate = {
  type: 'json',
  body: {
    region: Joi.string().required().description('大区 id'),
    inputNumbers: {
      bike: Joi.object({
        total: Joi.number().description('总数'),
        lost: Joi.number().description('丢失'),
        detention: Joi.number().description('被扣押数量'),
        scrap: Joi.number().description('报废'),
      }).required(),
      battery: Joi.object({
        total: Joi.number().description('总数'),
        damage: Joi.number().description('损坏'),
        scrap: Joi.number().description('报废'),
        lost: Joi.number().description('丢失'),
      }).required(),
    },
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ body }) => {
  return await RCBikeBatteryNumber.create(body)
};