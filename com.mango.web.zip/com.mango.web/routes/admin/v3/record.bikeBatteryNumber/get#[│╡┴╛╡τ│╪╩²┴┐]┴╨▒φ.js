const Joi = require('koa-joi-router').Joi;
const RCBikeBatteryNumber = require('../../../../services/database/record/bikeBatteryNumber');

exports.permissions = ['admin.rc.bike_battery_number.getMany'];

exports.validate = {
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      region: Joi.string().allow(null).description('大区'),
    }).description('连表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(Joi.object()),
        count: Joi.number()
      })
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await RCBikeBatteryNumber.find(query);
  const count = await RCBikeBatteryNumber.count({
    query: query.query
  });
  return {
    items,
    count
  }
};