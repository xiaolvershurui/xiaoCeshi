const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const Core = require('../../../../services/core/shark');

exports.permissions = ['admin.op.point_to_measure.post'];


exports.validate = {
  type: 'json',
  body: {
    coordinates: validators.location.required().description('中心点'),
    coordinateSystem: Joi.string().description('坐标系'),
    region: Joi.string().empty('').description('大区'),
  },
};

exports.handler = async ({ body, ctx }) => {
  return await Core.sendSync({
    c: 'operation/pointToMeasure/create.a.1',
    params: {
      coordinates: body.coordinates,
      coordinateSystem: body.coordinateSystem,
      userId: ctx.state.user.id,
      region: body.region,
    },
  });
};
