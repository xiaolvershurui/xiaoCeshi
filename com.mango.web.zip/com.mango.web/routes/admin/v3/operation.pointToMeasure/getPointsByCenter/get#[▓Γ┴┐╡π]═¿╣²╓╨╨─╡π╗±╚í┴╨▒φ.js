const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../services/core/shark');

// exports.permissions = ['admin.op.point_to_measure.getMany'];
exports.permissions = ['public'];

exports.validate = {
  query: {
    center: validators.location.description('中心点'),
    coordinateSystem: Joi.string().description('坐标'),
    radius: Joi.number().description('半径'),
  },
};

exports.handler = async ({ query }) => {
  query.radius = 1000;
  return await Core.sendSync({
    c: 'operation/pointToMeasure/findNear.a.1',
    params: query,
  });
};
