const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../services/core/shark');

exports.permissions = ['admin.op.point_to_measure.delete'];


exports.validate = {
  params: {
    id: validators.id.required().description('测量点id'),
  },
};

exports.handler = async ({ params }) => {
  return await Core.sendSync({
    c: 'operation/pointToMeasure/remove.a.1',
    params: {
      pointToMeasureId: params.id,
    },
  });
};
