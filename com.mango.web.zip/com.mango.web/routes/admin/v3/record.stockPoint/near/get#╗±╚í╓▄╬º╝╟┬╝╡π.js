const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const validators = require('../../../../../com.mango.common/settings/validators');
const rcStockPoint = require('../../../../../com.mango.common/validators/index').rc_stock_point;
exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    center: validators.location.required().description('搜索中心点'),
    radius: Joi.number().min(0).description('搜索半径'),
    limit: Joi.number().min(0).description('最大搜索条目数'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'region': Joi.string(),
      'stock': Joi.string(),
      'style': Joi.string(),
      'box': Joi.string(),
    }).description('连表选项')
  },
  output: {
    200: {
      body: Joi.array().items(rcStockPoint)
    }
  }
};
exports.handler = async ({query}) => {
  return await RCStockPoint.searchNear({
    center: query.center,
    radius: query.radius,
    limit: query.limit
  });
};