const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../services/database/record/stockPoint');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'region': Joi.string(),
      'stock': Joi.string(),
      'style': Joi.string(),
      'box': Joi.string(),
    }).description('连表选项')
  },
  output:{
    200:{
      body: Joi.array().items(Joi.object())
    }
  }
};
exports.handler = async ({ query }) => {
  return await RCStockPoint.findDistinctStockPath({
    query: query.query,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector
  })
};