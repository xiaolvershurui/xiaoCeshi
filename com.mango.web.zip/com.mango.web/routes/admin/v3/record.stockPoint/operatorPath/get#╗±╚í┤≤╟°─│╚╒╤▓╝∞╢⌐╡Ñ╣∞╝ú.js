const OPInspectionOrder = require('../../../../../services/database/operation/inspectionOrder');
const OPRideOrder = require('../../../../../services/database/operation/riderOrder');
const OPRegion = require('../../../../../services/database/operation/region');
const Joi = require('koa-joi-router').Joi;
const OTSStockPoint = require('../../../../../services/ots/stockPoint');


exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    region: Joi.string().required(),
    date: Joi.date().required(),
  },
  output: {
    200: {
      body: Joi.object({
        content: Joi.array().items(Joi.object()),
        fileName: Joi.string(),
      }),
    },
  },
};

const fetchData = async ({ box_month, start, end, _id }) => {
  let ret = await OTSStockPoint.find({ box_month, time: [start, end], _id });
  let lastRecordId = ret[ret.length - 1] && ret[ret.length - 1]._id;
  if (ret.length === 5000) {
    const newRet = await fetchData({ box_month, start: ret[ret.length - 1].time, end, _id: lastRecordId._id + 1 });
    ret = ret.concat(newRet);
  }
  return ret;
};


exports.handler = async ({ query }) => {
  const { region, date } = query;
  const operationOrders = await OPInspectionOrder.find({
    query: {
      createdAt: { $gte: date, $lt: date.getTime() + 24 * 3600 * 1000 },
      region,
      box: { $exists: true },
    },
    selector: 'times box user.name user.tel',
  });
  const rideOrders = await OPRideOrder.find({
    query: {
      createdAt: { $gte: date, $lt: date.getTime() + 24 * 3600 * 1000 },
      region,
      box: { $exists: true },
    },
    selector: 'times box user.name user.tel',
  });
  const now = new Date();
  const boxes = operationOrders.concat(rideOrders).map(item => {
    return {
      id: item.box,
      operatorName: item.user.name,
      operatorTel: item.user.tel,
      startTime: item.times.startedAt,
      endTime: item.times.stoppedAt || now,
    };
  });
  const result = [];
  let index = 0;
  for (let box of boxes) {
    const startMonth = `0${box.startTime.getMonth() + 1}`.slice(-2);
    const endMonth = `0${box.endTime.getMonth() + 1}`.slice(-2);

    const points = [];
    (await fetchData({
      box_month: [
        `${box.id}_${box.startTime.getFullYear()}${startMonth}`,
        `${box.id}_${box.endTime.getFullYear()}${endMonth}`,
      ],
      start: box.startTime.getTime(),
      end: box.endTime.getTime(),
    })).forEach(item => {
      if (item.gps && item.gps.lngLat && item.gps.lngLat[0] && item.gps.lngLat[1]) {
        points.push(item.gps.lngLat);
      }
    });

    result.push({
      path: {
        type: 'Feature',
        geometry: {
          type: 'LineString',
          coordinates: points,
        },
        properties: {
          hash: index,
          name: box.operatorName,
          tel: box.operatorTel,
        },
      },
    });
    index += 1;
  }
  const regionData = await OPRegion.findById({ id: region, selector: 'name' });
  const month = `0${date.getMonth() + 1}`.slice(-2);
  const day = `0${date.getDate()}`.slice(-2);
  return { content: result, fileName: `${regionData.name}_${date.getFullYear()}${month}${day}.json` };
};
