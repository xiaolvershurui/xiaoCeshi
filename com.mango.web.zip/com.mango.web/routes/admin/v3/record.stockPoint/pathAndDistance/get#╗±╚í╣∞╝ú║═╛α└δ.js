const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const getDistance = require('../../../../../utils/calculateDistanceBetweenPointAndPoint');
const geolib = require('geolib');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    startTime: Joi.date().required(),
    endTime: Joi.date().required(),
    box: Joi.string().required(),
  },
  // TODO: output
};
exports.handler = async ({ query }) => {
  // const coordinates = await RCStockPoint.findPath(query);
  const coordinates = await RCStockPoint.findPathWithGPSInfo(query);

  const points = [];
  coordinates.forEach(point => {
    if (point.gps && point.gps.lngLat && point.gps.lngLat[0] && point.gps.lngLat[1]) points.push(point.gps.lngLat);
  });

  const { distance } = points.reduce((memo, item) => {
    memo.distance += geolib.getDistance({
      longitude: memo.lngLat[0], latitude: memo.lngLat[1],
    }, {
      longitude: item[0], latitude: item[1],
    }, 0, 3);
    memo.lngLat = item;
    return memo;
  }, {
    lngLat: points[0],
    distance: 0,
  });
  const time = {
    startTime: coordinates[0] && new Date(coordinates[0].time),
    endTime: coordinates[coordinates.length - 1] && new Date(coordinates[coordinates.length - 1].time),
  };
  const timeDif = ((time.endTime ? time.endTime.getTime() : Date.now()) - (time.startTime ? time.startTime.getTime() : Date.now())) / (1000 * 60);
  return {
    coordinates: points,
    distance,
    timeDif,
  };
};

