const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    startTime: Joi.date().required(),
    endTime: Joi.date().required(),
    box: Joi.string().required(),
  },
  // TODO: output
};
exports.handler = async ({ query }) => {
  return await RCStockPoint.findPath(query);
};
