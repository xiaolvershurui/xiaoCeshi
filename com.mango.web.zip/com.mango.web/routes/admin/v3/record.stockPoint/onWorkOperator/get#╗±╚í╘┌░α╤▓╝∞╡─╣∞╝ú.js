const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const OPInspectionOrder = require('../../../../../services/database/operation/inspectionOrder');
const OPRideOrder = require('../../../../../services/database/operation/riderOrder');
const OPRegion = require('../../../../../services/database/operation/region');
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    center: validators.location,
  },
};
exports.handler = async ({ query }) => {
  return [];
  const regions = await OPRegion.findNearSphere({ center: query.center, query: { enable: true }, maxDistance: 50000, minDistance: 0 });
  if (!regions.length) return [];
  const inspectionOrders = await OPInspectionOrder.find({ query: { state: constants.OP_INSPECTION_ORDER_STATE.派单中, region: { $in: regions.map(region => region._id) }, box: { $exists: true } }, limit: 0, selector: 'box times user.name user.tel' });
  const rideOrders = await OPRideOrder.find({ query: { state: constants.OP_RIDER_ORDER_STATE.派单中, region: { $in: regions.map(region => region._id) }, box: { $exists: true } }, limit: 0, selector: 'box times user.name user.tel' });
  const result = [];
  const now = new Date();
  for (let inspectionOrder of inspectionOrders) {
    result.push({
      operatorName: inspectionOrder.user.name,
      operatorTel: inspectionOrder.user.tel,
      path: await RCStockPoint.findPath({
        box: inspectionOrder.box,
        startTime: inspectionOrder.times.startedAt,
        endTime: now,
      }),
    });
  }
  for (let rideOrder of rideOrders) {
    result.push({
      operatorName: rideOrder.user.name,
      operatorTel: rideOrder.user.tel,
      path: await RCStockPoint.findPath({
        box: rideOrder.box,
        startTime: rideOrder.times.startedAt,
        endTime: now,
      }),
    });
  }
  return result;
};
