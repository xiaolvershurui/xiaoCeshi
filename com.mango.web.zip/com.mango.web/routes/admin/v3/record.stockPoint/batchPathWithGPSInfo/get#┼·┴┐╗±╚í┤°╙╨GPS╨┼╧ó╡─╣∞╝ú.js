const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    querys: Joi.array().items(Joi.array().items([
      Joi.string().required(),
      Joi.date().required(),
      Joi.date().required(),
    ]))
  }
  // TODO: output
};
exports.handler = async ({ query }) => {
  return await Promise.all(query.querys.map(async ([box, startTime, endTime]) => {
    return await RCStockPoint.findPathWithGPSInfo({
      box,
      startTime,
      endTime,
    })
  }));
};