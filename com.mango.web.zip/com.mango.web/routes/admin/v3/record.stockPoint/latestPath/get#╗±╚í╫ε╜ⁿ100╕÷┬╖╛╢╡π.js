const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    box: validators.id.required().description('盒子ID')
  },
  output:{
    200: {
      body: Joi.array().items(Joi.object())
    }
  }
};

exports.handler = async ({ query }) => {
  return await RCStockPoint.findLatestPath({
    box: query.box,
    limit: 100,
  });
};