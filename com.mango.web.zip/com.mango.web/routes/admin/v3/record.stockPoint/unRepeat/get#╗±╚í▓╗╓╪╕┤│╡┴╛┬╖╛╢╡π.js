const Joi = require('koa-joi-router').Joi;
const RCStockPoint = require('../../../../../services/database/record/stockPoint');
const rcStockPoint = require('../../../../../com.mango.common/validators/index').rc_stock_point;

exports.permissions = ['admin.rc.stock_point.getMany'];
exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'region': Joi.string(),
      'stock': Joi.string(),
      'style': Joi.string(),
      'box': Joi.string(),
    }).default({}).description('连表选项')
  },
  output:{
    200:{
      body: Joi.array().items(rcStockPoint)
    }
  }
};
exports.handler = async ({ query }) => {
 return await RCStockPoint.findDistinctStockPath({
    query: query.query,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
   populateSelector: query.populateSelector
  });
};