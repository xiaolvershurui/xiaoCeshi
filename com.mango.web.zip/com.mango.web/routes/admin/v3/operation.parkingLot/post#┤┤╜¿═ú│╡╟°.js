const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../services/core/shark');
const BadRequestError = require('../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.parkingLot.post','运营组长'];

exports.validate = {
  type: 'json',
  body: {
    coordinates: Joi.array().items(Joi.array().items(validators.location)).description('停车区'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body, ctx }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/create.a.1',
    params: {
      coordinates: body.coordinates,
      userId: ctx.state.user.id,
    },
  });
};
