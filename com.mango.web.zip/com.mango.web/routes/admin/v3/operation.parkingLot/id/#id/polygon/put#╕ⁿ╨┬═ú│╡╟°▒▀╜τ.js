const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../services/core/shark');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.parkingLot.put', '运营组长'];

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    coordinates: Joi.array().items(Joi.array().items(validators.location)).description('停车区'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/updatePolygon.a.1',
    params: {
      coordinates: body.coordinates,
      parkingLotId: params.id,
    },
  });
};
