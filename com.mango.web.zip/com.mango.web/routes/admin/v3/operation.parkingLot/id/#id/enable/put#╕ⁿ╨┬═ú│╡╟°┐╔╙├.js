const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../services/core/shark');

exports.permissions = ['admin.op.parkingLot.put'];

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    enable: Joi.boolean().description('停车区是否可用'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/updateEnable.a.1',
    params: {
      enable: body.enable,
      parkingLotId: params.id,
    },
  });
};
