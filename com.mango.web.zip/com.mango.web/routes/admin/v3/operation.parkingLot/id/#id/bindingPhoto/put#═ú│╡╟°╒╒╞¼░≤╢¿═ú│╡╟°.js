const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../../../../services/business/operation/photoToPoint');
const OPPhotoToPointData = require('../../../../../../../services/database/operation/photoToPoint');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../../services/core/shark');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const coordtransform = require('coordtransform');

exports.permissions = ['admin.op.parkingLot.put'];

const getLocation = function(isGcj, coordinates) {
  if (isGcj) {
    return {
      geometry: {
        type: 'Point',
        coordinates: coordtransform.wgs84togcj02(coordinates[0], coordinates[1]),
      },
      gcj02Geometry: {
        type: 'Point',
        coordinates,
      },
    };
  } else {
    return {
      geometry: {
        type: 'Point',
        coordinates,
      },
      gcj02Geometry: {
        type: 'Point',
        coordinates: coordtransform.wgs84togcj02(coordinates[0], coordinates[1]),
      },
    };
  }
};

exports.validate = {
  params: {
    id: validators.id.required().description('停车区 Id'),
  },
  type: 'json',
  body: {
    photo: Joi.string().description('照片url'),
    coordinates: validators.location.required().description('点位置'),
    isGcj: Joi.boolean().default(false).required().description('是否是国测局'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body, ctx }) => {
  // 创建停车区照片
  const location = getLocation(body.isGcj, body.coordinates);
  const finalQuery = body.isGcj ? {
    'location.gcj02Geometry.coordinates': location.gcj02Geometry.coordinates,
  } : {
    'location.geometry.coordinates': location.geometry.coordinates,
  };

  const photoToPoint = await OPPhotoToPointData.create({
    creator: ctx.state.user.id,
    location,
    photo: body.photo,
  });

  const parkingLot = await Core.sendSync({
    c: 'operation/parkingLot/findById.a.1.ts',
    params: { parkingLotId: params.id },
  });

  if (!parkingLot) throw new NotFoundError(`停车区${params.id}不存在`);
  if(parkingLot.photoToPoint) {
    await OPPhotoToPointData.update({
      id: parkingLot.photoToPoint._id,
      data: {
        parkingLot: null
      }
    })
  }

  await OPPhotoToPointData.update({
    id: photoToPoint._id,
    data: {
      parkingLot: params.id
    }
  });

  await Core.sendSync({
    c: 'operation/parkingLot/bindingPhoto.a.1.ts',
    params: {
      parkingLotId: params.id,
      photoToPoint: photoToPoint._id,
    },
  });

};


