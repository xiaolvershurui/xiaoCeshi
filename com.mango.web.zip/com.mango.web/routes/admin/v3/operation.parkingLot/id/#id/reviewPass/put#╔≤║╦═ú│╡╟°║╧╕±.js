const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../services/core/shark');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['manager'];

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    reviewRemark: Joi.string().description('停车区审核通过备注'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/reviewPass.a.1',
    params: {
      reviewRemark: body.reviewRemark,
      parkingLotId: params.id,
      userId: this.state.user.id,
    },
  });
};
