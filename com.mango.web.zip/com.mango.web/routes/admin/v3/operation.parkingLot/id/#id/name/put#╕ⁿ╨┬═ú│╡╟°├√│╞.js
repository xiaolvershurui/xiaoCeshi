const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../services/core/shark');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.parkingLot.put'];

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    name: Joi.string().description('停车区名称'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/updateName.a.1',
    params: {
      name: body.name,
      parkingLotId: params.id,
    },
  });
};
