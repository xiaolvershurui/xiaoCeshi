const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../../services/core/shark');
const BadRequestError = require('../../../../../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['manager'];

exports.validate = {
  params: {
    id: Joi.string().required().description('停车区 Id'),
    reviewState: Joi.number().required().description('停车区状态'),
  },
  type: 'json',
  body: {
    reviewRemark: Joi.string().allow('').description('停车区审核合格或不合格备注'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body, ctx }) => {
  let dataParams;
  switch (params.reviewState) {
    case constants.OP_PARKING_LOT_REVIEW_STATE.待审:
      dataParams = {
        c: 'operation/parkingLot/resetReview.a.1',
        params: { parkingLotId: params.id },
      };
      break;
    case constants.OP_PARKING_LOT_REVIEW_STATE.合格:
      dataParams = {
        c: 'operation/parkingLot/reviewPass.a.1',
        params: {
          reviewRemark: body.reviewRemark,
          parkingLotId: params.id,
          userId: ctx.state.user.id,
        },
      };
      break;
    case constants.OP_PARKING_LOT_REVIEW_STATE.不合格:
      dataParams = {
        c: 'operation/parkingLot/reviewReject.a.1',
        params: {
          reviewRemark: body.reviewRemark,
          parkingLotId: params.id,
          userId: ctx.state.user.id,
        },
      };
      break;
    default:
  }
  console.log(dataParams)
  await Core.sendSync(dataParams)
};
