const Joi = require('koa-joi-router').Joi;
const Core = require('../../../../../../../services/core/shark');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['manager'];

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/resetReview.a.1',
    params: {
      parkingLotId: params.id,
      userId: this.state.user.id,
    },
  });
};
