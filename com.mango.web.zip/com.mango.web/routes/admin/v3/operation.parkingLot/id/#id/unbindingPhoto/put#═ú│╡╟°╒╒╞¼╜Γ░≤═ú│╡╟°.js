const Joi = require('koa-joi-router').Joi;
const OPParkingLot = require('../../../../../../../services/database/operation/parkingLot');
const OPPhotoToPoint = require('../../../../../../../services/business/operation/photoToPoint');
const OPPhotoToPointData = require('../../../../../../../services/database/operation/photoToPoint');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../../services/core/shark');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const coordtransform = require('coordtransform');

exports.permissions = ['admin.op.parkingLot.put'];


exports.validate = {
  params: {
    id: validators.id.required().description('停车区 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params }) => {

  const parkingLot = await OPParkingLot.findById({
    id: params.id,
    selector: 'photoToPoint'
  });

  if (!parkingLot) throw new NotFoundError(`停车区${params.id}不存在`);

  if(parkingLot.photoToPoint) {
    await OPPhotoToPointData.update({
      id: parkingLot.photoToPoint._id,
      data: {
        parkingLot: null
      }
    })
  }

  await OPParkingLot.update({
    id: parkingLot._id,
    data: {
      photoToPoint: null
    }
  });
};


