const OPPhotoToPoint = require('../../../../../../services/database/operation/photoToPoint')
const validators = require('../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../services/core/shark');

exports.permissions = ['admin.op.parkingLot.delete', '运营组长'];

exports.validate = {
  params: {
    id: validators.id.required().description('停车区 Id'),
  },
};

exports.handler = async ({ params }) => {
  const parkingLot = await Core.sendSync({
    c: 'operation/parkingLot/findById.a.1',
    params: { parkingLotId: params.id },
  });

  await Core.sendSync({
    c: 'operation/parkingLot/remove.a.1',
    params: {
      parkingLotId: params.id
    },
  });

  if (parkingLot.photoToPoint) {
    await OPPhotoToPoint.update({
      id: parkingLot.photoToPoint._id,
      data: {
        parkingLot: null
      }
    })
  }

};
