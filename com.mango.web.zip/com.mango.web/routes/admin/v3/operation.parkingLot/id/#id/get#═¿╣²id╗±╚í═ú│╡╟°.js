const validators = require('../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../services/core/shark');

exports.permissions = ['admin.op.parkingLot.get', '运营组长'];

exports.validate = {
  params: {
    id: validators.id.required().description('停车区 Id'),
  },
};

exports.handler = async ({ params }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/findById.a.1',
    params: { parkingLotId: params.id },
  });
};
