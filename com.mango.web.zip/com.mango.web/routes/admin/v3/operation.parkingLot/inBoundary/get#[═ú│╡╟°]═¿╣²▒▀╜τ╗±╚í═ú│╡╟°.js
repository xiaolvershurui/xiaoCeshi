const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../services/core/shark');

exports.permissions = ['admin.op.parkingLot.getMany', '运营组长'];

exports.validate = {
  query :{
    boundary: Joi.array().items(validators.location.required()),
  }
};

exports.handler = async ({ query }) => {
  return await Core.sendSync({
    c: 'operation/parkingLot/findInBoundary.a.1',
    params: {
      sw: query.boundary[0],
      ne: query.boundary[1]
    }
  })
}
