const BKBattery = require('../../../../services/database/ebike/battery');
const bkBatteryValidator = require('../../../../com.mango.common/validators/index').bk_battery;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.battery.getMany'];
exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(bkBatteryValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  const items = await BKBattery.find(query);
  const count = await BKBattery.count({
    query: query.query,
  });
  return { items, count };
};
