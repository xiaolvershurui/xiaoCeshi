const BKBattery = require('../../../../../../services/database/ebike/battery');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');

exports.permissions = ['tracer'];
exports.validate = {
  query: {
    center: validators.location.required().description('搜索中心点'),
    searchRadius: Joi.number().default(constants.STOCK_SEARCH_RADIUS_ADMIN).description('搜索半径'),
    limit: Joi.number().default(10000).description('搜索条数'),
    selector: Joi.string().empty('').description('字段选择器'),
  },
  // TODO: 返回值
};
exports.handler = async ({ query }) => {
  return await BKBattery.findNear(Object.assign({
    query: {
      $or: [{
        isSuspectedLost: true,
        locate: constants.BK_BATTERY_LOCATE.安装于车辆,
      }, {
        locate: constants.BK_BATTERY_LOCATE.丢失,
      }]
    }
  }, query));
};