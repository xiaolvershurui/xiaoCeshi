const Joi = require("koa-joi-router").Joi;
const BKBattery = require('../../../../../services/database/ebike/battery');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.bk.battery.get'];

exports.validate = {
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ ctx }) => {
  const station = ctx.state.user.stationId;

  // 仓库电池数量
  const total = await BKBattery.count({ query: { station } });
  // 损坏电池总数
  const totalDamageCount = await BKBattery.count({
    query: {
      station,
      state: constants.BK_BATTERY_STATE.损坏,
    },
  });
  // 损坏率
  const damageRate = total ? ((totalDamageCount / total) * 100).toFixed(2) + '%' : '0';

  // 48小时未维修数
  const twoDaysNoRepair = await BKBattery.count({
    query: {
      lastUpdatedStateAt: {
        $lt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      state: constants.BK_BATTERY_STATE.损坏,
      station
    },
  });

  // 完好电池总数
  const totalIntactCount = await BKBattery.count({
    query: {
      station,
      state: constants.BK_BATTERY_STATE.完好,
    },
  });
  // 报废电池总数
  const totalScrapCount = await BKBattery.count({
    query: {
      station,
      state: constants.BK_BATTERY_STATE.报废,
    },
  });
  return {
    total, // 电池总数
    totalDamageCount, // 损坏电池总数
    damageRate, // 损坏率
    twoDaysNoRepair, // 48小时未维修数
    totalIntactCount, // 完好电池总数
    totalScrapCount, // 报废电池总数
  }
};
