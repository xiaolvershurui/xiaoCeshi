const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const OPBatteryStation = require('../../../../../services/database/operation/batteryStation');
const BKBattery = require('../../../../../services/database/ebike/battery');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.bk.battery.put'];

exports.validate = {
  type: 'json',
  body: {
    QRCodes: Joi.array().items(Joi.string()).required().description('电池二维码').error(new Error('不是电池二维码')),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const station = ctx.state.user.stationId;
  const opRegion = await OPBatteryStation.findById({ id: station, selector: 'region' });

  const region = opRegion.region && opRegion.region._id;

  const result = [];
  const needCreate = [];

  for (let code of body.QRCodes) {
    const battery = await BKBattery.findByCode({ code, selector: 'mark region station damageDescription state' });
    if (!battery) {
      result.push({ QRCode: code, shouldNotCommitReason: '不存在' });
      needCreate.push(code);
    } else if (!battery.mark || station !== battery.station || region !== battery.region || battery.state === constants.BK_BATTERY_STATE.损坏) {
      result.push({
        QRCode: code,
        shouldNotCommitReason: `
          ${!battery.mark ? '无标记号': ''}
          ${station !== battery.station ? '电池不在所在仓库': ''}
          ${region !== battery.region ? '电池不在仓库所在大区': ''}
          ${battery.state === constants.BK_BATTERY_STATE.损坏 ? `电池损坏不能出库:${battery.damageDescription}`: ''}
        `
      });
    } else {
      result.push({ QRCode: code });
    }
  }
  return result;
};
