const Joi = require('koa-joi-router').Joi;
const BKBattery = require('../../../../../services/database/ebike/battery');
const bkBatteryValidator = require('../../../../../com.mango.common/validators/index').bk_battery;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.battery.getMany'];
exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(bkBatteryValidator),
    },
  },
};
exports.handler = async ({ query, ctx }) => {
  // 查询状态更改时间大于48小时的电池
  if (query.query.isTwoDays) {
    Reflect.deleteProperty(query.query, 'isTwoDays');
    query.query = Object.assign({
      lastUpdatedStateAt: {
        $lt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
    }, query.query)
  } else {
    Reflect.deleteProperty(query.query, 'isTwoDays')
  }

  Object.assign(query.query, {
    station: ctx.state.user.stationId,
  });

  return await BKBattery.find(query);
};
