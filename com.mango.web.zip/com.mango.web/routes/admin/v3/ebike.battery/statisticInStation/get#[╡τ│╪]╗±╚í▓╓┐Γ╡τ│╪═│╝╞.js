const Joi = require('koa-joi-router').Joi;
const BKBattery = require('../../../../../services/database/ebike/battery');

exports.permissions = ['admin.bk.battery.getMany'];

exports.handler = async _ => {
  return await BKBattery.findStatisticInStation();
};
