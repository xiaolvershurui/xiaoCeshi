const BKStock = require('../../../../../../../services/database/ebike/stock');
const BKBattery = require('../../../../../../../services/business/ebike/battery');
const Joi = require('koa-joi-router').Joi;
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.bk.battery.getMany'];

exports.validate = {
  params: {
    code: Joi.string().required().description('电池 二维码'),
  },
  query: {
    date: Joi.object({
      $gte: Joi.date().default('today'.beginning).description('时间区间'),
      $lte: Joi.date().default('today'.ending).description('时间区间'),
    }).required().description('时间区间'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};
exports.handler = async ({ params, query }) => {

  const { date } = query;
  const now = new Date(date.$lte);
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}0`.slice(-3, -1);

  return await BKBattery.getBatteryPoint({
    code: params.code,
    now,
    year,
    month,
    startTime: date.$gte.getTime(),
    endTime: date.$lte.getTime(),
    earliestTime: date.$gte
  });
};