const BKStock = require('../../../../../../../services/database/ebike/stock');
const BKBattery = require('../../../../../../../services/business/ebike/battery');
const RCBatteryPoint = require('../../../../../../../services/database/record/batteryPoint');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');
const OTSBatteryInStockPoint = require('../../../../../../../services/ots/batteryInStockPoint');

exports.permissions = ['admin.bk.battery.getMany'];

exports.validate = {
  params: {
    id: validators.id.required().description('电池 Id'),
  },
  query: {
    date: Joi.object({
      $gte: Joi.date().default('today'.beginning).description('时间区间'),
      $lte: Joi.date().default('today'.ending).description('时间区间'),
    }).required().description('时间区间'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};
exports.handler = async ({ params, query }) => {

  const { date } = query;
  const now = new Date(date.$lte);
  const year = now.getFullYear();
  const month = `0${now.getMonth() + 1}0`.slice(-3, -1);

  return await BKBattery.getBatteryPoint({
    id: params.id,
    now,
    year,
    month,
    startTime: date.$gte.getTime(),
    endTime: date.$lte.getTime(),
    earliestTime: date.$gte
  });
};