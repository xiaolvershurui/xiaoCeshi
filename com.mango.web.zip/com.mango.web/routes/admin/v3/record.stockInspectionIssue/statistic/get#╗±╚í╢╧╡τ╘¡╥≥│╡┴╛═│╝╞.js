const Joi = require('koa-joi-router').Joi;
const RCInspectionIssue = require('../../../../../services/database/record/stockInspectionIssue');

exports.permissions = ['admin.rc.stock_inspection_issue.getMany'];

exports.validate = {
  query: {
    createdAt: Joi.object().description('创建时间搜索')
  }
};

exports.handler = async ({ query }) => {
  const items = await RCInspectionIssue.findStatistic(query);
  const count = items.length;
  return { items, count }
};
