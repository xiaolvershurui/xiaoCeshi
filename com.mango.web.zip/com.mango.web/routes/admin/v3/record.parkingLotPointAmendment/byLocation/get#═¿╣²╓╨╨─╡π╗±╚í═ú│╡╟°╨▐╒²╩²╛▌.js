const validators = require('../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../services/core/shark');
const Joi = require('koa-joi-router').Joi;

exports.permissions = ['admin.rc.parkingLot_point_amendment.getMany'];

exports.validate = {
  query: {
    date: {
      $gte: Joi.date().required(),
      $lt: Joi.date().required(),
    },
    sw: validators.location.required(),
    ne: validators.location.required(),
  },
};

exports.handler = async ({ query }) => {
  return await Core.sendSync({
    c: 'record/parkingLotPointAmendment/findInBoundary.a.1',
    params: query
  })
};
