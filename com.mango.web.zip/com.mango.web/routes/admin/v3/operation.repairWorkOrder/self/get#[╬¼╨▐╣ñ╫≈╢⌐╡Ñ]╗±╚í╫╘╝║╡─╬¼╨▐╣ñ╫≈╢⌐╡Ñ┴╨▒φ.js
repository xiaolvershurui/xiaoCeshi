const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const opRepairWorkOrderValidator = require('../../../../../com.mango.common/validators/index').op_repair_work_order;
const OPRepairWorkOrder = require('../../../../../services/database/operation/repairWorkOrder');

exports.permissions = ['admin.op.repair_work_order.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(opRepairWorkOrderValidator),
    },
  },
};
exports.handler = async ({ query, ctx }) => {
  query.query = {
    $and: [query.query, {
      repairMembers: {
        $in: [ctx.state.user.id],
      },
    }],
  };

  return await OPRepairWorkOrder.find(query);
};
