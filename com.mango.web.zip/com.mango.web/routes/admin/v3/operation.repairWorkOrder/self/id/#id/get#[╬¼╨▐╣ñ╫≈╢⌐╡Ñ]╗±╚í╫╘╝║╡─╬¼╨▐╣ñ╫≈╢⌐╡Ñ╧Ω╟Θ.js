const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const opRepairWorkOrderValidator = require('../../../../../../../com.mango.common/validators/index').op_repair_work_order;
const OPRepairWorkOrder = require('../../../../../../../services/database/operation/repairWorkOrder');

exports.permissions = ['admin.op.repair_work_order.get'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  query: validators.findOne,
  output: {
    200: {
      body: opRepairWorkOrderValidator,
    },
  },
};
exports.handler = async ({ params, query, ctx }) => {
  return await OPRepairWorkOrder.findByIdAndRepairMember({
    id: params.id,
    repairMember: [ctx.state.user.id],
    selector: query.selector,
    populateSelector: query.populateSelector,
  });
};
