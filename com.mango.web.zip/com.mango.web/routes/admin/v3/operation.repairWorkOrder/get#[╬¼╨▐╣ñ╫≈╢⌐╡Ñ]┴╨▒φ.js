const validators = require('../../../../com.mango.common/settings/validators');
const opRepairWorkOrderValidator = require('../../../../com.mango.common/validators/index').op_repair_work_order;
const OPRepairWorkOrder = require('../../../../services/database/operation/repairWorkOrder');
const ACUser = require('../../../../services/database/account/user');
const STRepairTeam = require('../../../../services/database/setting/repairTeam');

exports.permissions = ['admin.op.repair_work_order.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(opRepairWorkOrderValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  if (query.query.tel) {
    const repairMember = await ACUser.findByTel({ tel: query.query.tel });
    Reflect.deleteProperty(query.query, 'tel');
    query.query = {
      $and: [query.query, {
        repairMembers: repairMember._id,
      }],
    };
  }

  if (query.query.name) {
    const users = (await ACUser.find({
      query: {
        'cert.name': query.query.name,
      },
      limit: 0,
    })).map(item => item._id);
    Reflect.deleteProperty(query.query, 'name');
    query.query = {
      $and: [query.query, {
        repairMembers: {
          $in: users,
        },
      }],
    };
  }

  if (query.query.teamName) {
    const team = await STRepairTeam.findByName({ name: query.query.teamName });
    Reflect.deleteProperty(query.query, 'teamName');
    query.query = {
      $and: [query.query, {
        'team.id': team._id,
      }],
    };
  }

  const items = await OPRepairWorkOrder.find(query);
  const count = await OPRepairWorkOrder.count({
    query: query.query,
  });
  return { items, count };
};
