const Joi = require('koa-joi-router').Joi;
const RCLogin = require('../../../../services/database/record/login');

exports.permissions = ['admin.rc.login.getMany'];

exports.validate = {
  query: {
    query: Joi.object(),
    sort: Joi.object(),
    skip: Joi.number(),
    limit: Joi.number(),
    selector: Joi.string(),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object())
    }
  }
};

exports.handler = async ({ query }) => {
  return await RCLogin.find(query);
};

