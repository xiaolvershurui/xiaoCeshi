const RCStockAlarm = require('../../../../services/database/record/stockAlarm');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const rcStockAlarmValidator = require('../../../../com.mango.common/validators/index').rc_stock_alarm;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.stock_alarm.getMany'];
exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'region': Joi.string(),
      'stock': Joi.string(),
      'style': Joi.string(),
      'box': Joi.string(),
      'point': Joi.string(),
      'order': Joi.string(),
    }).default({}).description('连表选项')
  },
  output: {
    200:{
      body: Joi.array().items(rcStockAlarmValidator),
    }
  }
};

exports.handler = async ({ query }) => {
  return await RCStockAlarm.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
