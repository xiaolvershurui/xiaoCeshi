const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../services/database/operation/inspectionOrder');
const validators = require('../../../../../com.mango.common/settings/validators');
const InspectionOrderValidator = require('../../../../../com.mango.common/validators').op_inspection_order;

exports.permissions = ['admin.op.inspection_order.getMany'];

exports.validate = {
  params: {},
  query: {},
  output: {
    200: {
      body: Joi.array().items(InspectionOrderValidator)
    }
  }
};
exports.handler = async ({ ctx }) => {
  return await OPInspectionOrder.findByUser({
    user: ctx.state.user.id,
    limit: 120,
    selector: 'user state inspectedStocks fixedStatistic createdAt payment'
  });
};
