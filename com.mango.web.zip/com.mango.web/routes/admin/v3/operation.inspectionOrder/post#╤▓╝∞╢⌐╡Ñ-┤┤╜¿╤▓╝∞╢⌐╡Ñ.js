const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../services/business/operation/inspectionOrder');
const OPRiderOrder = require('../../../../services/business/operation/riderOrder');
const ACOperator = require('../../../../services/database/account/operator');
const STConfig = require('../../../../services/database/setting/config');
const constants = require('../../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../../com.mango.common/errors/BadRequestError');
const NotFoundError = require('../../../../com.mango.common/errors/NotFoundError');


exports.permissions = ['admin.op.inspection_order.post'];

exports.validate = {
  params: {},
  type: 'json',
  body: {
    id: Joi.string().description('Operator Id'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body }) => {
  const operator = await ACOperator.findById({ id: body.id, selector: 'updatedAt isWorking inspectionType regions' });
  if (!operator) throw new NotFoundError(`运营人员${body.id}不存在`);
  if (operator.isWorking) throw new BadRequestError(`运营人员${body.id}已上班`);

  if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机) {
    return await OPInspectionOrder.create({
      id: body.id,
    });
  } else if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行) {
    return await OPRiderOrder.create({
      id: body.id,
    });
  } else {
    // TODO: 非司机和骑手，仅上班
    // 获取颜色分配
    const usedColors = await ACOperator.findUsedColors(operator.regions.map(region => region._id));
    const colors = (await STConfig.get({ key: 'ac.operator.colors', cache: { enable: true } })) || [];
    if (colors.length <= usedColors) throw new BadRequestError('没有可分配的颜色，请添加后重试');
    const unusedColors = colors.filter(color => !usedColors.includes(color));

    return await ACOperator.update({
      id: body.id,
      updatedAt: operator.updatedAt,
      data: {
        isWorking: true,
        color: unusedColors[parseInt(Math.random() * unusedColors.length)],
      },
    });
  }
};
