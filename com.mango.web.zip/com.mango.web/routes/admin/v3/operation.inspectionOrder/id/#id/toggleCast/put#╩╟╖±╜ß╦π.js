const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin.op.inspection_order.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('巡检订单编号')
  },
  type: 'json',
};
exports.handler = async ({ params }) => {
  await OPInspectionOrder.toggleCast({ id: params.id });
};
