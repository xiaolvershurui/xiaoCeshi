const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin.op.inspection_order.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('InspectionOrder Id'),
  },
  query: {

  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({ params }) => {
  return await OPInspectionOrder.affirm({
    id: params.id,
  });
};