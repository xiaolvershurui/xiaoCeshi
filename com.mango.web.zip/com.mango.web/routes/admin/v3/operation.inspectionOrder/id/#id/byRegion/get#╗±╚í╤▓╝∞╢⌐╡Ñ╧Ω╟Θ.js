const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/database/operation/inspectionOrder');
const InspectionOrderValidator = require('../../../../../../../com.mango.common/validators').op_inspection_order;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.inspection_order.get'];

exports.validate = {
  params: {
    id: Joi.string().required().description('巡检订单编号')
  },
  query: validators.findOne,
  output: {
    200: {
      body: InspectionOrderValidator
    }
  }
};
exports.handler = async ({ params, query, ctx }) => {
  return await OPInspectionOrder.findByIdAndRegion({
    id: params.id,
    region: ctx.state.user.regionIds[0],
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};