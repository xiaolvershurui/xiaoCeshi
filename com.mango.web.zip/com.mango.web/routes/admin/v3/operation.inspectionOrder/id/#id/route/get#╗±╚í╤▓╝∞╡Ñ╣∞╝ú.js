const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');
const InspectionOrderValidator = require('../../../../../../../com.mango.common/validators').op_inspection_order;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const OTSStockPoint = require('../../../../../../../services/ots/stockPoint');

exports.permissions = ['admin.op.inspection_order.getMany'];

exports.validate = {
  params: {
    id: Joi.string().required().description('巡检订单编号')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};
exports.handler = async ({ params }) => {
  return await OPInspectionOrder.getInspectionPoint({
    id: params.id
  });

};