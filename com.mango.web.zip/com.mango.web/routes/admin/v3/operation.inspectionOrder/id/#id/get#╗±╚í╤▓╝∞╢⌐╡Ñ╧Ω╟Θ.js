const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../services/database/operation/inspectionOrder');
const InspectionOrderValidator = require('../../../../../../com.mango.common/validators').op_inspection_order;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.inspection_order.get'];

exports.validate = {
  params: {
    id: Joi.string().required().description('巡检订单编号')
  },
  query: validators.findOne,
  output: {
    200: {
      body: InspectionOrderValidator
    }
  }
};
exports.handler = async ({ params }) => {
  return await OPInspectionOrder.findById({
    id: params.id,
    selector: 'user state inspectedStocks fixedStatistic createdAt payment route',
    populateSelector: {
      'user.operator': 'showAmount'
    }
  });};
