const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin.op.inspection_order.fixed'];

exports.validate = {
  params: {
    id: Joi.string().required().description('InspectionOrder Id'),
  },
  type: 'json',
  body: {
    index: Joi.number().required().description('巡检车辆索引'),
    task: Joi.object({
      hasFound: Joi.boolean().description('是否找到'),
      isBatteryLock: Joi.boolean().description('电池锁状态'),
      isReturnedBack: Joi.boolean().description('是否拖回'),
      isExchangedBattery: Joi.boolean().description('是否换电'),
      isBackIntoRegion: Joi.boolean().description('是否回栏'),
      isHardToFindButFound: Joi.boolean().description('是否难寻找到'),
      isPutOn: Joi.boolean().description('是否投放'),
      isNormal: Joi.boolean().description('是否普通'),
      finishedAt: Joi.date().description('结束巡检时间'),
      isValidTask: Joi.boolean().description('是否有效任务'),
    })
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body }) => {
  return await OPInspectionOrder.updateStockTask({
    id: params.id,
    index: body.index,
    task: body.task,
  });
};
