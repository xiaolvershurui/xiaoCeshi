const Joi = require('koa-joi-router').Joi;
const inspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin.op.inspection_order.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('InspectionOrder Id'),
  },
  query: {

  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({ params, query, body }) => {
  return await inspectionOrder.pause({
    id: params.id
  });
};