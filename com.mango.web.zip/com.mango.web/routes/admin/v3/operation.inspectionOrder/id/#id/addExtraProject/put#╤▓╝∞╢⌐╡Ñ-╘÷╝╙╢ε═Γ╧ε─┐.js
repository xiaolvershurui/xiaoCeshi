const Joi = require('koa-joi-router').Joi;
const inspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin', 'admin.op.inspection_order.fixed'];

exports.validate = {
  params: {
    id: Joi.string().required().description('InspectionOrder Id'),
  },
  query: {

  },
  type: 'json',
  body: {
    name: Joi.string().required().description('额外项目名'),
    value: Joi.number().required().description('价格')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({ params, query, body }) => {
  return await inspectionOrder.addExtraProject({
    id: params.id,
    name: body.name,
    value: body.value
  });
};
