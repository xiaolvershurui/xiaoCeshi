const Joi = require('koa-joi-router').Joi;
const inspectionOrder = require('../../../../../../../services/business/operation/inspectionOrder');

exports.permissions = ['admin.op.inspection_order.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('InspectionOrder Id'),
  },
  query: {

  },
  type: 'json',
  body: {
    index: Joi.number().min(0).required()
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};
exports.handler = async ({ params, query, body }) => {
  return await inspectionOrder.removeExtraProject({
    id: params.id,
    index: body.index
  });
};