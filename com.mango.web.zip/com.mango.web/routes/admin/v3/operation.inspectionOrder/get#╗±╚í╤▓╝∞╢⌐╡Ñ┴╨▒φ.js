const Joi = require('koa-joi-router').Joi;
const OPInspectionOrder = require('../../../../services/database/operation/inspectionOrder');
const validators = require('../../../../com.mango.common/settings/validators');
const inspectionOrderValidator = require('../../../../com.mango.common/validators/index').op_inspection_order;

exports.permissions = ['admin.op.inspection_order.getMany'];

exports.validate = {
  query: {
    query: Joi.object().required().description('查询参数'),
    limit: Joi.number().empty(''),
    sort: Joi.object().empty(''),
    skip: Joi.number().empty(''),
    selector: validators.selector,
    populateSelector: Joi.object({
      'user.operator': validators.selector,
      'region': validators.selector,
    }).unknown().description('联表选项').empty(''),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(inspectionOrderValidator),
        count: Joi.number().description('总条目数'),
      }),
    },
  },
};
exports.handler = async ({ query }) => {
  const items = await OPInspectionOrder.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector,
  });
  const count = await OPInspectionOrder.count({
    query: query.query,
  });
  return { items, count };
};
