const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const stockRepairValidator = require('../../../../com.mango.common/validators/index').rc_stock_repair;
const NotFoundError = require('../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../com.mango.common/errors/BadRequestError');
const BKStock = require('../../../../services/database/ebike/stock');
const RCStockRepair = require('../../../../services/database/record/stockRepair');
const STRepairProject = require('../../../../services/database/setting/repairProject');
const STRepairProjectGroup = require('../../../../services/database/setting/repairProjectGroup');
const RCStockOp = require('../../../../services/database/record/stockOp');
const RCStockInspectionIssue = require('../../../../services/database/record/stockInspectionIssue');
const STInspectionIssueReason = require('../../../../services/database/setting/inspectionIssueReason');
const ACOperator = require('../../../../services/database/account/operator');
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.stock_repair.post'];

exports.validate = {
  type: 'json',
  body: {
    stock: validators.id.required().description('车辆 id'),
    repairProjectIds: Joi.array().items(Joi.string()).required().description('维修项目 id'),
    inspectionIssueReason: Joi.string().empty('').description('离线断电原因'),
    inspectionIssueReasonExtra: Joi.string().empty('').description('其他离线端电原因'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const user = ctx.state.user.id;
  const operator = await ACOperator.findByUser({user, selector: 'inspectionType'});

  const stock = await BKStock.findById({ id: body.stock, selector: 'station region inspectionIssueReason taskList' });
  if (!stock) throw new NotFoundError(`车辆${body.stock}不存在`);
  if (!stock.station) throw new BadRequestError(`车辆${body.stock}站点不存在，请联系线上运维`);
  if (!stock.region) throw new BadRequestError(`车辆${body.stock}大区不存在，请联系线上运维`);

  // 如果为断电离线
  if (stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内疑似离线 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.一天内真离线 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天真离线 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.超一天疑似离线 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.高压离线 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.被盗断电 }) ||
    stock.taskList.search({ code: constants.BK_TASK_TYPE.零电断电 })
  ) {
    const stInspectionIssueReason = await STInspectionIssueReason.findById({
      id: body.inspectionIssueReason,
      selector: 'reason'
    });
    
    // 原因为其他必须填写额外选项
    if (stInspectionIssueReason._id === '1806021830005' && !body.inspectionIssueReasonExtra) throw new BadRequestError(`原因为其他时必须填写额外选项`);
    await RCStockInspectionIssue.create({
      region: stock.region && stock.region._id,
      stock: stock._id,
      reason: body.inspectionIssueReason,
      reasonExtra: body.inspectionIssueReasonExtra,
      creator: user,
      inspectionType: operator.inspectionType
    })
  }

  const station = stock.station && stock.station._id;
  const region = stock.region && stock.region._id;

  const repairProject = (await STRepairProject.find({
    query: {
      _id: {
        $in: [... new Set(body.repairProjectIds)]
      },
    },
    limit: 0,
    selector: 'name group',
    populateSelector: {
      group: 'name',
    },
  })).map(project => {
    return {
      projectId: project._id,
      projectName: project.name,
      projectGroupId: project.group && project.group._id,
      projectGroupName: project.group && project.group.name,
    }
  });

  return await RCStockRepair.create({
    stock: body.stock,
    user,
    region,
    station,
    repairProject,
  });
};
