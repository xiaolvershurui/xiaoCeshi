const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const stockRepairValidator = require('../../../../../com.mango.common/validators/index').rc_stock_repair;
const RCStockRepair = require('../../../../../services/database/record/stockRepair');

exports.permissions = ['admin.rc.stock_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(stockRepairValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  return await RCStockRepair.find(query);
};
