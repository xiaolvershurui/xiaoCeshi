const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const stockRepairValidator = require('../../../../com.mango.common/validators/index').rc_stock_repair;
const RCStockRepair = require('../../../../services/database/record/stockRepair');
const ACUser = require('../../../../services/database/account/user');
const BKStock = require('../../../../services/database/ebike/stock');

exports.permissions = ['admin.rc.stock_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(stockRepairValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  let user;
  let stock;
  if (query.query.tel) {
    user = await ACUser.findByTel({ tel: query.query.tel });
    if (user) {
      Object.assign(query.query, { user: user._id });
    }
    Reflect.deleteProperty(query.query, 'tel');
  }

  if (query.query.name) {
    user = await ACUser.find({
      query: {
        'cert.name': query.query.name
      },
      limit: 0
    });
    if (user) {
      Object.assign(query.query, { user: {
       $in: user.map(item => item._id)
      }});
    }
    Reflect.deleteProperty(query.query, 'name');
  }
  if (query.query.number) {
    stock = await BKStock.findByNumber({ number: query.query.number });
    if (stock) {
      Object.assign(query.query, { stock: stock._id });
    }
    Reflect.deleteProperty(query.query, 'number');
  }
  const items = await RCStockRepair.find(query);
  const count = await RCStockRepair.count({
    query: query.query
  });
  return { items, count };
};
