const Joi = require('koa-joi-router').Joi;
const BKBTBox = require('../../../../../services/database/ebike/btBox');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.btBox.get'];
exports.validate = {
  params: {
    id: Joi.string().required().example('866100033148348').description('设备号'),
  },
  query: {
    selector: Joi.string().empty('').description('字段选择器'),
  },
  output: {
    200: {
      body: Joi.object({
        _id: Joi.string().required().example('866100033148348').description('设备号'),
        dataSource: Joi.number().integer().description('数据源'),
        deviceType: Joi.string().description('设备型号'),
        appVersion: Joi.string().description('软件版本号'),
        sim: Joi.object({
          imsi: Joi.string().description('设备SIM卡imsi'),
          powerOn: Joi.boolean().description('SIM卡开机状态'),
          expiryDate: Joi.date().description('SIM卡过期时间'),
          dataUsage: Joi.number().description('已使用流量'),
          dataBalance: Joi.number().description('剩余流量'),
        }),
        isOnline: Joi.boolean().description('设备是否在线'),
        latestOnlineAt: Joi.date().description('最近上线时间'),
        mode: Joi.number().integer().description('设备工作模式'),
        signal: Joi.number().integer().description('设备SIM卡信号'),
        voltage: Joi.number().description('设备检测到的电压'),
        gpsLocation: Joi.object({
          gpsLngLat: validators.location.description('GPS定位'),
          lngLat: validators.location.description('高德定位'),
          time: Joi.date().description('定位时间'),
          speed: Joi.number().description('速度'),
          direction: Joi.number().description('相位角'),
        }),
        cellLocation: Joi.object({
          mcc: Joi.number().integer(),
          mnc: Joi.number().integer(),
          cells: Joi.array().items({
            lac: Joi.number().integer(),
            cellid: Joi.number().integer(),
            rxl: Joi.number().integer()
          }),
          time: Joi.date().description('基站定位时间')
        })
      })
    }
  }
};
exports.handler = async ({ params, query }) => {
  return await BKBTBox.findById({
    deviceId: params.id,
    selector: query.selector,
  });
};