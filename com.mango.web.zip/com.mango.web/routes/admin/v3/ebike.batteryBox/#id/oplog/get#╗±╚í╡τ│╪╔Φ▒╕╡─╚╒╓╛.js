const RCOplog = require('../../../../../../services/database/record/oplog');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.bk.btBox.get'];
exports.validate = {
  params: {
    id: Joi.string().required().example('866100033148348').description('设备号'),
  },
  query: {
    selector: Joi.string().empty('').description('字段选择器'),
    skip: Joi.number().integer().description('跳过条数'),
    limit: Joi.number().integer().description('查询条数'),
    sort: Joi.object().description('排序')
  },
  output: {
    200: {
      body: Joi.array().items({
        _id: Joi.string().description('操作ID'),
        operator: Joi.object({
          name: Joi.string().description('姓名'),
          tel: Joi.string().description('手机号'),
          avator: Joi.string().description('头像'),
          location: Joi.object({
            lngLat: validators.location,
            address: Joi.string()
          }).description('操作地址')
        }).description('操作人信息'),
        opAt: Joi.date().description('操作时间'),
        description: Joi.string().description('描述'),
        params: Joi.object().description('参数'),
        code: Joi.string().description('操作code')
      })
    }
  }
};
exports.handler = async ({ params, query }) => {
  return await RCOplog.findByBTBox({
    btBox: params.id,
    selector: query.selector,
    skip: query.skip,
    limit: query.limit,
    sort: query.sort,
  });
};