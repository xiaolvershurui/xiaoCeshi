const Joi = require('koa-joi-router').Joi;
const IoT = require('../../../../../../services/iot');

exports.permissions = ['admin.bk.btBox.put'];
exports.validate = {
  params: {
    id: Joi.string().required().example('866100033148348').description('设备号'),
  },
  type: 'json',
  body: {
    command: Joi.string().required().valid([
      'getInfo', 'reboot', 'changeServer',
      'remoteUpgrade', 'kick', 'status', 'setConfig', 'setEcoMode'
    ]).description('指令名'),
    params: Joi.object().description('指令参数')
  }
};
exports.handler = async ({ body, params }) => {
  return await IoT.sendCommand({
    type: 1,
    command: body.command,
    params: body.params,
    deviceId: params.id,
  });
};
