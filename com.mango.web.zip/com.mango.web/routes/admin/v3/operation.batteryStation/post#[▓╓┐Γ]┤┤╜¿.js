const Joi = require('koa-joi-router').Joi;
const OPBatteryStation = require('../../../../services/business/operation/batteryStation');

exports.permissions = ['admin.op.battery_station.post'];

exports.validate = {
  params: {},
  type: 'json',
  body: {
    region: Joi.string().required().description('大区　ID'),
    name: Joi.string().required().description('大区名称'),
    director: Joi.string().required().description('负责人'),
    enable: Joi.boolean().description('启用状态'),
    location: Joi.object({
      address: Joi.string().empty('').description('地址'),
      lngLat: Joi.array().items(Joi.number()).empty('').description('经纬度')
    })
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body }) => {
  return await OPBatteryStation.create({
    region: body.region,
    name: body.name,
    director: body.director,
    enable: body.enable,
    location: body.location,
  })
};
