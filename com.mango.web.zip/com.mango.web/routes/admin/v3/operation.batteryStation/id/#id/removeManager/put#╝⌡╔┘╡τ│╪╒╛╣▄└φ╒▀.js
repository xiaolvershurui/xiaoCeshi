const Joi = require('koa-joi-router').Joi;
const OPBatteryStation = require('../../../../../../../services/business/operation/batteryStation');
const ACUser = require('../../../../../../../services/database/account/user');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.station.put'];

exports.validate = {
  params: {
    id: Joi.string().required().description('站点id')
  },
  body: {
    userId: Joi.string().required().description('管理者ID')
  },
  type: 'json',
  output: {
    200: {
      body: Joi.object({_id: Joi.string()}),
    }
  }
};

exports.handler = async ({ params, body }) => {
  const acUser = await ACUser.findById({
    id: body.userId
  });
  if(!acUser){
    throw new NotFoundError('未找到此用户');
  }
  return await OPBatteryStation.update({
    id: params.id,
    data:{},
    arrayOp: {
      $pull: {
        storeManagers: acUser._id
      }}
  });
};
