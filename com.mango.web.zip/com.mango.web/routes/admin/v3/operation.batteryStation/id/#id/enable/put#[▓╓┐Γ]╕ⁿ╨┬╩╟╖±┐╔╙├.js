const Joi = require('koa-joi-router').Joi;
const OPBatteryStation = require('../../../../../../../services/business/operation/batteryStation');

exports.permissions = ['admin.op.battery_station.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('启用状态'),
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body }) => {
  return await OPBatteryStation.update({
    id: params.id,
    data: body
  })
};
