const Joi = require('koa-joi-router').Joi;
const BKStockRelieveDetained = require('../../../../services/business/ebike/stockRelieveDetained');

exports.permissions = ['admin.bk.stock_relieve_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().required().description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
    handler: Joi.string().required().description('处理人'),
    penalty: Joi.number().description('罚款金额'),
    parkingFee: Joi.number().description('停车费'),
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await BKStockRelieveDetained.create({
    detainedArea: body.detainedArea,
    stock: body.stock,
    penalty: body.penalty,
    parkingFee: body.parkingFee,
    handler: body.handler,
    operator: ctx.state.user.id,
    regions: ctx.state.user.regionIds
    ,
  });
};
