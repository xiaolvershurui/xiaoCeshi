const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const BKStockRelieveDetained = require('../../../../services/database/ebike/stockRelieveDetained');
const stockRelieveDetainedValidator = require('../../../../com.mango.common/validators').bk_stock_relieve_detained;

exports.permissions = ['admin.bk.stock_relieve_detained.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(stockRelieveDetainedValidator),
        count: Joi.number(),
      }),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await BKStockRelieveDetained.find(query);
  const count = await BKStockRelieveDetained.count({
    query: query.query,
  });
  return { items, count };
};