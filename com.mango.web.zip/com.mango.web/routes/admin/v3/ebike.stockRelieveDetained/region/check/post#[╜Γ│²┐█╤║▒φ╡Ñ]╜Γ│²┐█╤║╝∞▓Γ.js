const Joi = require('koa-joi-router').Joi;
const BKStockRelieveDetained = require('../../../../../../services/business/ebike/stockRelieveDetained');
const STDetainedArea = require('../../../../../../services/database/setting/detainedArea');
const BadRequestError = require('../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.bk.stock_relieve_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().empty('').description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  console.log(ctx.state.user.regionIds)
  return await BKStockRelieveDetained.check({
    regions: ctx.state.user.regionIds,
    detainedArea: body.detainedArea,
    stock: body.stock,
  });
};
