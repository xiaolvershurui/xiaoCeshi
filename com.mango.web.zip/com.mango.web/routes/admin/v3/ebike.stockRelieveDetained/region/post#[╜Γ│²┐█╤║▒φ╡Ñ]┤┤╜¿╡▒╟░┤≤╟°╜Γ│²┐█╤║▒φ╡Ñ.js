const Joi = require('koa-joi-router').Joi;
const BKStockRelieveDetained = require('../../../../../services/business/ebike/stockRelieveDetained');
const STDetainedArea = require('../../../../../services/database/setting/detainedArea');
const BadRequestError = require('../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.bk.stock_relieve_detained.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().required().description('扣押点'),
    stock: Joi.array().items(Joi.string().required()).description('车牌号'),
    penalty: Joi.number().description('罚款金额'),
    parkingFee: Joi.number().description('停车费'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const stDetainedArea = await STDetainedArea.findById({
    id: body.detainedArea,
    selector: 'region name stocks',
    populateSelector: {
      region: 'name',
      stocks: 'number.custom'
    },
  });
  const region = ctx.state.user.regionIds;
  if (!region.includes(stDetainedArea.region._id)) {
    throw new BadRequestError(`扣押点${stDetainedArea.name}不在您的权限大区${region}内`);
  }

  const checkStocks = body.stock.reduce((memo, item) => {
    if (stDetainedArea.stocks.find(i => i.number.custom === item)) {
      memo = [...memo, item];
    }
    return memo;
  }, []);

  if (checkStocks.length !== body.stock.length) throw new BadRequestError(`有车辆不在当前扣押点`);

  return await BKStockRelieveDetained.create({
    detainedArea: body.detainedArea,
    stock: body.stock,
    penalty: body.penalty,
    parkingFee: body.parkingFee,
    handler: ctx.state.user.id,
    operator: ctx.state.user.id,
    regions: ctx.state.user.regionIds
  });
};
