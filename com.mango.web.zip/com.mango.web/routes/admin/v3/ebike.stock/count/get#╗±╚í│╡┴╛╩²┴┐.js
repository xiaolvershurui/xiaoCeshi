const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');
const BKStock = require('../../../../../services/database/ebike/stock');

exports.permissions = ['admin.bk.stock.getMany', 'operation'];

exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
  },
  output: {
    200: {
      body: Joi.number()
    }
  }
};

exports.handler = async ({ query }) => {
  return await BKStock.count(query);
};