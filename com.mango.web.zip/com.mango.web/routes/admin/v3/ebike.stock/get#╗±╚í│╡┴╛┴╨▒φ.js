const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const BKStock = require('../../../../services/database/ebike/stock');
const stockValidator = require('../../../../com.mango.common/validators').bk_stock;

exports.permissions = ['admin.bk.stock.getMany', 'operation'];

exports.validate = {
  query: {
    query: Joi.object().description('查询条件'),
    selector: Joi.string().empty('').description('字段选择器'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    populateSelector: Joi.object({
      'invite.invitedBy': Joi.string(),
      'auth.primaryUser': Joi.string(),
      'lockVin.operator': Joi.string()
    }).empty('').description('联表选项'),
  },
  output: {
    200: {
      body: Joi.array().items(stockValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  return await BKStock.find(query);
};