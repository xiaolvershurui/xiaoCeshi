const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const BKStock = require('../../../../../../services/database/ebike/stock');
const stockValidator = require('../../../../../../com.mango.common/validators').bk_stock;

exports.permissions = ['admin.bk.stock.getMany', 'operation'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(stockValidator),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  Object.assign(query.query, {
    station: ctx.state.user.stationId,
    'lockVin.isLocked': {
      $ne: true
    },
  });
  return await BKStock.find(query);
};