const Joi = require('koa-joi-router').Joi;
const BKStock = require('../../../../../../services/database/ebike/stock');

exports.permissions = ['admin.bk.stock.getMany', 'operation'];

exports.validate = {
  query: {
    query: Joi.object().default({}).description('查询条件'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  // 仓库所有车辆数量
  query.query = Object.assign({}, query.query, {
    station: ctx.state.user.stationId,
  });
  const total = await BKStock.count(query);

  // 仓库锁定车架号车辆数量
  query.query = Object.assign({}, query.query, {
    station: ctx.state.user.stationId,
    'lockVin.isLocked': true,
  });
  const lockedStocks = await BKStock.count(query);

  // 仓库绑定车机号车辆数量

  query.query = Object.assign({}, query.query, {
    station: ctx.state.user.stationId,
    box: {
      $exists: true
    },
  });
  const boxStocks = await BKStock.count(query);

  return {
    total,
    lockedStocks,
    boxStocks,
  };
};