const Joi = require('koa-joi-router').Joi;
const BKStock = require('../../../../../services/database/ebike/stock');

exports.permissions = ['admin.bk.stock.getMany', 'operation'];

exports.validate = {
  query: {
    query: Joi.object().default({}).description('查询条件'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  // 所有车辆数量
  const total = await BKStock.count(query);

  // 锁定车架号车辆数量
  query.query = Object.assign({}, query.query, {
    'lockVin.isLocked': true,
  });
  const lockedStocks = await BKStock.count(query);

  // 绑定车机号车辆数量
  query.query = Object.assign({}, query.query, {
    box: {
      $exists: true
    },
  });
  const boxStocks = await BKStock.count(query);

  return {
    total,
    lockedStocks,
    boxStocks,
  };
};