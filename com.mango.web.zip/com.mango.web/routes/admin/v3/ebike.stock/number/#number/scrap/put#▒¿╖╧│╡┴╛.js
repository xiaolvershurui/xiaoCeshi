const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const BKStock = require('../../../../../../../services/business/ebike/stock');

exports.permissions = ['admin.bk.stock.put', 'operation'];

exports.validate = {
  params: {
    number: Joi.string().required().description('车牌号')
  },
  query: {},
  type: 'json',
  body: Joi.object({
    reason: Joi.string().empty('').description('车辆未找到原因'),
    photo: Joi.string().empty('').description('照片'),
  }),
  output: {
    200: {
      body: Joi.object({})
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await BKStock.setScrap({
    number: params.number,
    operator: ctx.state.user.id,
    reason: body.reason,
    photo: body.photo
  });
};