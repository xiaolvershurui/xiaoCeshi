const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const BKStock = require('../../../../../../services/business/ebike/stock');

exports.permissions = ['admin.bk.stock.put', 'operation'];

exports.validate = {
  params: {
    id: validators.id.required().description('车辆ID')
  },
  type: 'json',
  body: Joi.object({
    hasFind: Joi.boolean().required().description('是否找到'),
    remark: Joi.string().empty('').description('备注'),
    failedReason: Joi.number().empty('').description('车辆未找到原因'),
    photo: Joi.string().empty('').description('照片'),
    failedAddress: Joi.string().description('未找到不能进入地址'),
    inspectionIssueReason: Joi.string().empty('').description('断电离线原因'),
    inspectionIssueReasonExtra: Joi.string().empty('').description('其他断电离线原因')
  }),
  output: {
    200: {
      body: Joi.object({})
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await BKStock.findStock({
    id: params.id,
    uid: ctx.state.user.id,
    hasFind: body.hasFind,
    location: ctx.state.deviceInfo.location,
    remark: body.remark,
    failedReason: body.failedReason,
    photo: body.photo,
    failedAddress: body.failedAddress,
    inspectionIssueReason: body.inspectionIssueReason,
    inspectionIssueReasonExtra: body.inspectionIssueReasonExtra,
  });
};
