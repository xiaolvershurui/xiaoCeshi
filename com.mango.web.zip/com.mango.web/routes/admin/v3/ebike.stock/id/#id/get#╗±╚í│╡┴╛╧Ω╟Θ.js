const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const BKStock = require('../../../../../../services/database/ebike/stock');

exports.permissions = ['admin.bk.stock.put', 'operation'];

exports.validate = {
  params: {
    id: validators.id.required().description('车辆ID')
  },
  query: Joi.object({
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'invite.invitedBy': Joi.string(),
      'auth.primaryUser': Joi.string(),
      'lockVin.operator': Joi.string()
    }).empty('').description('联表选项'),  }),
  output: {
    200: {
      body: Joi.object({})
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await BKStock.findById({
    id: params.id,
    selector: body.selector,
    populateSelector: body.populateSelector
  });
};