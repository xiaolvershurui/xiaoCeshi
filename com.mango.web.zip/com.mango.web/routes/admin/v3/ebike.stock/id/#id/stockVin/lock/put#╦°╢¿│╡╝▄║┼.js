const Joi = require('koa-joi-router').Joi;
const BKStock = require('../../../../../../../../services/business/ebike/stock');
const BadRequestError = require('../../../../../../../../com.mango.common/errors/BadRequestError');
const validators = require('../../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.bk.stock.put', 'operation'];

exports.validate = {
  params: {
    id: validators.id.required().description('车辆ID'),
  },
  output: {
    200: {
      body: Joi.object({ _id: Joi.string() }),
    },
  },
};

exports.handler = async ({ params, ctx }) => {

  return await BKStock.updateStockAndRecord({
    id: params.id,
    type: constants.RC_STOCK_OP_TYPE.锁定车架号,
    data: {
      lockVin: {
        isLocked: true,
        operator: ctx.state.user.id,
        lockedAt: new Date(),
      },
    },
  });
};
