const RCBatteryInStockPoint = require('../../../../../services/database/record/batteryInStockPoint');
const Joi = require('koa-joi-router').Joi;
const oss = require('../../../../../services/oss');

// exports.permissions = ['admin.rc.battery_in_stock_point.getMany'];
exports.permissions = ['public'];
exports.validate = {
  query: {
    battery: Joi.string().required(),
  },
};

exports.out = Joi.object();

exports.handler = async ({ query }) => {
  const ret = await RCBatteryInStockPoint.findLastOne({
    query: { battery: query.battery, finished: true },
    sort: { _id: -1 },
    selector: 'url',
  });
  let signedUrl;
  if (ret) {
    signedUrl = (oss.private.getUrls(ret.url)).signedUrl;
  }
  return signedUrl;

};
