const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../services/database/account/user');
const userValidator = require('../../../../../../com.mango.common/validators/index').ac_user;
const BadRequestError = require('../../../../../../com.mango.common/errors/BadRequestError');
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.user.get'];

exports.validate = {
  params: {
    role: Joi.string().required().description('用户角色'),
  },
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(userValidator),
    },
  },
};

exports.handler = async ({ params, query }) => {
  if (params.role === 'user') throw new BadRequestError(`所有用户均有user角色`);
  Object.assign(query.query, {
    'auth.roles': {
      $in: [params.role],
    },
  });
  return await ACUser.find(query);
};