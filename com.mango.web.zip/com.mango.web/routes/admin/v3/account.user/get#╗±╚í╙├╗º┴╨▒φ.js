const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../services/database/account/user');
const userValidator = require('../../../../com.mango.common/validators/index').ac_user;

exports.permissions = ['admin.ac.user.getMany'];

exports.validate = {
  query : {
    query: Joi.object().required().description('查询条件'),
    selector: Joi.string().empty('').description('字段选择器'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    populateSelector: Joi.object({
      'invite.invitedBy': Joi.string(),
      'auth.primaryUser': Joi.string(),
    }).empty('').description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(userValidator),
        count: Joi.number().description('条目数')
      })
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ACUser.find({
    query: query.query,
    selector: query.selector,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    populateSelector: query.populateSelector
  });
  const count = await ACUser.count({
      query: query.query,
    });
  return {
    items,
    count
  }
};