const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../services/database/account/user');
const userValidator = require('../../../../../com.mango.common/validators/index').ac_user;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.user.get'];

exports.validate = {
  params: {
  },
  query: {
    tel: validators.tel.required().description('手机号'),
    populateSelector: Joi.object({
      'invite.invitedBy': Joi.string(),
      'auth.primaryUser': Joi.string(),
    }).empty('').description('连表选项'),
    selector: validators.selector,
  },
  output: {
    200: {
      body: userValidator,
    }
  }
};

exports.handler = async ({ params , query }) => {
  return await ACUser.findByTel({
    tel: query.tel,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};