const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../services/database/account/user');
const userValidator = require('../../../../../../com.mango.common/validators/index').ac_user;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.user.get'];

exports.validate = {
  query : {
    id: validators.id.required().description('User Id'),
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'invite.invitedBy': Joi.string(),
      'auth.primaryUser': Joi.string()
    })
  },
  output: {
    200: {
      body: userValidator
    }
  }
};

exports.handler = async ({ query }) => {
 return await ACUser.findById({
    id: query.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};