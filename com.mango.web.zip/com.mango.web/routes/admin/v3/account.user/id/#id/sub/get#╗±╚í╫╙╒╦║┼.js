const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/database/account/user');
const userValidators = require('../../../../../../../com.mango.common/validators/index').ac_user;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.user.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('主账号ID')
  },
  query: {
    query: Joi.object().required().description('查询参数'),
    selector: Joi.string().empty('').description('字段选择器'),
    popuSelector: Joi.object({
      regions: Joi.string().empty(''),
      inspectionAreas: Joi.string().empty(''),
      user: Joi.string().empty('')
    }).empty('').description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(userValidators),
        count: Joi.number()
      })
    }
  }
};

exports.handler = async ({ params, query }) => {
  const dbQuery = {
    'auth.primaryUser': params.id
  };
  const items = await ACUser.find({
    sort: query.sort,
    skip: query.skip,
    limit: query.limit,
    query: dbQuery,
    selector:  query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ACUser.count({
    query: dbQuery
  });
  return { items,count }
};