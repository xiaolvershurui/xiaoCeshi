const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const FNTicket = require('../../../../../../../services/database/finance/ticket');
const fnTicketValidator = require('../../../../../../../com.mango.common/validators/index').fn_ticket;

exports.permissions = ['admin.ac.user.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('用户ID'),
  },
  query:{
    limit: Joi.number(),
    skip: Joi.object(),
    selector: Joi.string()
  },
  output: {
    200: {
      body: Joi.object({
        items: fnTicketValidator,
        count: Joi.number().description('条目数')
      })
    }
  }
};

exports.handler = async ({ params, query }) => {
  const items = await FNTicket.find({
    query: {
      user: params.id
    },
    limit: query.limit,
    skip: query.skip,
    selector: query.selector,
    sort: { _id: -1 }
  });
  const count = await  FNTicket.count({
    query
  });
  return { count,items };
};