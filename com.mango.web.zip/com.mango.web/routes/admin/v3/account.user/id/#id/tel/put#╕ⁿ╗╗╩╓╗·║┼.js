const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/database/account/user');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.ac.user.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('主账号ID'),
  },
  type: 'json',
  body: {
    tel: validators.tel.required().description('手机号'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body }) => {
  const acUserById = await ACUser.findById({ id: params.id });
  if (!acUserById) throw new NotFoundError(`用户${params.id}不存在`);

  const acUserByTel = await ACUser.findByTel({ tel: body.tel });
  if (acUserByTel) throw new BadRequestError(`手机号为${body.tel}已经存在，请换一个手机号重试`);

  return await ACUser.update({
    id: params.id,
    data: {
      'auth.tel': body.tel,
    },
  });
};
