const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/database/account/user');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.ac.user.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('User Id')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params }) => {
  const acUser = await ACUser.findById({
    id: params.id,
    selector: 'cert'
  });
  const activeUser = await ACUser.find({
    query: {
      'cert.certNo': acUser.certNo,
      'cert.certType': acUser.certType,
      'auth.primaryUser': { $exists: false },
      'destroyed': false
    }
  });
  if(activeUser.length !==0){
    throw new Error('认真信息已经被重新利用,无法从注销中恢复');
  }
  return await  ACUser.update({
    id: params.id,
    data:{
      destroyed: false
    }
  })
};