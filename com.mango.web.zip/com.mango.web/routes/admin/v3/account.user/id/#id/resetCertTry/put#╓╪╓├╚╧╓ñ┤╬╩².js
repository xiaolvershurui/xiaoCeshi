const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/database/account/user');
const validators = require('../../../../../../../com.mango.common/settings/validators');


exports.permissions = ['admin.ac.user.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('用户编号')
  },
  query: {

  },
  output: {
    200: {
      body: Joi.object({
        _id: Joi.string().required('Id')
      })
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ACUser.update({
    id: params.id,
    data: {
      'cert.triedAt': [],
    }
  })
};