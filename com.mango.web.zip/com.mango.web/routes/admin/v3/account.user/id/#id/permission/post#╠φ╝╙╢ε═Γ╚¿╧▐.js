const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/business/account/user');
const validators = require('../../../../../../../com.mango.common/settings/validators');


exports.permissions = ['admin'];

exports.validate = {
  params: {
    id: validators.id.required().description('用户编号')
  },
  query: {

  },
  type: "json",
  body:{
    permission: Joi.string().required().description('要删除额外权限'),
  },
  output: {
    200: {
      body: Joi.object({
        _id: Joi.string().required('Id')
      })
    }
  }
};

exports.handler = async ({ params,body }) => {
  return await ACUser.addPermission({
    id: params.id,
    permission: body.permission
  })
};