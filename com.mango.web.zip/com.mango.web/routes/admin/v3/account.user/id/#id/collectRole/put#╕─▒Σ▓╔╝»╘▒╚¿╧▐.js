const Joi = require('koa-joi-router').Joi;
const ACUser = require('../../../../../../../services/business/account/user');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin'];

exports.validate = {
  params: {
    id: validators.id.required().description('主账号ID')
  },
  type: "json",
  body: {
    unset: Joi.boolean().required().description('删除或授予'),
  },
  query: {

  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params, query, body }) => {
  return await ACUser.setCollectRole({
    id: params.id,
    unset: body.unset
  });
};