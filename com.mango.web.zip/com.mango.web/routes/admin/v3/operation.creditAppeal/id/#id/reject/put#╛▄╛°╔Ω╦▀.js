const Joi = require('koa-joi-router').Joi;
const OPCreditAppeal = require('../../../../../../../services/business/operation/creditAppeal');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');


exports.permissions = ['admin.op.credit_appeal.put'];

exports.validate = {
  params:{
    id: validators.id.required().description('CreditAppear Id')
  },
  type: 'json',
  body: {
    rejectReason: Joi.string().description('驳回原因'),
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string() })
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return OPCreditAppeal.reject({
    id: params.id,
    rejectReason: body.rejectReason,
    processor: ctx.state.user.id
  })
};