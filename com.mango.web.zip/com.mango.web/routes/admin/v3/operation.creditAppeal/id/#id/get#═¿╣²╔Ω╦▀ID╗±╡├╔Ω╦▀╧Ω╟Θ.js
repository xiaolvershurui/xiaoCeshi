const Joi = require('koa-joi-router').Joi;
const OPCreditAppeal = require('../../../../../../services/database/operation/creditAppeal');
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const opCreditAppealValidator = require('../../../../../../com.mango.common/validators/index').op_credit_appeal;

exports.permissions = ['admin.op.credit_appeal.get'];

exports.validate = {
  params:{
    id: validators.id.required().description('CreditAppear Id')
  },
  query: {
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'credit': Joi.string(),
      'user': Joi.string(),
      'processor': Joi.string(),
      'order': Joi.string()
    }).default({}).description('连表选项')
  },
  output: {
    200: {
      body: opCreditAppealValidator
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await OPCreditAppeal.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};