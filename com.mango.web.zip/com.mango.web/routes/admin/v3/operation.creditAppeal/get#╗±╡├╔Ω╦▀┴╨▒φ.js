const Joi = require('koa-joi-router').Joi;
const OPCreditAppeal = require('../../../../services/database/operation/creditAppeal');
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const opCreditAppealValidator = require('../../../../com.mango.common/validators/index').op_credit_appeal;

exports.permissions = ['admin.op.credit_appeal.getMany'];

exports.validate = {
  query: {
    query: Joi.object().default({}).description('query 参数'),
    selector: Joi.string().description('返回字段'),
    sort: Joi.object().description('排序选项'),
    limit: Joi.number().description('返回数量'),
    skip: Joi.number().description('跳过数量'),
    populateSelector: Joi.object({
      'credit': Joi.string(),
      'user': Joi.string(),
      'processor': Joi.string(),
      'order': Joi.string()
    }).default({}).description('连表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(opCreditAppealValidator),
        count: Joi.number().description('总条目')
      })
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await OPCreditAppeal.find({
    query: query.query,
    selector: query.selector,
    sort: query.sort,
    limit: query.limit,
    skip: query.skip,
    populateSelector: query.populateSelector
  });
  const count = await OPCreditAppeal.count({
    query: query.query
  });
  return { items, count }
};