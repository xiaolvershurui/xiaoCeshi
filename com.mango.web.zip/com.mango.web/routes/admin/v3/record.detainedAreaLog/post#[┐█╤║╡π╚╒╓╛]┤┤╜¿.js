const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const RCDetainedAreaLog = require('../../../../services/business/record/detainedAreaLog');

exports.permissions = ['admin.rc.detained_area_log.post'];

exports.validate = {
  type: 'json',
  body: {
    detainedArea: Joi.string().required().description('扣押点编号'),
    logType: Joi.number().required().description('日志类型'),
    mark: Joi.string().required().description('备注')
  },
};

exports.handler = async ({ body }) => {
  return await RCDetainedAreaLog.create(body);
};