const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const RCDetainedAreaLog = require('../../../../services/database/record/detainedAreaLog');
const detainedAreaLogValidator = require('../../../../com.mango.common/validators').rc_detained_area_log;

exports.permissions = ['admin.rc.detained_area_log.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: {
        items: Joi.array().items(detainedAreaLogValidator),
        count: Joi.number(),
      },
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await RCDetainedAreaLog.find(query);
  const count = await RCDetainedAreaLog.count({
    query: query.query,
  });
  return { items, count };
};