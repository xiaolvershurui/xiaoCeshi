const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');
const RCDetainedAreaLog = require('../../../../../services/database/record/detainedAreaLog');
const STDetainedArea = require('../../../../../services/database/setting/detainedArea');
const detainedAreaLogValidator = require('../../../../../com.mango.common/validators').rc_detained_area_log;
const BKStock = require('../../../../../services/database/ebike/stock');

// exports.permissions = ['admin.rc.detained_area_log.getMany'];
exports.permissions = ['public'];

exports.validate = {
  query: {
    region: Joi.string().required().description('大区'),
    date: Joi.object({
      $gte: Joi.date().required().description('起始时间'),
      $lte: Joi.date().required().description('结束时间'),
    }).required().description('时间区间'),
  },
  output: {
    200: {
      body: Joi.array().items(detainedAreaLogValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  // 此大区所有扣押点
  const detainedAreas = (await STDetainedArea.find({
    query: {
      region: query.region,
    },
    limit: 0,
  })).map(item => item._id);

  // 获取扣押点扣押日志
  const detainedStocksInArea = await RCDetainedAreaLog.find({
    query: {
      detainedArea: {
        $in: detainedAreas,
      },
      createdAt: query.date,
      operator: '1',
    },
    limit: 0,
    selector: 'stock detainedArea createdAt',
    populateSelector: {
      stock: 'number.custom location.lngLat box',
      detainedArea: 'number region name lngLat address contact tel unit principal stocks'
    }
  });

  const stockIds = [...new Set(detainedStocksInArea.reduce((memo, item) => {
    memo = [...memo, ...item.stock];
    return memo;
  }, []).map(item => item._id))];

  const stocks = await BKStock.find({
    query: {
      _id: {
        $in: stockIds
      }
    },
    limit: 0,
    selector: 'locate'
  });

  return detainedStocksInArea.reduce((memo, item) => {
    const s = memo.find(i => i.detainedArea._id === item.detainedArea._id);
    if (!s) {
      const stocksResult = item.stock.filter(i => {
        const stock = stocks.find(s => s._id === i._id);
        if (stock) {
          return stock.locate === constants.BK_LOCATE.扣押
        }
      });
      memo = [...memo, {
        detainedArea: item.detainedArea,
        stocks: stocksResult,
        createdAt: item.createdAt,
        _id: item._id
      }]
    } else {
      let resultStocks = item.stock.filter(i => {
        const stock = stocks.find(s => s._id === i._id);
        if (stock) {
          return stock.locate === constants.BK_LOCATE.扣押
        }
      });
      resultStocks = resultStocks.filter(i => {
        return !s.stocks.find(s => s._id === i._id)
      });
      s.stocks = [...s.stocks, ...resultStocks]
    }
    return memo;
  }, []);
};
