const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../services/database/setting/boxUpgrade');

// TODO: output
exports.handler = async _ => {
  return await STBoxUpgrade.find();
};