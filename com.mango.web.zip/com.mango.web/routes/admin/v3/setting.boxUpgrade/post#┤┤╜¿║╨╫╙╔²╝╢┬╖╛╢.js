const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../services/business/setting/boxUpgrade');

exports.permissions = ['admin.st.box_upgrade.post'];
exports.validate = {
  type: 'json',
  body: {
    enable: Joi.boolean(),
    version: Joi.string(),
    packVersion: Joi.string(),
  },
  output: {
    200: {
      body: Joi.object({
        _id: Joi.string()
      })
    }
  }
};
exports.handler = async ({ body }) => {
  return await STBoxUpgrade.create(body);
};