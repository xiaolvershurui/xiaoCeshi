const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../../../services/business/setting/boxUpgrade');

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    packVersion: Joi.string().required()
  }
};
exports.handler = async ({ params, body }) => {
  await STBoxUpgrade.updatePackVersion({ id: params.id, packVersion: body.packVersion });
};