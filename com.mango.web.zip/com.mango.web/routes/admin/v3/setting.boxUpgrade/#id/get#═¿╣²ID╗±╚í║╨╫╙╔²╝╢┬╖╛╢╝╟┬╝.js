const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../../services/database/setting/boxUpgrade');

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  // TODO: output
};
exports.handler = async ({ params }) => {
  return await STBoxUpgrade.findById(params);
};