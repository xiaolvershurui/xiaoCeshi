const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../../services/database/setting/boxUpgrade');

exports.validate = {
  params: {
    id: Joi.string().required()
  }
};
exports.handler = async ({ params }) => {
  await STBoxUpgrade.delete(params.id);
};