const Joi = require('koa-joi-router').Joi;
const STBoxUpgrade = require('../../../../../../services/business/setting/boxUpgrade');

exports.validate = {
  params: {
    id: Joi.string().required(),
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required()
  }
};
exports.handler = async ({ params, body }) => {
  await STBoxUpgrade.toggleEnable({ id: params.id, enable: body.enable });
};