const Joi = require('koa-joi-router').Joi;
const BKDamage = require('../../../../services/database/ebike/damage');
const validators = require('../../../../com.mango.common/settings/validators');
const bkDamageValidator = require('../../../../com.mango.common/validators/index').bk_damage;

exports.permissions = ['admin.bk.damage.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: validators.selector,
    populateSelector: Joi.object({
      stock: Joi.string().allow(''),
      submitter: Joi.string().allow(''),
      repairer: Joi.string().allow(''),
    }).empty('').description('联表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(bkDamageValidator),
        count: Joi.number().description('总条目数')
      })
    }
  }
};

exports.handler = async ( { query } ) => {
  const items = await BKDamage.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await BKDamage.count({
    query: query.query
  });
  return { items, count }
}