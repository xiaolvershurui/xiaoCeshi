const BKDamage = require('../../../../../services/database/ebike/damage');
const validators = require('../../../../../com.mango.common/settings/validators');
const damageValidator = require('../../../../../com.mango.common/validators/index').bk_damage;
const Joi = require('koa-joi-router').Joi;

exports.permissions = ['admin.bk.damage.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('车损 ID'),
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object({
      stock: Joi.string().empty(''),
      submitter: Joi.string().empty(''),
      repairer: Joi.string().empty('')
    }).empty('').description('连表选项'),
  },
  output: {
    200: {
      body: damageValidator
    }
  }
};

exports.handler = async ( { params, query } ) => {
  return await BKDamage.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector,
  })
};
