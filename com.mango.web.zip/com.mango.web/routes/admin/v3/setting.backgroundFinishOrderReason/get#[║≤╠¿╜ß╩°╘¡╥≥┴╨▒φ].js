const Joi = require('koa-joi-router').Joi;
const STBackgroundFinishOrderReason = require('../../../../services/database/setting/backgroundFinishOrderReason');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.backgroundFinishOrderReason.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object())
    }
  }
};

exports.handler = async ({ query }) => {
  return await STBackgroundFinishOrderReason.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector
  });
};