const RCScanQR = require('../../../../services/database/record/scanQR');
const Joi = require('koa-joi-router').Joi;
const rcScanQRValidators = require('../../../../com.mango.common/validators/index').rc_scan_qr;
const constants = require('../../../../com.mango.common/settings/validators');
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.rc.scan_qr.getMany'];

exports.validate = {
  query: validators.findlist,
};

exports.out = validators.tableListOutput(rcScanQRValidators);

exports.handler = async ({ query }) => {
  const items = await RCScanQR.find(query);
  const count = await RCScanQR.count({
    query: query.query,
  });
  return { items, count };
};
