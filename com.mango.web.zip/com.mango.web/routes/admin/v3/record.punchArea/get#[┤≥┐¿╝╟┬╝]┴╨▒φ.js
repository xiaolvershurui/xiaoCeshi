const Joi = require('koa-joi-router').Joi;
const RCPunchArea = require('../../../../services/database/record/punchArea');
const ACUser = require('../../../../services/database/account/user');
const rcPunchAreaValidator = require('../../../../com.mango.common/validators/index').rc_punch_area;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.rc.punch_area.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(rcPunchAreaValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  // const name = query.query['cert.name'];
  // const tel = query.query['auth.tel'];
  // if (name) {
  //   const userByName = await ACUser.findByName({
  //     name,
  //     selector: '_id'
  //   });
  //   Object.assign(query.query, {
  //     puncher: userByName._id
  //   })
  // }
  // if (tel) {
  //   const userByTel = await ACUser.findByTel({
  //     tel,
  //     selector: '_id'
  //   });
  //   Object.assign(query.query, {
  //     puncher: userByTel._id
  //   })
  // }
  const items = await RCPunchArea.find(query);
  const count = await RCPunchArea.count({
    query: query.query,
  });
  return { items, count };
};
