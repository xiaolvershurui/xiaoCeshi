const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../../../services/database/operation/photoToPoint');

exports.permissions = ['admin.op.photo_to_point.delete'];


exports.validate = {
  params: {
    id: Joi.string().required().description('停车区照片编号'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params }) => {
  return await OPPhotoToPoint.remove({ id: params.id });
};


