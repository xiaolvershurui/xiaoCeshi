const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../../../../services/business/operation/photoToPoint');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const Core = require('../../../../../../../services/core/shark');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.photo_to_point.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('停车区照片 Id'),
  },
  type: 'json',
  body: {
    parkingLotId: validators.id.required().description('停车区 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  const parkingLot = await Core.sendSync({
    c: 'operation/parkingLot/findById.a.1',
    params: { parkingLotId: body.parkingLotId },
  });
  if (!parkingLot) throw new NotFoundError(`停车区${body.parkingLotId}不存在`);

  return await OPPhotoToPoint.bindingPhotoToPoint(Object.assign(params, body));
};


