const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../services/database/operation/photoToPoint');
const constants = require('../../../../com.mango.common/settings/constants');
const BadRequestError = require('../../../../com.mango.common/errors/BadRequestError');
const validators = require('../../../../com.mango.common/settings/validators');
const coordtransform = require('coordtransform');

exports.permissions = ['admin.op.photo_to_point.post'];

const getLocation = function (isGcj, coordinates) {
  if (isGcj) {
    return {
      geometry: {
        type: 'Point',
        coordinates: coordtransform.wgs84togcj02(coordinates[0], coordinates[1]),
      },
      gcj02Geometry: {
        type: 'Point',
        coordinates,
      },
    };
  } else {
    return {
      geometry: {
        type: 'Point',
        coordinates,
      },
      gcj02Geometry: {
        type: 'Point',
        coordinates: coordtransform.wgs84togcj02(coordinates[0], coordinates[1]),
      },
    };
  }
};

exports.validate = {
  type: 'json',
  body: {
    photo: Joi.string().description('照片url'),
    coordinates: validators.location.required().description('点位置'),
    isGcj: Joi.boolean().default(false).required().description('是否是国测局'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body, ctx }) => {
  const location = getLocation(body.isGcj, body.coordinates);
  const { heading } = ctx.state.deviceInfo;
  const finalQuery = body.isGcj ? {
    'location.gcj02Geometry.coordinates': location.gcj02Geometry.coordinates,
  } : {
    'location.geometry.coordinates': location.geometry.coordinates,
  };
  const opPhotoPoint = await OPPhotoToPoint.find({
    query: finalQuery,
    limit: 0,
  });
  if (opPhotoPoint && opPhotoPoint.length) throw new BadRequestError('此坐标点已经存在图片');
  return await OPPhotoToPoint.create({
    creator: ctx.state.user.id,
    location,
    photo: body.photo,
    heading,
  });
};


