const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../../services/database/operation/photoToPoint');
const constants = require('../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../com.mango.common/settings/validators');
const oss = require('../../../../../services/oss');

exports.permissions = ['admin.op.photo_to_point.getMany'];

exports.validate = {
  query: {
    radius: Joi.number().default(500).description('查询半径'),
    center: validators.location.required().description('点位置'),
    isGcj: Joi.boolean().default(false),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};
exports.handler = async ({ query }) => {
  Object.assign(query, {
    selector: 'creator location photo parkingLot createdAt',
    populateSelector: {
      creator: 'cert.name',
    },
  });
  return await OPPhotoToPoint.findByLocation(query);
};


