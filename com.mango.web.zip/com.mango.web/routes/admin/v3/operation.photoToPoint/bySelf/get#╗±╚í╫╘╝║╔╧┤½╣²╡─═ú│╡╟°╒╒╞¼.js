const Joi = require('koa-joi-router').Joi;
const OPPhotoToPoint = require('../../../../../services/database/operation/photoToPoint');
const constants = require('../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../com.mango.common/settings/validators');
const opPhotoToPointValidator = require('../../../../../com.mango.common/validators/index').op_photo_to_point;

exports.permissions = ['admin.op.photo_to_point.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(opPhotoToPointValidator),
    },
  },
};
exports.handler = async ({ ctx }) => {
  query.query = {
    $and: [
      query.query,
      {
        removed: false,
        creator: ctx.state.user.id
      }],
  };
  return await OPPhotoToPoint.find(query);
};


