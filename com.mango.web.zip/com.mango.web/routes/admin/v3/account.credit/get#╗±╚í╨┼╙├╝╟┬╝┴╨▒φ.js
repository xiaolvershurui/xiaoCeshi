const Joi = require('koa-joi-router').Joi;
const ACCredit = require('../../../../services/database/account/credit');
const creditValidator = require('../../../../com.mango.common/validators/index').ac_credit;

exports.permissions = ['admin.ac.credit.getMany'];
exports.validate = {
  params: {

  },
  query : {
    query: Joi.object().required().description('查询参数'),
    selector: Joi.string().empty('').description('字段选择器'),
    sort: Joi.object().empty('').description('排序选项'),
    skip: Joi.number().empty('').description('跳过条目'),
    limit: Joi.number().empty('').description('限制条目'),
    populateSelector: Joi.object({
      user: Joi.string().empty('')
    }).empty('').description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(creditValidator),
        count: Joi.number()
      })
    }
  }
};

exports.handler = async ({ params, query }) => {
  const items = await ACCredit.find({
    sort: query.sort,
    skip: query.skip,
    limit: query.limit,
    query   :  query.query,
    selector:  query.selector,
    populateSelector: query.populateSelector
  });
  const count = await  ACCredit.count({
    query: query.query,
  });
  return {
    items,
    count
  }
};