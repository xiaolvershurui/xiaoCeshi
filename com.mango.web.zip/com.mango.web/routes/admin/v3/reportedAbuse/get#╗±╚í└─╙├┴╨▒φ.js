const OPReportedAbuse = require('../../../../services/database/operation/reportedAbuse');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const reportedAbuseValidator = require('../../../../com.mango.common/validators/index').op_reported_abuse;
const constants = require('../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.od.reportedAbuse.getMany'];
exports.validate = {
  query: {
    query: Joi.object().default({}),
    limit: Joi.number().default(constants.PAGE_SIZE),
    sort: Joi.object().default({}),
    skip: Joi.number().default(0),
    selector: Joi.string().description('连表选项'),
    populateSelector: Joi.object({
      'bike': Joi.string().allow(''),
      'reporter': Joi.string().allow(''),
      'processor': Joi.string().allow(''),
    }).default({}).description('连表查询字段')
  },
  output: {
    200:{
      body: {
        items: Joi.array().items(reportedAbuseValidator),
      }
    }
  }
};
exports.handler = async ({ query }) => {
  return await OPReportedAbuse.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};