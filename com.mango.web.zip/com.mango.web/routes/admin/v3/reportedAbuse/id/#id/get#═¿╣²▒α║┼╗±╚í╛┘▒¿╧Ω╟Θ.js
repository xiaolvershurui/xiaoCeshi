const OPReportedAbuse = require('../../../../../../services/database/operation/reportedAbuse');
const validators =  require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const reportedAbuseValidator = require('../../../../../../com.mango.common/validators/index').op_reported_abuse;
const Joi = require('poolishark').Joi;

exports.permissions = ['admin.od.reportedAbuse.get'];
exports.validate = {
  params: {
    id: validators.id.required().description('举报记录编号')
  },
  query: {
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'bike': Joi.string().allow(''),
      'reporter': Joi.string().allow(''),
      'processor': Joi.string().allow(''),
    }).default({}).description('连表查询字段')
  },
  output: {
    200:{
      body: reportedAbuseValidator
    }
  }
};

exports.handler = async ({ query, params }) => {
  return await OPReportedAbuse.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};