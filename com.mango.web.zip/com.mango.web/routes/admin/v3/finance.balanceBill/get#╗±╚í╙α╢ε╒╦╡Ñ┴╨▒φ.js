const FNBalanceBill = require('../../../../services/database/finance/balanceBill');
const constants = require('../../../../com.mango.common/settings/constants');
const Joi = require('joi');
const fnBalanceBillValidator = require('../../../../com.mango.common/validators/index').fn_balance_bill;

exports.permissions = ['admin.fn.balance_bill.getMany'];

exports.validate = {
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'region': Joi.string(),
      'style': Joi.string(),
      'order': Joi.string(),
      'ticket': Joi.string(),
    }).description('连表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(fnBalanceBillValidator),
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await FNBalanceBill.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  return { items };
};
