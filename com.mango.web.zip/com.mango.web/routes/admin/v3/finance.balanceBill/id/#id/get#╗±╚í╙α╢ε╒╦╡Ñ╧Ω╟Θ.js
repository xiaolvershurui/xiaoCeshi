const FNBalanceBill = require('../../../../../../services/database/finance/balanceBill');
const Joi = require('joi');
const fnBalanceBillValidator = require('../../../../../../com.mango.common/validators/index').fn_balance_bill;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.fn.balance_bill.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('FNBalanceBill Id')
  },
  query: {
    selector: Joi.string().description('返回字段'),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'region': Joi.string(),
      'style': Joi.string(),
      'order': Joi.string(),
      'ticket': Joi.string(),
    }).description('连表选项')
  },
  output: {
    200: {
      body: fnBalanceBillValidator,
    }
  }
};

exports.handler = async ({ params,query }) => {
  return  await FNBalanceBill.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
