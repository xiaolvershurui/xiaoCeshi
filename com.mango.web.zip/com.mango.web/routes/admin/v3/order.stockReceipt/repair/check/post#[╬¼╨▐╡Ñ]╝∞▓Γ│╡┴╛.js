const Joi = require('koa-joi-router').Joi;
const ODStockRepair = require('../../../../../../services/business/order/stockRepair');

exports.permissions = ['admin.od.stock_repair.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.object()).description('车辆'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockRepair.check({
    stocks: body.stocks,
    station: ctx.state.user.stationId,
  });
};
