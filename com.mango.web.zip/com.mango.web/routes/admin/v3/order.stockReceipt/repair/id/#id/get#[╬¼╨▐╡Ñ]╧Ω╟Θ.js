const Joi = require('koa-joi-router').Joi;
const ODStockRepair = require('../../../../../../../services/database/order/stockRepair');
const odStockRepairValidator = require('../../../../../../../com.mango.common/validators/index').od_stock_repair;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_repair.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: validators.findOne,
  output: {
    200: {
      body: odStockRepairValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODStockRepair.findById(Object.assign({}, params, query))
};
