const ODStockRepair = require('../../../../../../../../services/business/order/stockRepair');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_repair.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('维修单 id')
  },
};

exports.handler = async ({ params }) => {
  return await ODStockRepair.retry({
    id: params.id,
  });
};
