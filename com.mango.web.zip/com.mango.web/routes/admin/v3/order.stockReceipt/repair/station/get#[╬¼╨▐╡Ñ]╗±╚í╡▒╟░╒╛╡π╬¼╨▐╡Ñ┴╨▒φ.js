const ODStockRepair = require('../../../../../../services/database/order/stockRepair');
const odStockRepairValidator = require('../../../../../../com.mango.common/validators').od_stock_repair;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_repair.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odStockRepairValidator),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  query.query = {
    $and: [query.query, {
      station: ctx.state.user.stationId,
    }],
  };
  const items = await ODStockRepair.find(query);
  const count = await ODStockRepair.count({
    query: query.query,
  });
  return { items, count };
};
