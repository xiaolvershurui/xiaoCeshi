const Joi = require('koa-joi-router').Joi;
const ODStockRepair = require('../../../../../../../../services/database/order/stockRepair');
const odStockRepairValidator = require('../../../../../../../../com.mango.common/validators').od_stock_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_repair.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('维修单 id')
  },
  query: validators.findOne,
  output: {
    200: {
      body: odStockRepairValidator,
    },
  },
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODStockRepair.findInStation(Object.assign(params, query, {
    station: ctx.state.user.stationId,
  }));
};
