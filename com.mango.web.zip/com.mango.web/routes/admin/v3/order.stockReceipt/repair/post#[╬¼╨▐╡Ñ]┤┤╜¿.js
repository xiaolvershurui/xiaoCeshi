const Joi = require('koa-joi-router').Joi;
const ODStockRepair = require('../../../../../services/business/order/stockRepair');

exports.permissions = ['admin.od.stock_repair.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.string()).description('车辆')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockRepair.create({
    station: ctx.state.user.stationId,
    storeManager: ctx.state.user.id,
    stocks: body.stocks
  });
};
