const Joi = require('koa-joi-router').Joi;
const ODStockPullBack = require('../../../../../services/business/order/stockPullBack');

exports.permissions = ['admin.od.stock_pull_back.post'];

exports.validate = {
  type: 'json',
  body: {
    driver: Joi.string().required().description('司机'),
    stocks: Joi.array().items(Joi.string()).description('车辆')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockPullBack.create({
    station: ctx.state.user.stationId,
    storeManager: ctx.state.user.id,
    driver: body.driver,
    stocks: body.stocks
  });
};
