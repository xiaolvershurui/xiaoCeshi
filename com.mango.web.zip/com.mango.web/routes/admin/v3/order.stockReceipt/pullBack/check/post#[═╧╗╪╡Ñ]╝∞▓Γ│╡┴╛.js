const Joi = require('koa-joi-router').Joi;
const ODStockPullBack = require('../../../../../../services/business/order/stockPullBack');

exports.permissions = ['admin.od.stock_pull_back.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.object()).description('车辆')
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    }
  }
};

exports.handler = async ({ body }) => {
  return await ODStockPullBack.check({
    stocks: body.stocks
  });
};
