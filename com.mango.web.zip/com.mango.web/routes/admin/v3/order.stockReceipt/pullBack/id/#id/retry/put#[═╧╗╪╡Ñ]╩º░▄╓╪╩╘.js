const Joi = require('koa-joi-router').Joi;
const ODStockPullBack = require('../../../../../../../../services/business/order/stockPullBack');
const odStockPullBackValidator = require('../../../../../../../../com.mango.common/validators/index').od_stock_pull_back;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_pull_back.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odStockPullBackValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODStockPullBack.retry({
    id: params.id
  })
};
