const Joi = require('koa-joi-router').Joi;
const ODStockPullBack = require('../../../../../services/database/order/stockPullBack');
const odStockPullBackValidator = require('../../../../../com.mango.common/validators').od_stock_pull_back;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_pull_back.getMany'];

exports.validate = {
  params: {},
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odStockPullBackValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODStockPullBack.find(query);
  const count = await ODStockPullBack.count({
    query: query.query
  });
  return { items, count };
};
