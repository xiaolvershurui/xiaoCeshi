const Joi = require('koa-joi-router').Joi;
const ODStockPullBack = require('../../../../../../services/database/order/stockPullBack');
const odStockPullBackValidator = require('../../../../../../com.mango.common/validators').od_stock_pull_back;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_pull_back.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(Joi.object()),
        count: Joi.number().description('条目数'),
      }),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODStockPullBack.find(Object.assign(query, { station: ctx.state.user.stationId }));
  const count = await ODStockPullBack.count({
    query: {
      station: ctx.state.user.stationId,
    },
  });
  return { items, count };
};
