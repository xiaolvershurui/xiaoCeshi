const Joi = require('koa-joi-router').Joi;
const ODStockInFactory = require('../../../../../../../../services/business/order/stockInFactory');
const odStockInFactoryValidator = require('../../../../../../../../com.mango.common/validators').od_stock_in_factory;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_in_factory.put'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  output: {
    200: {
      body: odStockInFactoryValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODStockInFactory.retry({
    id: params.id
  })
};
