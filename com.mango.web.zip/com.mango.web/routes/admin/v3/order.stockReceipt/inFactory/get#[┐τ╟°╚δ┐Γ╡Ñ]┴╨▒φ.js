const Joi = require('koa-joi-router').Joi;
const ODStockInFactory = require('../../../../../services/database/order/stockInFactory');
const odStockInFactoryValidator = require('../../../../../com.mango.common/validators').od_stock_in_factory;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_in_factory.getMany'];

exports.validate = {
  params: {},
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odStockInFactoryValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODStockInFactory.find(query);
  const count = await ODStockInFactory.count({
    query: query.query
  });
  return { items, count };
};
