const Joi = require('koa-joi-router').Joi;
const ODStockInFactory = require('../../../../../../services/business/order/stockInFactory');

exports.permissions = ['admin.od.stock_in_factory.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.object()).description('车辆')
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    }
  }
};

exports.handler = async ({ body }) => {
  return await ODStockInFactory.check({
    stocks: body.stocks
  });
};
