const Joi = require('koa-joi-router').Joi;
const ODStockInFactory = require('../../../../../services/business/order/stockInFactory');

exports.permissions = ['admin.od.stock_in_factory.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.string()).description('车辆')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockInFactory.create({
    station: ctx.state.user.stationId,
    storeManager: ctx.state.user.id,
    stocks: body.stocks
  });
};
