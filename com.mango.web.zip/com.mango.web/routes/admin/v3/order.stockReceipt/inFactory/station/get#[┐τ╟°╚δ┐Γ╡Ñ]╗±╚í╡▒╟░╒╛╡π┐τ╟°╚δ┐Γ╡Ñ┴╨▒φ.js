const Joi = require('koa-joi-router').Joi;
const ODStockInFactory = require('../../../../../../services/database/order/stockInFactory');
const odStockInFactoryValidator = require('../../../../../../com.mango.common/validators').od_stock_in_factory;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_in_factory.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odStockInFactoryValidator)
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODStockInFactory.find(Object.assign(query, { station: ctx.state.user.stationId }));
  const count = await ODStockInFactory.count({
    query: {
      station: ctx.state.user.stationId,
    },
  });
  return { items, count };
};
