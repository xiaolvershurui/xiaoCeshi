const ODStockDamage = require('../../../../../services/database/order/stockDamage');
const odStockDamageValidator = require('../../../../../com.mango.common/validators').od_stock_damage;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_damage.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(odStockDamageValidator)
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODStockDamage.find(query);
  const count = await ODStockDamage.count({
    query: query.query
  });
  return { items, count };
};
