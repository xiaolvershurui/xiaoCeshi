const ODStockDamage = require('../../../../../../../../services/business/order/stockDamage');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_damage.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('置损单 id')
  },
};

exports.handler = async ({ params }) => {
  return await ODStockDamage.retry({
    id: params.id,
  });
};
