const Joi = require('koa-joi-router').Joi;
const ODStockDamage = require('../../../../../../services/business/order/stockDamage');
const BadRequestError = require('../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.od.stock_damage.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.object()).description('车辆'),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};

exports.handler = async ({ body, ctx }) => {
  const {stationId} = ctx.state.user;
  if(!stationId) throw new BadRequestError('当前账户未管理任何仓库,无法操作');
  return await ODStockDamage.check({
    stocks: body.stocks,
    station: stationId
  });
};
