const Joi = require('koa-joi-router').Joi;
const ODStockDamage = require('../../../../../services/business/order/stockDamage');

exports.permissions = ['admin.od.stock_damage.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.string()).description('车辆')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockDamage.create({
    station: ctx.state.user.stationId,
    storeManager: ctx.state.user.id,
    stocks: body.stocks
  });
};
