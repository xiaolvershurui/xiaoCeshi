const Joi = require('koa-joi-router').Joi;
const ODStockPutOn = require('../../../../../services/database/order/stockPutOn');
const ODStockPullBack = require('../../../../../services/database/order/stockPullBack');

exports.permissions = ['admin.od.stock_put_on.get'];

exports.validate = {
  query: {
    region: Joi.string().required(),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ query }) => {
  // 获取车辆出库数
  const putOns = await ODStockPutOn.find({
    query: {
      finishedAt: {
        $gte: 'today'.beginning,
        $lt: 'today'.ending,
      },
      region: query.region,
    },
    limit: 0,
    sort: { _id: -1 },
    selector: 'putOnSuccess',
  });
  const putOnCount = putOns.reduce((memo, item) => {
    memo += item.putOnSuccess.length;
    return memo;
  }, 0);

  // 获取车辆入库数
  const pullBacks = await ODStockPullBack.find({
    query: {
      finishedAt: {
        $gte: 'today'.beginning,
        $lt: 'today'.ending,
      },
      region: query.region,
    },
    limit: 0,
    sort: { _id: -1 },
    selector: 'pullBackSuccess',
  });
  const pullBackCount = pullBacks.reduce((memo, item) => {
    memo += item.pullBackSuccess.length;
    return memo;
  }, 0);


  if (putOnCount && pullBackCount) {
    return {
      date: 'today'.beginning,
      rate: parseFloat((putOnCount / pullBackCount).toFixed(4))
    };
  } else {
    return {
      date: 'today'.beginning,
      rate: 0,
    };
  }
};
