const Joi = require('koa-joi-router').Joi;
const ODStockPutOn = require('../../../../../../services/business/order/stockPutOn');

exports.permissions = ['admin.od.stock_put_on.post'];

exports.validate = {
  type: 'json',
  body: {
    stocks: Joi.array().items(Joi.object()).description('车辆')
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    }
  }
};

exports.handler = async ({ body }) => {
  return await ODStockPutOn.check({
    stocks: body.stocks
  });
};
