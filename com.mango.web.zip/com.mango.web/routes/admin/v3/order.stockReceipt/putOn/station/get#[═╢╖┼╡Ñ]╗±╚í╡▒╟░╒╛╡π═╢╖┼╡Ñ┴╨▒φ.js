const Joi = require('koa-joi-router').Joi;
const ODStockPutOn = require('../../../../../../services/database/order/stockPutOn');
const odStockPutOnValidator = require('../../../../../../com.mango.common/validators').od_stock_put_on;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_put_on.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(Joi.object()),
        count: Joi.number().description('条目数'),
      }),
    },
  },
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODStockPutOn.find(Object.assign(query, { station: ctx.state.user.stationId }));
  const count = await ODStockPutOn.count({
    query: {
      station: ctx.state.user.stationId,
    },
  });
  return { items, count };
};
