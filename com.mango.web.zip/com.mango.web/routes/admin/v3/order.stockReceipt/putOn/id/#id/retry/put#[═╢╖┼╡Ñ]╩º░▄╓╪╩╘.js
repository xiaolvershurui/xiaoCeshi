const Joi = require('koa-joi-router').Joi;
const ODStockPutOn = require('../../../../../../../../services/business/order/stockPutOn');
const odStockPutOnValidator = require('../../../../../../../../com.mango.common/validators/index').od_stock_put_on;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.stock_put_on.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odStockPutOnValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODStockPutOn.retry({
    id: params.id
  })
};
