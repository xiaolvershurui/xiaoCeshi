const Joi = require('koa-joi-router').Joi;
const ODStockPutOn = require('../../../../../services/business/order/stockPutOn');

exports.permissions = ['admin.od.stock_put_on.post'];

exports.validate = {
  type: 'json',
  body: {
    driver: Joi.string().required().description('司机'),
    stocks: Joi.array().items(Joi.string()).description('车辆')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODStockPutOn.create({
    station: ctx.state.user.stationId,
    storeManager: ctx.state.user.id,
    driver: body.driver,
    stocks: body.stocks
  });
};
