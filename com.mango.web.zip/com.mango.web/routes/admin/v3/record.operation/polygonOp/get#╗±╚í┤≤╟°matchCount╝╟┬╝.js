const Joi = require('koa-joi-router').Joi;
const RCPolygonOp = require('../../../../../services/database/record/polygonOp');
const rcPolygonOpValidator = require('../../../../../com.mango.common/validators/index').rc_polygon_op;
exports.permissions = ['admin.rc.polygon_op.getMany'];
exports.validate = {
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      user: Joi.string().allow(null).description('大区'),
      polygon: Joi.string().allow(null).description('仓库'),
    }).empty('').description('连表选项')
  },
  output: {
    200: {
      body: Joi.array().items(rcPolygonOpValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  return await RCPolygonOp.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};