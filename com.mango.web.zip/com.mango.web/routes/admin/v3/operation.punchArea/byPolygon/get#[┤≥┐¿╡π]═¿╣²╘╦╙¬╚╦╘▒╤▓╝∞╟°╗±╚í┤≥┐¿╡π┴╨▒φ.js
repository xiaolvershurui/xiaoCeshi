const OPPunchArea = require('../../../../../services/database/operation/punchArea');
const ACOperator = require('../../../../../services/database/account/operator');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');
const opPunchAreaValidator = require('../../../../../com.mango.common/validators/index').op_punch_area;
const NotFoundError = require('../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.punch_area.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.array().items(opPunchAreaValidator),
    },
  },
};
exports.handler = async ({ query, ctx }) => {
  const operator = await ACOperator.findByUser({
    user: ctx.state.user.id,
    selector: 'inspectionAreas distributePunchArea',
  });
  if (!operator) throw new NotFoundError('运营人员不存在');
  if (operator.distributePunchArea) {
    Object.assign(query.query, {
      enable: true,
      polygon: {
        $in: operator.inspectionAreas.map(item => item._id),
      },
    });
    return await OPPunchArea.find(query);
  }
};
