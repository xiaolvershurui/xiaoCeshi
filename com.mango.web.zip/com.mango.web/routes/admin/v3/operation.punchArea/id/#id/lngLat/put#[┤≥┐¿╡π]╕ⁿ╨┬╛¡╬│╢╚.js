const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPunchArea = require('../../../../../../../services/database/operation/punchArea');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.punch_area.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('打卡点 Id'),
  },
  type: 'json',
  body: {
    polygon: Joi.string().empty('').description('巡检区 id'),
    lngLat: validators.location.required().description('经纬度'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body }) => {
  const punchArea = await OPPunchArea.findById({
    id: params.id,
  });
  if (!punchArea) throw new NotFoundError(`打卡点${params.id}不存在`);
  // let data = {};
  // if (body.polygon) {
  //   data = {
  //     polygon: body.polygon,
  //     'location.lngLat': body.location
  //   };
  // } else {
  //   data = {
  //     polygon: null,
  //
  //   };
  // }
  return await OPPunchArea.update({
    id: params.id,
    data: {
      'location.lngLat': body.lngLat
    },
  });
};
