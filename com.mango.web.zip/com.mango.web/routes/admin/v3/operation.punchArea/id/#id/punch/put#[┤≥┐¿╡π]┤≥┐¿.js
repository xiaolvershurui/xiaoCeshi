const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPunchArea = require('../../../../../../../services/business/operation/punchArea');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.punch_area.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('打卡点 Id'),
  },
  type: 'json',
  body: {
    remark: Joi.string().empty('').description('打卡备注'),
    photo: Joi.string().empty('').description('打卡图片'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body, ctx }) => {
  return await OPPunchArea.punch({
    id: params.id,
    puncher: ctx.state.user.id,
    remark: body.remark,
    photo: body.photo,
  });
};
