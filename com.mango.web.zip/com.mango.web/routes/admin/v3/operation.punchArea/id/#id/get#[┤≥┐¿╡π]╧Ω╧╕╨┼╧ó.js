const OPPunchArea = require('../../../../../../services/database/operation/punchArea');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const opPunchAreaValidator = require('../../../../../../com.mango.common/validators/index').op_punch_area;

exports.permissions = ['admin.op.punch_area.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('打卡点 id'),
  },
  query: validators.findOne,
  output: {
    200: {
      body: opPunchAreaValidator,
    },
  },
};
exports.handler = async ({ params, query }) => {
  return await OPPunchArea.findById(Object.assign(query, {
    id: params.id,
  }));
};
