const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPunchArea = require('../../../../../../../services/database/operation/punchArea');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');
const BadRequestError = require('../../../../../../../com.mango.common/errors/BadRequestError');

exports.permissions = ['admin.op.punch_area.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('打卡点 Id'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};

exports.handler = async ({ params, body }) => {
  const punchArea = await OPPunchArea.findById({
    id: params.id,
    selector: 'name needPunch'
  });
  if (!punchArea) throw new NotFoundError(`打卡点${params.id}不存在`);
  if (punchArea.needPunch) throw new BadRequestError(`打卡点${punchArea.name}未打卡，无需重置`);
  return await OPPunchArea.update({
    id: params.id,
    data: {
      needPunch: true,
      punchInfo: null
    },
  });
};
