const OPPunchArea = require('../../../../services/database/operation/punchArea');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const opPunchAreaValidator = require('../../../../com.mango.common/validators/index').op_punch_area;

exports.permissions = ['admin.op.punch_area.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(opPunchAreaValidator)
    }
  }
};
exports.handler = async ({ query }) => {
  Object.assign(query.query, {
    enable: true
  });
  const items = await OPPunchArea.find(query);
  const count = await OPPunchArea.count({
    query: query.query
  });
  return { items, count };
};