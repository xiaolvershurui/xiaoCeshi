const OPPunchArea = require('../../../../../../../services/database/operation/punchArea');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.punch_area.get'];

exports.validate = {
  params: {
    region: validators.id.required().description('大区 id')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};
exports.handler = async ({ params }) => {
  const punched = await OPPunchArea.count({
    region: params.region,
    needPunch: false,
    enable: true
  });
  const unPunch = await OPPunchArea.count({
    region: params.region,
    needPunch: true,
    enable: true
  });
  const punchedRate = (punched + unPunch) ? ((punched / (punched + unPunch)) * 100).toFixed(2) + '%' : '0%';
  return {
    punched,
    unPunch,
    punchedRate
  };
};
