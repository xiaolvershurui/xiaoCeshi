const OPPunchArea = require('../../../../services/database/operation/punchArea');
const OPRegion = require('../../../../services/database/operation/region');
const OPPolygon = require('../../../../services/database/operation/polygon');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const opPunchAreaValidator = require('../../../../com.mango.common/validators/index').op_punch_area;
const NotFoundError = require('../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.punch_area.post'];

exports.validate = {
  type: 'json',
  body: {
    region: Joi.string().required().description('大区 ref'),
    polygon: Joi.string().description('巡检区 ref'),
    name: Joi.string().required().description('打卡点名称'),
    lngLat: validators.location.required().description('经纬度'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body, ctx }) => {
  const region = await OPRegion.findById({
    id: body.region,
    selector: 'name'
  });
  if (!region) throw new NotFoundError(`大区${body.region}不存在`);
  if (body.polygon) {
    const polygon = await OPPolygon.findById({
      id: body.polygon,
    });
    if (!polygon) throw new NotFoundError(`所选巡检区${body.polygon}不存在`);
  }
  const finalBody = Object.assign({}, {
    creator: ctx.state.user.id,
  }, {
    region: region._id,
    regionName: region.name,
    polygon: body.polygon,
    name: body.name,
    location: {
      lngLat: body.lngLat,
    },
  });
  return await OPPunchArea.create(finalBody);
};

