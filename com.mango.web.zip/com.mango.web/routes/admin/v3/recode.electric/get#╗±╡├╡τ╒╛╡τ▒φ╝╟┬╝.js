const RCElectric = require('../../../../services/database/record/electric');
const Joi = require('koa-joi-router').Joi;
const RCElectricValidators = require('../../../../com.mango.common/validators/index').rc_electric;

exports.permissions = ['admin.rc.electric.getMany'];
exports.validate = {
  query: {
    query: Joi.object(),
    limit: Joi.number(),
    skip: Joi.number(),
    sort: Joi.object(),
    selector: Joi.string().empty(''),
    populateSelector: Joi.object({
      station: Joi.string().empty(''),
      operator: Joi.string().empty('')
    }).empty('').description('联表选项')
  }
};

exports.out = Joi.array().items(RCElectricValidators);

exports.handler = async ({ query }) => {
  return await RCElectric.find(query);
};
