const OPPolygon = require('../../../../services/database/operation/polygon');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const opPolygonvalidator = require('../../../../com.mango.common/validators/index').op_polygon;

exports.permissions = ['admin.op.polygon.post'];

exports.validate = {
  type: 'json',
  body: {
    enable: Joi.boolean().description('启用状态'),
    name: Joi.string().description('区域名称'),
    type: Joi.number().default(constants.OP_POLYGON_TYPE.无类型).valid(constants.OP_POLYGON_TYPE_ENUMS).description('区域类型'),
    neighborhood: Joi.number().default(constants.OP_POLYGON_NEIGHBORHOOD.无类型).valid(constants.OP_POLYGON_NEIGHBORHOOD_ENUMS).description('区域社区类型'),
    city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('所在城市'),
    area: Joi.string().required().description('所在行政区'),
    address: Joi.string().empty('').description('街道地址'),
    lngLat: validators.location.required().description('经纬度'),
    path: Joi.array().items(Joi.object()).required().description('区域围栏')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(opPolygonvalidator),
        count: Joi.number().description('返回条目数')
      })
    }
  }
};
exports.handler = async ({ body, ctx }) => {
  return await OPPolygon.create(Object.assign({
    creator: ctx.state.user.id,
  }, body));
};