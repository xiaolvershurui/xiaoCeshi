const OPPolygon = require('../../../../services/database/operation/polygon');
const validators = require('../../../../com.mango.common/settings/validators');
const opPolygonValidator = require('../../../../com.mango.common/validators/index').op_polygon;

exports.permissions = ['admin.op.polygon.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(opPolygonValidator),
    },
  },
};
exports.handler = async ({ query }) => {
  const items = await OPPolygon.find(query);
  const count = await  OPPolygon.count({
    query: query.query,
  });
  return { items, count };
};
