const OPPolygon = require('../../../../../services/business/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.get'];

exports.validate = {
  query :{
    query: Joi.object().default({}).description('查询条件'),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ query }) => {
 // TODO: 聚合统计操作
};