const OPPolygon = require('../../../../../services/database/operation/polygon');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.getMany'];

exports.validate = {
  query: {
    sw: validators.location.required(),
    ne: validators.location.required(),
    query: Joi.object(),
    selector: validators.selector,
    populateSelector: Joi.object({
      creator: validators.selector,
      reviewer: validators.selector,
    }).allow(null),
    cache: validators.cache
  },
  // TODO: output
};

exports.handler = async ({ query }) => {
  return await OPPolygon.findInBox(query);
};