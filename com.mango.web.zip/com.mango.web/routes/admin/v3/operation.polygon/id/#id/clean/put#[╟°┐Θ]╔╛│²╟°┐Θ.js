const OPPolygon = require('../../../../../../../services/business/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.delete'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  return await OPPolygon.cleanPolygon({
    user: ctx.state.user.id,
    id: params.id
  })
};
