const OPPolygon = require('../../../../../../services/database/operation/polygon');
const BKStock = require('../../../../../../services/database/ebike/stock');
const Joi = require('joi');
const constants = require('../../../../../../com.mango.common/settings/constants');
const opPolygonValidator = require('../../../../../../com.mango.common/validators/index').op_polygon;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  query: {
    selector: Joi.string().description('返回对象'),
    populateSelector: Joi.object({
      'creator': Joi.string(),
      'reviewer': Joi.string()
    }).default({}).description('连表选项')
  },
  output: {
    200: {
      body: opPolygonValidator
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await OPPolygon.findById({
    id: params.id,
    populateSelector: query.populateSelector,
    selector: query.selector
  });
};