const OPPolygon = require('../../../../../../../services/business/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    state: Joi.number().required().valid(constants.OP_POLYGON_STATE_ENUMS).description('区块状态'),
    proposedChanges: Joi.string().empty('').description('修改建议'),
    reworkReasons: Joi.array().items(Joi.number().valid(constants.OP_POLYGON_REWORK_REASON_ENUMS)).description('返工原因列表')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({params,body,ctx}) => {
  const rework = body.state === constants.OP_POLYGON_STATE.返工;
  return await OPPolygon.updateInfo({
    id: params.id,
    data: {
      state,
      proposedChanges: rework ? proposedChanges : null,
      reworkReasons: rework ? reworkReasons : [],
      reviewer: ctx.state.user.id,
    }
  })
};