const OPPolygon = require('../../../../../../../services/business/operation/polygon');
const OPPolygonDataBase = require('../../../../../../../services/database/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.put'];
exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  await OPPolygon.resetMatchCount({
    id: params.id,
    operator: ctx.state.user.id
  });
  return await OPPolygonDataBase.findById({
    id: params.id,
    selector: '',
    populateSelector: {
      reviewer: 'auth.tel cert.name',
      creator: 'auth.tel cert.name'
    }
  })
};