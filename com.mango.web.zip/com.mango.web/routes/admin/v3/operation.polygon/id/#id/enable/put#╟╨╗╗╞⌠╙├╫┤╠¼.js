const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPolygon = require('../../../../../../../services/business/operation/polygon');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    enable: Joi.boolean().required().description('启用禁用状态')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({params,body}) => {
  return await OPPolygon.updateEnable({
    id: params.id,
    data:{
      enable: body.enable
    }
  })
};