const OPPolygon = require('../../../../../../services/business/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    enable: Joi.boolean().empty('').description('启用状态'),
    name: Joi.string().empty('').description('区域名称'),
    type: Joi.number().empty('').description('区域类型'),
    neighborhood: Joi.number().empty('').description('区域社区类型'),
    location: Joi.object({
      city: Joi.string().description('所在城市'),
      area: Joi.string().description('所在行政区'),
      address: Joi.string().description('街道地址'),
      lngLat: validators.location.description('经纬度'),
    }).empty(''),
    path: Joi.array().items(Joi.object()).description('区域围栏')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({ params,body }) => {

  return await OPPolygon.updateInfo({
    id: params.id,
    data:{
      enable: body.enable,
      name: body.name,
      type: body.type,
      neighborhood: body.neighborhood,
      location: body.location,
      path: body.path
    }
  });
};
