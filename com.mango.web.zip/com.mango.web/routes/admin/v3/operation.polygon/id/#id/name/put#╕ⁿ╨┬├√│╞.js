const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPolygon = require('../../../../../../../services/business/operation/polygon');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    name: Joi.string().required().description('名称')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({params,body}) => {
  return await OPPolygon.updateInfo({
    id: params.id,
    data: {
      name: body.name
    }
  });
};