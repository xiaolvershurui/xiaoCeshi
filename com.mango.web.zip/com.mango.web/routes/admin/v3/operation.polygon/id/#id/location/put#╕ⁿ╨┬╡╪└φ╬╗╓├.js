const Joi = require('poolishark').Joi;
const validators = require('../../../../../../../com.mango.common/settings/validators');
const OPPolygon = require('../../../../../../../services/business/operation/polygon');
const constants = require('../../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    location: Joi.object({
      city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('所在城市'),
      area: Joi.string().required().description('所在行政区'),
      address: Joi.string().empty('').description('街道地址'),
      lngLat: validators.location.required().description('经纬度'),
    }).description('位置')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({params,body}) => {
  return await OPPolygon.updateInfo({
    id: params.id,
    data: {
      location: body.location
    }
  });
};