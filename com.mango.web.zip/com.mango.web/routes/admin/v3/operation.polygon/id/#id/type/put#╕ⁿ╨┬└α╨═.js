const OPPolygon = require('../../../../../../../services/business/operation/polygon');
const Joi = require('joi');
const constants = require('../../../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.op.polygon.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('Polygon Id')
  },
  type: 'json',
  body:{
    type: Joi.number().default(constants.OP_POLYGON_TYPE.无类型).valid(constants.OP_POLYGON_TYPE_ENUMS).description('区域类型')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.object()})
    }
  }
};

exports.handler = async ({params,body}) => {
  return await OPPolygon.updateInfo({
    id: params.id,
    data: {
      type: body.type
    }
  })
};