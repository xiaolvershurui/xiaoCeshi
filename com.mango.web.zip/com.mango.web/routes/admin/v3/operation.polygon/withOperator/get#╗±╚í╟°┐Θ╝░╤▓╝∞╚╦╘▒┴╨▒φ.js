const OPPolygon = require('../../../../../services/database/operation/polygon');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');
const opPolygonvalidators = require('../../../../../com.mango.common/validators/index').op_polygon;

exports.permissions = ['admin.op.polygon.getMany'];

exports.validate = {
  query: {
    query: Joi.object().default({}).description('搜索条件'),
    limit: Joi.number().default(constants.PAGE_SIZE).description('限制返回数量'),
    sort: Joi.object().default({}).description('排序选项'),
    skip: Joi.number().default(0).description('跳过条目数'),
    selector: Joi.string().description('返回字段')
  },
  output: {
    200: {
      body: opPolygonvalidators
    }
  }
};
exports.handler = async ({ query }) => {
  // TODO
};