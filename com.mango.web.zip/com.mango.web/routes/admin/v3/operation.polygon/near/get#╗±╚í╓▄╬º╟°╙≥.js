const OPPolygon = require('../../../../../services/database/operation/polygon');
const Joi = require('koa-joi-router').Joi;
const validators = require('../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../com.mango.common/settings/constants');
const opPolygonvalidator = require('../../../../../com.mango.common/validators/index').op_polygon;

exports.permissions = ['admin.op.polygon.getMany'];

exports.validate = {
  query: {
    query: Joi.object().default({}).description('搜索条件'),
    center: validators.location.required().description('搜索中心点'),
    radius: Joi.number().default(constants.POLYGON_SEARCH_RADIUS_ADMIN).min(0).description('polygon 搜索半径'),
    limit: Joi.number().default(10000).description('限制返回数量'),
    selector: Joi.string().description('返回字段')
  },
  output: {
    200: {
      body: opPolygonvalidator
    }
  }
};
exports.handler = async ({ query }) => {
  return await OPPolygon.findNear({
    query: query.query,
    center: query.center,
    searchRadius: query.radius,
    limit: query.limit,
    selector: query.selector
  });
};