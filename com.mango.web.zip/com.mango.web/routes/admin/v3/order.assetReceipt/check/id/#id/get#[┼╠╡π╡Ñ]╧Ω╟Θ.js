const Joi = require('koa-joi-router').Joi;
const ODAssetCheck = require('../../../../../../../services/database/order/assetCheck');
const odAssetCheckValidator = require('../../../../../../../com.mango.common/validators/index').od_asset_check;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_check.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object({
      'submitter': Joi.string(),
      'user': Joi.string(),
      'fixedUser': Joi.string(),
      'region': Joi.string(),
      'station': Joi.string(),
      'assets.id': Joi.string(),
    }).description('联查字段')
  },
  output: {
    200: {
      body: odAssetCheckValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODAssetCheck.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
