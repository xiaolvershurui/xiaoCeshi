const Joi = require('koa-joi-router').Joi;
const ODAssetCheck = require('../../../../../../../services/business/order/assetCheck');
const odAssetCheckValidator = require('../../../../../../../com.mango.common/validators/index').od_asset_check;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_check.put'];

exports.validate = {
  type: 'json',
  body: {
    assets: Joi.array().items(Joi.object({
      code: Joi.string().description('物料二维码'),
      actualDamageCount: Joi.number().description('盘点损坏数量'),
      actualIntactCount: Joi.number().description('盘点完好数量'),
    })).description('盘点零件')
  },
  params:{
    id: validators.id.required().description('ODAssetCheck Id')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()}),
    }
  }
};

exports.handler = async ({ params, body ,ctx }) => {
  return await ODAssetCheck.finish({
    id: params.id,
    operator: ctx.state.user.id,
    assets: body.assets
  })
};
