const Joi = require('koa-joi-router').Joi;
const ODAssetCheck = require('../../../../../../../../services/business/order/assetCheck');
const odAssetCheckValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_check;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_check.put'];

exports.validate = {
  params:{
    id: validators.id.required().description('ODAssetCheck Id')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()}),
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODAssetCheck.retry({
    id: params.id
  })
};
