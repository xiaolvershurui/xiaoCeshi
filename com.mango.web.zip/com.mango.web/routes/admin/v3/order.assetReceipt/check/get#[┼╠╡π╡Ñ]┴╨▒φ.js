const Joi = require('koa-joi-router').Joi;
const ODAssetCheck = require('../../../../../services/database/order/assetCheck');
const odAssetCheckValidator = require('../../../../../com.mango.common/validators').od_asset_check;

exports.permissions = ['admin.od.asset_check.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'submitter': Joi.string().allow(''),
      'fixedUser': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow('')
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetCheckValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODAssetCheck.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetCheck.count({
    query: query.query
  });
  return { items, count };
};
