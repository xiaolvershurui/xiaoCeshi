const Joi = require('koa-joi-router').Joi;
const ODAssetCheck = require('../../../../../services/business/order/assetCheck');
const validators = require('../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.od.asset_check.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {},
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODAssetCheck.create({
    user: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    station: ctx.state.user.stationId,
  });
};
