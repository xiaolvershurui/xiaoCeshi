const Joi = require('koa-joi-router').Joi;
const ODAssetDispatch = require('../../../../../../../../services/business/order/assetDispatch');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_dispatch.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('assetDispatch Id')
  },
  type: 'json',
  body:{
    endAssets: Joi.array().items({
      id: Joi.string().required().description('Asset Id'),
      code: Joi.string().required().description('Code'),
      endIntactCount: Joi.number().required().description('接收完整数量'),
      endBadCount: Joi.number().required().description('接收损坏订单数量')
    }).required().description('接收配件单')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  await ODAssetDispatch.endDispatchOrder({
    receiver: ctx.state.user.id,
    id: params.id,
    endAssets: body.endAssets
  });
};
