const Joi = require('koa-joi-router').Joi;
const ODAssetDispatch = require('../../../../../../../../services/business/order/assetDispatch');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_dispatch.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('assetDispatch Id')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  await ODAssetDispatch.retry({
    id: params.id,
    operator: ctx.state.user.id
  })
};
