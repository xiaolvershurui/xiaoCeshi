const Joi = require('koa-joi-router').Joi;
const ODAssetDispatch = require('../../../../../../../../services/database/order/assetDispatch');
const odAssetDispatchValidator = require('../../../../../../../../com.mango.common/validators').od_asset_dispatch;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_dispatch.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('assetDispatch Id')
  },
  query: {
    selector: Joi.string().empty('').default('_id').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'dispenser': Joi.string().allow(''),
      'receiver': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'startStation': Joi.string().allow(''),
      'endStation': Joi.string().allow(''),
    }).unknown().description('连表选项'),
  },
  output: {
    200: {
      body: odAssetDispatchValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODAssetDispatch.findInStartStation({
    id: params.id,
    startStation: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
