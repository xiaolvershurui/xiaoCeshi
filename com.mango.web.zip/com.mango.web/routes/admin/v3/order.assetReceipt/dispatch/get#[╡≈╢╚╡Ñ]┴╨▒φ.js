const Joi = require('koa-joi-router').Joi;
const ODAssetDispatch = require('../../../../../services/database/order/assetDispatch');
const odAssetDispatchValidator = require('../../../../../com.mango.common/validators').od_asset_dispatch;

exports.permissions = ['admin.od.asset_dispatch.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').default('_id').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'dispenser': Joi.string().allow(''),
      'receiver': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'startStation': Joi.string().allow(''),
      'endStation': Joi.string().allow(''),
    }).unknown().description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetDispatchValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODAssetDispatch.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetDispatch.count({
    query: query.query
  });
  return { items, count };
};
