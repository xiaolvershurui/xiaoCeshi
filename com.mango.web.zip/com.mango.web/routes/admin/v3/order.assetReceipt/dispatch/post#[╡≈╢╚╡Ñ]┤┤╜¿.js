const Joi = require('koa-joi-router').Joi;
const ODAssetDispatch = require('../../../../../services/business/order/assetDispatch');
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_dispatch.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    endStation: validators.id.description('Station Id'),
    assets: Joi.array().items(Joi.object({
      code: Joi.string().required().description('标识码'),
      startIntactCount: Joi.number().required().description('调度完好数目'),
      startBadCount: Joi.number().required().description('调度损坏数目')
    }))
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ query, body, ctx }) => {
  return await ODAssetDispatch.createDispatchOrder({
    dispenser: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    startStation: ctx.state.user.stationId,
    endStation: body.endStation,
    assets: body.assets
  });
};
