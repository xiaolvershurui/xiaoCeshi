const Joi = require('koa-joi-router').Joi;
const ODAssetScrap = require('../../../../../services/business/order/assetScrap');

exports.permissions = ['admin.od.asset_scrap.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    assets: Joi.array().items({
      code: Joi.string().required().description('Code'),
      intactCount: Joi.number().required().description('完好报废'),
      damageCount: Joi.number().required().description('残次报废')
    }).description('报废物料信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODAssetScrap.creatScrapOrder({
    dispenser: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    station: ctx.state.user.stationId,
    assets: body.assets
  });
};
