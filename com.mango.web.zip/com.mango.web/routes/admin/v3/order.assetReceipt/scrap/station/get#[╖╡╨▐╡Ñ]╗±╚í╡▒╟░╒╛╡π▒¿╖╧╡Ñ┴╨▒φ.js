const Joi = require('koa-joi-router').Joi;
const ODAssetScrap = require('../../../../../../services/database/order/assetScrap');
const odAssetScrapValidator = require('../../../../../../com.mango.common/validators').od_asset_scrap;

exports.permissions = ['admin.od.asset_scrap.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'dispenser': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetScrapValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODAssetScrap.find({
    query: {
      station: ctx.state.user.stationId
    },
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetScrap.count({
    query: {
      station: ctx.state.user.stationId
    }
  });
  return { items, count };
};
