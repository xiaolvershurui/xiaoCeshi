const Joi = require('koa-joi-router').Joi;
const ODAssetScrap = require('../../../../../../../../services/database/order/assetScrap');
const odAssetScrapValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_scrap;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_scrap.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODAssetScrap Id')
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object({
      'dispenser': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
      'assets.id': Joi.string().allow('')
    })
  },
  output: {
    200: {
      body: odAssetScrapValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODAssetScrap.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
