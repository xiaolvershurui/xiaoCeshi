const Joi = require('koa-joi-router').Joi;
const ODAssetScrap = require('../../../../../../../services/database/order/assetScrap');
const odAssetScrapValidator = require('../../../../../../../com.mango.common/validators/index').od_asset_scrap;
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_check.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odAssetScrapValidator,
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODAssetScrap.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
