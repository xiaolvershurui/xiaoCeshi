const Joi = require('koa-joi-router').Joi;
const ODAssetScrap = require('../../../../../../../../services/business/order/assetScrap');
const odAssetScrapValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_scrap;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_scrap.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odAssetScrapValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODAssetScrap.retry({
    id: params.id
  })
};
