const Joi = require('koa-joi-router').Joi;
const ODAssetPurchase = require('../../../../../services/database/order/assetPurchase');
const odAssetPurchaseValidator = require('../../../../../com.mango.common/validators').od_asset_purchase;
const validators = require('../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_purchase.getMany'];

exports.validate = {
  params: {},
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetPurchaseValidator),
        count: Joi.number().description('总条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODAssetPurchase.find(query);
  const count = await ODAssetPurchase.count({
    query: query.query
  });
  return { items, count };
};
