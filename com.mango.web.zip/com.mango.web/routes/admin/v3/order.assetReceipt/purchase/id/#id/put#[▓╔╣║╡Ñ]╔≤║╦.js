const Joi = require('koa-joi-router').Joi;
const ODAssetPurchase = require('../../../../../../../services/business/order/assetPurchase');
const validators = require('../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_purchase.put'];

exports.validate = {
  params: {
    id: validators.id,
  },
  type: 'json',
  body: {
    status: Joi.number().required().description('采购单状态')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  await ODAssetPurchase.auditing({
    id: params.id,
    auditor : ctx.state.user.id,
    status: body.status
  })
};
