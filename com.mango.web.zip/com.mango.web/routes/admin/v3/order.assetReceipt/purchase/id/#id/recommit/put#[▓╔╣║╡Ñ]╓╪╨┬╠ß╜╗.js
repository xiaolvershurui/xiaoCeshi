const Joi = require('koa-joi-router').Joi;
const ODAssetPurchase = require('../../../../../../../../services/business/order/assetPurchase');
// const odAssetPurchaseValidator = require('../../../../../../../../com.mango.common/validators').od_asset_purchase;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_purchase.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  type: 'json',
  body: {
    supplier: Joi.string().required().description('供应商 ref'),
    contractFile: Joi.string().description('合同文件'),
    assets: Joi.array().items(Joi.object({
      id: Joi.string().required().description('配件 ref').error(new Error('配件不正确')),
      specification: Joi.string().required().description('规格').error(new Error('规格不正确')),
      count: Joi.number().required().description('数量').error(new Error('数量不正确')),
      price: Joi.number().required().description('单价').error(new Error('价格不正确')),
      style: Joi.string().required().description('适用车型 ref').error(new Error('车型不正确')),
    }).unknown().required().description('采购信息'))
  },
  output: {
    200: {
      body: Joi.object({}),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODAssetPurchase.update({
    id : params.id,
    user: ctx.state.user.id,
    supplier: body.supplier,
    contractFile: body.contractFile,
    assets: body.assets
  })
};
