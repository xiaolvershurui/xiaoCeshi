const Joi = require('koa-joi-router').Joi;
const ODAssetInbound = require('../../../../../../../../services/business/order/assetInbound');
const odAssetInboundValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_inbound;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_inbound.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odAssetInboundValidator,
    }
  }
};

exports.handler = async ({ params }) => {
  return await ODAssetInbound.retry({
    id: params.id
  })
};
