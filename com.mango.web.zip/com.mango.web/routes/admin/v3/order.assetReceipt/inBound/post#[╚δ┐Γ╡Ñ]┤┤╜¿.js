const Joi = require('koa-joi-router').Joi;
const ODAssetInbound = require('../../../../../services/business/order/assetInbound');

exports.permissions = ['admin.od.asset_inbound.post'];

exports.validate = {
  params: {},
  query: {},
  type: 'json',
  body: {
    assets: Joi.array().items({
      code: Joi.string().required().description('Code'),
      count: Joi.number().required().description('数量'),
      unitCost: Joi.number().description('单价')
    }).description('入库物料信息')
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODAssetInbound.createInboundOrder({
    user: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    station: ctx.state.user.stationId,
    assets: body.assets
  });
};
