const Joi = require('koa-joi-router').Joi;
const ODAssetInbound = require('../../../../../../../../services/database/order/assetInbound');
const odAssetInboundValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_inbound;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_inbound.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odAssetInboundValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODAssetInbound.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
