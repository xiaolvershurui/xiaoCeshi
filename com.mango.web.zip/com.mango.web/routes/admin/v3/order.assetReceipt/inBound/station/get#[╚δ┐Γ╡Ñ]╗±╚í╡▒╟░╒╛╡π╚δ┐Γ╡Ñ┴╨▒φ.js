const Joi = require('koa-joi-router').Joi;
const ODAssetInbound = require('../../../../../../services/database/order/assetInbound');
const odAssetInboundValidator = require('../../../../../../com.mango.common/validators').od_asset_inbound;

exports.permissions = ['admin.od.asset_inbound.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().default({}).description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow('')
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetInboundValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODAssetInbound.find({
    query: {
      station: ctx.state.user.stationId
    },
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetInbound.count({
    query: {
      station: ctx.state.user.stationId
    }
  });
  return { items, count };
};
