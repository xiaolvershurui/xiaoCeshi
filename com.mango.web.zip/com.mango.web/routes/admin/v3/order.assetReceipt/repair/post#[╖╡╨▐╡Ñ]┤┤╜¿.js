const Joi = require('koa-joi-router').Joi;
const ODAssetRepair = require('../../../../../services/business/order/assetRepair');

exports.permissions = ['admin.od.asset_repair.post'];

exports.validate = {
  params: {},
  query: {},
  type:'json',
  body:{
    assets: Joi.array().items(Joi.object({
      code: Joi.string().required().description('Code'),
      outboundCount: Joi.number().required().description('损坏返修数量'),
    }))
  },
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ body, ctx }) => {
  return await ODAssetRepair.createOrder({
    dispenser: ctx.state.user.id,
    region: ctx.state.user.regionIds[0],
    station: ctx.state.user.stationId,
    assets: body.assets,
  });
};
