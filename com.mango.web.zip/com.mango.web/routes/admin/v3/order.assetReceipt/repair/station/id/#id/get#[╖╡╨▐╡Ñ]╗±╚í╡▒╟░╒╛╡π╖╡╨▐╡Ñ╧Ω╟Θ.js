const Joi = require('koa-joi-router').Joi;
const ODAssetRepair = require('../../../../../../../../services/database/order/assetRepair');
const odAssetRepairValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_repair;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_repair.get'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODAssetRepair Id')
  },
  query: {
    selector: validators.selector,
    populateSelector: Joi.object({
      'dispenser': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
      'assets.id': Joi.string().allow('')
    })
  },
  output: {
    200: {
      body: odAssetRepairValidator,
    }
  }
};

exports.handler = async ({ query, params, ctx }) => {
  return await ODAssetRepair.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};
