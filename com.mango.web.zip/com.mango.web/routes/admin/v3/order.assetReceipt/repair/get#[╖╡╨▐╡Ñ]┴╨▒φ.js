const Joi = require('koa-joi-router').Joi;
const ODAssetRepair = require('../../../../../services/database/order/assetRepair');
const odAssetRepairValidator = require('../../../../../com.mango.common/validators').od_asset_repair;

exports.permissions = ['admin.od.asset_repair.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'dispenser': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow(''),
      'records.id': Joi.string().allow(''),
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetRepairValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODAssetRepair.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetRepair.count({
    query: query.query
  });
  return { items, count };
};
