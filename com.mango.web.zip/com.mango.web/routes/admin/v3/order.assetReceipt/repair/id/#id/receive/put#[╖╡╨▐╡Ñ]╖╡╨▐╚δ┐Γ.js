const Joi = require('koa-joi-router').Joi;
const ODAssetRepair = require('../../../../../../../../services/business/order/assetRepair');
const validators = require('../../../../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.od.asset_repair.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODRepairAssets Id')
  },
  type: 'json',
  body: {
    isFinished: Joi.boolean().required(),
    assets: Joi.array().items(Joi.object({
      id: Joi.string().description('物料Id'),
      code: Joi.string().description('物料二维码'),
      damageCount: Joi.number().required().description('损坏数量'),
      intactCount: Joi.number().required().description('完整数量'),
    }))
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODAssetRepair.receiveAssets({
    id: params.id,
    receiver: ctx.state.user.id,
    isFinished: body.isFinished,
    assets: body.assets
  })
};
