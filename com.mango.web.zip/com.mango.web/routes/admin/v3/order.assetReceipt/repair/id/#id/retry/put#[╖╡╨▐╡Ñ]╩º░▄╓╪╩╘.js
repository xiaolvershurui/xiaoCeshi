const Joi = require('koa-joi-router').Joi;
const ODAssetRepair = require('../../../../../../../../services/business/order/assetRepair');
const validators = require('../../../../../../../../com.mango.common/settings/validators');
exports.permissions = ['admin.od.asset_repair.put'];

exports.validate = {
  params: {
    id: validators.id.required().description('ODRepairAssets Id')
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    }
  }
};

exports.handler = async ({ query, params }) => {
  return await ODAssetRepair.retryCreateOrder({
    id: params.id
  })
};
