const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../services/database/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../../com.mango.common/validators').od_asset_receive;
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.od.asset_receive.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().empty('').description('查询条件'),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数'),
    sort: Joi.object().description('排序条件'),
    skip: Joi.number().min(0).default(0).description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'dispenser': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow('')
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetReceiveValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query, ctx }) => {
  const items = await ODAssetReceive.find({
    query: {
      user: ctx.state.user.id
    },
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetReceive.count({
    query: {
      user: ctx.state.user.id
    }
  });
  return { items, count };
};
