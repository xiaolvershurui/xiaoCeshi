const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../../../services/database/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../../../../com.mango.common/validators').od_asset_receive;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_receive.get'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  query: {
    selector: validators.selector.description('查询器字段'),
    populateSelector: Joi.object().unknown().description('联查字段')
  },
  output: {
    200: {
      body: odAssetReceiveValidator,
    }
  }
};

exports.handler = async ({ params, query, ctx }) => {
  return await ODAssetReceive.findInStation({
    id: params.id,
    station: ctx.state.user.stationId,
    selector: query.selector,
    populateSelector: query.populateSelector
  })
};
