const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../../../services/business/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_receive;

exports.permissions = ['admin.od.asset_receive.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  output: {
    200: {
      body: odAssetReceiveValidator,
    }
  }
};

exports.handler = async ({ params, ctx }) => {
  return await ODAssetReceive.retry({
    id: params.id,
    dispenser: ctx.state.user.id
  })
};
