const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../../../services/business/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_receive;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_receive.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  type: 'json',
  body: {
    assets: Joi.array().items(Joi.object({
      code: Joi.string().required().description('Scanning Code'),
      backIntactCount: Joi.number().required().description('归还完好数量'),
      backBadCount: Joi.number().required().description('归还损坏数量'),
    }))
  },
  output: {
    200: {
      body: odAssetReceiveValidator,
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await ODAssetReceive.returnBack({
    id: params.id,
    dispenser: ctx.state.user.id,
    assets: body.assets
  })
};
