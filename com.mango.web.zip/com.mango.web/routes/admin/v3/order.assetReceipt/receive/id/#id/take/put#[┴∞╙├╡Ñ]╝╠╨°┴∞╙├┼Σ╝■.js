const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../../../services/business/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../../../../com.mango.common/validators/index').od_asset_receive;
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.od.asset_receive.put'];

exports.validate = {
  params: {
    id: Joi.string().required()
  },
  type: 'json',
  body: {
    assets: Joi.array().items(Joi.object({
      code: Joi.string().required().description('Scanning Code'),
      receiveCount: Joi.number().required().description('领取数量'),
    }))
  },
  output: {
    200: {
      body: odAssetReceiveValidator,
    }
  }
};

exports.handler = async ({ params, body, ctx}) => {
  return await ODAssetReceive.take({
    id: params.id,
    dispenser: ctx.state.user.id,
    isRetry: false,
    assets: body.assets
  })
};
