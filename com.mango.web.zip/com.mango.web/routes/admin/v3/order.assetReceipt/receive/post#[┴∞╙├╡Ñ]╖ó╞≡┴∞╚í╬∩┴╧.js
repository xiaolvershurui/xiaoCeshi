const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../services/business/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../com.mango.common/validators').od_asset_receive;

exports.permissions = ['admin.od.asset_receive.post'];

exports.validate = {
  type: 'json',
  body: {
    user: Joi.string().required().description('领用人ID'),
    assets: Joi.array().items(Joi.object({
      code: Joi.string().required().description('Scanning Code'),
      receiveCount: Joi.number().required().description('领取数量'),
    }).required())
  },
  output: {
    200: {
      body: odAssetReceiveValidator,
    }
  }
};

exports.handler = async ({ query, body, ctx }) => {
  const { regionIds, stationId } = ctx.state.user;
  return await ODAssetReceive.createAssetReceive({
    assets: body.assets,
    dispenser: ctx.state.user.id,
    user: body.user,
    region: regionIds[0],
    station: stationId,
  });
};
