const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../services/database/order/assetReceive');
const odAssetReceiveValidator = require('../../../../../com.mango.common/validators').od_asset_receive;

exports.permissions = ['admin.od.asset_receive.getMany'];

exports.validate = {
  params: {},
  query: {
    query: Joi.object().empty('').description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
    populateSelector: Joi.object({
      'user': Joi.string().allow(''),
      'dispenser': Joi.string().allow(''),
      'assets.id': Joi.string().allow(''),
      'returnSuccess.dispenser': Joi.string().allow(''),
      'returnFailed.dispenser': Joi.string().allow(''),
      'receiveSuccess.dispenser': Joi.string().allow(''),
      'receiveFailed.dispenser': Joi.string().allow(''),
      'region': Joi.string().allow(''),
      'station': Joi.string().allow('')
    }).default({}).description('连表选项'),
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(odAssetReceiveValidator),
        count: Joi.number().description('条目数')
      }),
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await ODAssetReceive.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await ODAssetReceive.count({
    query: query.query
  });
  return { items, count };
};
