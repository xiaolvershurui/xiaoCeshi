const Joi = require('koa-joi-router').Joi;
const ODAssetReceive = require('../../../../../../../services/business/order/assetReceive');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const odAssetReceiveValidator = require('../../../../../../../com.mango.common/validators/index').od_asset_receive;

exports.permissions = ['admin.od.asset_receive.get'];

exports.validate = {
  params: {
    id: validators.id
  },
  query: {
    query: Joi.object().empty('').description('查询条件'),
    limit: Joi.number().empty('').description('查询条数'),
    sort: Joi.object().empty('').description('查询条件'),
    skip: Joi.number().empty('').description('跳过条数'),
    selector: Joi.string().empty('').description('字段选择器'),
  },
  output: {
    200: {
      body: Joi.object({
        id: Joi.string().allow(''),
        isExist: Joi.boolean()
      }),
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await ODAssetReceive.findUnReturned({
    query: Object.assign({}, query.query, {
      user: params.id
    }),
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
  });
};
