const Joi = require('koa-joi-router').Joi;
const RCDivideSolution = require('../../../../../services/database/record/divideSolution');
const validators = require('../../../../../com.mango.common/settings/validators');
const exporter = require('../../../../../services/dataTrasfer/exporter');
const constants = require('../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.rc.divide_solution.getMany'];

exports.validate = {
  query: validators.findlist,
};

exports.handler = async ({ query, ctx }) => {
  const items = await RCDivideSolution.find({
    query: query.query,
    sort: query.sort,
    limit: 0,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  console.log(items[0])
  ctx.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  return await exporter(items, {
    时间: item => new Date(item.date).format('yyyyMMdd'),
    车辆编号: item => item.stock.number && item.number.custom,
    方案: item => item.solution,
    周期: item => item.period,
    新日今日收入: item => (Math.round(item.rentAmount) / 100).toFixed(2),
    今日总共收入: item => (Math.round(item.totalAmount) / 100).toFixed(2),
    是否保底: item => item.isFloor ? '是' : '否',
    是否封顶: item => item.isCapping ? '是' : '否',
    第二周期累计收入: item => item.rentAmountInPeriodTwo.toCNY(),
  }, `收入分配方案-${new Date().toNanoString()}`);
};
