const Joi = require('koa-joi-router').Joi;
const RCDivideSolution = require('../../../../services/database/record/divideSolution');
const validators = require('../../../../com.mango.common/settings/validators');
const exporter = require('../../../../services/dataTrasfer/exporter');
const constants = require('../../../../com.mango.common/settings/constants');
const divideSolutionValidator = require('../../../../com.mango.common/validators/index').rc_divide_solution;

exports.permissions = ['admin.rc.divide_solution.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: validators.tableListOutput(divideSolutionValidator),
    },
  },
};

exports.handler = async ({ query }) => {
  const items = await RCDivideSolution.find(query);
  const count = await RCDivideSolution.count({
    query: query.query,
  });
  return { items, count };
};
