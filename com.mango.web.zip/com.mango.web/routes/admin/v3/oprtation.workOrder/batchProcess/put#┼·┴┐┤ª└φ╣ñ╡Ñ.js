const OPWorkOrder = require('../../../../../services/business/operation/workOrder');
const validators = require('../../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.work_order.put'];
exports.validate = {
  type: 'json',
  body: {
    ids: Joi.array().items(Joi.string()).description('批量处理 workOrder Ids'),
    reply: Joi.string().description('给用户的回复').required(),
    reason: Joi.string().description('真实原因').required(),
  },
  output: {
    200: {
      body: Joi.object({success: Joi.array().items({_id:Joi.string()}), count: Joi.number()}),
    }
  }
};

exports.handler = async ({body, ctx}) => {
  const result = [];
  const { ids,reply,reason } = body;
  for (let id of ids ){
    await OPWorkOrder.process({
      id,
      reply: reply,
      processor: ctx.state.user.id,
      reason: reason
    });
    result.push({_id: id})
  }
  return { success: result, count: result.length }
};
