const OPWorkOrder = require('../../../../services/database/operation/workOrder');
const validators = require('../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const opWorkOrderValidator = require('../../../../com.mango.common/validators/index').op_work_order;

exports.permissions = ['admin.op.work_order.getMany'];

exports.validate = {
  query: {
    query: Joi.object().description('查询参数'),
    limit: Joi.number().description('限制条目'),
    skip: Joi.number().description('跳过条目'),
    sort: Joi.object().description('排序选项'),
    selector: Joi.string().description('返回字段'),
    poulateSelector: Joi.object({
      'processor': Joi.string(),
      'user': Joi.string(),
    })
  },
  output: {
    200: {
      body: Joi.array().items(opWorkOrderValidator),
    }
  }
};
exports.handler = async ({ query }) => {
  return await OPWorkOrder.find({
    limit: query.limit,
    skip: query.skip,
    sort: query.sort,
    selector: query.selector,
    query: query.query,
    poulateSelector: query.populateSelector
  });
};
