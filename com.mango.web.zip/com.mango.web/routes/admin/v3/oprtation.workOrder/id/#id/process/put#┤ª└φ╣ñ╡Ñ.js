const OPWorkOrder = require('../../../../../../../services/business/operation/workOrder');
const validators = require('../../../../../../../com.mango.common/settings/validators');
const Joi = require('koa-joi-router').Joi;
const constants = require('../../../../../../../com.mango.common/settings/constants');
const NotFoundError = require('../../../../../../../com.mango.common/errors/NotFoundError');

exports.permissions = ['admin.op.work_order.put'];
exports.validate = {
  params: {
    id: validators.id.required().description('workOrder Id'),
  },
  type: 'json',
  body: {
    reply: Joi.string().description('给用户的回复').required(),
    reason: Joi.string().description('真实原因').required()
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()}),
    }
  }
};

exports.handler = async ({body, params,ctx}) => {
  return await  OPWorkOrder.process({
    id: params.id,
    reply: body.reply,
    processor: ctx.state.user.id,
    reason: body.reason
  });
};
