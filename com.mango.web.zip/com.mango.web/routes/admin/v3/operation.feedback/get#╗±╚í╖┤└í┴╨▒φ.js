const Joi = require('koa-joi-router').Joi;
const OPFeedback = require('../../../../services/database/operation/feedback');
const validators = require('../../../../com.mango.common/settings/validators');
const constants = require('../../../../com.mango.common/settings/constants');
const opFeedbackValidator = require('../../../../com.mango.common/validators/index').op_feedback;

exports.permissions = ['admin.op.feedback.getMany'];

exports.validate = {
  query:{
    query: Joi.object().default({}).description('查询参数'),
    selector: Joi.string().description('返回字段'),
    limit: Joi.number().description('返回字段'),
    skip: Joi.number().description('跳过条目'),
    sort: Joi.object().description('排序选项'),
    populateSelector: Joi.object({
      'user': Joi.string(),
      'processor': Joi.string()
    }).description('连表选项')
  },
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(opFeedbackValidator),
        count: Joi.number().description('总数量')
      })
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await OPFeedback.find({
    query: query.query,
    limit: query.limit,
    sort: query.sort,
    skip: query.skip,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
  const count = await OPFeedback.count({
    query: query.query
  });
  return { items, count }
};