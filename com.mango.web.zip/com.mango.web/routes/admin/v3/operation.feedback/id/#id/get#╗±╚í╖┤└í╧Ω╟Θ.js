const Joi = require('koa-joi-router').Joi;
const OPFeedback = require('../../../../../../services/database/operation/feedback');
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');
const opFeedbackValidator = require('../../../../../../com.mango.common/validators/index').op_feedback;

exports.permissions = ['admin.op.feedback.get'];

exports.validate = {
  params:{
    id: validators.id.required().description('Feedback Id')
  },
  query:{
    selector: Joi.string(),
    populateSelector: Joi.object({
    'user': Joi.string(),
    'processor': Joi.string()
  })
  },
  output: {
    200: {
      body: opFeedbackValidator
    }
  }
};

exports.handler = async ({ params, query }) => {
  return await OPFeedback.findById({
    id: params.id,
    selector: query.selector,
    populateSelector: query.populateSelector
  });
};