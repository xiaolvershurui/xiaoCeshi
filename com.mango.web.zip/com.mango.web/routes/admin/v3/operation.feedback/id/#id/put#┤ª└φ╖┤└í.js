const Joi = require('koa-joi-router').Joi;
const OPFeedback = require('../../../../../../services/database/operation/feedback');
const validators = require('../../../../../../com.mango.common/settings/validators');
const constants = require('../../../../../../com.mango.common/settings/constants');

exports.permissions = ['admin.op.feedback.put'];

exports.validate = {
  params:{
    id: validators.id.required().description('Feedback Id')
  },
  type: 'json',
  body: {
    result: Joi.string().required().allow('').description('内部备注信息'),
    reply: Joi.string().required().allow('').description('回复用户内容')
  },
  output: {
    200: {
      body: Joi.object({_id: Joi.string()})
    }
  }
};

exports.handler = async ({ params, body, ctx }) => {
  return await OPFeedback.update({
    id: params.id,
    data: {
      result: body.result,
      reply: body.reply,
      state: constants.OP_REPORT_STATE.已处理,
      processedAt: new Date(),
      processor: ctx.state.user.id
    }
  })
};