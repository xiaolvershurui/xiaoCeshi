const Joi = require('koa-joi-router').Joi;
const OPGeoJson = require('../../../../../../services/database/operation/geojson');
const { md5 } = require('xx-utils').crypto;
const coordtransform = require('coordtransform');

exports.permissions = ['manager'];

exports.validate = {
  params: {
    id: Joi.string().required().description('区块编号'),
  },
  type: 'json',
  body: {
    checkStatus: Joi.number().description('审核结果'),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params, body }) => {
  return await OPGeoJson.update({
    id: params.id,
    data: {
      checkStatus: body.checkStatus,
    },
  });
};


