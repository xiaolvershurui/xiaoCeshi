const Joi = require('koa-joi-router').Joi;
const OPGeoJson = require('../../../../../services/database/operation/geojson');

exports.permissions = ['admin.parkingLot.op','运营组长'];


exports.validate = {
  params: {
    id: Joi.string().required().description('区块编号'),
  },
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ params }) => {
  return await OPGeoJson.remove({ id: params.id });
};


