const Joi = require('koa-joi-router').Joi;
const OPGeoJson = require('../../../../services/database/operation/geojson');
const constants = require('../../../../com.mango.common/settings/constants');
const validators = require('../../../../com.mango.common/settings/validators');
const { md5 } = require('xx-utils').crypto;
const coordtransform = require('coordtransform');

exports.permissions = ['admin.parkingLot.op','运营组长'];

const getHash = function (obj, type, encode) {
  const str = JSON.stringify(obj);
  const md5Hash = md5(str);
  const suffix = Buffer.from(str).toString('base64').slice(-10);
  return `${type}.${encode}.${md5Hash}.${suffix}`;
};

exports.validate = {
  params: {},
  type: 'json',
  body: {
    type: Joi.string().description('类型'),
    coordinates: Joi.array().items(Joi.array().items(validators.location)),
    properties: Joi.object(),
  },
  query: {},
  output: {
    200: {
      body: Joi.object(),
    },
  },
};
exports.handler = async ({ body }) => {
  const hash = getHash(body.coordinates, body.type, 'wgs84');
  return await OPGeoJson.create({
    hash,
    geometry: {
      type: body.type,
      coordinates: body.coordinates,
    },
    gcj02Geometry: {
      type: body.type,
      coordinates: [body.coordinates[0].map(lngLat => coordtransform.wgs84togcj02(lngLat[0], lngLat[1]))]
    },
    properties: body.properties,
  });
};


