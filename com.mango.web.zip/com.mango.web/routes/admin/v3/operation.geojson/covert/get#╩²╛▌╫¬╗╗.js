const Core = require('../../../../../services/core/shark');

exports.permissions = ['admin'];

exports.validate = {
  params: {},
  query: {},
};
exports.handler = async () => {
  return await Core.sendSync({
    c: 'operation/geojson/batchCovertToParkingLot.a.1',
    params: {},
  }, { timeout: 60000 });
};


