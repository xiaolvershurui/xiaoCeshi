const Joi = require('koa-joi-router').Joi;
const OPGeoJson = require('../../../../../services/database/operation/geojson');
const constants = require('../../../../../com.mango.common/settings/constants');
const validators = require('../../../../../com.mango.common/settings/validators');


exports.permissions = ['admin.parkingLot.op', '运营组长'];


exports.validate = {
  params: {},
  query: {
    boundary: Joi.array().items(validators.location),
    isGcj: Joi.boolean().default(false),
  },
  output: {
    200: {
      body: Joi.array().items(Joi.object()),
    },
  },
};
exports.handler = async ({ query }) => {
  const bottomLeft = query.boundary[0];
  const upperRight = query.boundary[1];
  return await OPGeoJson.findInBoundary({
    bottomLeft,
    upperRight,
    isGcj: query.isGcj
  });
};


