const Joi = require('koa-joi-router').Joi;
const STDetainedArea = require('../../../../services/database/setting/detainedArea');
const detainedAreaValidator = require('../../../../com.mango.common/validators/index').st_detained_area;
const validators = require('../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.detained_area.getMany'];

exports.validate = {
  query: validators.findlist,
  output: {
    200: {
      body: Joi.object({
        items: Joi.array().items(detainedAreaValidator),
        count: Joi.number().description('总页数'),
      })
    }
  }
};

exports.handler = async ({ query }) => {
  const items = await STDetainedArea.find(query);
  const count = await STDetainedArea.count({
    query: query.query
  });
  return { items, count };
};