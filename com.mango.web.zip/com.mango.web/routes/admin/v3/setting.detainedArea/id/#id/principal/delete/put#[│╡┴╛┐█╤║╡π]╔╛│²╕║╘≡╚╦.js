const Joi = require('koa-joi-router').Joi;
const STDetainedArea = require('../../../../../../../../services/business/setting/detainedArea');
const validators = require('../../../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.detained_area.put'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};
exports.handler = async ({ params, body }) => {
  await STDetainedArea.deletePrincipal({
    id: params.id
  })
};