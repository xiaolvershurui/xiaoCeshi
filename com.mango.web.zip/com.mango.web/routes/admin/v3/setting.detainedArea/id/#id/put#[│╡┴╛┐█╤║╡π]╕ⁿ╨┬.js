const Joi = require('koa-joi-router').Joi;
const STDetainedArea = require('../../../../../../services/business/setting/detainedArea');
const detainedAreaValidator = require('../../../../../../com.mango.common/validators/index').st_detained_area;
const validators = require('../../../../../../com.mango.common/settings/validators');

exports.permissions = ['admin.st.detained_area.put'];

exports.validate = {
  params: {
    id: validators.id.required()
  },
  type: 'json',
  body: {
    name: Joi.string().description('名称'),
    lngLat: Joi.array().items(Joi.number()).description('经纬度'),
    address: Joi.string().description('地址'),
    contact: Joi.string().description('联系人'),
    tel: Joi.string().description('联系方式'),
    unit: Joi.string().description('所属单位'),
  },
  output: {
    200: {
      body: Joi.object()
    }
  }
};

exports.handler = async ({ params, body }) => {
  await STDetainedArea.update({
    id: params.id,
    data: body
  })
};