const path = require('path');
exports.info = {
  title: '芒果电单车-管理端API',
  description: 'Common permissions: `super` `<METHOD> <path>`',
  version: '3.0',
  contact: {
    name: '技术支持',
    email: 'miserylee@foxmail.com'
  }
};
exports.basePath = '/admin/v3';
exports.docPath = '/docs/admin/v3';
exports.routesPath = path.resolve(__dirname, 'v3');
exports.preMiddleware = [async (ctx, next) => {
  await next();
  ctx.set('v', '3.0');
}];
exports.enhancer = require('../enhancers/rbac');
