require('xx-utils');
const Koa = require('koa');
const app = new Koa();
const koact = require('koact');
const routes = require('./routes');
const ports = require('./com.mango.common/settings/ports');
const logger = require('./com.mango.common/utils/logger');
const settings = require('./settings');

app.keys = settings.keys;
app.use(require('./mw/transformV3Interface'));
app.use(require('koa-compress')(settings.compress));
app.use(require('./mw/logger')());
app.use(require('kcors')(settings.cors));
if (process.env.REDIRECT_TO_PRODUCTION && process.env.NODE_ENV === 'development') {
  app.use(require('./mw/redirectToProduction'));
}
app.use(require('xx-passport')(settings.passport));
app.use(require('./mw/authFromQuery')());
app.use(require('./mw/jwt')());
app.use(require('./mw/rbac')());
app.use(require('./mw/deviceInfoParser')());
koact(app, routes);

app.listen(ports.SERVICE_WEB, _ => {
  logger.info(`Web server listening on ${ports.SERVICE_WEB}`);
});
