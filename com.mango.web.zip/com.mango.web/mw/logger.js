const logger = require('../com.mango.common/utils/logger');
const MetricsUploader = require('aliyun-metrics-uploader').default;
const metricsUploaderConfig = require('../services/metrics');

const uploader = new MetricsUploader(metricsUploaderConfig.endpoint, metricsUploaderConfig.accessKeyId, metricsUploaderConfig.accessKeySecret);

uploader.on('error', console.error);

module.exports = _ => {
  return async (ctx, next) => {
    const ts = Date.now();
    const method = ctx.method;
    const path = ctx.path;
    const ip = ctx.get('X-Forwarded-For') || ctx.ip;
    const deviceInfo = ctx.state.deviceInfo || {};
    const { plat = '', ver = '', mdl = '', udid, name, appv, lngLat, address, city, accuracy = 0 } = deviceInfo;
    if (!ctx.state.deviceInfo) ctx.state.deviceInfo = {};
    try {
      await next();
      // 网关检测不打log
      if (path === '/') return;
      const status = ctx.status;
      if (status >= 400) ctx.throw(status);
      const duration = Date.now() - ts;
      if (process.env.NODE_ENV !== 'production') {
        logger.info([
          `${ip}[${plat}-${mdl}-${ver}]`,
          `${method} ${path}`,
          status,
          `${duration}ms`,
        ].join('|'));
      } else if (method !== 'OPTIONS') {
        uploader.appendRaw(4004, 'api', { r: status }, duration);
      }
    } catch (err) {
      const duration = Date.now() - ts;
      let message = '';
      switch (err.name) {
        case 'TransactionEntityLockedError':
          ctx.status = 400;
          message = '您访问的资源正忙，等会再试吧！';
          break;
        case 'ValidationError':
        case 'BadRequestError':
          ctx.status = 400;
          message = err.message;
          break;
        case 'UnauthorizedError':
          ctx.status = 401;
          message = '您还未登陆';
          break;
        case 'ForbiddenError':
          if (!ctx.state.user || ctx.state.user.roles.toString() === 'guest') {
            ctx.status = 401;
            message = '您还未登陆';
          } else {
            ctx.status = 403;
            message = '您没有权限';
          }
          break;
        case 'NotFoundError':
          ctx.status = 404;
          message = err.message || '您访问的资源不存在';
          break;
        case 'ExplainError':
          ctx.status = 400;
          message = '索引错误';
          break;
        case 'Error':
        case 'TypeError':
        case 'SyntaxError':
        case 'ReferenceError':
        case 'RangeError':
        case 'EvalError':
        case 'URIError':
        case 'InternalServerError':
        case  'MongoError':
          ctx.status = 500;
          message = '服务器开小差了，等会再试吧！';
          break;
        default:
          const status = ctx.status;
          if (status > 500) {
            message = '服务器开小差了，等会再试吧！';
          } else {
            ctx.body = { error: err.message };
          }
          ctx.status = status;
      }
      ctx.body = ctx.body || {};
      ctx.body.error = message;

      logger.error([
        `${ip}[${plat}-${mdl}-${ver}]`,
        `${method} ${path}`,
        ctx.status,
        `${duration}ms`,
        err.message,
        err.stack && err.stack.split('\n')[1],
      ].join('|'));

      const params = ctx.params;
      const query = ctx.query;
      const body = ctx.request.body;
      const parts = ctx.request.parts;
      const headers = ctx.headers;
      // TODO: 记录错误日志到数据库中

    }
  };
};
