const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI1YTUzNTMxNzQ1ODE1ZjAwMjgzZDU5NDMiLCJleHAiOjE1MTgwMDIyMDAsImlzcyI6IuiKkuaenOeUteWNlei9piIsInRlbCI6IjE1OSoqKiowNzQ3Iiwicm9sZXMiOlsidXNlciIsInN1cGVyIiwiZGV2ZWxvcGVyIiwib3BlcmF0b3IiXSwicGVybWlzc2lvbnMiOltdLCJpZCI6IjE3MDMxMTA0MDQwMDMiLCJoYXNWZXJpZmllZCI6dHJ1ZSwicmVnaW9uSWRzIjpbIjE3MTAxODE0NDc4NDEiLCIxNzAzMTcxNjI0MDA0IiwiMTcwNDIxMTc0MTAxMiIsIjE3MTAxOTA4Mjk4NDIiLCIxNzAzMzAxMzMyMDA3IiwiMTcwNDA2MjMxOTAwOCIsIjE3MTEyNTEyMDM4NDUiLCIxNzExMDUxNzE5ODQzIiwiMTcwMzExMDI0ODAwMSIsIjE3MDkyOTExNDE4NDAiLCIxNzExMTAxNjUxODQ0IiwiMTcwMzE1MjAzMTAwMyIsIjE3MDMxMTIzNDYwMDIiLCIxNzAzMzAxMjAxMDA2IiwiMTcxMjIzMTEyNzg0NiJdLCJzdGF0aW9uSWQiOm51bGwsImlhdCI6MTUxNTQxMDE5OX0.DebcRGe3PMA6XMKUvlvApty6HYv5Kd2ysxr2qKSM_r4";
const axios = require('axios');
const BadRequestError = require('../com.mango.common/errors/BadRequestError');

const api = axios.create({
  baseURL: 'http://duet.mangoebike.com',
});

module.exports = async ctx => {
  if (ctx.method === 'GET') {
    try {
      const { data } = await api({
        method: ctx.method,
        url: ctx.path,
        headers: {
          Authorization: `Bearer ${token}`,
          origin: 'mangoebike.com',
        },
        params: Object.keys(ctx.query).reduce((memo, key) => {
          if (typeof ctx.query[key] === 'string') {
            memo[key] = ctx.query[key];
            return memo;
          }
          memo[key] = JSON.stringify(ctx.query[key]);
          return memo;
        }, {}),
        data: ctx.request.body,
      });
      ctx.body = data;
      ctx.set('r', true);
    } catch (err) {
      if (!err.response) throw err;
      throw new BadRequestError(err.response.data.error);
    }
  } else {
    throw new BadRequestError('只允许GET方法重定向');
  }
};
