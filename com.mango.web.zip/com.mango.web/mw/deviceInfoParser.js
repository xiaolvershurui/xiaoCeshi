const { crypto } = require('xx-utils');
const settings = require('../settings');

const { key, iv } = settings.deviceInfoDecryption;

module.exports = _ => {
  return async (ctx, next) => {
    const encryptedInfo = ctx.get('mg-dvi');
    if (encryptedInfo) {
      try {
        const stuff = crypto.aes256(key, iv).decode(encryptedInfo);
        ctx.state.deviceInfo = JSON.parse(stuff);
      } catch (err) {
        // noop
      }
    }
    // TODO: 用户快照
    await next();
  };
};
