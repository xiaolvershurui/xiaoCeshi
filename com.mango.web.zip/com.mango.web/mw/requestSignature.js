const isDev = process.env.NODE_ENV === 'development';
const { verify } = require('show-your-ticket');
const BadRequestError = require('../com.mango.common/errors/BadRequestError');
const { key, expires } = require('../settings').requestSignature;

module.exports = _ => {
  return async (ctx, next) => {
    const signature = ctx.get('mg-sig');
    let timestamp = ctx.get('mg-ts');
    const stuffKeys = ctx.get('mg-sk');
    if (!isDev || signature) {
      if (!signature) throw new BadRequestError('Require signature in headers');
      if (!timestamp) throw new BadRequestError('Require timestamp in headers');
      timestamp = new Date(parseFloat(timestamp));
      try {
        verify({
          payload: {
            body: ctx.request.body,
            query: ctx.request.query,
          },
          method: ctx.method,
          path: ctx.path,
          signature,
          timestamp,
          stuffKeys,
          secretKey: key,
          expires,
        });
      } catch (error) {
        throw new BadRequestError(error.message);
      }
    }
    await next();
  }
};
