const jwt = require('koa-jwt');
const compose = require('koa-compose');
const jwtOptions = require('../settings').jwt;
const Token = require('../services/database/token');

const checkValid = async (ctx, next) => {
  const auth = ctx.state.user;
  if (auth) {
    const token = await Token.findById({ jti: auth.jti, selector: '_id' });
    if (!token) {
      Reflect.deleteProperty(ctx.state, 'user');
    }
  }
  await next();
};

module.exports = _ => {
  return compose([jwt(jwtOptions), checkValid]);
};
