const rbac = require('koa-rbac');
const JsonProvider = rbac.RBAC.providers.JsonProvider;
class Provider extends JsonProvider {
  constructor (rules) {
    super(rules);
  }

  getRoles (roles) {
    const rules = this._rules || {};
    const cache = {};

    const collect = (roles, userRoles, depth) => {
      roles.forEach(role => {
        cache[role] = cache[role] || depth;
      });
      roles.forEach(role => {
        if (cache[role] >= depth) {
          const r = rules[role];
          if (r) {
            if (Array.isArray(r.inherited)) {
              userRoles[role] = collect(r.inherited, {}, depth + 1);
            } else {
              userRoles[role] = null;
            }
          } else {
            userRoles[role] = null;
          }
        }
      });
      return userRoles;
    };
    return collect(roles || [], {}, 1);
  }

  getPermissions (role) {
    const rules = this._rules || {};
    return (rules[role] && rules[role].permissions) || [role];
  }
}
module.exports = Provider;