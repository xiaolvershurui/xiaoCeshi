module.exports = ({
  ends = [],
  modules = [],
  operations = [],
  rules = {},
}) => {
  const modulesKeys = Object.keys(modules);
  const systemRules = {};
  ends.forEach(end => {
    systemRules[`${end}.op`] = { inherited: [] };
    operations.forEach(operation => {
      const key = `${end}.${operation}`;
      systemRules[key] = { inherited: [] };
      modulesKeys.forEach(mod => {
        systemRules[key].inherited.push(`${end}.${mod}.${operation}`);
      });
      systemRules[`${end}.op`].inherited.push(key);
    });
    modulesKeys.forEach(mod => {
      const subModules = modules[mod];
      const modOpKey = `${end}.${mod}.op`;
      systemRules[`${end}.op`].inherited.push(modOpKey);
      systemRules[modOpKey] = { inherited: [] };
      operations.forEach(operation => {
        const key = `${end}.${mod}.${operation}`;
        systemRules[key] = systemRules[key] || { permissions: [] };
        subModules.forEach(subMod => {
          systemRules[key].permissions.push(`${end}.${mod}.${subMod}.${operation}`);
        });
        systemRules[modOpKey].inherited.push(key);
      });
      subModules.forEach(subMod => {
        const key = `${end}.${mod}.${subMod}.op`;
        systemRules[key] = { permissions: operations.map(op => `${end}.${mod}.${subMod}.${op}`) };
        systemRules[modOpKey].inherited.push(key);
      });
    });
  });

  rules = Object.assign(rules, systemRules);

  const { permissions, roles } = Object.keys(rules).reduce((memo, role) => {
    const re = role => {
      if (!memo.permissions[role]) {
        memo.permissions[role] = rules[role].permissions || [];
        memo.roles[role] = [role];
        if (rules[role].inherited) {
          rules[role].inherited.forEach(r => {
            memo.roles[role].add(r);
            if (!memo.permissions[r]) {
              re(r);
            }
            memo.permissions[r].forEach(permission => memo.permissions[role].add(permission));
            memo.roles[r].forEach(r => memo.roles[role].add(r));
          });
        }
      }
    };
    re(role);
    return memo;
  }, { permissions: [], roles: [] });

  return {
    rules,
    permissions,
    roles,
  };
};