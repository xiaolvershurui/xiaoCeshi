const rbac = require('koa-rbac');
const Provider = require('./Provider');
const { rules } = require('./rules');

module.exports = _ => {
  return rbac.middleware({
    rbac: new rbac.RBAC({
      provider: new Provider(rules)
    }),
    identity: ctx => {
      if (!ctx.state || !ctx.state.user) return ['guest'];
      const roles = ctx.state.user.roles || [];
      const permissions = ctx.state.user.permissions || [];
      return [...roles, ...permissions];
    }
  });
};
