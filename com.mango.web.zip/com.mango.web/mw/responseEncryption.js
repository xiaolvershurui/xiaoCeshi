const { crypto, judgement } = require('xx-utils');
const { key, iv } = require('../settings').responseEncryption;
const isPro = process.env.NODE_ENV === 'production';

module.exports = _ => {
  return async (ctx, next) => {
    await next();
    const encrypt = ctx.get('mg-eyt');
    if ((isPro || encrypt) && ctx.body) {
      let body = ctx.originalBody = ctx.body;
      if (judgement.isObject(body)) body = JSON.stringify(body);
      const encryptedStuff = crypto.aes256(key, iv).encode(body);
      ctx.body = {
        joker: true,
        body: encryptedStuff,
      };
    }
  };
};
