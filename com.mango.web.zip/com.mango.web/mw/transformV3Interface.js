module.exports = async (ctx, next) => {
  const path = ctx.path;
  if (/^\/admin\/v3/.test(path)) {
    if (path.indexOf('.', 10) !== -1) {
      return await next()
    }
    const index = path.indexOf('/', 10);
    ctx.path = [path.slice(0, index), path.slice(index + 1)].join('.');
  }
  await next();
};