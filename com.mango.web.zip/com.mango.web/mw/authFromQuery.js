const url = require('url');
const jwtSettings = require('../settings').jwt;

module.exports = _ => {
  return async (ctx, next) => {
    if (ctx.query.token) {
      ctx.cookies.set(jwtSettings.cookie, ctx.query.token, { signed: true });
      const parsedUrl = url.parse(ctx.originalUrl);
      const query = ctx.query;
      Reflect.deleteProperty(query, 'token');
      ctx.redirect(url.format({
        pathname: parsedUrl.pathname,
        query
      }));
      return;
    }
    await next();
  };
};