const { verify } = require('show-your-ticket');
const settings = require('../settings');

module.exports = _ => {
  return async (ctx, next) => {
    const signature = ctx.get('mg-sig');
    let timestamp = ctx.get('mg-ts');
    const stuffKeys = ctx.get('mg-sk');
    if (!signature) ctx.throw(400, 'Require signature in headers');
    if (!timestamp) ctx.throw(400, 'Require timestamp in headers');
    timestamp = new Date(parseFloat(timestamp));
    try {
      verify({
        payload: {
          body: ctx.request.body,
          query: ctx.request.query,
        },
        method: ctx.method,
        path: ctx.path,
        signature,
        timestamp,
        stuffKeys,
        secretKey: settings.requestSignature.key,
        expires: settings.requestSignature.expires,
      });
    } catch (error) {
      ctx.throw(400, error.message);
    }
    await next();
  }
};