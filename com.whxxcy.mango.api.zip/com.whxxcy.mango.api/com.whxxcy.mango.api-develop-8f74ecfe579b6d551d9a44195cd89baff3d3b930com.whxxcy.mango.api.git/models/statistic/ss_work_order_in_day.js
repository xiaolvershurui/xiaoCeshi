const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 总共工单笔数
  count: { type: Number, default: 0 },
  // 平均处理时长
  perDuration: { type: Number, default: 0 },
  // 各个人处理工单数
  handle: [{
    processor: String,
    perDuration: { type: Number, default: 0 },
    count: { type: Number, default: 0 },
    feedbackCount: { type: Number, default: 0 },
    satisfactionCount: { type: Number, default: 0 },
  }],
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_work_order_in_day', schema);