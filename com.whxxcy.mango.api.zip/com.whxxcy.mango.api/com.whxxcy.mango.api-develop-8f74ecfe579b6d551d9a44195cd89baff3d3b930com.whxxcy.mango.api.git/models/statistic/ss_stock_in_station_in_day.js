const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 仓库ref
  station: { type: String, required: true },
  // 仓库名称
  stationName: String,
  // 入库数量
  inboundCount: { type: Number, min: 0, required: true },
  // 出库数量
  outboundCount: { type: Number, min: 0, required: true },
  // 在库数量
  totalCount: { type: Number, min: 0, required: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1, station: 1, date: 1 }, { unique: true });
schema.plugin(betterId, { connection: conn.statistic });

module.exports = conn.statistic.model('ss_stock_in_station_in_day', schema);