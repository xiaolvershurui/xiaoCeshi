const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 总订单数
  totalCount: Number,
  // 停车区订单数
  inParkCount: Number,
  // 逆行订单数
  wrongDirection: Number,
  // 横跨机动车道
  acrossMotorway: Number,
  // 逆行切横跨机动车道
  wrongDirectionAndAcrossMotorway: Number,
  // 无违章
  niceOrder: Number
}, {
  read: 'secondaryPreferred'
});

schema.index({ createdAt: 1 });
schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_illegal', schema);