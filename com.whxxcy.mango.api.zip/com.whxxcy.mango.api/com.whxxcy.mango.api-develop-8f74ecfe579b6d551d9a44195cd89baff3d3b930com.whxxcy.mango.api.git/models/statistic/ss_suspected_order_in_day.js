const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 订单
  order: { type: String, required: true },
  // 当前时长
  totalDuration: Number,
  // 里程
  distance: Number,
  // 当前金额
  totalAmount: Number,
  // 是否已处理
  processed: { type: Boolean, required: true, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1, order: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_suspected_order_in_day', schema);