const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  date: Date,
  // 总设备数
  totalUdidCount: { type: Number, default: 0 },
  // 总用户数
  totalUserCount: { type: Number, default: 0 },
  // 今日新增设备
  increaseUdidCount: { type: Number, default: 0 },
  // 今日新增用户
  increaseUserCount: { type: Number, default: 0 },
  // 总活跃人数(去重)
  totalActiveCount: Number,
  // 押金账户 当天缴纳押金的用户
  totalDepositCount: Number,
  // 订单账户 当天下过订单的用户
  totalOrderCount: Number,
  // 新增用户留存
  registerKeep: [],
  // 活跃用户留存
  activeKeep: [],
  // 押金账户留存
  depositKeep: [],
  // 订单账户留存
  orderKeep: [],
}, {
  read: 'secondary',
});

schema.index({ date: -1 });

module.exports = conn.statistic.model('ss_new_login', schema);
