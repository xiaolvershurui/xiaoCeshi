const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 预约次数
  subscribeCount: { type: Number, default: 0 },
  // 预约下单数
  reservationCount: { type: Number, default: 0 },
  // 下单总数
  orderCount: { type: Number, default: 0 },
  // 完成订单数
  finishCount: { type: Number, default: 0 },
  // 使用优惠券的完成订单数
  finishCountUseCoupon: { type: Number, default: 0 },
  // 订单统计消费总额
  costAmount: { type: Number, default: 0 },
  // 账单统计总额
  rentAmount: { type: Number, default: 0 },
  // 合作伙伴租金
  partnerRentAmount: { type: Number, default: 0 },
  // 累计账单统计总收入
  totalRentAmount: { type: Number, default: 0 },
  // 累计合作伙伴收入
  totalPartnerRentAmount: { type: Number, default: 0 },
  // 完成订单保险总额
  insuranceAmount: { type: Number, default: 0 },
  // 完成订单优惠券总额
  couponAmount: { type: Number, default: 0 },
  // 订单使用总时长
  totalUsingTime: { type: Number, default: 0 },
  // 订单使用里程
  totalUsingMileage: { type: Number, default: 0 },
  // 可用车辆数
  enableStockCount: { type: Number, default: 0 },
  // 使用车辆数
  usedStockCount: { type: Number, default: 0 },
  // 投放车辆数
  putInStockCount: { type: Number, default: 0 },
  // 总可用时长
  totalValidTime: { type: Number, default: 0 },
  // 每小时下单
  orderPerHour: [{ type: Number, default: 0 }],
  // 完美订单数量
  perfectCount: Number,
  // 计算调度费账单总计总额
  rentAmountWithDispatch: { type: Number, default: 0 },
  // 计算调度费合作伙伴租金
  partnerRentAmountWithDispatch: { type: Number, default: 0 },
  // 计算调度费累计账单总收入
  totalRentAmountWithDispatch: { type: Number, default: 0 },
  // 计算调度费累计合作伙伴收入
  totalPartnerRentAmountWithDispatch: { type: Number, default: 0 },
  // 停车区订单数
  inPark: { type: Number, default: 0 },
}, {
  read: 'secondaryPreferred',
});

schema.index({ region: 1, date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_rent_in_day', schema);
