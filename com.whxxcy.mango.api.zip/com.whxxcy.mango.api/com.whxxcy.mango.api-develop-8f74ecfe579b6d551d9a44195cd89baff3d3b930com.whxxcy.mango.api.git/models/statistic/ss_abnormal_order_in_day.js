const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 车辆编号
  stock: { type: String, required: true },
  // 车牌号
  stockNo: { type: String, required: true },
  // 异常类型
  state: { type: Number, enums: constants.OD_ORDER_STATE_ENUMS, required: true },
  // 次数
  orderCount: { type: Number, default: 0, required: true },
  // 影响人
  users: [String],
  // 影响人数
  userCount: Number
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 });
schema.index({ region: 1, date: 1 });
schema.index({ date: 1, stock: 1, state: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_abnormal_order_in_day', schema);