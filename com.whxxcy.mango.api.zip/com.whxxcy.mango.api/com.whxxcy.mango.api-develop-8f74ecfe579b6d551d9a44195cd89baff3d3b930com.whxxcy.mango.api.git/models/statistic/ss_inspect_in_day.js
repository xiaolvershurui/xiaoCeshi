const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 巡检人员
  inspector: { type: String, required: true },
  // 巡检人员姓名
  inspectorName: { type: String, required: true },
  // 巡检人员手机号
  inspectorTel: { type: String },
  // 巡检员车辆类型
  stockType: Number,
  // 巡检员来源
  stockSource: Number,
  // 签到时间
  checkIn: { type: Date, required: true },
  // 签退时间
  checkOut: { type: Date, required: true },
  // 工作时长
  workTime: { type: Number, default: 0 },
  // 巡检时长
  inspectTime: { type: Number, default: 0 },
  // 找车打卡次数
  taskCount: { type: Number, default: 0 },
  // 自己任务
  selfTask: { type: Number, default: 0 },
  // 有效任务数
  validCount: { type: Number, default: 0 },
  // 第一次打卡
  firstOp: Date,
  // 最后一次打卡
  lastOp: Date,
  // 找到车次数
  hasFind: { type: Number, default: 0 },
  // 完成任务数
  finished: { type: Number, default: 0 },
  // 找车成功率
  foundSuccessRate: { type: Number, default: 0 },
  // 任务完成率
  finishedRate: { type: Number, default: 0 },
  // 巡检距离
  distance: { type: Number, default: 0 },
  // 每小时找车数
  foundPerHour: { type: Number, default: 0 },
  // 每车通勤里程
  mileagePerFound: { type: Number, default: 0 },
  // 找车详情
  foundInfo: [{
    // 车辆ID
    stock: String,
    // 车牌号
    stockNo: String,
    // 最后一次打卡时间
    foundAt: Date,
    // 是否找到（最终一次打卡的结果）
    hasFound: Boolean,
    // 第一次打卡任务列表
    prevTaskList: [],
    // 最后一次打卡任务列表
    lastTaskList: [],
    // 第一次打卡车辆去向
    prevLocate: Number,
    // 最后一次打卡去向
    lastLocate: Number,
    // 添加的任务列表
    addedTasks: [],
    // 释放的任务列表
    releasedTasks: [],
    // 巡检人信息
    inspector: String,
    inspectorName: String,
    inspectorTel: String,
    // 是否有效
    valid: { type: Boolean, default: false },
    // 是否自己的任务
    self: { type: Boolean, default: false },
    // 是否锁好电池
    batteryLockOn: { type: Boolean, default: true },
    // 是否存在断电任务
    unHandle: { type: Boolean, default: false }
  }],
  // 释放离线任务数
  releasedOffline: Number,
  // 拖回数
  returnBack: Number,
  // 投放数
  putIn: Number,
  // 难寻
  difficultFind: Number,
  // 司机未找到
  driverNotFound: Number,
  // 白班未找到
  dayNotFound: Number,
  // 高手未找到
  superiorNotFound: Number,
  // 离线拖回数
  offlineReturnBack: Number,
  // 未处理任务数
  unresolvedTasks: [],
  // 未锁好电池数
  batteryUnLockOn: Number,
  // 未完成断电任务数
  unHandle: Number,
  // 错误换电数
  wrongCount: Number,
  // 错误换电的设备
  wrongStock: [{
    stock: String,
    number: String,
    battery: String
  }],
  // 缺失电池数
  missCount: Number
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1 });

module.exports = conn.statistic.model('ss_inspect_in_day', schema);