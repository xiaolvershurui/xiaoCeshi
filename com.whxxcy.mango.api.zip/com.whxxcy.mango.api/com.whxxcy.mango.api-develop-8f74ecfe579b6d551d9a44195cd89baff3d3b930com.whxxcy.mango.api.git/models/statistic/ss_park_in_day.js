const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 禁停区车辆数
  forbiddenPark: { type: Number, default: 0 },
  // 骑出围栏用户数
  outFenceUser: { type: Number, default: 0 },
  // 出围栏车辆数
  outFenceStock: { type: Number, default: 0 },
  // 出围栏订单数
  outFenceOrder: { type: Number, default: 0 },
  // 出围栏次数
  totalCount: { type: Number, default: 0 },
  // 长时间未移动结束订单
  unMoveEnd: { type: Number, default: 0 },
  // 禁行区车辆数
  forbiddenMove: { type: Number, default: 0 },
  // 未移动结束且在禁停区车辆数
  unMoveEndInForbiddenPark: { type: Number, default: 0 },
  // 未移动结束且在禁行区车辆数
  unMoveEndInForbiddenMove: { type: Number, default: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1, date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_park_in_day', schema);