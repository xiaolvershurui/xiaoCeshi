const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 款式
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 离线总数
  offline: { type: Number, default: 0 },
  // 离线
  offlineStocks: [String],
  // 当日净增
  increased: { type: Number, default: 0 },
  // 上日残留变投放
  lastDayToPutIn: { type: Number, default: 0 },
  // 上日残留变在库
  lastDayToStore: { type: Number, default: 0 },
  // 新增变投放
  toDayToPutIn: { type: Number, default: 0 },
  // 新增变在库
  toDayToStore: { type: Number, default: 0 },
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1 }, { unique: true });
schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_offline_in_day', schema);
