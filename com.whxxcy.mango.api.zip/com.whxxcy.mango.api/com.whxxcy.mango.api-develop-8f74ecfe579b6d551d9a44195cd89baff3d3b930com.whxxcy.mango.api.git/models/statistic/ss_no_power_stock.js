const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 零电日期
  noPowerDate: { type: Date, required: true },
  // 车辆
  stock: { type: String, required: true },
  // 首次离线日期
  offlineDate: Date,
  // 零电后首次找车日期
  findDate: Date,
  // 离线后找车次数
  findCount: { type: Number, min: 0 },
  // 断电警报日期
  powerOffDate: Date,
  // 是否清除
  clear: { type: Boolean, required: true, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 }, { unique: true });
schema.index({ date: 1, region: 1 });

module.exports = conn.statistic.model('ss_no_power_stock', schema);