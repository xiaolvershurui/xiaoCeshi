const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 新充值押金笔数
  newChargeCount: { type: Number, default: 0 },
  // 新充值押金金额
  newChargeAmount: { type: Number, default: 0 },
  // 新提交提现押金笔数
  newWithdrawCount: { type: Number, default: 0 },
  // 新提交提现金额
  newWithdrawAmount: { type: Number, default: 0 },
  // 执行退款笔数
  refundCount: { type: Number, default: 0 },
  // 执行退款金额
  refundAmount: { type: Number, default: 0 },
  // 提现中笔数
  withdrawCount: { type: Number, default: 0 },
  // 提现中金额
  withdrawAmount: { type: Number, default: 0 },
  // 未提交提现押金池笔数
  remainCount: { type: Number, default: 0 },
  // 未提交提现押金沉淀金额
  remainAmount: { type: Number, default: 0 },
  // 剩余押金笔数(包括提现未打款)
  residueCount: { type: Number, default: 0 },
  // 剩余押金金额(包括提现未打款)
  residueAmount: { type: Number, default: 0 },
  // 累计支付押金池笔数
  totalPayCount: { type: Number, default: 0 },
  // 累计支付押金金额
  totalPayAmount: { type: Number, default: 0 },
  // 累计退还押金笔数
  totalRefundCount: { type: Number, default: 0 },
  // 累计退还押金金额
  totalRefundAmount: { type: Number, default: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_deposit_in_day', schema);