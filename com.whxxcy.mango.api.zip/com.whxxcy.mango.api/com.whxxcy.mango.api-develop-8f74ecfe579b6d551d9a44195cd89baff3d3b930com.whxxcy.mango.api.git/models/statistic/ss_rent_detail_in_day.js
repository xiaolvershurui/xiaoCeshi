const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 车辆
  stock: { type: String, required: true },
  // 车牌号
  stockNo: { type: String, required: true },
  // 下单次数
  orderCount: { type: Number, default: 0 },
  // 总租金
  totalAmount: { type: Number, default: 0 },
  // 车辆可用时长
  validTime: { type: Number, default: 0 },
  // 车辆行驶距离
  validDistance: { type: Number, default: 0 },
  // 订单时长
  orderDuration: { type: Number, default: 0 },
  // 扫码次数
  scanCount: { type: Number, default: 0 },
  // 扫码错误次数
  scanErrorCount: { type: Number, default: 0 },
}, {
  read: 'secondaryPreferred',
});

schema.index({ stock: 1, date: 1, region: 1 }, { unique: true });
schema.index({ date: 1, region: 1 });
schema.index({ stock: 1, date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_rent_detail_in_day', schema);
