const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 当天小时
  hour: { type: Number, required: true },
  // 当天分钟
  minute: { type: Number, required: true },
  // 投放车辆数
  total: { type: Number, default: 0 },
  // 当前在租车辆
  rent: { type: Number, default: 0 },
  // 任务车辆数(5km, 离线, 断电, 待拖回, 服务区外)
  task: { type: Number, default: 0 },
  // 待拖回数
  back: { type: Number, default: 0 },
  // 离线
  offline: { type: Number, default: 0 },
  // 断电
  powerUnlink: { type: Number, default: 0 },
  // 5km
  lowPower: { type: Number, default: 0 },
  // 服务区外
  outsideRegion: { type: Number, default: 0 },
  // 在租车辆占比
  rentRate: { type: Number, min: 0, max: 1 },
  // 大于等于39v 信号大于等于3
  greaterVoltageAndGreaterSignal: { type: Number, min: 0 },
  // 大约等于39v 信号小于3
  greaterVoltageAndLessSignal: { type: Number, min: 0 },
  // 小于39v 离线
  lessVoltageAndOffline: { type: Number, min: 0 },
  //  大于等于39v 信号大于等于3 有离线任务
  hasPowerUnlink: { type: Number, min: 0 },
  //  大于等于39v 信号大于等于3 无离线任务
  notHasPowerUnlink: { type: Number, min: 0 },
  // sim卡高压开机
  simPowerOnWithGreaterVoltage: { type: Number, min: 0 },
  // sim卡低压开机
  simPowerOnWithLessVoltage: { type: Number, min: 0 },
  // sim卡关机
  simPowerOff: { type: Number, min: 0 }
}, {
  shardKey: {
    date: 1,
    hour: 1,
    minute: 1,
    region: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ date: 1, hour: 1, minute: 1, region: 1, style: 1 }, { unique: 1 });
schema.index({ date: 1, _id: 1, region: 1 });

module.exports = conn.statistic.model('ss_order_count_in_minute', schema);