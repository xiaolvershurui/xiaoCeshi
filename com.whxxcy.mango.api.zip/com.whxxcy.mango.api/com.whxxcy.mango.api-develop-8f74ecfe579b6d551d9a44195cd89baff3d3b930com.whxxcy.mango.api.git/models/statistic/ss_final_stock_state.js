const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 大区名
  regionName: String,
  // 日期
  date: { type: Date, required: true },
  // 大区车辆总数
  totalCount: Number,
  // 投放数
  putOn: Number,
  // 失控车辆数
  lostControl: Number,
  // 新增失控
  lostControlIncreased: Number,
  // 投放可租数
  enableRent: Number,
  // 投放禁租
  forbiddenRent: Number,
  // 在库车辆数
  inStation: Number,
  // 在库报废车辆数
  scrapedInStation: Number,
  // 在库车辆数(包括报废)
  totalInStation: Number,
  // 正常在库率
  inStationRate: Number,
  // 报废车辆在库数
  scrapedInStationRate: Number,
  // 在库率
  totalInStationRate: Number,
  // 运输车辆数
  inTransport: Number,
  // 扣押车辆数
  inDetain: Number,
  // 新增被扣
  inDetainIncreased: Number,
  // 疑似丢失
  inSuspectedLost: Number,
  // 丢失
  inLost: Number,
  // 报废车辆
  scrap: Number,
  // 车辆租金
  rentAmount: Number,
  // 新增丢失报废
  batteryLostAndDamageIncreased: Number,
  // 巡检上报丢失
  batteryLostRecordCount: Number,
  // 随车丢失
  batteryLostWithStockRecordCount: Number,
  // 电池丢失报废
  batteryLostAndDamage: Number,
  // 电池待维修数
  batteryNeedRepaired: Number,
  // 电池总数
  batteryTotalCount: Number,
  // 完好电池数  前端填写更新
  batteryIntactCount: Number,
  // 其他
  other: {
    // 内部使用
    internalUsing: Number,
    // 其他占用
    otherUsing: Number,
    // 待拖回
    pullBack: Number
  },
  // 高压离线
  highVoltageButOffline: Number,
  // 司机难寻车辆
  difficultFind: [],
  // 找到难寻车辆
  difficultFindButFound: [],
  // 12小时未上线的车辆
  offlineBeforeHours: [],
  // 找到离线车辆
  offlineButFound: [],
  // 各个类型不可租原因 互斥
  invalidReason: {
    // 离线
    offline: Number,
    // 低电
    lowPower: Number,
    // 无定位
    noGpsLocation: Number,
    // 围栏外非免单
    outSideRegionNoFree: Number
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1 });
schema.index({ date: 1 });

module.exports = conn.statistic.model('ss_final_stock_state', schema);