const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 库存ref
  stock: { type: String, required: true },
  // 车牌号
  stockNo: { type: String },
  // 大区ref
  region: { type: String, required: true },
  // 车型ref
  style: { type: String, required: true },
  // 日期
  date: { type: Date, required: true },
  // 累计可用时长 (分钟)
  validTime: { type: Number, default: 0, required: true },
  // 最近转换为不可用的时间
  latestSetInvalidAt: Date,
  // 最近转换为可用的时间
  latestSetValidAt: Date,
  // 累计租用时长
  usingTime: { type: Number, default: 0, required: true },
  // 累计租用里程 (米)
  usingMileage: { type: Number, default: 0, required: true },
  // 最近转为在租的时间
  latestSetUsingAt: Date,
  // 最近转为不在租的时间
  latestSetNotUsingAt: Date,
  // 最近转为在租时记录的总里程
  latestSetUsingMileage: Number,
  // 最近转为在线的时间
  latestSetOnlineAt: Date,
  // 最近转为离线的时间
  latestSetOfflineAt: Date,
  // 累计在线时长
  onlineTime: { type: Number, default: 0 },
  // 累计离线次数
  setOfflineTimes: { type: Number, default: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1, date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_stock_in_day', schema);