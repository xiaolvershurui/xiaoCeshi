const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  // 今日新提交工单数
  workOrderCount: Number,
  // 今日处理数
  handleCount: Number,
  // 当天21点前产生的工单未处理数
  noHandleAtNight: Number,
  // 工单净增长 ((新增工单-前一天新增) / 前一天新增)
  netIncrease: Number,
  // 工单反馈满意数
  satisfactionCount: Number,
  // 工单原因及评分
  workOrderDistribution: [{
    // 真实原因
    realReason: String,
    // 数量
    count: Number,
    // 已评价数
    commentCount: Number,
    // 满意数
    satisfactionCount: Number
  }]
}, {
  read: 'secondaryPreferred'
});


module.exports = conn.statistic.model('ss_support_in_day', schema);