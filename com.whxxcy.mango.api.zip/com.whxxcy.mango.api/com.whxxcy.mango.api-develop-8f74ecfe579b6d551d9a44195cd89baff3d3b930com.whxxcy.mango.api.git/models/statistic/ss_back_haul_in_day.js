const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车辆编号 ref
  stock: { type: String, required: true },
  // 车牌号 ref
  stockNo: { type: String, required: true },
  // 车辆问题
  remark: { type: String, required: true },
  // 操作人
  operator: { type: String, required: true },
  // 操作人姓名
  operatorName: { type: String, required: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ stockNo: 1 });

module.exports = conn.statistic.model('ss_back_haul_in_day', schema);