const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({

}, {
  read: 'nearest',
});


module.exports = conn.statistic.model('ss_divide_solution', schema);
