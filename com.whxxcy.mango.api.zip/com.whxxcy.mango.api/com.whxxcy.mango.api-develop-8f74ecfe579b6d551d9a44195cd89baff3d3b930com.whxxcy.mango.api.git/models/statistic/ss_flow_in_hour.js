const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 当天小时
  hour: { type: Number, required: true },
  // 支付押金笔数
  depositCount: { type: Number, default: 0 },
  // 支付押金总额
  depositAmount: { type: Number, default: 0 },
  // 退款押金笔数
  refundDepositCount: { type: Number, default: 0 },
  // 退款押金总额
  refundDepositAmount: { type: Number, default: 0 },
  // 充值笔数
  rechargeCount: { type: Number, default: 0 },
  // 充值总额
  rechargeAmount: { type: Number, default: 0 },
  // 余额退款笔数
  refundBalanceCount: { type: Number, default: 0 },
  // 余额退款总额
  refundBalanceAmount: { type: Number, default: 0 },
  // 总收入流水
  totalIncome: { type: Number, default: 0 },
  // 总支出流水
  totalOutcome: { type: Number, default: 0 },
  // 是否已经检查过
  checked: { type: Boolean, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, hour: 1, region: 1 }, { unique: true });
schema.index({ date: 1, hour: 1, checked: 1 });

module.exports = conn.statistic.model('ss_flow_in_hour', schema);