const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 车辆
  stock: { type: String, required: true },
  // 未找到人员
  noFoundOperator: [String],
  // 找到人员
  operator: { type: String, required: true },
  // 任务组类型
  taskGroup: { type: Number, enums: constants.BK_TASK_GROUP_ENUMS, required: true },
  // 最高任务类型
  highestTask: { type: Number, enums: constants.BK_TASK_TYPE_ENUMS, required: true },
  // 找到描述
  description: String
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 });
schema.index({ date: 1, region: 1 });

module.exports = conn.statistic.model('ss_day_found', schema);