const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 总订单数
  totalOrderCount: { type: Number, required: true, min: 0 },
  // 正常完成订单数
  finishCount: { type: Number, required: true, min: 0 },
  // 异常结束订单数
  abnormalCount: { type: Number, required: true, min: 0 },
  // 超时结束
  overTimeCount: { type: Number, required: true, min: 0 },
  // 无移动结束
  unMoveCount: { type: Number, required: true, min: 0 },
  // 后台结束
  backEndCount: { type: Number, required: true, min: 0 },
  // 系统结束
  systemEndCount: { type: Number, required: true, min: 0 },
  // 禁停区结束
  forbiddenCount: { type: Number, required: true, min: 0 },
  // 总预约订单数
  totalCount: { type: Number, required: true, min: 0 },
  // 预约完成订单数
  finishWithReservation: { type: Number, required: true, min: 0 },
  // 预约超时数
  reservationTimeOut: { type: Number, required: true, min: 0 },
  // 预约取消
  reservationCancel: { type: Number, required: true, min: 0 },
  // 用其他车
  useOtherStock: { type: Number, required: true, min: 0 },
  // 被预约导致预约失败
  reservationFailed: { type: Number, required: true, min: 0 },
  // 预约失败总数
  reservationFailedTotal: { type: Number, required: true, min: 0 },
  // 被预约导致扫码失败
  reservationScanQRFailed: { type: Number, required: true, min: 0 },
  // 扫码失败总数
  reservationScanQRFailedTotal: { type: Number, required: true, min: 0 },
  // 被预约导致下单失败
  rentFailed: { type: Number, required: true, min: 0 },
  // 下单失败总数
  rentFailedTotal: { type: Number, required: true, min: 0 },
  // TODO:预约时长统计
  // 每日各时长区间内预约完成、超时、取消、扫其他码的数量
  reservationCountInMinutes: [
    {
      time: Number,
      finishWithReservation: { type: Number, min: 0},
      reservationTimeOut: { type: Number, min: 0},
      reservationCancel: { type: Number, min: 0},
      useOtherStock: { type: Number, min: 0}
    },
  ],
  // 寻车意愿时长
  // 平均预约时长
  reservationTimeAvg: { type: Number, min: 0 },
  // TODO:预约距离统计
  // 每日各距离区间内预约完成、超时、取消、扫其他码的数量
  reservationCountInMiles: [
    {
      distance: Number,
      finishWithReservation: { type: Number, min: 0},
      reservationTimeOut: { type: Number, min: 0},
      reservationCancel: { type: Number, min: 0},
      useOtherStock: { type: Number, min: 0}
    }
  ],
  // 寻车意愿距离
  // 平均预约距离
  reservationDistanceAvg: { type: Number, min: 0 },

  // TODO: 预约次数统计
  // 每日各次数区间内预约完成、超时、取消、扫其他码的数量
  reservationCount: { type: Number, min: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_reservation_in_day', schema);
