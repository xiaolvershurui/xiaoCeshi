const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车辆编号 ref
  stock: { type: String, required: true },
  // 上次换电时间
  prevChangeDate: Date,
  // 换电前电压
  prevVoltage: Number,
  // 换电后电压
  nextVoltage: Number,
  // 换电电压区间及差值
  voltage: {
    start: Number,
    end: Number,
  },
  // 此次换电时间
  changeDate: Date,
  // 订单
  orders: [String],
  // 总金额
  totalAmount: { type: Number, min: 0 },
  // 总距离
  totalDistance: { type: Number, min: 0 },
  // 总时长
  totalDuration: { type: Number, min: 0 }
}, {
  read: 'nearest'
});

schema.index({ totalAmount: -1 });
schema.index({ region: 1 });
schema.index({ stock: 1 });
schema.index({ createdAt: -1 });
schema.index({ prevVoltage: 1 });

module.exports = conn.statistic.model('ss_change_battery', schema);