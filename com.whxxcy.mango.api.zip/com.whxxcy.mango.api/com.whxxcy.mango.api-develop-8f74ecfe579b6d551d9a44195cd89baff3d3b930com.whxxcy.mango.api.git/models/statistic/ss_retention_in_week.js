const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  //  创建时间
  date: { type: Date, required: true },
  // 当周押金支付数量
  depositCount: { type: Number, default: 0 },
  // 当周订单数量
  orderCount: { type: Number, default: 0 },
  // 押金留存N周分布
  depositRetentionInterval: {},
  // 订单留存N周分布
  orderRetentionInterval: {}
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_retention_in_week', schema);