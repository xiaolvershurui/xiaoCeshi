const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区
  region: String,
  // 车辆 ref
  stock: { type: String, required: true },
  // 离线日期
  date: { type: Date, required: true },
  // 首次找车日期
  findDate: Date,
  // 离线后找车次数
  findCount: { type: Number, min: 0 },
  // 离线任务产生次数
  offlineCount: { type: Number, min: 0 },
  // 离线时信号强度
  offlineSignal: { type: [Number], default: [] },
  // sim卡开关机
  simPowerOn: Boolean,
  // 是否低压
  isNoPower: Boolean,
  // 在线
  isOnline: Boolean,
  //去向
  locate: {
    type: Number,
    enums: constants.BK_LOCATE_ENUMS,
    default: constants.BK_LOCATE_ENUMS.仓库
  },
  // 是否清除
  clear: { type: Boolean, required: true, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 }, { unique: true });
schema.index({ date: -1 });
schema.index({ region: 1 });

module.exports = conn.statistic.model('ss_offline_stock', schema);