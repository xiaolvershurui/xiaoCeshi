const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  // 错误类型
  type: { type: Number, enums: constants.SS_ERROR_TYPE_ENUMS },
  // 报错的错误码
  code: { type: String, required: true },
  // 错误描述
  description: { type: String, required: true },
  // 请求方法
  method: { type: String, required: true },
  // 总共报错次数
  totalCount: { type: Number, default: 0 },
  // 实际报错人数(根据用户去重)
  actualCount: { type: Number, default: 0 },
  // 报错用户
  users: [{
    id: String,
    tel: String,
    ver: String,
    appv: String,
    plat: String,
    mdl: String,
    order: String,
  }],
}, {
  read: 'secondaryPreferred',
});

schema.index({ date: 1, code: 1, method: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_error_in_day', schema);
