const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 开始充电操作
  startCharge: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 结束充电操作
  endCharge: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 分配电池到站
  outbound: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 分发电池到巡检
  dispense: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 接收电池到站
  inbound: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 电池更换到车
  changeToStock: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 电池更换下车
  changeOutStock: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
  // 电池报损
  damage: [{
    operator: String,
    operatorName: String,
    count: { type: Number, default: 0 }
  }],
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_battery_op_in_day', schema);