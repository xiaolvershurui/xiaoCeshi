const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  //小时
  hour: Number,
  // 任务车
  taskCount: Number,
  // 完美
  perfect: Number,
  //投放中
  total: Number,
  // 去向类型
  locateType: {
    // 在租
    inRent: Number,
    // 在库
    inStorage: Number,
    // 内部使用
    interiorUse: Number,
    // 丢失
    lost: Number,
    // 调度
    dispatch: Number,
    // 其他占用
    otherUse: Number,
    // 被扣押
    detained: Number,
    // 待拖回
    backHaul: Number,
    // 疑似丢失
    suspectedLost: Number,
  },
  // 超一天丢失扫码
  lostScanAfterDays: Number,
  // 一天内丢失扫码
  lostScanAfterOneDay: Number,
  // 报废数
  scrapCount: Number,
  // 任务类型
  taskType: {
    // 超一天离线扫码
    offlineScanAfterDays: Number,
    // 超一天无定位扫码车
    noLocationScanAfterDays: Number,
    // 一天内离线扫码
    offlineScanAfterOneDay: Number,
    // 一天内无定位扫码车
    noLocationScanAfterOneDay: Number,
    // 超一天真离线
    realOfflineAfterDays: Number,
    // 超一天疑似离线
    suspectedOfflineAfterDays: Number,
    // 一天内真离线
    realOfflineAfterOneDay: Number,
    // 一天内疑似离线
    suspectedOfflineAfterOneDay: Number,
    // 被盗断电
    powerOffByStolen: Number,
    // 零电断电
    powerOffByNoVoltage: Number,
    // 零电
    noVoltage: Number,
    // 困难换电
    difficultExchange: Number,
    // 无定位
    noLocation: {
      // 故障无定位
      damage: Number,
      // 休眠无定位
      dormancy: Number,
    },
    // 低电
    lowPower: Number,
    // 围栏外非免单
    outSideRegionNoFree: Number,
    // 低压预警
    lowPowerWarn: Number,
    // 高压预警
    highPowerWarn: Number,
    // 高压离线
    highPowerOffline: Number,
    // 司机未找到
    driverNotFound: Number,
    // 高手未找到
    superiorNoFound: Number,
    // 围栏外免单车
    outSideRegionFree: Number,
    // 其他情况
    others: [{
      _id: String,
      isOnline: Boolean,
      noGpsLocation: Boolean,
      voltage: Number,
      outsideRegion: Boolean,
      taskList: [],
      locate: Number,
      stockNo: String,
    }],
  },
}, {
  read: 'secondaryPreferred',
});

schema.index({ createdAt: 1, region: 1 }, { unique: true });
schema.index({ hour: 1 });

module.exports = conn.statistic.model('ss_task_monitor', schema);
