const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  // 大区
  region: { type: String, required: true },
  // 单车租金 24时
  rentPerStock: Number,
  // 投放数 6时
  putOn: Number,
  // 在库数量 6时
  inStation: Number,
  // 可租数量 6时
  enableRent: Number,
  // 禁停区数量 6时
  inForbiddenArea: Number,
  // 24小时未租 6时
  unWakeUp: Number,
  // 免单金额 24时
  freeDiscountAmount: Number,
  // 优惠券减免金额 24时
  freeCouponAmount: Number,
  // 24小时未租车辆被调度 6时
  unWakeUpDispatched: Number
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1, date: -1 }, { unique: true });

module.exports = conn.statistic.model('ss_key_target_in_day', schema);