const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 时间
  date: { type: Date, required: true },
  // 站点
  station: { type: String, required: true },
  // 出库数量
  outboundCount: { type: Number, required: true, default: 0 },
  // 入库带码数量
  inboundCount: { type: Number, required: true, default: 0 },
  // 入库无码数量
  inboundExtraCount: { type: Number, required: true, default: 0 },
}, {
  read: 'nearest',
});

schema.index({ station: 1 });
schema.index({ date: -1 });

module.exports = conn.statistic.model('ss_battery_in_day', schema);
