const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 日期
  date: { type: Date, required: true },
  // 总投放车辆数
  totalStockCount: { type: Number },
  // 平均每公里单价
  mileageUnit: Number,
  // 平均每单里程
  mileagePerOrder: Number,
  // 里程分布表
  mileageDistribution: {},
  // 里程收益表
  mileageWithEarnings: {},
}, {
  read: 'secondaryPreferred',
});

schema.index({ region: 1, date: -1 });

module.exports = conn.statistic.model('ss_change_voltage', schema);
