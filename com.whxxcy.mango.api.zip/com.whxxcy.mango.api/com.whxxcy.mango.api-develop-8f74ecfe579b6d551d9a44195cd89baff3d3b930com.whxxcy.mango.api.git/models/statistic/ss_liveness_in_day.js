const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  //  当日活跃总人数
  totalCount: { type: Number, default: 0 },
  //  活跃天数分布
  freshInterval: {},
  // 注册时间分布
  registerInterval: {},
  // N天后登陆(留存)
  loginRetentionInterval: {},
  // 当日预约数量
  reservationCount: { type: Number, default: 0 },
  // 当日交付押金数量
  depositCount: { type: Number, default: 0 },
  // 当日下达订单数量
  orderCount: { type: Number, default: 0 },
  // 订单留存
  orderRetentionInterval: {},
  // 押金留存
  depositRetentionInterval: {},
  //  预约留存
  reservationRetentionInterval: {},
  // 新增账户留存
  newRegisterUserInterval: {}
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_liveness_in_day', schema);