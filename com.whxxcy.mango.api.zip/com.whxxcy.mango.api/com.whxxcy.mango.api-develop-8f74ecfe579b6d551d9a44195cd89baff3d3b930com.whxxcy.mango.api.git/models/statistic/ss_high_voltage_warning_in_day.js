const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  stock: String,
  lowVoltageTime: Date,
  atSixAM: {
    voltage: Number,
    mileage: Number
  },
  atSixPM: {
    voltage: Number,
    mileage: Number,
    todayMileage: Number,
    orderCount: Number
  },
  atTenPM: {
    voltage: Number,
    mileage: Number,
    todayMileage: Number,
    orderCount: Number
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1, stock: 1 }, { unique: true });
schema.index({ stock: 1 });

module.exports = conn.statistic.model('ss_high_voltage_waring_in_day', schema);