const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  // 充值笔数
  count: { type: Number, default: 0 },
  // 充值金额
  amount: { type: Number, default: 0 },
  // 支付宝充值笔数
  alipayCount: { type: Number, default: 0 },
  // 支付宝充值金额
  alipayAmount: { type: Number, default: 0 },
  // 微信充值笔数
  wxCount: { type: Number, default: 0 },
  // 微信充值金额
  wxAmount: { type: Number, default: 0 },
  // 消费笔数(包括租金+保险)
  consumeCount: { type: Number, default: 0 },
  // 消费金额
  consumeAmount: { type: Number, default: 0 },
  // 24小时以上未使用的未唤醒的 半价车订单收入金额
  halfPriceAmount: { type: Number, default: 0 },
  // 免单笔数
  freeCount: { type: Number, default: 0 },
  // 免单金额
  freeAmount: { type: Number, default: 0 },
  // 今日余额沉淀
  residueAmount: { type: Number, default: 0 },
  // 累计余额沉淀
  totalResidueAmount: { type: Number, default: 0 },
  // 优惠卷减免
  couponDiscount: {
    totalAmount: { type: Number, default: 0 },
    inRegion: [{
      region: String,
      discount: { type: Number, default: 0 }
    }]
  },
  // 优惠券减免分类
  couponDiscountDetail: [{
    name: { type: String },
    count: { type: Number },
    amount: { type: Number }
  }],
  // 停车区减免
  parkingDiscount: {
    totalAmount: { type: Number, default: 0 },
    inRegion: [{
      region: String,
      discount: { type: Number, default: 0 }
    }]
  },
  // 免单减免 (TODO: 与上面通过账单查询免单金额有误差)
  freeDiscount: {
    totalAmount: { type: Number, default: 0 },
    inRegion: [{
      region: String,
      discount: { type: Number, default: 0 }
    }]
  },
  // 馈电损失租金
  feedLoss: {
    totalAmount: { type: Number, default: 0 },
    inRegion: [{
      region: String,
      lowPowerScanCount: {type: Number, default: 0},
      discount: { type: Number, default: 0 }
    }]
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_balance_in_day', schema);
