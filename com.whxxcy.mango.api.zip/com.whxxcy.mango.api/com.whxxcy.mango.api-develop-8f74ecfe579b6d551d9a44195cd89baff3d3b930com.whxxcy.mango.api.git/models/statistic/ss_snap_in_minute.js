const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 车型
  style: String,
  // 日期
  date: { type: Date, required: true },
  // 当天小时
  hour: { type: Number, required: true },
  // 当天分钟
  minute: { type: Number, required: true },
  // 当前车辆
  stock: { type: Object, required: true }
}, {
  shardKey: {
    date: 1,
    hour: 1,
    minute: 1
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, hour: 1, minute: 1, 'stock._id': 1 }, { unique: true });
schema.index({ data: 1, region: 1 });


module.exports = conn.statistic.model('ss_snap_in_minute', schema);