const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 头天二十一点任务量
  taskCountLastDay: { type: Number, default: 0 },
  // 今天早上八点任务量
  taskCountToDay: { type: Number, default: 0 },
  // 处理任务量
  handleTaskCount: { type: Number, default: 0 },
  // 任务增长比例
  taskIncrease: { type: Number, min: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });
schema.index({ date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_task_increase_in_day', schema);
