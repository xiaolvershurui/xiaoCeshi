const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  region: String,
  date: Date,
  // 断电任务 (零电断电、被盗断电) 6
  powerOff: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
  // 离线 (真离线、疑似离线) 5, 14
  offLine: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
  // 高压离线 1108
  highPowerOffline: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
  // 无定位 15
  noLocation: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
  // 司机未找到 18
  driverNotFound: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
  // 扫码车 1402, 502, 1403, 503
  latestScannedAt: [{
    // 车辆任务类型
    type: { type: Number },
    // 车辆 ref
    bikeId: String,
  }],
}, {
  read: 'secondaryPreferred'
});

schema.index({ region: 1 });

schema.plugin(betterId, { connection: conn.statistic });
module.exports = conn.statistic.model('ss_task_divide', schema);

