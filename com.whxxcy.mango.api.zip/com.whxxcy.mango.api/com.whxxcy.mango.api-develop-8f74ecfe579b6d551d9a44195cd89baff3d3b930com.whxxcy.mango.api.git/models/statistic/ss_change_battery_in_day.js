const Schema = require('mongoose').Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 日期
  date: { type: Date, required: true },
  // 总有效换电次数
  totalValidChange: Number,
  // 换电区间
  changeSection: [{
    // 当前电压区间
    start: Number,
    end: Number,
    // 换电数量
    changeCount: Number,
    // 最大里程数
    maxMileage: Number,
    // 最小里程数
    minMileage: Number,
    // 平均行驶里程
    avgMileage: Number,
    // 里程方差
    varMileage: Number,
    // 最小收入
    minIncome: Number,
    // 最大收入
    maxIncome: Number,
    // 平均收入
    avgIncome: Number,
    // 收入方差
    varIncome: Number
  }],
  // 各类型换电比例
  taskSection: {
    // 高压预警任务 (换电前电压47-48.3)
    highVoltageWarning: Number,
    // 低压预警任务 (换电前电压45.8-47)
    lowVoltageWarning: Number,
    // 低电任务 (换电前电压43.5-45.8)
    lowPowerWarning: Number,
    // 骑行断电 (换电前电压41-43.5)
    ridingNoPower: Number,
    // 困难换电 (换电前电压39-41)
    difficultChange: Number,
    //零电(换电前电压39v以下)
    noPower: Number
  }
});

schema.index({ region: 1, date: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_change_battery_in_day', schema);