const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date, required: true },
  // 每日分享的次数
  shareCount: { type: Number, default: 0 },
  // 每日接受邀请的人数
  receiveShareAccount: { type: Number, default: 0 },
  // 邀请成功率
  shareSuccessRate: { type: Number, default: 0 },
  // 每日分享优惠券的使用数
  shareCouponUsed: { type: Number, default: 0 },
  // 每日分享优惠券的使用率
  shareCouponUsedRate: { type: Number, default: 0 },
}, {
  read: 'secondaryPreferred',
});

module.exports = conn.statistic.model('ss_share_in_day', schema);
