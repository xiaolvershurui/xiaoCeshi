const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: String,
  // 日期
  date: { type: Date, required: true },
  // 新用户
  registerCount: { type: Number, default: 0 },
  // 新增实名认证人数
  authorizationCount: { type: Number, default: 0 },
  // 当天充押金人数
  chargeCount: { type: Number, default: 0 },
  // 付费用户
  payUser: {
    // 新用户下单人数
    newUserCount: { type: Number, default: 0 },
    // 老用户下单数
    oldUserCount: { type: Number, default: 0 },
    // 下单一次用户数
    orderOnce: { type: Number, default: 0 },
    // 下单二次用户数
    orderTwice: { type: Number, default: 0 },
    // 下单三次用户数
    orderThrice: { type: Number, default: 0 },
    // 下单四次用户数
    orderQuartic: { type: Number, default: 0 },
    // 下单五次及以上用户数
    orderMoreThenQuintic: { type: Number, default: 0 }
  },
  // 活跃度
  vitality: {
    // 登陆用户数
    loginCount: { type: Number, default: 0 },
    // 一天留存
    stayOneDay: { type: Number, default: 0 },
    // 两天留存
    stayTwoDay: { type: Number, default: 0 },
    // 三天留存
    stayThreeDay: { type: Number, default: 0 },
    // 四天留存
    stayFourDay: { type: Number, default: 0 },
    // 五天留存
    stayFiveDay: { type: Number, default: 0 },
    // 六天留存
    staySixDay: { type: Number, default: 0 },
    // 七天留存
    staySevenDay: { type: Number, default: 0 },
    // 三十天留存
    stayThirtyDay: { type: Number, default: 0 },
    // 九十天留存
    stayNinetyDay: { type: Number, default: 0 },
    // 三百六十天留存
    stayThreeSixtyDay: { type: Number, default: 0 }
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1, region: 1 }, { unique: true });

module.exports = conn.statistic.model('ss_user_in_day', schema);