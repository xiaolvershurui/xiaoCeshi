const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 绑定账户
  user: { type: String, required: true, ref: 'ac_user' },
  // 能否下班
  enableOffDuty: Boolean,
  // 是否启用
  enable: { type: Boolean, default: false, required: true },
  // 当前是否在班
  isWorking: { type: Boolean, default: false, required: true },
  // 工作邮箱
  workEmail: String,
  // 颜色
  color: String,
  // 司机类型
  type: { type: Number, enums: constants.AC_OPERATOR_TYPE_ENUMS },
  // 可见大区列表
  regions: [{ type: String, required: true }],
  // 上次上班时间
  lastCheckInAt: Date,
  // 如果是巡检区分配任务，巡检区ref
  inspectionAreas: [{ type: String }],
  // 快照位置
  location: {
    // 地址
    address: String,
    // 经纬度
    lngLat: { type: [Number] },
    // 快照时间
    snappedAt: Date,
  },
  // 携带电池情况
  batteryBag: {
    enable: { type: Boolean, default: false, required: true },
    // 列表
    batteries: [String],
    // 出发总数
    total: { type: Number, default: 0, required: true },
    // 可用数量
    available: { type: Number, default: 0, required: true },
    // 更换后电池数量
    unavailable: { type: Number, default: 0, required: true },
  },
  // 可以接收的任务组
  acceptTaskGroups: [{ type: Number }],
  isDriver: { type: Boolean, required: true, default: false },
  checkStatus: { type: Number, required: true, default: 3, enums: constants.AC_DRIVER_STATUS_ENUMS },
  accountInfo: {
    // 身份证照片
    idCard: {
      positivePhoto: String,
      negativePhoto: String,
    },
    // 驾驶证照片
    license: {
      positivePhoto: String,
      negativePhoto: String,
    },
    // 手持身份证照片
    cardWithHand: {
      positivePhoto: String,
      negativePhoto: String,
    },
    // 银行卡照片
    bankCard: {
      positivePhoto: String,
      negativePhoto: String,
    },
    // 开户行
    bank: String,
    // 银行账号
    accountNumber: String,
    // 户名
    accountName: String,
    // 头像
    avator: String,
    // 性别
    gender: {
      type: String,
      enums: constants.AC_GENDER_ENUMS,
      default: constants.AC_GENDER_ENUMS[0],
    },
    // 婚否
    hasMarried: Boolean,
    // 住址
    address: String,
  },
  stockInfo: {
    // 车辆类型
    type: {
      type: Number,
      enums: constants.AC_STOCK_TYPE_ENUMS,
    },
    // 车辆照片
    stockPhoto: String,
    // 行驶证照片
    stockLicense: {
      positivePhoto: String,
      negativePhoto: String,
    },
    // 驾驶证有效期
    driverAvailable: Date,
    // 行驶证有效期
    stockAvailable: Date,
    // 车牌号
    number: String,
    // 可出车时间
    enableTime: String,
    // 周出车天数
    outCount: Number,
    // 限行日是否出车
    limit: Boolean,
    // 是否进入二环内
    enableToSecondRing: Boolean,
    // 来源类型
    source: {
      type: Number,
      enums: constants.AC_DRIVER_TYPE_ENUMS,
    },
  },
  // 多余电池
  missCount: { type: Number, default: 0 },
  // 错误换电
  wrongCount: { type: Number, default: 0 },
  // 错误换电的设备
  wrongStock: [{
    stock: String,
    number: String,
    battery: String,
  }],
  // 运营人员类型
  inspectionType: {
    type: Number,
    enums: constants.AC_OPERATOR_INSPECTION_TYPE_ENUMS,
  },
  box: String,
  // 巡检订单 冗余信息
  inspectionOrder: {
    id: String,
    state: Number,
  },
  // 骑行订单 冗余信息
  riderOrder: {
    id: String,
    state: Number,
  },
  // 计价规则
  inspectionPrice: String,
  // 是否展示巡检金额
  showAmount: { type: Boolean, default: true, required: true },
  // 是否需要结算
  needCast: { type: Boolean, default: false, required: true },
  // 是否分配打卡点
  distributePunchArea: { type: Boolean, default: false, required: true },
  // 分配给该巡检人员的打卡点
  punchAreas: { type: [String] },
}, {
  read: 'secondaryPreferred',
});

schema.index({ user: 1 }, { unique: true });
schema.index({ box: 1 });
schema.index({
  enable: 1,
  isWorking: 1,
  regions: 1,
  acceptTaskGroups: 1,
  inspectionAreas: 1,
  'location.lngLat': '2dsphere',
}, { name: 'valid_operators' });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_operator', schema);
