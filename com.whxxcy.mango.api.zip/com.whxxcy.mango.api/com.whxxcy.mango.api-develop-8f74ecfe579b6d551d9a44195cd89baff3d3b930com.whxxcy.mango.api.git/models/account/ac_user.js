const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.Types.ObjectId;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  auth: {
    // 八点到ID （判断是否从八点到迁移过来的）
    bddId: { type: ObjectId },
    // 手机号
    tel: { type: String, required: true },
    // 上次换手机号时间
    lastUpdateTelAt: Date,
    // 微信openid
    wxOpenId: { type: String },
    // 支付宝openid
    alipayOpenId: { type: String },
    // 角色
    roles: { type: [String], default: ['user'] },
    // 额外权限
    permissions: { type: [String], default: [] },
    // 主账号
    primaryUser: { type: String, ref: 'ac_user' },
    // 接受验证码手机号
    verifyTel: String,
    // 密码（用于管理端登陆）
    password: String,
    // 从宝驾注册
    fromBaojia: { type: Boolean, default: false },
  },
  profile: {
    // 昵称
    nickname: { type: String, default: '未设置昵称' },
    // 头像
    avator: { type: String, default: constants.AC_DEFAULT_AVATOR },
    // 性别
    gender: {
      type: String,
      enums: constants.AC_GENDER_ENUMS,
      default: constants.AC_GENDER_ENUMS[0],
    },
  },
  invite: {
    // 邀请码
    code: { type: String },
    // 是否更改过邀请码
    codeHasChanged: { type: Boolean, default: false },
    // 被邀请人
    invitedBy: { type: String, ref: 'ac_user' },
    // 该用户发送邀请的次数
    inviteCount: [{
      time: Date
    }],
    // 是否领取过优惠券
    isReceivedCoupon: { type: Boolean, default: false },
  },
  // 信用分
  credit: { type: Number, default: 100, required: true },
  // 积分
  points: { type: Number, default: 0, required: true },
  // 认证信息
  cert: {
    // 是否通过实名认证
    hasVerified: { type: Boolean, default: false },
    // 实名认证重试时间,每日3次
    triedAt: [Date],
    // 实名认证时间
    verifiedAt: Date,
    // 证件类型
    certType: {
      type: String,
      enums: constants.AC_CERT_TYPE_ENUMS,
      index: true,
    },
    // 证件号码
    certNo: { type: String },
    // 证件照
    certPic: String,
    // 由证件号获得的信息
    certInfo: {
      // 户籍地
      hometown: String,
      birthday: Date,
      gender: {
        type: String,
        enums: constants.AC_GENDER_ENUMS,
      },
    },
    // 真实姓名
    name: { type: String },
  },
  // 快照位置
  location: {
    lngLat: { type: [Number] },
    address: String,
    accuracy: Number,
    administrativeAreaName: String,
    city: String,
  },
  // 账号是否注销
  destroyed: { type: Boolean, default: false },
  // 违章次数
  illegalCount: Number,
  // 成就
  achievement: {
    // 总里程
    mileage: { type: Number, default: 0, required: true },
    // 减少碳排放
    lessCarbonEmission: Number,
  },
  lastLoginAt: Date,
}, {
  read: 'primary',
});

schema.index({ 'auth.tel': 1 }, { unique: true });
schema.index({ 'auth.wxOpenId': 1 }, { unique: true, sparse: true });
schema.index({ 'auth.alipayOpenId': 1 }, { unique: true, sparse: true });
schema.index({ 'invite.code': 1 });
schema.index({ 'cert.name': 1 });
schema.index({ 'auth.primaryUser': 1 });
schema.index({ 'cert.verifiedAt': 1 });
schema.index({ lastLoginAt: -1 });
schema.index({ destroyed: 1, 'cert.certType': 1, 'cert.certNo': 1, 'auth.primary': 1 });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_user', schema);
