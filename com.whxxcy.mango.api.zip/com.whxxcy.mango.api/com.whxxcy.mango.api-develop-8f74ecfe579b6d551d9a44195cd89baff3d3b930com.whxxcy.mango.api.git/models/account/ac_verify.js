const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 手机号
  tel: { type: String, required: true },
  // 验证进度
  step: { type: Number, enums: constants.AC_VERIFY_STEP_ENUMS, required: true, default: constants.AC_VERIFY_STEP.待验证短信验证码 },
  // 图片验证码
  captcha: String,
  // 图片验证码svg
  captchaSVG: String,
  // 验证码
  code: String,
  // 下次可重发时间
  resend: Date,
  // 过期时间
  expires: { type: Date, expires: 0, required: true },
  // 账户验证类型 [获取token，更换手机号]
  type: { type: Number, enums: constants.AC_VERIFY_TYPE_ENUMS, default: constants.AC_VERIFY_TYPE.登录 },
}, {
  read: 'secondaryPreferred'
});

schema.index({ tel: 1 }, { unique: true });
schema.index({ expires: 1 }, { expires: 0 });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_verify', schema);
