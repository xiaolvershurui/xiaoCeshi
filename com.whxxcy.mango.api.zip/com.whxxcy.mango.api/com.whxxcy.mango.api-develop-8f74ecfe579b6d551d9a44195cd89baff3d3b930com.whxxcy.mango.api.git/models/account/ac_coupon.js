const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 状态
  state: {
    type: Number,
    enums: constants.AC_COUPON_STATE_ENUMS,
    default: constants.AC_COUPON_STATE.可使用,
    required: true,
  },
  // 名称
  name: String,
  // 面额
  amount: { type: Number, min: 0, required: true },
  // 账户ref
  user: { type: String, ref: 'ac_user', required: true },
  // 过期时间
  expires: { type: Date, required: true },
  // 类型
  type: {
    type: Number,
    enums: constants.AC_COUPON_TYPE_ENUMS,
    default: constants.AC_COUPON_TYPE.租金抵扣券,
    required: true,
  },
  // 使用日期
  usedAt: { type: Date },
  actualDiscount: Number,
  // 如果是用兑换码兑换的，记录兑换码ID
  couponCode: { type: String },
  // 发放者
  granter: String,
  // 是否系统发放
  isSystem: Boolean,
  // 是否通过分享获取的优惠券(新版分享)
  isGetByShare: { type: Boolean, default: false },
}, {
  read: 'secondaryPreferred',
});

schema.index({ usedAt: 1 });
schema.index({ isSystem: 1 });
schema.index({ user: 1, expires: 1, state: 1, _id: -1 });
schema.index({ createdAt: -1, isGetByShare: 1 });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_coupon', schema);
