const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 账户ref
  user: { type: String, ref: 'ac_user', required: true },
  // 余额
  balance: { type: Number, required: true, default: 0 },
  // 押金信息
  deposit: {
    // 是否缴纳押金
    paid: { type: Boolean, default: false },
    // 已缴纳金额
    amount: { type: Number, min: 0, default: 0, required: true },
    // 退款状态
    state: {
      type: Number,
      enums: constants.FN_DEPOSIT_REFUND_STATE_ENUMS,
      default: constants.FN_DEPOSIT_REFUND_STATE.未缴纳,
      required: true
    },
    // 支付凭据ref
    ticket: { type: String },
    // 如果退款失败，为true
    // refundFailed: { type: Boolean, default: false },
  },
}, {
  read: 'primary'
});

schema.index({ user: 1 }, { unique: true });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_wallet', schema);
