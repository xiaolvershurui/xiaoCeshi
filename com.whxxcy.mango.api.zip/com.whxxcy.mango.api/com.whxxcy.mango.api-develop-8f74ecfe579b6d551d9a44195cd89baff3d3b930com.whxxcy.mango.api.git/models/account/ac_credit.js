const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 账户ref
  user: { type: String, ref: 'ac_user', required: true },
  // 名称项目
  name: { type: String, required: true },
  // 类型
  type: {
    type: Number,
    enums: constants.AC_CREDIT_RECORD_TYPE_ENUMS,
    default: constants.AC_CREDIT_RECORD_TYPE.加分,
    required: true,
  },
  // 订单
  order: String,
  // 分额
  point: { type: Number, required: true },
  // 申诉信息
  appeal: {
    // 是否已经申诉
    appealed: { type: Boolean, default: false },
    // 申诉时间
    appealedAt: Date,
    // 申诉结果
    result: {
      type: Number,
      enums: constants.OP_CREDIT_APPEAL_RESULT_ENUMS,
    },
    // 通过时间
    passedAt: Date,
    // 驳回时间
    rejectedAt: Date,
    // 驳回原因
    rejectReason: String,
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ user: 1 });
schema.index({ type: 1, user: 1, _id: -1 });

schema.plugin(betterId, { connection: conn.account });
module.exports = conn.account.model('ac_credit', schema);