const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 开发账户ref
  developer: { type: String, required: true },
  // 名称
  name: { type: String, required: true },
  // 密钥
  secretKey: { type: String, required: true },
  // 鉴权方法
  authMethod: { type: Number, required: true, enums: constants.CL_APP_AUTH_METHOD_ENUMS },
  // 是否启用
  enable: { type: Boolean, required: true, default: false },
  // 服务
  service: {
    // 转发服务
    forwarding: {
      // 是否启用转发服务
      enable: { type: Boolean, default: false },
      // 转发网关
      forwardGate: String,
    },
    // 开放订单
    openOrder: {
      // 是否启用
      enable: { type: Boolean, default: false },
      // 开放的大区
      regions: [String]
    }
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ name: 1 }, { unique: 1 });

schema.index({
  enable: 1,
  'service.forwarding.enable': 1,
  'service.forwarding.forwardGate': 1,
});

schema.plugin(betterId, { connection: conn.cloud });
module.exports = conn.cloud.model('cl_app', schema);