const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 账户
  user: { type: String, required: true },
  // 实体名称（企业或个人）
  name: { type: String, required: true },
  // 认证资料 TODO: 待添加
  cert: {},
  // 联系方式
  contact: {
    // 关键联系人
    important: {
      tel: { type: String, required: true },
      name: { type: String, required: true },
      email: { type: String, required: true }
    }
  },
  // 是否可用
  enable: { type: Boolean, default: false, required: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ user: 1 }, { unique: true });


schema.plugin(betterId, { connection: conn.cloud });
module.exports = conn.cloud.model('cl_developer', schema);