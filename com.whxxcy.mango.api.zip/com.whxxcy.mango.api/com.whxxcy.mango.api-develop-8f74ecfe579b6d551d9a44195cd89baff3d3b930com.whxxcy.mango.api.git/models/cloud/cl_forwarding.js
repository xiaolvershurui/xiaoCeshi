const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 开发账户ref
  developer: { type: String, required: true, ref: 'cl_developer' },
  // 应用ref
  app: { type: String, required: true, ref: 'cl_app' },
  // 车辆ref
  stock: { type: String, required: true },
}, {
  read: 'secondaryPreferred'
});

schema.index({
  developer: 1,
  app: 1,
  stock: 1
});

schema.plugin(betterId, { connection: conn.cloud });
module.exports = conn.cloud.model('cl_forwarding', schema);