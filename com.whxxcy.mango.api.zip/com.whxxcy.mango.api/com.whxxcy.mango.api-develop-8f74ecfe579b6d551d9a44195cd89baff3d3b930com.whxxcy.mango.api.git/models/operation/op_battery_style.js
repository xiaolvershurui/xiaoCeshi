const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 名称
  name: { type: String, required: true },
  // 适配车型
  stockStyles: [String],
}, {
  read: 'secondaryPreferred',
});

schema.index({ enable: true });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_battery_style', schema);
