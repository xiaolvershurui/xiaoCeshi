const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 名称
  name: { type: String, required: true },
  // 所属城市
  city: { type: String, required: true, enums: constants.ST_CITIES_ENUMS },
  // 大区围栏
  path: { type: Schema.Types.Polygon, required: true },
  // 大区拥有者 大区账户ref
  owner: { type: String },
  // 大区管理员们
  managers: [{ type: String }],
  // 是否是工厂
  isFactory: { type: Boolean, default: false },
  // 车型定价配置 数组索引号即为level号
  prices: [{
    // 时间单价 元/分钟
    timeUnit: { type: Number, min: 0, required: true },
    // 里程单价 元/公里
    mileageUnit: { type: Number, min: 0, required: true },
    // 最低消费 元
    floorCost: { type: Number, min: 0, required: true },
    // 是否开通保险服务
    enableInsurance: { type: Boolean, required: true },
    // 保费
    insurance: { type: Number, min: 0, required: true },
    // 停车区停车折扣率
    parkingRate: { type: Number, min: 0, max: 1, required: true, default: 0.5 },
    // 日封顶
    dayCeilingCost: { type: Number, min: 0, required: true },
    // 夜封顶
    nightCeilingCost: { type: Number, min: 0, required: true },
  }],
  // 录入车辆时默认选项
  isDefault: { type: Boolean, default: false },
  // 建议今晚最佳换电电压
  recommendChangeBatteryVoltage: Number,
  // 确定的换电电压（低电预警电压）
  changeBatteryVoltage: { type: Number, default: constants.BK_VERY_LOW_POWER_WARNING_VOLTAGE },
  // 是否停租
  offHire: { type: Boolean, default: false },
  // 停租原因
  offHireDescription: String,
  // 公告
  announcement: {
    title: String,
    content: String,
    // 落款日期 2018.03.23
    inscribeDate: String,
  },
  // 运营模式
  operationPattern: { type: Number, enums: constants.OP_REGION_PATTERN_ENUMS, default: constants.OP_REGION_PATTERN.可停不收费 },
  // 调度费用
  dispatchCost: { type: Number, default: 0, required: true },
  // 使用停车区类型
  parkingPattern: { type: Number, enums: constants.OP_REGION_PARKING_PATTERN_ENUMS, default: constants.OP_REGION_PARKING_PATTERN.旧停车区 },
  // 停车区优惠信息
  parkingDiscount: {
    rate: { type: Number, default: 0.5 },
    content: { type: String, default: '半价' },
  },
  // 车辆搜索半径
  stockSearchRadius: { type: Number, default: 200 },
  parkingLotRadius: { type: Number, default: 10, required: true },
}, {
  read: 'secondaryPreferred',
});

schema.index({ enable: 1, path: '2dsphere' });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_region', schema);
