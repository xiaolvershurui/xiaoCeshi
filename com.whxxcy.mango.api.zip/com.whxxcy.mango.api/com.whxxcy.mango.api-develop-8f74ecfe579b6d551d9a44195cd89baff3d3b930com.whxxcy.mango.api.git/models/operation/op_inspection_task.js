const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 车辆ref
  stock: { type: String, required: true },
  // 大区ref
  region: { type: String },
  // 任务类型
  type: { type: Number, required: true, enums: constants.OP_INSPECTION_TASK_TYPE_ENUMS },
  // 是否完成
  processed: { type: Boolean, required: true, default: false },
  // 处理人 为空则为系统处理
  processor: { type: String },
  // 处理时间
  processedAt: { type: Date },
  // 任务权值
  rate: { type: Number, min: 0, default: 0, required: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ type: 1, stock: 1, createdAt: -1 });
schema.index({ processed: 1, stock: 1, type: 1 });


schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_inspection_task', schema);