const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 名称
  name: { type: String, required: true },
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 地理位置
  location: {
    // 城市
    city: { type: String, enums: constants.ST_CITIES_ENUMS, required: true },
    // 行政区
    area: { type: String, required: true },
    // 街道地址
    address: String,
    // 经纬度
    lngLat: { type: [Number], required: true },
  },
  // 容量
  capacity: {
    // 充电口总数量
    totalChargePort: { type: Number, min: 0, default: 0, required: true },
    // 可存放电池数量
    totalBatteryStorage: { type: Number, min: 0, default: 0, required: true },
    // 可存放车辆数量
    totalBikeStorage: { type: Number, min: 0, default: 0, required: true },
    // 占用充电口数量
    usingChargePort: { type: Number, min: 0, default: 0, required: true },
    // 占用电池存放空间数量
    usingBatteryStorage: { type: Number, min: 0, default: 0, required: true },
    // 占用的车辆存放空间数量
    usingBikeStorage: { type: Number, min: 0, default: 0, required: true },
    // 剩余充电口数量
    remainChargePort: { type: Number, min: 0, default: 0, required: true },
    // 剩余电池存放空间
    remainBatteryStorage: { type: Number, min: 0, default: 0, required: true },
    // 剩余车辆存放空间数量
    remainBikeStorage: { type: Number, min: 0, default: 0, required: true },
  },
  // 携带电池情况
  batteryBag: {
    // 列表
    batteries: [String],
    // 总数
    total: { type: Number, default: 0, min: 0, required: true },
    // 可用数量
    available: { type: Number, default: 0, min: 0, required: true },
    // 不可用数量
    unavailable: { type: Number, default: 0, min: 0, required: true },
  },
  // 存放车辆情况
  bikeBag: {
    // 列表
    bikes: [String],
  }
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_station', schema);