const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 创建人
  creator: { type: String, required: true },
  // 位置信息
  location: {
    // 国际坐标
    geometry: Schema.Types.Point,
    // 国测局坐标
    gcj02Geometry: Schema.Types.Point,
  },
  // 图片
  photo: { type: String, required: true },
  // 是否删除
  removed: { type: Boolean, default: false, required: true },
  // 照片绑定的停车区
  parkingLot: String,
  // 朝向
  heading: Number,
  // 照片类型 0停车点  1摆车照
  type: { type: Number, default: 0, required: true },
  // 摆放前后
  processed: Boolean,
  // 地址
  address: String,
}, {
  read: 'nearest',
});

schema.index({ 'location.geometry': '2dsphere' });
schema.index({ 'location.gcj02Geometry': '2dsphere' });
schema.index({ parkingLot: 1 });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_photo_to_point', schema);
