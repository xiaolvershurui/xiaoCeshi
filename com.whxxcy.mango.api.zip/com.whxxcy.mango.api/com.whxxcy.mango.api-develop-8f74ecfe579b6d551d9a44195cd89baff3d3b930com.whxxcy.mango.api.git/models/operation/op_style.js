const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 名称
  name: { type: String, required: true },
  // 车型编号
  number: { type: String, required: true },
  // 缩略图
  thumbnail: { type: String, required: true },
  // 分级
  level: { type: Number, enums: constants.OP_STYLE_LEVEL_ENUMS, required: true },
  // 最大续航里程
  maxMileage: { type: Number, required: true },
  // 电池额定电压
  ratedVoltage: { type: Number, enums: constants.BK_RATED_VOLTAGE_ENUMS, required: true },
  // 录入车辆时默认选项
  isDefault: { type: Boolean, default: false },
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_style', schema);