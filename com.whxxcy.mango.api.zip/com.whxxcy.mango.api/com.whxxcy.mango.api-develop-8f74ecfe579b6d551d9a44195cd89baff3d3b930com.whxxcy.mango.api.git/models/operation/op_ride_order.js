const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 账户信息
  user: {
    id: { type: String, required: true },
    name: String,
    tel: String,
    avator: String,
    // 运营账户ref
    operator: String,
    // 巡检人员类型
    type: { type: Number },
    // 运营人员类型
    inspectionType: { type: Number },
    // 巡检车类型
    // carType: Number,
    // 运营人员来源
    // source: Number,
    // 调度能力
    dispatchAbility: { type: Number, default: 0 },
  },
  // 订单状态
  state: {
    type: Number,
    required: true,
    default: constants.OP_RIDER_ORDER_STATE.派单中,
    enums: constants.OP_RIDER_ORDER_STATE_ENUMS,
  },
  // 已巡检的车辆列表
  inspectedStocks: [{
    // 车辆ID
    id: String,
    // 车牌号
    bikeNo: String,
    // 车机号
    box: String,
    // 初次打卡电压
    prevVoltage: Number,
    // 末次打卡电压
    nextVoltage: Number,
    // 开始巡检任务快照
    prevTaskList: [],
    // 开始巡检时间
    startedAt: Date,
    // 最终任务快照
    lastTaskList: [],
    // 是否找到
    hasFound: Boolean,
    // 电池锁状态
    isBatteryLock: Boolean,
    // 难寻巡检数
    isHardToFind: Boolean,
    // 是否难寻找到
    isHardToFindButFound: Boolean,
    // 离线巡检数
    isOffline: Boolean,
    // 是否离线找到
    isOfflineButFound: Boolean,
    // 断电巡检数
    isPowerOff: Boolean,
    // 是否断电找到
    isPowerOffButFound: Boolean,
    // 挪车唤醒任务
    isMoveAndWakeUp: Boolean,
    // 其他任务
    otherFinished: Boolean,
    // 结束巡检时间
    finishedAt: Date,
    // 是否有效任务
    isValidTask: Boolean,
    // 车辆最后位置
    lastLocate: Number,
    // 车辆上一次位置
    prevLocate: Number,
    // 是否是自己的任务
    isSelfTask: Boolean,
    // 打卡图片展示
    findStockPhoto: String,
    // 是否审核通过
    isPassed: { type: Boolean, default: true, required: true },
    // 是否是拖回
    isReturnedBack: { type: Boolean, default: false },
    // 是否是投放
    isPutOn: { type: Boolean, default: false },
    // 是否是回栏
    isBackIntoRegion: { type: Boolean, default: false },
    // 是否是换电
    isExchangedBattery: { type: Boolean, default: false },
    // 是否是普通
    isNormal: { type: Boolean, default: false },
    // 奖金
    bonus: { type: Number, default: 0 },
  }],
  // 未修正的未巡检车辆
  unFixedUnInspectedStocks: [{
    // 车辆ID
    id: String,
    // 该车辆和未完成的紧急任务
    urgentTask: [{
      // 任务编号
      code: Number,
      // 任务产生时间
      issuedAt: Date,
    }],
    // 是否扣费
    isDeduct: { type: Boolean, default: true },
  }],
  // 未巡检车辆
  unInspectedStocks: [{
    // 车辆ID
    id: String,
    // 该车辆和未完成的任务
    urgentTask: [{
      // 任务编号
      code: Number,
      // 任务产生时间
      issuedAt: Date,
    }],
    // 是否扣费
    isDeduct: { type: Boolean, default: true },
  }],
  // 巡检轨迹
  path: Schema.Types.LineString,
  // 路线信息
  route: {
    // 上班路程
    onDuty: {
      // 上班开始时间
      startedAt: Date,
      // 上班结束时间
      finishedAt: Date,
      // 距离
      distance: Number,
      // 小时点密度
      pph: Number,
      // 轨迹点
      path: {
        ts: [Date],
        coordinates: [Array],
      },
    },
    // 巡检路程
    inInspection: {
      // 巡检开始时间
      startedAt: Date,
      // 巡检结束时间
      finishedAt: Date,
      // 距离
      distance: Number,
      // 小时点密度
      pph: Number,
      //轨迹点
      path: {
        ts: [Date],
        coordinates: [Array],
      },
    },
    // 下班路程
    offDuty: {
      // 下班开始时间
      startedAt: Date,
      // 下班结束时间
      finishedAt: Date,
      // 距离
      distance: Number,
      // 小时点密度
      pph: Number,
      // 轨迹点
      path: {
        ts: [Date],
        coordinates: [Array],
      },
    },
  },
  // 统计巡检数据
  statistic: {
    // 巡检总数
    total: Number,
    // 找到数
    found: Number,
    // 难寻巡检数
    hardToFind: Number,
    // 难寻找到数
    hardToFindButFound: Number,
    // 难寻未找到数
    hardToFindButNotFound: Number,
    // 离线巡检数
    offline: Number,
    // 离线找到数
    offlineButFound: Number,
    // 离线未找到数
    offlineButNotFound: Number,
    // 断电巡检数
    powerOff: Number,
    // 断电找到数
    powerOffButFound: Number,
    // 断电未找到数
    powerOffButNotFound: Number,
    // 挪车唤醒找到数
    moveAndWakeUp: Number,
    // 其他任务找到数
    otherFinished: Number,
    // 丢失电池数
    lostBattery: Number,
    // 巡检距离
    mileage: Number,
    // 未完成任务任务组分布
    unfinished: {},
    // 拖回数
    returnBack: Number,
    // 换电数
    exchangeBattery: Number,
    // 回栏数
    backIntoRegion: Number,
    // 投放数
    putOn: Number,
    // 普通数
    normal: Number,
    // 未完成拖回数
    returnBackUnfinished: Number,
    // 错误换电数
    wrongChange: Number,
  },
  // 统计巡检数据
  fixedStatistic: {
    // 巡检总数
    total: Number,
    // 找到数
    found: Number,
    // 难寻巡检数
    hardToFind: Number,
    // 难寻找到数
    hardToFindButFound: Number,
    // 难寻未找到数
    hardToFindButNotFound: Number,
    // 离线巡检数
    offline: Number,
    // 离线找到数
    offlineButFound: Number,
    // 离线未找到数
    offlineButNotFound: Number,
    // 断电巡检数
    powerOff: Number,
    // 断电找到数
    powerOffButFound: Number,
    // 断电未找到数
    powerOffButNotFound: Number,
    // 挪车唤醒找到数
    moveAndWakeUp: Number,
    // 其他任务找到数
    otherFinished: Number,
    // 丢失电池数
    lostBattery: Number,
    // 巡检距离
    mileage: Number,
    // 未完成任务任务组分布
    unfinished: {},
    // 拖回数
    returnBack: Number,
    // 换电数
    exchangeBattery: Number,
    // 回栏数
    backIntoRegion: Number,
    // 投放数
    putOn: Number,
    // 普通数
    normal: Number,
    // 未完成拖回数
    returnBackUnfinished: Number,
    // 错误换电数
    wrongChange: Number,
  },
  payment: {
    // 计费项目
    projects: [{
      name: String,
      count: Number,
    }],
  },
  // 关键时间
  times: {
    // 上班时间
    startedAt: Date,
    // 截单时间
    stoppedAt: Date,
    // 订单结束时间
    finishedAt: Date,
    // 审核时间
    auditedAt: Date,
    // 首次巡检开始时间
    firstInspectionStartedAt: Date,
    // 首次摆车时间
    firstPlaceStartedAt: Date,
    // 最后一次巡检结束时间
    lastInspectionFinishedAt: Date,
    // 最后一次摆车时间
    lastPlaceFinishedAt: Date,
    // 轧账时间
    checkedAt: Date,
    // 结算时间
    settledAt: Date,
    // 下班时间
    finishInspectionAt: Date,
  },
  // 审核人
  auditor: String,
  // 审核备注
  remark: String,
  // 运营人员绑定的盒子号
  box: String,
  // 车辆摆放前照片
  stockPlacePhotos: [],
  // 摆放车辆数量
  stockPlaceCount: { type: Number, default: 0 },
  // 摆放数及里程
  // 摆放车辆
  placeStocks: [String],
  // 审核
  audit: [{
    // 提交订单审核时间
    submitAuditedAt: Date,
    // 提交审核原因
    submitReason: String,
    // 审核时间
    auditedAt: Date,
    // 审核人
    auditor: String,
    // 未巡检审核结果
    unInspectedComment: String,
    // 已巡检审核结果
    inspectedComment: String,
    // 审核类型
    auditType: { type: Number, enums: constants.OP_INSPECTION_ORDER_AUDIT_TYPE_ENUMS },
  }],
  // 当前是否是第二次审核
  finalCommit: { type: Boolean, default: false },
  // 审核类型
  auditType: { type: Number, enums: constants.OP_INSPECTION_ORDER_AUDIT_TYPE_ENUMS },
  // 奖金总数
  sumBonus: { type: Number, default: 0 },
  // 车辆与对应的奖励
  bonusWithStocks: [{
    stock: String,
    bonus: Number,
  }]
}, {
  read: 'nearest',
});

schema.index({ 'user.id': 1, state: 1 });
schema.index({ 'user.name': 1 });
schema.index({ 'user.tel': 1 });
schema.index({ 'region': 1 });
schema.index({ 'createdAt': 1 });
schema.index({ state: 1, region: 1 });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_rider_order', schema);
