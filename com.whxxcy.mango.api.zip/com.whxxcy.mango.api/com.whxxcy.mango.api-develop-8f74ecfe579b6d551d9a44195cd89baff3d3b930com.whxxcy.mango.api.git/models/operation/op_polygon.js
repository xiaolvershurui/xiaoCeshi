const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 名称
  name: { type: String, default: '未命名' },
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 创建人
  creator: { type: String },
  // 类型
  type: {
    type: Number,
    required: true,
    default: constants.OP_POLYGON_TYPE.无类型,
    enums: constants.OP_POLYGON_TYPE_ENUMS,
  },
  // 社区类型
  neighborhood: {
    type: Number,
    required: true,
    default: constants.OP_POLYGON_NEIGHBORHOOD.无类型,
    enums: constants.OP_POLYGON_NEIGHBORHOOD_ENUMS,
  },
  location: {
    // 城市
    city: { type: String, enums: constants.ST_CITIES_ENUMS, required: true },
    // 行政区
    area: { type: String, required: true },
    // 街道地址
    address: String,
    // 经纬度
    lngLat: { type: [Number], required: true },
  },
  // 围栏
  path: { type: Schema.Types.Polygon, required: true },
  // 额外点
  extraPoints: [{
    lngLat: [Number],
    address: String
  }],
  // 方向线
  directionLine: {
    type: Schema.Types.LineString
  },
  // polygon状态，锁定状态将不能进行编辑
  state: { type: Number, default: constants.OP_POLYGON_STATE.待审, enums: constants.OP_POLYGON_STATE_ENUMS },
  // 返工原因
  reworkReasons: [{ type: Number, enums: constants.OP_POLYGON_REWORK_REASON_ENUMS }],
  // 修改建议
  proposedChanges: String,
  // 审核人
  reviewer: { type: String },
  // 审核日期
  reviewedAt: { type: Date},
  // 订单经过次数(禁停区)
  matchCount: Number,
  // 是否被清除
  isCleaned: { type: Boolean, default: false, required: true }
}, {
  read: 'nearest'
});

schema.index({ 'location.lngLat': '2dsphere' });
schema.index({ type: 1, 'location.lngLat': '2dsphere' });
schema.index({ type: 1, path: '2dsphere' });
schema.index({ creator: 1, state: 1 });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_polygon', schema);
