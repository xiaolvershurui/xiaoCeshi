const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 图片
  photos: [String],
  // 内容
  description: { type: String, required: true },
  // 处理状态
  state: {
    type: Number,
    required: true,
    enums: constants.OP_REPORT_STATE_ENUMS,
    default: constants.OP_REPORT_STATE.待处理
  },
  // 反馈时间
  feedbackAt: Date,
  // 处理人
  processor: { type: String },
  // 处理时间
  processedAt: Date,
  // 处理结果（内部使用的备注信息）
  result: String,
  // 回复用户的内容
  reply: String
}, {
  read: 'secondaryPreferredsecondaryPreferred'
});

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_feedback', schema);