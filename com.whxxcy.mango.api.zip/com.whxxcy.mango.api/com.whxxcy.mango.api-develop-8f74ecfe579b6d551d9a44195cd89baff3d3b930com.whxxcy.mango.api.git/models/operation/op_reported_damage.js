const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 车辆编号
  bikeNo: String,
  // 车辆ref
  bike: String,
  // 问题类型
  type: { type: Number, enums: constants.OP_REPORTED_DAMAGES_TYPE_ENUMS, required: true },
  // 如果是损坏，损坏的信息
  damageDetail: { type: Number, enums: constants.OP_REPORTED_DAMAGES_DETAIL_ENUMS },
  // 用户定位信息
  userLocation: {
    // 经纬度
    lngLat: { type: [Number] },
    // 地址
    address: String
  },
  // 照片
  photos: [String],
  // 详细描述
  description: String,
  // 上报人 账户ref
  reporter: { type: String, required: true },
  // 状态
  state: {
    type: Number,
    enums: constants.OP_REPORTED_DAMAGES_STATE_ENUMS,
    default: constants.OP_REPORTED_DAMAGES_STATE.待处理,
    required: true
  },
  // 上报时间
  reportedAt: { type: Date, required: true },
  // 处理人
  processor: { type: String },
  // 处理时间
  processedAt: { type: Date },
  // 处理结果
  result: { type: Number, enums: constants.OP_REPORTED_DAMAGES_RESULT_ENUMS },
  // 处理结果备注
  remark: String,
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_reported_damage', schema);