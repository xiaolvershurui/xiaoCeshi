const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 用户姓名
  userName: { type: String },
  // 用户手机号
  userTel: { type: String },
  // 订单快照
  order: {},
  // 车辆快照
  stock: {},
  // 设备信息
  deviceInfo: {},
  // 车辆或订单的大区
  region: { type: String },
  // 类型
  type: { type: Number, enums: constants.OP_WORK_ORDER_TYPE_ENUMS, required: true },
  // 图片
  photos: [String],
  // 描述
  description: { type: String, required: true },
  // 处理状态
  processed: { type: Boolean, default: false },
  // 处理人
  processor: { type: String },
  // 处理时间
  processedAt: { type: Date },
  // 反馈描述
  reply: String,
  // 起因（内部可见）
  reason: String,
  // 处理耗时 (毫秒数)
  timeCost: { type: Number },
  // 是否已评价
  commented: { type: Boolean, default: false },
  // 评价时间
  commentedAt: { type: Date },
  // 评价结果
  commentResult: { type: Number, enums: constants.OP_WORK_ORDER_COMMENT_RESULT_ENUMS },
}, {
  shardKey: {
    _id: 'hashed'
  },
  read: 'secondaryPreferred'
});

schema.index({ _id: 'hashed' });
schema.index({ userTel: 1 });
schema.index({ user: 1, _id: -1 });
schema.index({ createdAt: 1 });
schema.index({ createdAt: 1, type: 1, processed: 1 });
schema.index({ 'stock.number.custom': 1, _id: -1 });
schema.index({ processed: 1, user: 1, userName: 1, userTel: 1, 'stock._id': 1 });
schema.index({ processedAt: 1 });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_work_order', schema);
