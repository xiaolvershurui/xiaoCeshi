const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  //大区 ref
  region: { type: String, required: true },
  //名称
  name: { type: String, required: true },
  // 在外电池数
  outCount: { type: Number, required: true, default: 0 },
  // 发出车辆数
  outStockCount: { type: Number, required: true, default: 0 },
  //启用状态
  enable: { type: Boolean, default: false },
  //负责人 ref
  director: { type: String, required: true },
  // 可用库管
  storeManagers: [String],
  // 类型
  type: {
    type: Number,
    enums: constants.OP_BATTERY_STATION_TYPE_ENUMS,
    default: constants.OP_BATTERY_STATION_TYPE.中转仓
  },
  // 地址
  location: {
    // 地址
    address: String,
    // 经纬度
    lngLat: { type: [Number], index: '2dsphere' },
  },
}, {
  read: 'secondaryPreferred'
});

schema.index({ storeManagers: 1 });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_battery_station', schema);