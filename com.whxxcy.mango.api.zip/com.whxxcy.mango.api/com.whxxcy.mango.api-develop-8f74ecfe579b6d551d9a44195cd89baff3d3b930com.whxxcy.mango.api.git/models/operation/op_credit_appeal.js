const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 信用记录ref
  credit: { type: String, required: true },
  // 申诉缘由
  reason: { type: String, required: true },
  // 账户ref
  user: { type: String, required: true },
  // 图片
  photos: [String],
  // 订单
  order: String,
  // 处理状态
  state: {
    type: Number,
    required: true,
    enums: constants.OP_CREDIT_APPEAL_STATE_ENUMS,
    default: constants.OP_CREDIT_APPEAL_STATE.待处理
  },
  // 申诉时间
  appealedAt: Date,
  // 申诉结果
  result: {
    type: Number,
    enums: constants.OP_CREDIT_APPEAL_RESULT_ENUMS,
  },
  // 处理人
  processor: String,
  // 通过时间
  passedAt: Date,
  // 通过备注
  passRemark: String,
  // 驳回时间
  rejectedAt: Date,
  // 驳回原因
  rejectReason: String
}, {
  read: 'secondaryPreferred'
});

schema.index({ credit: 1 }, { unique: true });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('op_credit_appeal', schema);