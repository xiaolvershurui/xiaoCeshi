const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

// 地理信息考察点

const schema = new Schema({
  // 名称
  name: { type: String, default: '未命名' },
  // 备注
  remark: String,
  // 类型 0 起点  1 路径点  2 终点
  type: { type: Number, enums: [0, 1, 2], required: true },
  // 种类 0 禁停区采集点  1 可停区采集点
  category: { type: Number, enums: [0, 1], required: true },
  // 采集人id  ref user
  user: { type: String, required: true },
  // 定位
  lngLat: [Number],
}, {
  read: 'secondaryPreferred',
});

schema.index({ type: 1 });
schema.index({ category: 1 });
schema.index({ user: 1 });
schema.index({ lngLat: '2dsphere' });

module.exports = conn.operation.model('op_geo_inspection_point', schema);
