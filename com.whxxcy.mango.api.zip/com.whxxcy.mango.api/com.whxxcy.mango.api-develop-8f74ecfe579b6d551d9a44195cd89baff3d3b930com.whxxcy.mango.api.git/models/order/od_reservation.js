const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 用户ref
  user: { type: String, required: true },
  // 预约车辆 车辆ref
  stock: { type: String, required: true },
  // 盒子ref
  box: { type: String, required: true },
  // 盒子数据源
  boxDataSource: {
    type: Number,
    required: true,
    enums: constants.BK_BOX_DATA_SOURCE_ENUMS,
  },
  // 大区ref
  region: { type: String, required: true },
  // 车型ref
  style: { type: String, required: true },
  // 车型level
  styleLevel: { type: Number, required: true, enums: constants.OP_STYLE_LEVEL_ENUMS },
  // 预约状态
  state: {
    type: Number,
    required: true,
    enums: constants.OD_RESERVATION_STATE_ENUMS,
    default: constants.OD_RESERVATION_STATE.预约中,
  },
  // 开始预约时间
  reservedAt: { type: Date, required: true },
  // 预约过期时间
  expires: { type: Date, required: true },
  // 取消预约时间
  cancelledAt: { type: Date },
  // 取消原因
  cancelReason: {
    type: Number,
    enums: constants.OD_RESERVATION_CANCEL_REASON_ENUMS,
  },
  // 结束预约时间
  finishedAt: { type: Date },
  // 宝驾信息
  baojia: {
    isBaojia: { type: Boolean, default: false },
    // 宝驾订单号
    id: String,
  },
  // 预约时 是否免单
  isFree: Boolean,
  // 预约时车辆位置
  stockLocation: {
    lngLat: [Number],
    lastGpsLocatedAt: Date,
  },
}, {
  shardKey: {
    _id: 'hashed',
  },
  read: 'primary',
});

schema.index({ _id: 'hashed' });
schema.index({ state: 1, user: 1, stock: 1 });
schema.index({ 'baojia.id': 1 }, { unique: true, sparse: true });
schema.index({ user: 1, reservedAt: -1 });
schema.index({ createdAt: 1, region: 1, style: 1 });
schema.plugin(betterId, { connection: conn.order });
module.exports = conn.order.model('od_reservation', schema);
