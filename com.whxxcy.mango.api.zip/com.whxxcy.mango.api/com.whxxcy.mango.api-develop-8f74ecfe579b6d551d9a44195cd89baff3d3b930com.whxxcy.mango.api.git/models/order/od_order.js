const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 用户 ref
  user: { type: String, required: true },
  // 车辆ref
  stock: { type: String, required: true },
  // 车辆车牌号
  stockNo: { type: String, required: true },
  // 盒子ref
  box: { type: String, required: true },
  // 盒子数据源
  boxDataSource: {
    type: Number,
    required: true,
    enums: constants.BK_BOX_DATA_SOURCE_ENUMS,
  },
  // 大区ref
  region: { type: String, required: true },
  // 车型ref
  style: { type: String, required: true },
  // 车型level
  styleLevel: { type: Number, required: true, enums: constants.OP_STYLE_LEVEL_ENUMS },
  // 预约ref 如果预约成功并且使用了预约的车辆则记录预约订单
  reservation: { type: String, ref: 'od_reservation' },
  // 订单状态
  state: {
    type: Number,
    required: true,
    enums: constants.OD_ORDER_STATE_ENUMS,
    default: constants.OD_ORDER_STATE.租用中,
  },
  // 坏订单
  isBad: { type: Boolean },
  // 租期
  lease: {
    // 下单时间
    startTime: { type: Date, required: true },
    // 归还时间/快照时间
    endTime: { type: Date },
    // 使用时长 分钟
    totalDuration: { type: Number, min: 0, default: 0, required: true },
    // 白天使用时长
    dayDuration: { type: Number, min: 0, default: 0, required: true },
    // 夜间使用时长
    nightDuration: { type: Number, min: 0, default: 0, required: true },
  },
  // 路线信息
  route: {
    // 取车地点
    start: {
      address: String,
      lngLat: { type: [Number] },
      // 启动时距离围栏距离
      distanceWithRegionPath: Number,
      // 启动时距离禁行区的距离
      distanceWithProhibitedArea: Number,
      // 启动时距离禁停区的距离
      distanceWithForbiddenArea: Number,
      // 启动时距离停车区的距离
      distanceWithPark: Number,
      // 开始时停车区
      parkingLot: String,
    },
    // 还车地点/快照地点
    end: {
      address: String,
      lngLat: { type: [Number] },
      // 结束时距离围栏距离
      distanceWithRegionPath: Number,
      // 结束时距离禁行区的距离
      distanceWithProhibitedArea: Number,
      // 结束时距离禁停区的距离
      distanceWithForbiddenArea: Number,
      // 启动时距离停车区的距离
      distanceWithPark: Number,
      // 结束时停车区
      parkingLot: String,
      // 结束时附近的停车区(50m)
      nearParkingLots: [],
    },
    // 用户起始快照点
    userStartCapture: {
      address: String,
      lngLat: [Number],
      accuracy: Number,
    },
    // 用户的快照点
    userCapture: {
      address: String,
      lngLat: [Number],
      accuracy: Number,
    },
    // 取车时的车辆总里程
    startMileage: { type: Number, min: 0, required: true },
    // 还车/快照时的车辆总里程
    endMileage: { type: Number, min: 0 },
    // 骑行里程
    distance: { type: Number, min: 0, default: 0, required: true },
    // 上次更新骑行里程的时间
    latestUpdatedDistanceAt: { type: Date },
    // 计费里程数
    calculateDistance: { type: Number, min: 0, default: 0, required: true },
    // 取车时的总相位里程
    startPhaseMileage: { type: Number, min: 0, default: 0 },
    // 快照时的总相位里程
    endPhaseMileage: { type: Number, min: 0, default: 0 },
    // 相位里程差
    phaseMileage: { type: Number, min: 0, default: 0 },
    // 上次更新相位里程的时间
    latestUpdatedPhaseMileageAt: { type: Date },
    // 是否在停车区内
    inPark: { type: Boolean },
    // 所在大区 ref
    intersectRegion: { type: String },
    // 定位所在区域 区域ref
    intersectPolygon: { type: String },
    // 定位所在区域类型
    intersectPolygonType: {
      type: Number,
      enums: constants.OP_POLYGON_TYPE_ENUMS,
    },
    // 定位所在区域社区类型
    intersectPolygonNeighborhood: {
      type: Number,
      enums: constants.OP_POLYGON_NEIGHBORHOOD_ENUMS,
    },
    // 用户定位所在区块类型
    userIntersectPolygonType: {
      type: Number,
      enums: constants.OP_POLYGON_TYPE_ENUMS,
    },
    // 骑行轨迹
    path: Schema.Types.LineString,
    // 是否出过围栏
    hasOutsideRegion: Boolean,
  },
  // 支付信息
  payInfo: {
    // 租金
    rent: {
      // 计时部分租金
      timeRent: {
        // 原单价
        originalUnit: { type: Number, min: 0 },
        // 实际单价 （是否停在停车区）
        actualUnit: { type: Number, min: 0 },
        // 白天时长计费活动折前租金
        dayOriginalTotal: { type: Number, min: 0 },
        // 夜间时长计费活动折前租金
        nightOriginalTotal: { type: Number, min: 0 },
        // 活动折前总租金
        originalTotal: { type: Number, min: 0 },
        // 白天活动折后租金
        dayDiscountTotal: { type: Number, min: 0 },
        // 夜间活动折后租金
        nightDiscountTotal: { type: Number, min: 0 },
        // 活动折后总租金
        discountTotal: { type: Number, min: 0 },
        // 白天是否封顶
        isDayCeiling: { type: Boolean, default: false },
        // 夜间是否封顶
        isNightCeiling: { type: Boolean, default: false },
        // 实际白天租金
        dayActualTotal: { type: Number, min: 0 },
        // 实际夜间租金
        nightActualTotal: { type: Number, min: 0 },
        // 实际计时租金
        actualTotal: { type: Number, min: 0 },
      },
      // 里程部分租金
      mileageRent: {
        // 原单价
        originalUnit: { type: Number, min: 0 },
        // 实际单价
        actualUnit: { type: Number, min: 0 },
        // 活动折前总租金
        originalTotal: { type: Number, min: 0 },
        // 活动折后总租金
        discountTotal: { type: Number, min: 0 },
      },
      // 总计租金
      total: { type: Number, min: 0 },
      // 是否保底
      isFloor: { type: Boolean, default: false },
      // 计算保底后的实际总计租金
      actualTotal: { type: Number, min: 0 },
      // 优惠券减免租金
      discount: { type: Number, min: 0 },
      // 最终实付总租金
      finalTotal: { type: Number, min: 0 },
    },
    // 参与的活动列表
    events: [{ type: String }],
    // 使用的优惠券
    coupon: {
      // 实际减免的额度
      actualDiscount: { type: Number, min: 0, default: 0 },
      // 优惠券ref
      ref: String,
    },
    // 保险
    insurance: {
      // 保费
      amount: { type: Number, min: 0 },
      // 保单ref
      ref: { type: String },
    },
    // 结算总金额
    totalAmount: { type: Number, min: 0, default: 0 },
    // 结算时间
    paidAt: { type: Date, index: true },
    // 租金消费凭据 余额账单ref
    rentBill: { type: String },
    // 保险消费凭据 余额账单ref
    insuranceBill: { type: String },
    // 调度账单
    dispatchBill: { type: String },
    // 免单减免的金额
    freeDiscount: { type: Number, min: 0, default: 0 },
    // 免调度费金额
    freeDispatchDiscount: { type: Number, min: 0, default: 0 },
    // 免单返余额的账单ref
    freeBill: { type: String },
    // 免调度费账单
    freeDispatchBill: { type: String },
    // 计费锁定
    locked: { type: Boolean, default: false },
    // 停车区折扣
    parkingRate: Number,
    // 停车区折扣描述
    parkingRateContent: String,
    // 调度费用
    dispatchCost: { type: Number, default: 0 },
  },
  // 价格设定
  price: {
    // 时间单价 元/分钟
    timeUnit: { type: Number, min: 0, required: true },
    // 里程单价 元/公里
    mileageUnit: { type: Number, min: 0, required: true },
    // 最低消费 元
    floorCost: { type: Number, min: 0, required: true },
    // 是否开通保险服务
    enableInsurance: { type: Boolean, required: true },
    // 保费
    insurance: { type: Number, min: 0, required: true },
    // 停车区停车折扣率
    parkingRate: { type: Number, min: 0, max: 1, required: true, default: 0.5 },
    // 日封顶
    dayCeilingCost: { type: Number, min: 0, required: true },
    // 夜封顶
    nightCeilingCost: { type: Number, min: 0, required: true },
    // 车辆折扣率
    stockDiscountRate: { type: Number, default: 1, required: true },
    // 折扣
    shouldDiscount: {
      // 是否优惠车辆
      lockDiscount: { type: Boolean, default: false, require: true },
      // 优惠金额
      discountAmount: { type: Number, default: 0, min: 0, required: true },
    },
    // 调度费用
    dispatchCost: { type: Number, default: 0 },
  },
  // 结束时间
  finishedAt: { type: Date },
  // 分享时间
  sharedAt: { type: Date },
  // 评价
  comment: {
    rank: { type: Number, enums: constants.OD_COMMENT_RANK_ENUMS },
    commentedAt: { type: Date },
    content: String,
    tags: [String],
  },
  // 免单
  free: {
    // 是否已经免单
    isFree: { type: Boolean, default: false },
    // 处理人
    processor: { type: String },
    // 处理时间
    processedAt: Date,
    // 免单原因
    reason: String,
  },
  // 免调度费
  freeDispatch: {
    // 处理人
    processor: { type: String },
    // 处理时间
    processedAt: Date,
    // 免单原因
    reason: String,
    // 是否免调度费
    isFreeDispatch: { type: Boolean, default: false },
  },
  // 该订单最高时速
  highestSpeed: { type: Number, default: 0 },
  // 平均时速
  averageSpeed: { type: Number, default: 0 },
  // 最大快照间距离差
  highestDeltaDistance: { type: Number, default: -1 },
  // 最大快照间时间差
  highestDeltaTime: { type: Number, default: -1 },
  // 路径的最小外包矩形
  mbr: {
    maxLng: { type: Number, default: -180 },
    minLng: { type: Number, default: 180 },
    maxLat: { type: Number, default: -90 },
    minLat: { type: Number, default: 90 },
  },
  // 百米点密度
  ppk: { type: Number, default: 0 },
  // 小时点密度
  pph: { type: Number, default: 0 },
  // 订单结束后拍照
  shootAfterFinished: {
    // 定位
    lngLat: [Number],
    // 地址
    addresss: String,
    // 照片
    photo: String,
    // 拍照时间
    shootAt: Date,
    // 描述
    description: String,
  },
  // 是免单行程（针对于从非法区域将车辆骑回正常区域的行程，标记为免单行程）
  isFreeTrip: { type: Boolean, default: false },
  // 免单行程信息
  freeTripInfo: {
    // 免单原因
    reason: { type: Number, enums: constants.OD_FREE_TRIP_REASON_ENUMS },
  },
  // 宝驾订单信息
  baojia: {
    isBaojia: { type: Boolean, default: false },
    // 宝驾订单号
    id: String,
    // 宝驾订单否支付
    paid: { type: Boolean, default: false },
    // 支付费用
    amount: { type: Number, min: 0 },
    // 支付时间
    paidAt: Date,
  },
  // 网格索引
  grids: [String],
  // 起点网格索引
  startGrid: String,
  // 终点网格索引
  endGrid: String,
  // 违法记录
  illegal: String,
  // 是否违法
  isIllegal: Boolean,
  // 用于判断是否异常订单
  abnormalOrder: {
    // 是否异常
    isAbnormal: Boolean,
    // 低速持续时长
    lowSpeedTime: Number,
    // 低速开始时间
    lowSpeedStartedAt: Date,

  },
  // 开始电压
  startVoltage: Number,
  // 结束电压
  endVoltage: Number,
  // 结束时点击结束按钮时间
  finishSubmit: [Date],
  // 结束时 车辆电门状态
  accOn: Boolean,
  // 补偿优惠券
  grantCoupon: { type: Boolean, default: false },
  // 锁定操作
  lock: {
    isLocked: { type: Boolean, default: false },
    // 锁过期时间
    expires: { type: Date },
    times: [{
      start: Date,
      end: Date,
      lease: Number,
    }],
  },
  // 订单预结束时关键字段
  preFinish: {
    inPark: Boolean,
    expires: Date,
    parkingLot: String,
  },
  // 订单来源
  orderSource: {
    src: { type: Number },
  },
}, {
  read: 'primary',
});

schema.index({ user: 1 });
schema.index({ state: 1, user: 1 });
schema.index({ state: 1, box: 1 });
schema.index({ stock: 1, createdAt: -1 });
schema.index({ stockNo: 1 });
schema.index({ 'baojia.id': 1 }, { unique: true, sparse: true });
schema.index({ region: 1, _id: 1 });
schema.index({ finishedAt: -1, region: 1 });
schema.index({ 'orderSource.src': 1, state: 1, isBad: 1 });
schema.index({ state: 1, 'lock.expires': 1 });

schema.plugin(betterId, { connection: conn.order });
module.exports = conn.order.model('od_order', schema);
