const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../../connections/index');
const constants = require('../../../settings/constants');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 操作人(库管) ref
  storeManager: String,
  // 大区 ref
  region: String,
  // 站点 ref
  station: String,
  // 状态
  status: { type: Number, enums: constants.OD_STOCK_SCRAP_STATUS_ENUMS, default: constants.OD_STOCK_SCRAP_STATUS.正在进行 },
  // 需要报废总数
  stocks: [{
    // 车辆id ref
    stock: { type: String, required: true },
    // 报废描述
    description: { type: String, required: true },
    // 报废图片
    image: String,
  }],
  // 报废成功
  scrapSuccess: [{
    // 车辆id ref
    stock: { type: String, required: true },
    // 报废描述
    description: { type: String, required: true },
    // 报废图片
    image: String,
  }],
  // 报废失败
  scrapFailed: [{
    // 车辆id ref
    stock: { type: String, required: true },
    // 报废描述
    description: { type: String, required: true },
    // 报废图片
    image: String,
  }],
  // 下次重试时间
  nextTry: Date,
  // 结束时间
  finishedAt: Date,
});

schema.index({ station: 1 });

schema.plugin(betterId, { connection: conn.order });
module.exports = conn.order.model('od_stock_scrap', schema);
