const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const batteryId = require('mongoose-better-id');

const schema = new Schema({
  // 用户ref
  user: { type: String, required: true },
  // 大区
  region: String,
  // 订单ref
  order: { type: String, required: true },
  // 转换过的轨迹点记录
  points: [{
    // 时间
    ts: Date,
    // 经纬度
    lngLat: [Number],
    // 违规情况
    illegals: {
      // 逆行
      wrongDirection: {
        name: String,
        type: { type: Number },
        _id: String,
      },
      // 横跨机动车道
      acrossMotorway: {
        name: String,
        type: { type: Number },
        _id: String,
      },
    },
    // 所在polygon
    polygons: [{
      type: { type: Number },
      name: String,
      _id: String,
    }],
  }],
  // 违章记录
  illegals: [{
    // 违章类型
    type: { type: String },
    // 违章所在区块
    polygon: {
      type: { type: Number },
      name: String,
      _id: String,
    },
    // 违章轨迹
    points: [{
      ts: Date,
      lngLat: [Number],
    }],
    // 持续时长 秒
    duration: Number,
  }],
  // 通过的区块记录
  passedPolygons: [{
    directionLine: {
      type: Schema.Types.LineString,
    },
    path: {
      type: Schema.Types.Polygon,
    },
    type: { type: Number },
    name: String,
    _id: String,
  }],
  wrongDirectionTimes: Number,
  acrossMotorwayTimes: Number,
  totalTimes: Number,
}, {
  read: 'secondaryPreferred',
  toJSON: { versionKey: false },
});

schema.index({ user: 1 });
schema.index({ order: 1 }, { unique: true });
schema.index({ createdAt: -1, region: 1 });
schema.index({ region: 1, totalTimes: 1, _id: -1 });

schema.plugin(batteryId, { connection: conn.order });

module.exports = conn.order.model('od_illegal', schema);
