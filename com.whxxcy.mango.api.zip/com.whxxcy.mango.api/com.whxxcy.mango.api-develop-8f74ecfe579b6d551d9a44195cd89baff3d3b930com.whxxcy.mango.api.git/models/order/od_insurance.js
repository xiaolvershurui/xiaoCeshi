const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 用户ref
  user: { type: String, required: true },
  // 保险产品号
  productNo: { type: String, required: true },
  // 投保信息
  info: {
    // 订单ref
    order: { type: String, required: true },
    // 姓名
    name: { type: String, required: true },
    // 身份证号
    idCardNo: { type: String, required: true },
    // 手机号
    tel: { type: String, required: true },
    // 车辆ref
    stock: { type: String, required: true },
    // 车架号
    vin: { type: String, required: true },
    // 车牌号
    bikeNo: { type: String, required: true }
  },
  // 保单信息
  policy: {
    // 保单号
    no: { type: String, required: true },
    // 起保时间
    startTime: { type: Date, required: true },
    // 结保时间
    endTime: { type: Date, required: true },
    // 保期时长
    duration: { type: Number, min: 0, required: true },
    // 保险状态
    state: {
      type: Number,
      required: true,
      enums: constants.OD_INSURANCE_STATE_ENUMS,
    },
    // 保费
    cost: { type: Number, min: 0, required: true },
    // 保额
    amount: { type: Number, min: 0, required: true },
    // 投保时间
    insuredTime: { type: Date, required: true }
  },
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.order });
module.exports = conn.order.model('od_insurance', schema);