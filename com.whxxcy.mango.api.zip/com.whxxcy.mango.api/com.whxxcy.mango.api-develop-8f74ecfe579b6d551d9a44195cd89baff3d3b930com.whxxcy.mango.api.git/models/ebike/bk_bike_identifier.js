const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.Types.ObjectId;
const constants = require('../../settings/constants');
const conn = require('../../connections');

const schema = new Schema({
  _id: ObjectId,
  stock: String,
  number: String,
  license: String,
  vin: String,
  box: String,
}, {
  read: 'primary',
});

module.exports = conn.ebike.model('bk_bike_identifier', schema);
