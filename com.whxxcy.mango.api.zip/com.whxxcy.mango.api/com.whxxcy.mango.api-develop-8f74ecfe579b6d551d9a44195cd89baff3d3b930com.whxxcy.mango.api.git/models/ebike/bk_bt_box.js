const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 设备号
  _id: String,
  // 数据源
  dataSource: {
    type: Number,
    required: true,
    enums: constants.BK_BOX_DATA_SOURCE_ENUMS
  },
  // 设备型号
  deviceType: String,
  // 软件版本
  appVersion: String,
  // sim
  sim: {
    imsi: String,
    powerOn: Boolean,
    expiryDate: Date,
    dataUsage: Number,
    dataBalance: Number,
    invalid: { type: Boolean, default: false }
  },
  // 当前是否在线
  isOnline: { type: Boolean, default: false, required: true },
  // 最近上线时间
  latestOnlineAt: Date,
  // 模式
  mode: { type: Number, enums: constants.BK_BOX_WORK_MODE_ENUMS },
  // 信号
  signal: Number,
  // 电压
  voltage: Number,
  // 定位
  gpsLocation: {
    // gps经纬度
    gpsLngLat: [Number],
    // 经纬度
    lngLat: [Number],
    // 定位时间
    time: Date,
    // 速度
    speed: Number,
    // 相位角
    direction: Number
  },
  // 基站定位
  cellLocation: {
    mcc: Number,
    mnc: Number,
    cells: [{
      lac: Number,
      cellid: Number,
      rxl: Number,
    }],
    time: Date,
  }
}, {
  read: 'primary'
});

module.exports = conn.ebike.model('bk_bt_box', schema);