const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 创建人 ref
  creator: { type: String, required: true },
  // 单据类型
  type: { type: Number, enums: constants.BK_RECEIPT_TYPE_ENUMS, required: true },
  // 完成时间
  finishedAt: Date,
  // 仓库
  station: { type: String, required: true },
  // 领取人
  receiver: String,
  // 处理人
  handler: String,
  // 采购照片
  purchasePhoto: String,
  // 创建时完好配件类型及数量
  createWithIntactMounting: [{
    code: String,
    count: Number
  }],
  // 创建时损坏配件类型及数量
  createWithDamageMounting: [{
    code: String,
    count: Number
  }],
  // 处理时完好配件类型及数量
  finishWithIntactMounting: [{
    code: String,
    count: Number
  }],
  // 处理时损坏配件类型及数量
  finishWithDamageMounting: [{
    code: String,
    count: Number
  }],
  // 备注
  remark: String
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_receipt', schema);