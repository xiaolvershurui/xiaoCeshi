const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  //二维码
  QRCode: { type: String, required: true },
  // 型号
  style: String,
  // 标记
  mark: String,
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  //大区 ref
  region: { type: String },
  // 损坏状态
  state: {
    type: Number,
    required: true,
    enums: constants.BK_BATTERY_STATE_ENUMS,
    default: constants.BK_BATTERY_STATE.完好
  },
  // 去向
  locate: {
    type: Number,
    required: true,
    enums: constants.BK_BATTERY_LOCATE_ENUMS,
    default: constants.BK_BATTERY_LOCATE.在运营站
  },
  //绑定gps
  gps: String,
  // 定位信息
  location: {
    // 经纬度
    lngLat: [Number],
    // 定位时间
    time: Date,
    // 速度
    speed: Number,
    // 相位角
    direction: Number
  },
//充电状态
  charge: { type: Boolean, required: true, default: false },
  // 是否馈电
  underVoltage: { type: Boolean, required: true, default: false },
  // 所在运营人员ref
  inspector: String,
  // 所在电池站ref
  station: String,
  // 由某电池站发出
  fromStation: String,
  // 所在车辆 ref
  stock: { type: String, index: true },
  // 最近一次更新电量时间
  lastUpdatedPowerAt: { type: Date },
  //使用历史信息
  useRecord: {
    //充电次数
    rechargeCount: { type: Number, default: 0 },
    //使用次数
    useCount: { type: Number, default: 0 },
  },
  // 疑似丢失标记（用于判定工作状态变更）
  isSuspectedLost: { type: Boolean, default: false },
  // 损坏描述
  damageDescription: String,
}, {
  read: 'primary'
});

schema.index({ QRCode: 1 }, { unique: true });
schema.index({ region: 1, locate: 1 });
schema.index({ mark: 1 }, { unique: true, sparse: true });
schema.index({ 'location.lngLat': '2dsphere' });
schema.index({ gps: 1 }, { unique: true, sparse: true });

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_battery', schema);
