const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 盒子基本信息
  info: {
    // 一动设备IMEI or 比德文设备BYN码
    deviceId: { type: String },
    // 型号
    model: { type: String },
    // 电压范围
    voltageRange: String,
    // SN码
    sn: { type: String },
    // 数据源
    dataSource: {
      type: Number,
      required: true,
      enums: constants.BK_BOX_DATA_SOURCE_ENUMS,
    },
    // 设备类型
    deviceType: String,
    // 软件版本
    appVersion: String,
    // 批次
    batch: String,
  },
  // sim卡信息
  sim: {
    // CCID
    ccid: String,
    // IMSI
    imsi: String,
    // 开机状态
    powerOn: Boolean,
    // 工作状态
    working: Boolean,
    // msisdn
    msisdn: String,
    expiryDate: Date,
    dataUsage: Number,
    dataBalance: Number,
    // 无效的物联网卡
    invalid: { type: Boolean, default: false },
  },
  // 盒子是否在线
  isOnline: { type: Boolean, default: false, required: true },
  // 盒子信号
  signal: Number,
  // 盒子电量
  battery: Number,
  // 当前盒子电压
  voltage: Number,
  // 定位信息
  location: {
    // 上一次的计算用经纬度
    lastLngLat: [Number],
    // 卫星定位经纬度
    gpsLngLat: { type: [Number] },
    // 基站定位经纬度
    cellLngLat: { type: [Number] },
    // 卫星定位地址
    address: String,
    // 最近一次定位类型
    type: {
      type: Number,
      enums: constants.BK_BOX_LOCATION_TYPE_ENUMS,
    },
    // 最近一次卫星定位时间
    lastGpsLocatedAt: Date,
    // 最近一次基站定位时间
    lastCellLocatedAt: Date,
    // 定位所在大区 大区ref
    intersectRegion: { type: String },
    // 定位所在区域 区域ref
    intersectPolygon: { type: String },
    // 定位所在区域类型
    intersectPolygonType: {
      type: Number,
      enums: constants.OP_POLYGON_TYPE_ENUMS,
    },
    // 定位所在区域社区类型
    intersectPolygonNeighborhood: {
      type: Number,
      enums: constants.OP_POLYGON_NEIGHBORHOOD_ENUMS,
    },
  },
  // 最近一次快照时间
  snappedAt: { type: Date },
  // 当前所在网关
  gateway: String,
  // 是否省电模式
  ecoMode: Boolean,
  setEcoModeAt: Date,
  // 最近一次发送查询短信时间
  sentSMSAt: Date,
  // 最近自动下发指令时间
  latestSentCommandAt: Date,
  // 型号
  style: String,
}, {
  read: 'primary',
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_box', schema);
