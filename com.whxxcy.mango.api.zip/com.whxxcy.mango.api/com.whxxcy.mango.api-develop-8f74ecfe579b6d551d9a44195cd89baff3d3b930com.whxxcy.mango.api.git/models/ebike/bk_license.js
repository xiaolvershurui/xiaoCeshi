const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 车牌号
  bikeNo: { type: String, required: true },
  // 照片
  photo: { type: String, required: true },
  // 车辆颜色
  bikeColor: { type: String, required: true },
  // 所有人
  owner: { type: String, required: true },
  // 住址
  address: { type: String, required: true },
  // 车架号
  vin: { type: String, required: true },
  // 品牌型号
  model: { type: String, required: true },
  // 登记日期
  registeredAt: { type: Date, required: true },
  // 发证日期
  issuedAt: { type: Date, required: true },
  // 有效期
  expiredAt: { type: Date },
  // 证件号
  number: { type: String, required: true },
  // 发证机构
  issuer: { type: String, required: true },
  // 是否已经通过人工审核
  isChecked: { type: Boolean, default: false, required: true },
  // 车辆ref
  stock: { type: String, ref: 'bk_stock' },
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_license', schema);