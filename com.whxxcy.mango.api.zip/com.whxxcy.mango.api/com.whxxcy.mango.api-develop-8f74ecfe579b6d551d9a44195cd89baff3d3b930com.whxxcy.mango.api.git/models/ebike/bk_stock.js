const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  _id: String,
  number: {
    // 临时编号
    temp: { type: String },
    // 自定义车牌号
    custom: { type: String },
    // 交管局车牌号
    license: { type: String },
    // 车架号
    vin: { type: String },
    // 合格证号
    cert: { type: String },
  },
  check: { type: Boolean, default: false },
  // 位置信息
  location: {
    // 车辆最后记录的GPS位置
    lngLat: { type: [Number] },
    // 地址
    address: String,
    // 最后记录位置的时间
    locatedAt: { type: Date },
    // 定位所在大区 大区ref
    intersectRegion: { type: String },
    // 定位所在区域 区域ref
    intersectPolygon: { type: String },
    // 定位所在区域类型
    intersectPolygonType: {
      type: Number,
      enums: constants.OP_POLYGON_TYPE_ENUMS,
    },
    // 定位所在区域社区类型
    intersectPolygonNeighborhood: {
      type: Number,
      enums: constants.OP_POLYGON_NEIGHBORHOOD_ENUMS,
    },
    // 定位所在巡检区
    intersectInspectionArea: { type: String },
    // 所在大区名称
    intersectRegionName: String,
    // 所在区块名称
    intersectPolygonName: String,
    // 所在巡检区名称
    intersectInspectionAreaName: String,
    // 距离大区围栏的距离，有相交围栏以相交围栏为准，没有则以车辆大区围栏为准，围栏外为负值
    distanceWithRegionPath: { type: Number },
    // 距离禁行区的距离，在禁行区内以相交区为准，并为负值，若不在禁行区内，以5km范围内最近的禁行区为准，为空则表示距离最近的禁行区大于5km
    distanceWithProhibitedArea: { type: Number },
    // 距离禁停区的距离，在禁停区内则进行计算，衡为负值，为0表示不在禁停区内
    distanceWithForbiddenArea: { type: Number, default: 0 },
    // 距离停车区的距离，在停车区内相交区为准，为正值，若不在禁停区内，以5km范围内最近的停车区为准，为空表示距离最近的停车区大于5km
    distanceWithPark: { type: Number },
  },
  // 修正位置
  fixedLocation: {
    lngLat: [Number],
    address: String,
  },
  // 基站定位仅供参考
  cellLocation: {
    // 最近基站定位时间
    locatedAt: Date,
    // 最近基站定位位置
    lngLat: [Number],
    // 最近基站定位地址
    address: String,
  },
  // 大区ref
  region: { type: String },
  // 车型ref
  style: { type: String, required: true },
  // 车型level
  styleLevel: { type: Number, required: true, enums: constants.OP_STYLE_LEVEL_ENUMS },
  // 智能设备ref
  box: { type: String, ref: 'bk_box' },
  // 盒子是否在线
  isOnline: { type: Boolean, default: false, required: true },
  // 启用状态（是否可以出租）
  enable: { type: Boolean, default: true, required: true },
  // 车辆损坏状态
  state: {
    type: Number,
    required: true,
    enums: constants.BK_STATE_ENUMS,
    default: constants.BK_STATE.完好,
  },
  // 车辆去向
  locate: {
    type: Number,
    required: true,
    enums: constants.BK_LOCATE_ENUMS,
    default: constants.BK_LOCATE.仓库,
  },
  // 电池信息
  battery: {
    // 电池
    id: String,
    // 型号
    style: String,
    // 电压
    voltage: { type: Number, default: 0 },
    // 电量
    power: { type: Number, min: 0, max: 1, default: 0 },
    // 续航里程
    mileage: { type: Number, min: 0, default: 0 },
    // 如果是一动设备，用于估算电量的记录字段
    // 最近一次校准电量时间
    lastRechargedAt: Date,
    // 最近一次校准时的电量
    lastRechargePower: { type: Number, min: 0, max: 1 },
    // 最近一次校准时的总里程
    lastRechargeTotalMileage: Number,
    // 是否低电量状态
    isLowPower: { type: Boolean, default: true, required: true },
    // 低电警告
    isLowPowerWarning: { type: Boolean, default: false },
    // 是否是强制断电
    isForcePowerOff: Boolean,
    // 最近触发强制断电时间
    latestForcePowerOff: Date,
    // 真实电量
    truePower: Number,
    // 真实里程
    trueMileage: Number,
    // 是否零电
    isNoPower: Boolean,
  },
  // 行驶记录
  record: {
    // 今日行驶里程
    mileageOfDay: { type: Number, default: 0 },
    // 今日行驶时间
    timeOfDay: { type: Number, default: 0 },
    // 总里程
    mileageInAll: { type: Number, default: 0 },
    // 总时长
    timeInAll: { type: Number, default: 0 },
    // 上次更新时间
    recordedAt: Date,
    // 上次记录的经纬度
    lngLat: [Number],
    // 相位里程（根据定位计算的相位距离，不论是否行驶状态）
    phaseMileage: { type: Number, default: 0 },
    // 最近用于计算相位里程的经纬度
    latestPhaseLngLat: [Number],
  },
  // 是否一天内无订单
  notUsedInOneDay: { type: Boolean, default: false },
  // 是否两天内无订单
  notUsedInTwoDay: { type: Boolean, default: false },
  // 是否近期无卫星定位
  noGpsLocation: { type: Boolean, default: false },
  // 断电
  powerUnlink: { type: Boolean, default: false },
  // 非法位移
  illegalMovement: { type: Boolean, default: false },
  // 最近一次订单快照时间
  latestUsedAt: { type: Date },
  // 最近一次挪车时间
  latestMovedAt: { type: Date },
  // 是否在围栏外
  outsideRegion: { type: Boolean, default: false },
  // 是否在禁停区内
  insideForbiddenArea: { type: Boolean, default: false },
  // 是否在禁行区内
  insideProhibitedArea: { type: Boolean, default: false },
  // 是否在停车区内
  insidePark: { type: Boolean, default: false },
  // 车辆是否启动
  accOn: { type: Boolean, default: false },
  // 车辆是否设防
  lockOn: { type: Boolean, default: true },
  // 最近一次扫码时间
  latestScannedAt: { type: Date },
  // 车辆是否有任务
  hasTask: { type: Boolean, default: false },
  // 任务列表
  taskList: [{
    issuedAt: { type: Date },
    code: { type: Number, enums: constants.BK_TASK_TYPE_ENUMS },
  }],
  // 车辆是否正常可租
  isValid: { type: Boolean, default: false },
  // 不可租的原因
  invalidReasons: [{
    issuedAt: { type: Date, required: true },
    code: { type: Number, enums: constants.BK_INVALID_REASON_ENUMS, required: true },
  }],
  // 最近一次巡检是否找到车辆
  hasFind: { type: Boolean, default: true },
  // 最近一次巡检车辆的时间
  latestFoundAt: { type: Date },
  // 最近一次巡检车辆并找到的时间
  latestFoundSucceedAt: { type: Date },
  // 最近未找到打卡记录
  notFindRecords: [{
    // 打卡时间
    time: Date,
    // 打卡人
    finder: {
      id: String,
      type: { type: Number },
      name: String,
      tel: String,
    },
    // 打卡地点
    location: {
      lngLat: [Number],
      address: String,
    },
  }],
  // 车辆行驶速度、方向、海拔
  speed: Number,
  direction: Number,
  alt: Number,
  // 当前分配的巡检人员
  inspector: { type: String },
  // 巡检人姓名电话
  inspectorName: String,
  inspectorTel: String,
  // 特殊任务列表
  specialTasks: [{
    id: { type: String, required: true },
    time: { type: Date, required: true },
    remark: { type: String, required: true },
    photo: String,
    location: {
      lngLat: [Number],
      address: String,
    },
  }],
  // 消除复活任务的时间
  releasedRevivalAt: { type: Date },
  // 最近异常速度时间
  latestIllegalSpeedAt: { type: Date },
  // 最近订单异常事件 异常结束/超时结束/无距离
  latestIllegalOrderAt: { type: Date },
  // 是否可投放
  canPutOn: { type: Boolean },
  // 最近离线时间
  latestOfflineAt: { type: Date },
  // 最近改变去向状态时间
  latestUpdatedLocateAt: { type: Date },
  // 任务分组
  taskGroup: { type: Number },
  // 任务组匹配时间
  matchTaskGroupAt: Date,
  // 任务权值
  taskRate: { type: Number, default: 0 },
  // 标记该车辆暂时不需要自动分配，当人为将该车释放时，会进行标记，重新人为分配到人，会消除标记
  manualAssignTask: { type: Boolean, default: false },
  // 网络信号
  signal: Number,
  // gps精度因子
  gpsSignal: Number,
  // 电池仓锁状态
  batteryLockOn: { type: Boolean, default: true },
  // 后轮锁状态
  wheelLockOn: { type: Boolean, default: true },
  // 后轮转动
  wheelRand: { type: Boolean, default: false },
  // 是免单车
  isFree: { type: Boolean, default: false },
  // 盒子软件版本号
  boxAppVersion: { type: String },
  // 所属站点
  station: { type: String },
  // 是否宝驾在租
  rentingByBaojia: { type: Boolean, default: false },
  // sim卡信息
  sim: {
    // CCID
    ccid: String,
    // IMSI
    imsi: String,
    // 开机状态
    powerOn: Boolean,
    // 工作状态
    working: Boolean,
  },
  // 最高任务
  highestTask: Number,
  // 最近后轮转动时刻
  latestWheelRandAt: Date,
  // 是否锁定
  lockVin: {
    isLocked: { type: Boolean, default: false },
    operator: String,
    lockedAt: Date,
  },
  // 车辆折扣率
  discountRate: { type: Number, default: 1, required: true },
  // 产生未唤醒任务但不是半价车( 标识作用 )
  shouldDiscount: { type: Boolean, default: false },
  // 是否锁定半价优惠
  lockDiscount: { type: Boolean, default: false },
  // 上次订单结束用户位置
  lastUserCapture: {
    enable: Boolean,
    lngLat: [Number],
    address: String,
  },
  factoryInfo: {
    // 料号
    partCode: String,
    // 成车条码
    completeCode: String,
    // 电机码
    electricalCode: String,
    // 控制器
    controlCode: String,
    // 完工日期
    finishDate: Date,
    // 出货日期
    shipmentDate: Date,
    // 首次入库日期
    firstInBoundDate: Date,
    // 首次入库大区
    firstInBoundRegion: String,
  },
  parkingLot: String,
  // 错误控制器
  wrongControl: Boolean,
  // 投放日期
  putOnAt: Date,
  //  成本
  cost: Number,
  // 分成方案
  solution: Number,
  // 成本明细
  costDetail: {
    // 车辆价格
    price: Number,
    // 电池价格
    batteryPrice: Number,
    // 匹配后电池金额
    actualBatteryPrice: Number,
    // 运输费
    transportPrice: Number,
  },
  // 维修状态
  repairStatus: { type: Number, enums: constants.BK_REPAIR_STATUS_ENUMS, default: constants.BK_REPAIR_STATUS.不需要维修 },
  // 置损时间
  damageTime: Date,
  // 维修时间
  repairTime: Date,
  // 车辆收入
  income: {
    // 累计收入
    totalAmount: { type: Number, default: 0 },
  },
  detainedArea: { type: String },
  // 最近一次的订单
  lastOrder: {
    // 订单 ref
    // order: String,
    // 最后一次订单结束后的用户上传的定位
    lngLat: [Number],
  },
}, {
  read: 'primary',
});

schema.index({ 'number.custom': 1 }, { unique: true, sparse: true });
schema.index({ 'number.license': 1 }, { unique: true, sparse: true });
schema.index({ 'number.cert': 1 }, { unique: true, sparse: true });
schema.index({ 'number.vin': 1 }, { unique: true, sparse: true });
schema.index({ box: 1 }, { sparse: true });
schema.index({ 'taskList.code': 1, inspector: 1 });
schema.index({ inspector: 1, user: 1 });
schema.index({ box: 1, _id: 1 });
schema.index({ hasTask: 1, inspector: 1, region: 1, 'location.intersectInspectionArea': 1 });
schema.index({ hasTask: 1, inspector: 1, region: 1, 'location.lngLat': '2dsphere' });
schema.index({ enable: 1, lockOn: 1, isOnline: 1, locate: 1 });
schema.index({ enable: 1, locate: 1, region: 1, style: 1 });
schema.index({
  enable: 1, isOnline: 1, 'battery.isLowPower': 1, powerUnlink: 1,
  locate: 1, state: 1, 'location.distanceWithRegionPath': 1,
  region: 1, style: 1, 'location.lngLat': '2dsphere',
}, { name: 'search_near_stocks' });
schema.index({ 'location.lngLat': '2dsphere' });
schema.index({ enable: 1, locate: 1, region: 1, 'number.custom': 1 }, {
  name: 'baojia_api',
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_stock', schema);
