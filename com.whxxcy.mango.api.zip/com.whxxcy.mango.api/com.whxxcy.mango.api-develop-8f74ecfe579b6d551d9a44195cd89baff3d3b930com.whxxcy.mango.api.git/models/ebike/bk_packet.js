const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  //二维码
  QRCode: { type: String, required: true },
  // 大区
  region: { type: String, required: true },
  //运营站
  station: { type: String, required: true },
  //创建者
  creator: { type: String, required: true },
  //巡检人员
  inspector: { type: String },
  //电池组
  batteryIds: [{ type: String }],
  //配件
  mountings: [{
    type: { type: String },
    count: { type: Number }
  }]
}, {
  read: 'secondaryPreferred'
});

schema.index({ QRCode: 1 }, { unique: true });
schema.index({ inspector: 1 });
schema.index({ station: 1 });

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_packet', schema);