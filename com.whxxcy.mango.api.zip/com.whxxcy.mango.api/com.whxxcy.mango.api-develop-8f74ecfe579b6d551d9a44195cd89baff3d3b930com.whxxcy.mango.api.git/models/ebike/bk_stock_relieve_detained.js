const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 扣押点 ref
  detainedArea: String,
  // 车辆 ref
  stock: [String],
  // 上报时间
  reportTime: Date,
  // 处理人
  handler: String,
  // 罚款金额
  penalty: { type: Number, default: 0 },
  // 停车费
  parkingFee: { type: Number, default: 0 },
  // 操作人
  operator: String,
});

schema.index({ detainedArea: 1 });
schema.index({ stock: 1 });
schema.index({ handler: 1 });

schema.plugin(betterId, { connection: conn.ebike });

module.exports = conn.ebike.model('bk_stock_relieve_detained', schema);
