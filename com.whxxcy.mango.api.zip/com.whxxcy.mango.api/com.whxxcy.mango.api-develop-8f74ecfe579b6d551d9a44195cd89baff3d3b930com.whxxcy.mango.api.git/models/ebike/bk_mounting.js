const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 编码
  code: String,
  // 物资总数量
  count: { type: Number, required: true, default: 0 },
  // 物资所属大区
  region: { type: String, required: true },
  // 名称
  name: String,
  // 备注
  remark: String,
  // 运营站
  station: String,
  // 单位
  unit: {type: String, required: true},
  // 完好物资数量
  intactCount: { type: Number, default: 0 },
  // 损坏物资数量
  damageCount: { type: Number, default: 0 },
  // 报废物资数量
  scrapCount: { type: Number, default: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_mounting', schema);