const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 电池ref
  battery: { type: String, ref: 'bk_battery' },
  // 损坏描述
  description: { type: String, required: true },
  // 照片
  photo: { type: String, required: true },
  // 修复状态
  state: {
    type: Number,
    required: true,
    enums: constants.BK_DAMAGE_STATE_ENUMS,
    default: constants.BK_DAMAGE_STATE.未修复
  },
  // 录损时间
  recordedAt: { type: Date, required: true },
  // 通知时间
  notifiedAt: { type: Date },
  // 修复时间
  repairedAt: { type: Date },
  // 备注
  remark: String,
  // 修复人 账户ref
  repairer: { type: String },
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_battery_damage', schema);