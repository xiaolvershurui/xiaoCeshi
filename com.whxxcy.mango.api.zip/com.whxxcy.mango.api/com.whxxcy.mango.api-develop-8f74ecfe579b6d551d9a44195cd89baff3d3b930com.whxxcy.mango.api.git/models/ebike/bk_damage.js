const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 车辆ref
  stock: { type: String, ref: 'bk_stock', required: true },
  // 损坏描述
  description: { type: String, required: true },
  // 损坏配件
  mountings: [Number],
  // 照片
  photo: { type: String },
  // 修复照片
  repairPhoto: String,
  // 修复状态
  state: {
    type: Number,
    required: true,
    enums: constants.BK_DAMAGE_STATE_ENUMS,
    default: constants.BK_DAMAGE_STATE.未修复,
  },
  // 录损时间
  recordedAt: { type: Date, required: true },
  // 通知时间
  notifiedAt: { type: Date },
  // 修复时间
  repairedAt: { type: Date },
  // 修复备注
  repairRemark: String,
  // 提交人 账户ref
  submitter: { type: String, required: true },
  // 修复人 账户ref
  repairer: { type: String },
  // 导致库存变更为
  stockState: {
    type: Number,
    required: true,
    enums: constants.BK_STATE_ENUMS,
  },
}, {
  read: 'secondaryPreferred',
});

schema.index({ state: 1, stock: 1, stockState: 1, _id: 1 });
schema.index({ stock: 1 });

schema.plugin(betterId, { connection: conn.ebike });
module.exports = conn.ebike.model('bk_damage', schema);
