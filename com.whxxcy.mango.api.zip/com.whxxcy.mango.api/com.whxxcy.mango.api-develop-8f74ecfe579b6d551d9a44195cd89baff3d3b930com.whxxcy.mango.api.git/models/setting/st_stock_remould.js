const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

// 车辆改造项目配置
const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: true, required: true },
  // 名称
  name: { type: String, required: true },
  // 创建人 ref
  creator: { type: String, required: true },
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_stock_remould', schema);
