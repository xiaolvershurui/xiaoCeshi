const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 是否启用
  enable: { type: Boolean, default: true, required: true },
  // 生命期
  life: {
    start: { type: Date, required: true },
    end: { type: Date, required: true }
  },
  // 兑换码
  code: { type: String, required: true },
  // 可兑换手机号列表
  tels: [{ type: String }],
  // 已兑换手机号列表
  exchangedTels: [{ type: String }],
  // 剩余可兑换次数
  remainTimes: { type: Number, min: 0, default: 1 },
  // 类型
  type: {
    type: Number,
    enums: constants.AC_COUPON_TYPE_ENUMS,
    default: constants.AC_COUPON_TYPE.租金抵扣券,
    required: true
  },
  // 名称
  name: String,
  // 面额
  amount: { type: Number, min: 0, required: true },
  // 有效期天数
  validDuration: { type: Number, min: 1, required: true },
  // 可用大区列表
  validRegions: [{ type: String }],
  // 可用车型level列表
  validStyleLevels: [{ type: Number, enums: constants.OP_STYLE_LEVEL_ENUMS }]
}, {
  read: 'secondaryPreferred'
});

schema.index({ enable: 1, code: 1, tels: 1, _id: -1 });

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_coupon_code', schema);