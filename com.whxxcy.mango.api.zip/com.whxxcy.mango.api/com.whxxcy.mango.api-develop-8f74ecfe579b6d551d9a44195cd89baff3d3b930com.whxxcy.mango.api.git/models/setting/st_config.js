const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: true, required: true },
  // 启用平台
  valid: {
    // 平台类型(留空为全平台)
    platforms: [{
      type: String,
      enums: constants.ST_CONFIG_PLATFORM_ENUMS,
    }],
    //iOS平台最低版本号
    iOSLowestVersion: { type: String, default: '0.0.0' },
    // Android平台最低版本号
    androidLowestVersion: { type: String, default: '0.0.0' }
  },
  // 键
  key: { type: String, required: true },
  // 值类型
  valueType: {
    type: String,
    enums: constants.ST_CONFIG_VALUE_TYPE_ENUMS,
    default: 'String',
    required: true
  },
  // 值
  value: {},
  // 说明
  description: String
}, {
  read: 'secondaryPreferred'
});

schema.index({ key: 1 }, { unique: true });
schema.index({ key: 1, _id: 1 });
schema.index({ enable: 1, 'valid.platforms': 1 });

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_config', schema);