const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 理由类型
  type: { type: Number, required: true },
  // 理由描述
  reason: { type: String, required: true },
}, {
  read: 'secondaryPreferred'
});

module.exports = conn.record.model('st_background_finish_order_reason', schema);