const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 生命期
  life: {
    start: { type: Date },
    end: { type: Date }
  },
  // 名称
  name: { type: String, required: true },
  // 图片地址
  image: { type: String, required: true },
  // 跳转链接
  link: String,
  // 可见城市列表（不填为所有城市）
  validCities: [{
    type: String,
    enums: constants.ST_CITIES_ENUMS
  }],
  // 排序权重
  queue: { type: Number, default: 0 }
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_ad', schema);