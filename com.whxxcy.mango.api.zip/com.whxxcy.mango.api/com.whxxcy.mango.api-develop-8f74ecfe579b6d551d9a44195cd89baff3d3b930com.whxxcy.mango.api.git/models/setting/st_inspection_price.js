const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 是否启用
  enable: { type: Boolean, default: true, required: true },
  // 名称
  name: { type: String, required: true },
  // 单价
  unit: {
    // 拖回单价
    returnBack: { type: Number, required: true, default: 0 },
    // 换电单价
    exchangeBattery: { type: Number, required: true, default: 0 },
    // 回栏单价
    backIntoRegion: { type: Number, required: true, default: 0 },
    // 难寻找到
    hardToFindButFound: { type: Number, required: true, default: 0 },
    // 投放
    putOn: { type: Number, required: true, default: 0 },
    // 普通任务
    normal: { type: Number, required: true, default: 0 },
    // 拖回未完成
    returnBackUnfinished: { type: Number, required: true, default: 0 }
  }
}, {
  read: 'secondaryPreferred'
});

schema.index({ name: 1 });
schema.index({ enable: 1 });

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_inspection_price', schema);