const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: true, required: true },
  // 类别
  type: { type: String, required: true },
  // 回复
  reply: { type: String, required: true },
  // 最近修改人
  lastEditor: String,
  // 最近修改时间
  lastEditedAt: Date,
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_work_order_reply', schema);
