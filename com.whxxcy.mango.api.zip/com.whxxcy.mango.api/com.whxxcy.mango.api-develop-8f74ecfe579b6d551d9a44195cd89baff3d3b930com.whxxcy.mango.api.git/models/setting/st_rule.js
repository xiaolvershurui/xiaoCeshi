const Schema = require('mongoose').Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 创建人
  creator: String,
  // 是否启用
  enable: Boolean,
  // 角色
  role: String,
  // 权限
  permissions: [String],
  // 权重 判断能够设置哪些角色
  weight: { type: Number, default: 0, required: true }
});

schema.index({ role: 1 }, { unique: true });

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_rule', schema);