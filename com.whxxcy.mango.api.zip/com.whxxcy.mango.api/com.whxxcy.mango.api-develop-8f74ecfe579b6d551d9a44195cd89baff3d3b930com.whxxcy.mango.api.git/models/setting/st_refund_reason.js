const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 是否可用
  enable: { type: Boolean, default: true },
  // 退款原因
  reason: { type: String },
  // 展示优先级
  index: { type: Number },
}, {
  read: 'secondaryPreferred',
});

schema.index({ index: -1 });
schema.plugin(betterId, { connection: conn.setting });

module.exports = conn.setting.model('st_refund_reason', schema);
