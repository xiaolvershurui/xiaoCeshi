const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const constants = require('../../settings/constants');
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 生命期
  life: {
    start: { type: Date },
    end: { type: Date }
  },
  // 标题
  title: { type: String, required: true },
  // 描述
  description: String,
  // 图片地址
  image: { type: String, required: true },
  // 链接
  link: String,
  // 活动规则
  rule: {
    // 租金折扣规则
    discountRent: {
      // 是否启用
      enable: { type: Boolean, default: false },
      // 折扣率
      cutRate: { type: Number, min: 0, max: 1 }
    },
    // 租金抵扣
    cutRent: {
      // 是否启用
      enable: { type: Boolean, default: false },
      // 抵扣面额
      amount: { type: Number, min: 0 },
      // 起用金额
      validAmount: { type: Number, min: 0 }
    },
    // 免费租车
    freeRent: {
      // 是否启用
      enable: { type: Boolean, default: false }
    },
    // 免费保险
    freeInsurance: {
      // 是否启用
      enable: { type: Boolean, default: false }
    }
  },
  // 可用大区列表
  validRegions: [{ type: String }],
  // 可用车型level列表
  validStyleLevels: [{ type: Number, enums: constants.OP_STYLE_LEVEL_ENUMS }]
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_event', schema);