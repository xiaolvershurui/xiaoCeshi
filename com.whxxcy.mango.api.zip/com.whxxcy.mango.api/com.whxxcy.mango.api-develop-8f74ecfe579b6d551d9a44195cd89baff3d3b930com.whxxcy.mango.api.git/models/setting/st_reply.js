const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 启用状态
  enable: { type: Boolean, default: false, required: true },
  // 回复用户内容
  reply: {type: String, required: true},
  // 真实原因
  realReason: {type: String, required: true}
}, {
  read: 'secondaryPreferred'
});

schema.plugin(betterId, { connection: conn.setting });
module.exports = conn.setting.model('st_reply', schema);