const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 编号
  number: { type: String, required: true },
  // 大区
  region: { type: String },
  // 名称
  name: String,
  // 位置
  lngLat: { type: [Number] },
  // 地址
  address: String,
  // 联系人
  contact: String,
  // 联系方式
  tel: String,
  // 所属单位
  unit: String,
  // 负责人
  principal: String,
  // 扣押点内的扣押车辆
  stocks: [String]
});

schema.index({ region: 1 });
schema.index({ 'lngLat': '2dsphere' }, { sparse: true });

schema.plugin(betterId, { connection: conn.setting });

module.exports = conn.setting.model('st_detained_area', schema);
