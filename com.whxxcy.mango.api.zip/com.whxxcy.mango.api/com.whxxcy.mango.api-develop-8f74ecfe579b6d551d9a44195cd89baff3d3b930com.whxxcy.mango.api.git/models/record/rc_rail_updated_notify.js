const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');

// 围栏修改通知
const schema = new Schema({
  // 是否通知所有的用户
  isNotifyAllUsers: { type: Boolean },
  // 通知所有
  notifyAllUsers: {
    // 标题
    title: String,
    // 内容
    content: String,
    // 过期时间
    expiredAt: { type: Date },
    // 落款时间
    inscribeDate: Date,
  },
  // 通知部分
  notifyPartUsers: {
    // 标题
    title: String,
    // 内容
    content: String,
    // 是否已读
    read: { type: Boolean },
    // 通知用户 ref
    user: { type: String },
    // 过期时间
    expiredAt: { type: Date },
    // 落款时间
    inscribeDate: Date,
  }
}, {
  read: 'secondaryPreferred',
});

schema.index({ user: 1, isNotifyAllUsers: 1 });
module.exports = conn.record.model('rc_rail_updated_notify', schema);
