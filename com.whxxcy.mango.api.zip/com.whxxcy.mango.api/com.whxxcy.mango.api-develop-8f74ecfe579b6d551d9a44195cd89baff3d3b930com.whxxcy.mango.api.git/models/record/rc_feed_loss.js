const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 大区
  region: { type: String, required: true },
  // 日期
  date: Date,
  // 低电扫码用户
  user: String,
  // 低电扫码车辆
  stock: String,
  // 扫码位置
  location: {
    lngLat: [Number],
    address: String,
  },
  // 扫码时间
  scannedAt: Date,
  // 最终租成功(20分钟内下单了)
  rentSuccess: { type: Boolean, required: true, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ date: 1 });
schema.index({ scannedAt: 1, user: 1 });

module.exports = conn.record.model('rc_feed_loss', schema);