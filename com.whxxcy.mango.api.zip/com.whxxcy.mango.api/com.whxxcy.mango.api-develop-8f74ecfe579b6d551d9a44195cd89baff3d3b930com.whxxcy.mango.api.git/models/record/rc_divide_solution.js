const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 车辆
  stock: String,
  // 大区
  region: String,
  // 日期
  date: Date,
  // 方案
  solution: Number,
  // 周期
  period: Number,
  // 新日今日收入
  rentAmount: Number,
  // 总共今日收入
  totalAmount: { type: Number, default: 0 },
  // 是否保底
  isFloor: { type: Boolean, default: false },
  // 是否封顶
  isCapping: { type: Boolean, default: false },
  // 第二周期累计收入
  rentAmountInPeriodTwo: Number,
}, {
  read: 'secondaryPreferred',
});

schema.index({ stock: 1, _id: -1 });
// schema.index({ stock: 1, date: -1 }, {unique: true});
schema.index({ date: -1 });

module.exports = conn.record.model('rc_divide_solution', schema);
