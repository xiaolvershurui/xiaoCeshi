const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 是否已经发送通知
  notified: { type: Boolean, default: false },
  // 通知类型
  type: { type: Number, enums: constants.RC_NOTIFICATION_TYPE_ENUMS, required: true },
  // 通知内容参数
  data: {},
  // 通知发送时间
  notifiedAt: { type: Date },
  // 通知渠道
  channel: { type: Number, enums: constants.RC_NOTIFICATION_CHANNEL_ENUMS, required: true },
}, {
  shardKey: {
    _id: 'hashed'
  },
  read: 'secondaryPreferred'
});

schema.index({ notified: 1 });
schema.index({ createdAt: 1 }, {expireAfterSeconds: 30 * 24 * 3600 * 1000});

module.exports = conn.record.model('rc_notification', schema);
