const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 订单
  order: String,
  // 操作类型
  opType: Number,
  // 是否在停车区
  inParkingLot: Boolean,
  stock: {
    id: String,
    lngLat: [Number],
  },
  user: {
    id: String,
    lngLat: [Number],
  }
}, {
  read: 'secondaryPreferred',
});

module.exports = conn.record.model('rc_parkingLot_point_amendment', schema);
