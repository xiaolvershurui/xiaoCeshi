const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 日期
  date: { type: Date },
  // 账户ref
  user: { type: String },
  // 登录时间
  loggedAt: { type: Date, required: true },
  // 与上一次登录时间间隔
  lastTimeInterval: { type: Number, default: 0 },
  // 上次登陆时间间隔天
  lastLoginInterval: { type: Number, default: 0 },
  // 预约间隔时间
  reservationInterval: { type: Number, default: 0 },
  // 当日预约
  isReservation: { type: Boolean, default: false },
  // 订单间隔
  orderInterval: { type: Number, default: 0 },
  // 当日下达订单
  isOrder: { type: Boolean, default: false },
  // 今日缴纳押金
  isDeposit: { type: Boolean, default: false },
  // 押金缴纳间隔
  depositInterval: { type: Number, default: 0 },
  // 是否为当日新增用户
  isNewUser: { type: Boolean, default: false },
  // 新增间隔天数
  registerInterval: { type: Number, default: 0 },
  // 30天内活跃天数
  freshDays: { type: Number, default: 0 },
  // 上次用于统计押金留存周数日期
  lastDepositWeekTime: { type: Date },
  // 设备信息
  deviceInfo: {
    // 平台
    platform: String,
    // 系统版本
    version: String,
    // 设备型号
    modal: String,
    // udid
    udid: String,
    // 设备名
    name: String,
    // 手机朝向
    heading: Number,
    // 手机电量
    battery: Number,
    // 速度
    speed: Number,
  },
  // app版本号
  appVersion: String,
  // ip信息
  ip: String,
  // 经纬度
  lngLat: { type: [Number], index: '2dsphere' },
  // 地址
  address: String,
  // 城市
  city: String,
  // 定位精度
  accuracy: Number,
}, {
  read: 'nearest',
});

schema.index({ user: 1, loggedAt: 1 });
schema.index({ date: 1 });

module.exports = conn.record.model('rc_login', schema);

