const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 操作人
  operator: { type: String, required: true },
  // 入库
  isInBound: { type: Boolean, required: true },
  // 接收\发出 人
  sourceAccount: String,
  // 接收\发出 站
  sourceStation: String,
  // 二维码数量
  QRCodeCount: Number,
  // 无标数量
  noSignCount: Number,
  // 电池列表
  batteries: [String]
}, {
  read: 'secondaryPreferred'
});

schema.index({ operator: 1 });
schema.index({ isInBound: 1, sourceStation: 1 });
schema.index({ createdAt: 1, isInBound: 1, sourceStation: 1 });

module.exports = conn.record.model('rc_battery_receipt', schema);
