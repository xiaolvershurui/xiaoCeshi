const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 账户ref
  user: { type: String },
  // 该运营管理的大区
  regions: [{ type: String }],
  // 快照时间
  snappedAt: { type: Date, required: true },
  // 设备信息
  deviceInfo: {
    // 平台
    platform: String,
    // 系统版本
    version: String,
    // 设备型号
    modal: String,
    // udid
    udid: String,
    // 设备名
    name: String,
    // 手机朝向
    heading: Number,
    // 手机电量
    battery: Number,
    // 速度
    speed: Number,
    // 海拔
    alt: Number,
  },
  // app版本号
  appVersion: String,
  // ip信息
  ip: String,
  // 经纬度
  lngLat: { type: [Number] },
  // 地址
  address: String,
  // 城市
  city: String,
  // 是否是管理员
  isAdmin: { type: Boolean, default: false },
  // 定位精度
  accuracy: Number
}, {
  shardKey: {
    user: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ user: 1, snappedAt: -1 });
schema.index({ user: 1, snappedAt: 1, lngLat: 1 });

module.exports = conn.record.model('rc_operator_capture', schema);