const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 年份
  year: Number,
  // 月份
  month: Number,
  // 上报人
  operator: { type: String, required: true },
  // 电站
  station: { type: String, required: true },
  // 上报图片
  electricMeterBoxImage: String,
  // 上报电量度数
  electricQuantity: { type: Number, default: 0 },
  // 上报温度
  temperature: Number,
  // 上一次录入电量到本次录入电量之间的度数差值
  diffElectric: { type: Number, default: 0, required: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ station: 1 });
schema.index({ createdAt: 1 });
schema.index({ year: 1, month: 1 });

module.exports = conn.record.model('rc_electric', schema);
