const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 账户姓名
  userName: { type: String },
  // 账户电话a
  userTel: { type: String },
  // 大区
  region: String,
  // 错误信息
  errorInfo: { type: String, required: true },
  // 错误类型
  errorType: {
    type: Number,
    required: true,
    default: constants.RC_ERROR_TYPE.预约,
    enums: constants.RC_ERROR_TYPE_ENUMS,
  },
  errorDescription: { type: String },
  // 如果是芒果车辆，车辆ref
  stock: String,
  // 扫码位置
  lngLat: { type: [Number], index: '2dsphere' },
  // 地址
  address: String,
  // 精度
  accuracy: Number,
  // 设备信息
  deviceInfo: {
    // 平台
    platform: String,
    // 系统版本
    version: String,
    // 设备型号
    modal: String,
    // udid
    udid: String,
    // 设备名
    name: String,
  },
  // app版本号
  appVersion: String,
  // 城市
  city: String
}, {
  shardKey: {
    stock: 1,
    scannedAt: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ type: 1 });
schema.index({ createdAt: 1 });

module.exports = conn.record.model('rc_error', schema);
