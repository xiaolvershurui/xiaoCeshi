const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  user: { type: String, required: true },
  stock: { type: String, required: true },
  scannedAt: { type: Date, required: true },
  // 扫码成功
  succeed: { type: Boolean, required: true },
  // 如果失败，报错信息
  error: String,
  errorCode: String,
  region: String,
  order: String,
  // 下单完成(产生费用)
  rentFinish: { type: Boolean, default: false },
  // 骑行失败(禁行围栏导致断电订单)
  noPowerByRegion: { type: Boolean, default: false },
  // 断电时间
  noPoweredAt: Date,
  // 上次断电类型
  lastPowerUnlink: String,
  // 围栏外断电
  outsideRegion: {
    noPower: { type: Boolean, default: false },
    lastNoPoweredAt: Date,
    noPowerForSeconds: Number
  },
  // 禁行区断电
  prohibitionArea: {
    noPower: { type: Boolean, default: false },
    lastNoPoweredAt: Date,
    noPowerForSeconds: Number
  },
  // 正常骑行断电五秒以上
  normalRide: {
    noPower: { type: Boolean, default: false },
    lastNoPoweredAt: Date,
    noPowerForSeconds: Number,
  },
  // 禁行禁停围栏导致还车失败 最后系统结束
  returnFailedByArea: { type: Boolean, default: false },
  // 离线导致还车失败
  returnFailedByOffline: { type: Boolean, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ scannedAt: -1, region: 1 });
schema.index({ scannedAt: -1 });
schema.index({ order: -1 });
schema.index({ user: -1, stock: 1 });

module.exports = conn.record.model('rc_user_experience', schema);
