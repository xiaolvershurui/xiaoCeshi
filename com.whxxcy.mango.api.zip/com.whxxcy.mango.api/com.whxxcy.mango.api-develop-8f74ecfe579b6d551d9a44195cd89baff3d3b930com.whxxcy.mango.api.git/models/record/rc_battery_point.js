const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  //设备Id
  deviceId: { type: String, required: true },
  // 数据源
  ds: { type: Number, required: true },
  // 状态
  status: {
    // 工作状态
    mode: Number,
    // 电压
    voltage: Number,
    // 信号强度
    signal: Number
  },
  gpsLocation: {
    // wgs84经纬度
    gpsLngLat: [Number],
    // 经纬度
    lngLat: [Number],
    // 瞬时时速
    speed: Number,
    // 方向
    direction: Number,
    // 时间
    time: Date
  },
  cellLocation: {
    mcc: Number,
    mnc: Number,
    cells: [{
      lac: Number,
      cellid: Number,
      rxl: Number
    }],
    time: Date
  },
  nId: { type: String },
  appVersion: { type: String }
}, {
  read: 'secondaryPreferred'
});

schema.index({ deviceId: 1, createdAt: -1 });

module.exports = conn.record.model('rc_battery_point', schema);