const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 操作人 为空即为系统操作
  operator: {
    // 姓名
    name: { type: String, index: true, sparse: true },
    // 手机号
    tel: { type: String, index: true, sparse: true },
    // 头像
    avator: String,
    // 操作地点
    location: {
      lngLat: [Number],
      address: String,
    }
  },
  // 操作时间
  opAt: { type: Date, index: true, sparse: true },
// 日志实体（被操作数据），用于搜索
  entities: {
    // 车辆id
    stockId: { type: String, index: true, sparse: true },
    // 车牌号
    stockNo: { type: String, index: true, sparse: true },
    // 盒子号
    box: { type: String, index: true, sparse: true },
    // 车型（对车型的操作，如果是操作车辆，不记录车型）
    style: { type: String, index: true, sparse: true },
    // 大区
    region: { type: String, index: true, sparse: true },
    // 用户
    user: { type: String, index: true, sparse: true },
    // 用户手机号
    userTel: { type: String, index: true, sparse: true },
    // 订单
    order: { type: String, index: true, sparse: true },
    // 预约订单
    reservation: { type: String, index: true, sparse: true },
    // 电池盒子号
    btBox: { type: String, index: true, sparse: true },
  },
  // 描述
  description: { type: String, required: true },
  // 参数（替换描述中占位符）
  params: {},
  // 用于筛选的编码
  code: { type: String, required: true, index: true }
}, {
  read: 'secondaryPreferred'
});

schema.index({ opAt: -1, code: 1});
schema.index({
  opAt: -1,
  'operator.tel': 1,
});
schema.index({ opAt: 1 }, {expireAfterSeconds: 30 * 24 * 3600 * 1000});

module.exports = conn.record.model('rc_oplog', schema);
