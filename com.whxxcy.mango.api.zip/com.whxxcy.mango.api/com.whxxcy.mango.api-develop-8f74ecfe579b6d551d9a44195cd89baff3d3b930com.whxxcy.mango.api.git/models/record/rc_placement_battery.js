const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 操作人ref
  operator: { type: String, required: true },
  // 大区
  region: { type: String, rquired: true },
  // 车辆
  stock: { type: String, required: true },
  // 占位电池id
  battery: { type: String, required: true },
  // 二维码
  QRCode: { type: String, required: true },
  // 去向
  locate: Number,
  // 产生原因
  reason: { type: Number, required: true, enums: constants.RC_PLACEMENT_BATTERY_TYPE_ENUMS },
}, {
  read: 'secondaryPreferred',
});

schema.index({ stock: 1 });

module.exports = conn.record.model('rc_placement_battery', schema);
