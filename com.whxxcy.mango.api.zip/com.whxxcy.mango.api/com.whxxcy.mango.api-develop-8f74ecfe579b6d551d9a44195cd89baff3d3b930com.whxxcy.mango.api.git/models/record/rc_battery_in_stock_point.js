const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 电池编号 ref
  battery: { type: String, required: true },
  // 车辆编号
  stock: { type: String, required: true },
  // 盒子号
  box: { type: String, required: true },
  // 大区
  region: { type: String, required: true },
  // 开始时间
  startTime: { type: Date, required: true },
  // 结束时间
  endTime: { type: Date },
  // 是否完成
  finished: { type: Boolean, default: false },
  // oss地址
  url: { type: String, required: true },
}, {
  read: 'secondaryPreferred',
});

schema.index({ battery: 1, stock: 1, _id: -1 });
schema.index({ battery: 1, endTime: -1 });

module.exports = conn.record.model('rc_battery_in_stock_point', schema);
