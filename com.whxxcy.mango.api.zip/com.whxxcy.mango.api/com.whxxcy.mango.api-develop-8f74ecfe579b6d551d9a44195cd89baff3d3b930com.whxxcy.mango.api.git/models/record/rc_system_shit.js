const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 是否删除
  removed: { type: Boolean, default: false, required: true },
  // 编号
  number: Number,
  // 创建人
  creator: { type: String, required: true },
  // 端口
  port: { type: Number, enums: constants.RC_SYSTEM_SHIT_PORT_ENUMS, required: true },
  // 状态
  state: { type: Number, enums: constants.RC_SYSTEM_SHIT_STATE_ENUMS, default: constants.RC_SYSTEM_SHIT_STATE.待处理 },
  // 内容
  content: { type: String, required: true },
  // 图片
  image: [],
  // 最近一次更新人
  updater: { type: String },
  // 支持此反馈人数
  supporter: [{
    // 支持的用户 id
    id: String,
    // 用户支持的时间
    time: Date
  }],
  // 认领人
  receiver: [String],
  // 处理人
  handler: [String],
  // 紧急程度
  level: Number,
  // 评论
  comments: [{
    // 创建人
    creator: String,
    // 评论内容
    content: String,
    // 评论时间
    time: Date
  }],
  // 反馈的超链接
  href: String
}, {
  read: 'secondaryPreferred',
});

schema.index({ port: 1 });
schema.index({ updatedAt: -1 });

module.exports = conn.record.model('rc_system_shit', schema);
