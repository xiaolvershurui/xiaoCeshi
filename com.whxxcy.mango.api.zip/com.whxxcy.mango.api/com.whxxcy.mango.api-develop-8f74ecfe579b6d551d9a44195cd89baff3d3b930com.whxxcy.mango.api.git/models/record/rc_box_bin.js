const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  type: String,
  deviceId: String,
  cmd: Number,
  pid: Number,
  body: String,
}, {
  shardKey: { deviceId: 1 },
  read: 'secondaryPreferred'
});

// schema.index({ deviceId: 1, createdAt: -1 });

module.exports = conn.record.model('rc_box_bin', schema);