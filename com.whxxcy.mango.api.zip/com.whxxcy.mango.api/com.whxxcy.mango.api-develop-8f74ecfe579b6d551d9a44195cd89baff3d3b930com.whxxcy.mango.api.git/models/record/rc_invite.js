const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 邀请人账户ref
  user: { type: String, required: true },
  // 被邀请人ref
  invitedUser: { type: String, required: true },
  // 邀请时间
  invitedAt: { type: Date, required: true },
}, {
  shardKey: {
    user: 1,
  },
  read: 'secondaryPreferred',
});

schema.index({ user: 1 });

module.exports = conn.record.model('rc_invite', schema);
