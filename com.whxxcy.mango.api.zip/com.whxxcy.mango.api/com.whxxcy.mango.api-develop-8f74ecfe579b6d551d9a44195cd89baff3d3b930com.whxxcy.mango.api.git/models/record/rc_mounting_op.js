const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 配件类型
  mounting: { type: String, required: true },
  // 使用数量
  count: { type: Number, required: true, min: 0, index: true },
  // 使用者
  operator: String,
}, {
  read: 'secondaryPreferred'
});

module.exports = conn.record.model('rc_mounting_op', schema);