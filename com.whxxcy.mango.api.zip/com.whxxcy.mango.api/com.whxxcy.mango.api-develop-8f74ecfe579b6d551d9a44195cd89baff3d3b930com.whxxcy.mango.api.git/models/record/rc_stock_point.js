const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区ref
  region: { type: String },
  // 车辆ref
  stock: { type: String },
  // 车型ref
  style: { type: String },
  // 盒子ref
  box: { type: String, required: true },
  // 数据源
  dataSource: {
    type: Number,
    required: true,
    enums: constants.BK_BOX_DATA_SOURCE_ENUMS,
  },
  // 是否在线
  isOnline: { type: Boolean },
  // gps信息
  gps: {
    // 经纬度
    lngLat: { type: [Number], index: '2dsphere' },
    // 地址
    address: String,
    // 定位类型
    locationType: {
      type: Number,
      enums: constants.BK_BOX_LOCATION_TYPE_ENUMS
    },
    // 瞬时速度
    speed: Number,
    // 方向
    direction: Number,
    // 海拔
    alt: Number,
  },
  // 警报事件
  alarms: [{
    type: Number,
    enums: constants.RC_ALARM_TYPE_ENUMS
  }],
  // 附加信息
  extra: {
    // 今日里程
    mileageOfDay: Number,
    // 今日行驶时间
    timeOfDay: Number,
    // 总行驶里程
    mileageInAll: Number,
    // 总行驶时间
    timeInAll: Number,
    // 电压
    voltage: Number,
    // 设备电量
    battery: Number,
    // 设备信号
    signal: Number,
    // GPS精度因子
    gpsSignal: Number
  },
  // 电门状态
  acc: Boolean,
  // 锁定状态
  lock: Boolean,
  // 电池仓锁锁定状态
  batteryLock: Boolean,
  // 断电状态
  powerUnlink: Boolean,
  // 后轮锁状态
  wheelLock: Boolean,
  // 采集时间
  time: { type: Date, required: true },
  // 车辆电量
  stockPower: Number,
  // sim卡信息
  sim: {
    // CCID
    ccid: String,
    // IMSI
    imsi: String,
    // 开机状态
    powerOn: Boolean,
    // 工作状态
    working: Boolean,
  },
  // 上报时间差
  expires: { type: Number },
  // 盒子软件版本号
  appVersion: String,
  // 盒子型号
  deviceType: String,
  // 与上一个有效点的距离
  deltaMileage: Number,
  mdis: Number,
  // 采样速度
  sampleSpeed: Number,
  lastLngLat: [Number],
  // 上次记录时间
  lastSnappedAt: Date,
  // 记录时是否过期
  expired: Boolean,
  // 不合法的经纬度
  illegalLngLat: Boolean,
  // 节点ID
  nodeId: String,
  // 指令
  cmd: Number,
  // 报文
  bin: String,
}, {
  shardKey: {
    box: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ box: 1, time: -1, 'gps.locationType': 1 });
schema.index({ 'gps.locationType': 1, acc: 1, lock: 1, 'gps.lngLat': '2dsphere' });

module.exports = conn.record.model('rc_stock_point', schema);