const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 电池编号 ref
  battery: { type: String, required: true },
  // 车辆
  stock: String,
  // 二维码
  QRCode: { type: String, required: true },
  // 丢失地点
  lostAddress: String,
  // 标记
  mark: String,
  // 报失时间
  lostAt: Date,
  // 创建人
  operator: { type: String, required: true },
  // 找回人
  finder: String,
  // 找回地址
  findAddress: String,
  // 找回时间
  foundedAt: Date,
  // 是否找回
  hasFind: { type: Boolean, required: true, default: false }
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 });
schema.index({ QRCode: 1, type: 1 });

module.exports = conn.record.model('rc_battery_lost', schema);