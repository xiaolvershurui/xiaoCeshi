const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const constants = require('../../settings/constants');
// 消息体系
const schema = new Schema({
  // 消息通知类型
  type: { type: Number, enums: constants.RC_MESSAGE_SYSTEM_TYPE },
  // 消息通知样式
  style: { type: Number, enums: constants.RC_MESSAGE_STYLE },
  // 列表跳转方式
  linkStyle: { type: Number, enums: constants.RC_MESSAGE_LINK_STYLE },
  // 是否通知所有的用户
  isNotifyAllUsers: Boolean,
  // 是否已读
  isRead: { type: Boolean, default: false},
  //  工单回复通知
  workOrderNotify: {
    // 工单回复 ref
    id: String,
    // 用户 ref
    user: String,
  },
  // 订单免单通知
  orderFreeNotify: {
    // 订单免单 ref
    id: String,
    // 免单用户 ref
    user: String,
  },
  // 优惠券到账通知
  couponNotify: {
    // 优惠券 ref
    id: String,
    // 用户 ref
    user: String,
  },
  // 重大活动通知
  importActivityNotify: {
    // 创建人
    creator: String,
    // 最近一次更新人
    updater: String,
    // 是否已读
    isRead: Boolean,
    // 标题
    title: String,
    // 内容
    content: String,
    // 图
    image: String,
    // 发布时间
    releaseTime: Date,
    // 过期时间
    expiredAt : Date,
    // 链接地址
    linkUrl: String,
  },
  // 计价变更通知
  priceChangeNotify: {
    // 计价变更 ref
    id: String,
  },
  // 围栏变更通知
  railUpdateNotify: {
    // 通知 ref
    id: String,
    // 用户 ref
    user: String,
    // 过期时间
    expiredAt: { type: Date },
  },
  // 押金退还
  refundNotify: {
    // 账单 ref
    id: String,
    user: String,
  },
  // 信用减分
  creditDecreaseNotify: {
    // 用户 ref
    user: String,
    // 订单 ref
    order:String,
  },
}, {
  read: 'secondaryPreferred',
});

schema.index({ type: 1, user: 1, isNotifyAllUsers: 1 });
module.exports = conn.record.model('rc_message_system', schema);
