const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 仓库ref
  station: { type: String, required: true },
  // 盘点人
  operator: { type: String, required: true },
  // 线上总数
  onlineCount: { type: Number, required: true, min: 0 },
  // 线下总数
  offlineCount: { type: Number, required: true, min: 0 },
  // 线上有
  online: [String],
  // 线下车牌号
  offlineNo: [String],
  // 线下车架号
  offlineVin: [String],
  // 线下盒子号
  offlineBox: [String],
  // 线下盒子序号
  offlineBoxIndex: [String]
}, {
  read: 'secondaryPreferred'
});

schema.index({ station: 1 });

module.exports = conn.record.model('rc_stock_check', schema);