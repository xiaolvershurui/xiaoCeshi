const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 操作人
  operator: { type: String, required: true },
  // 总编号
  stocks: [String],
  // 总车牌号
  numbers: [String],
  // 成功数组
  success: [],
  // 失败车牌
  failed: {},
  // 去向大区
  toRegion: { type: String, required: true },
  // 卡车车牌
  carNo: String,
  // 重试时间
  lastTriedAt: Date,
  // 出库完成
  isFinished: { type: Boolean, default: false },
  // 出库完成时间
  finishedAt: Date,
}, {
  read: 'secondaryPreferred'
});

schema.index({
  numbers: 1,
  isFinished: 1
});

module.exports = conn.record.model('rc_out_factory', schema);
