const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 电池编号 ref
  battery: { type: String, required: true },
  // 大区
  region: String,
  // 车辆
  stock: String,
  // 二维码
  QRCode: { type: String, required: true },
  // 标记
  mark: String,
  // 描述
  description: String,
  // 操作备注
  remark: String,
  // 电池站
  inStation: String,
  // 操作类型
  type: { type: Number, enums: constants.RC_BATTERY_OP_RECORD_TYPE_ENUMS, required: true },
  // 接收电池电站来源
  fromStation: String,
  // 巡检师傅来源
  fromAccount: String,
  // 操作时间
  operatedAt: { type: Date, required: true },
  // 操作人
  operator: { type: String, required: true },
  // 操作人姓名
  operatorName: { type: String, required: true },
  // 位置
  location: [Number],
  // 位置
  address: String,
  // 电池图片
  batteryImages: [String],
  // 更新状态
  updateState: {
    prev: Number,
    next: Number,
  },
  // 更新去向
  updateLocate: {
    prev: Number,
    next: Number,
  },
  updateQRCode: {
    prev: String,
    next: String,
  },
  updateMark: {
    prev: String,
    next: String,
  },
  updateRegion: {
    prev: String,
    next: String,
  },
  updateStation: {
    prev: {
      id: String,
      name: String,
    },
    next: {
      id: String,
      name: String,
    },
  },
  updateInspector: {
    prev: {
      id: String,
      name: String,
      tel: String,
    },
    next: {
      id: String,
      name: String,
      tel: String,
    },
  },
}, {
  read: 'secondaryPreferred'
});

schema.index({ stock: 1 });
schema.index({ QRCode: 1, type: 1 });
schema.index({ operatedAt: 1 });
schema.index({ battery: 1 });

module.exports = conn.record.model('rc_battery_op', schema);
