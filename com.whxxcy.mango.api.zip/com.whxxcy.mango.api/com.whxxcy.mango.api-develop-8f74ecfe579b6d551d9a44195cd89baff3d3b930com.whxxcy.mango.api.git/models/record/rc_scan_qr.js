const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 用户姓名
  userName: String,
  // 用户手机号
  userTel: String,
  // 大区
  region: String,
  // 二十分钟内是否依然下单成功
  rentSuccess: { type: Boolean, default: false, required: true },
  // 扫码内容
  scanContent: String,
  // 是否是扫码记录 否则是输入车牌号记录
  isScanQR: { type: Boolean },
  // 是否发放了优惠券
  issuedCoupon: { type: Boolean, default: false },
  // 扫码结果
  succeed: { type: Boolean, default: false, required: true },
  // 如果失败，报错信息
  error: String,
  errorCode: String,
  // 如果是芒果车辆，车辆ref
  stock: String,
  // 如果是芒果车辆，车辆车牌号
  stockNo: String,
  // 扫码位置
  lngLat: { type: [Number], index: '2dsphere' },
  // 地址
  address: String,
  // 精度
  accuracy: Number,
  // 扫码时间
  scannedAt: { type: Date },
  // 设备信息
  deviceInfo: {
    // 平台
    platform: String,
    // 系统版本
    version: String,
    // 设备型号
    modal: String,
    // udid
    udid: String,
    // 设备名
    name: String,
  },
  // app版本号
  appVersion: String,
  // 城市
  city: String
}, {
  shardKey: {
    stock: 1,
    scannedAt: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ isScanQR: 1, stock: 1, scannedAt: -1 });
schema.index({ stock: 1, user: 1, scannedAt: -1 });
schema.index({ user: 1, scannedAt: -1, error: -1 });
schema.index({ scannedAt: -1, error: -1});

module.exports = conn.record.model('rc_scan_qr', schema);