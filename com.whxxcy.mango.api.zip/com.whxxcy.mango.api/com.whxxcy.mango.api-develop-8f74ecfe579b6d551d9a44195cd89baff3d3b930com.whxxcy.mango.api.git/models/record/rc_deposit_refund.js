const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 账户
  user: { type: String },
  // 大区
  region: String,
  // 历史退款次数
  refundCount: { type: Number },
  // 上次退押金时间
  lastRefundDate: { type: Date },
  // 本次提交押金时间
  refundDate: { type: Date },
  // 距上次退押金时间间隔(天)
  refundInterval: { type: Number },
  // 历史下单成功次数
  historySuccessOrderCount: { type: Number },
  // 本次下单成功数
  successOrderCountInSection: { type: Number },
  // 注册天数
  registeredDays: { type: Number },
}, {
  read: 'secondaryPreferred'
});

schema.index({ 'refundDate': 1 });
schema.index({ user: 1 });
schema.index({ region: 1 });

module.exports = conn.record.model('rc_deposit_refund', schema);