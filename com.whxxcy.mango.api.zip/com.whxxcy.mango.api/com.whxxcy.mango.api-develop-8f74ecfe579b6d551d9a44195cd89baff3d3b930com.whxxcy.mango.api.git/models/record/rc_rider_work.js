const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 骑行单
  riderOrder: { type: String, required: true },
  // 巡检人
  user: { type: String, required: true },
  // 一小时内巡检车辆数
  inspectionCountOneHour: { type: Number, default: 0 },
  // 一小时内摆放车辆数
  placeCountOneHour: { type: Number, default: 0 },
  // 累计巡检车辆数
  totalInspectionCount: { type: Number, default: 0 },
  // 累计摆放车辆数
  totalPlaceCount: { type: Number, default: 0 },
  // 累计巡检里程
  totalDistance: { type: Number, default: 0 },
});

schema.index({ user: 1 });
module.exports = conn.record.model('rc_rider_work', schema);
