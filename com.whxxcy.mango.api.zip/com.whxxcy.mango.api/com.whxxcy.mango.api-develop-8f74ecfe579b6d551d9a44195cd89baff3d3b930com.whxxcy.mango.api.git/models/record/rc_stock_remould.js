const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

// 车辆改造记录
const schema = new Schema({
  // 状态
  status: { type: Number, enums: constants.RC_STOCK_REMOULD_STATUS_ENUMS, default: constants.RC_STOCK_REMOULD_STATUS.未改造 },
  // 车辆 ref
  stock: { type: String, required: true },
  // 改造项
  remould: { type: String, required: true },
  // 改造链接
  href: { type: String },
  // 改造人 ref
  remouldMan: String,
  // 改造时间
  remouldTime: Date,
  // 改造图片
  remouldPhoto: String,
  // 车辆改造记录创建人 ref
  creator: String
}, {
  read: 'secondaryPreferred'
});

schema.index({ 'stock': 1 });

schema.plugin(betterId, { connection: conn.record });
module.exports = conn.record.model('rc_stock_remould', schema);
