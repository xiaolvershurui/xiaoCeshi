const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  region: String,
  date: Date,
  // 18点数据分析
  changeVoltage: [{
    mileage: Number,
    // 换电车辆换电后收入 + 不换电车辆不换电收入
    totalAmount: Number,
    // 换电车辆不换电收入
    originAmount: Number,
    // 换电成本
    changeCost: Number,
    // 利润
    profit: Number,
    // 换电数量
    changeCount: Number,
  }],
  // 参考日期
  referenceDate: Date,
  // 最佳换电里程
  bestMileage: Number,
  // 后一个里程
  nextMileage: Number,
  // 后一个电压
  nextVoltage: Number,
  // 前一个里程
  prevMileage: Number,
  // 前一个电压
  prevVoltage: Number,
}, {
  read: 'secondaryPreferred',
});

module.exports = conn.record.model('rc_change_voltage', schema);
