const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');
const schema = new Schema({
  // 订单Id
  orderId: {type: String, required: true},
  // 操作员
  operator: {type: String, required: true},
  // 日期
  date: {type: Date, required: true},
  // 后台结束原因
  reason: {type: Number, required: true},
}, {
  read: 'secondaryPreferred'
});
schema.index({orderId: 1});
schema.index({date: 1});
module.exports = conn.record.model('rc_background_finish_order_op', schema);