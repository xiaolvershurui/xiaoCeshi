const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 分享账户ref
  user: { type: String },
  // 分享类型
  type: {
    type: Number,
    required: true,
    enums: constants.RC_SHARE_TYPE_ENUMS,
  },
  // 分享渠道
  channel: {
    type: Number,
    required: true,
    enums: constants.RC_SHARE_CHANNEL_ENUMS
  },
  // 分享时间
  sharedAt: { type: Date, required: true }
}, {
  read: 'secondaryPreferred'
});

module.exports = conn.record.model('rc_share', schema);