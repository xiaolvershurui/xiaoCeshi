const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 签到账户ref
  user: { type: String, required: true },
  // 运营账号ref
  operator: { type: String, required: true },
  // 签到时间
  checkedAt: { type: Date, required: true },
  // 签到类型
  type: { type: Number, enums: constants.RC_CHECK_IN_TYPE_ENUMS, required: true },
  // 位置
  location: {
    lngLat: { type: [Number], index: '2dsphere' },
    address: String
  },
  // 工作时长 单位：分钟
  totalWorkTime: { type: Number, min: 0 },
  // 是否是被踢下线
  isKickedOff: { type: Boolean, default: false },
  // 是否强制上线
  isForceCheckIn: { type: Boolean, default: false },
}, {
  read: 'secondaryPreferred'
});

schema.index({ user: 1 });
schema.index({ operator: 1, checkedAt: -1 });
schema.index({ type: 1, user: 1, checkedAt: -1 });

module.exports = conn.record.model('rc_check_in', schema);