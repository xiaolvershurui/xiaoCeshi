const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 上传人
  uploader: { type: String, required: true },
  // 大区
  prevRegion: { type: String, required: true },
  nextRegion: { type: String, required: true },
  // 状态 0 完善中 1 已完成
  status: { type: Number, default: constants.OD_COMPLETE_STOCK_STATUS.完善中, enums: [0, 1] },
  // 车辆列表
  stocks: [{
    // 车牌号
    custom: String,
    // 料号
    partCode: String,
    // 成车条码
    completeCode: String,
    // 车架码
    vin: String,
    // 电机码
    electricalCode: String,
    // 控制器
    controlCode: String,
    // 完工日期
    finishDate: Date,
    // 出货日期
    shipmentDate: Date,
    // 失败理由
    reason: String,
    // 状态 0 处理中 1 成功 2 失败 3 跳过
    status: { type: Number, default: 0 },
  }],
  // 文件地址
  files: [{
    uploadedAt: Date,
    url: String,
  }],
}, {
  read: 'secondaryPreferred',
});

schema.index({ uploader: 1 });

schema.plugin(betterId, { connection: conn.record });
module.exports = conn.record.model('rc_complete_stock', schema);
