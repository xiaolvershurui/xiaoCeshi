const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 被操作用户id
  user: { type: String, required: true },
  // 被操作用户姓名
  userTel: { type: String },
  // 操作类型
  type: { type: Number, enums: constants.RC_USER_OP_ENUMS, required: true },
  // 操作描述
  description: String,
  // 操作人
  operator: String,
  // 操作人手机号
  operatorTel: String,
  // 操作时间
  operatedAt: { type: Date, required: true },
}, {
  read: 'secondaryPreferred'
});

schema.index({ user: 1, type: 1 });

module.exports = conn.record.model('rc_user_op', schema);
