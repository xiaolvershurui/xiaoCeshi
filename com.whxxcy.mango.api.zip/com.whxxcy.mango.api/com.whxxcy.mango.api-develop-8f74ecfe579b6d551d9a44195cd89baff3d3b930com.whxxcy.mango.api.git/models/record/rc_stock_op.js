const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 车辆ref
  stock: { type: String, required: true },
  // 车牌号
  stockNo: { type: String },
  // 大区
  region: { type: String },
  // 车型
  style: { type: String },
  // 操作类型
  type: { type: Number, enums: constants.RC_STOCK_OP_TYPE_ENUMS, required: true },
  // 操作描述
  description: String,
  // 操作人 为空即为系统操作
  operator: String,
  // 操作人姓名
  operatorName: String,
  // 操作人手机号
  operatorTel: String,
  // 操作人头像
  operatorAvator: String,
  // 操作时间
  operatedAt: { type: Date, required: true },
  // 车辆去向
  locate: Number,
  // 设防
  lockOn: Boolean,
  // 电门状态
  accOn: Boolean,
  // 电压
  voltage: Number,
  // 电池锁状态
  batteryLockOn: Boolean,
  // 操作地点
  operateLocation: {
    lngLat: [Number],
    address: String
  },
  // 操作备注/描述/原因
  operateRemark: String,
  // 车辆位置
  stockLocation: {
    lngLat: [Number],
    address: String
  },
  // 车辆当前分配的巡检人员信息
  inspector: String,
  inspectorName: String,
  inspectorTel: String,
  inspectorAvator: String,
  // 车辆当前分配的巡检区信息
  inspectionArea: String,
  inspectionAreaName: String,
  // 该操作解除的任务列表
  releasedTasks: [],
  // 该操作添加的任务列表
  addedTasks: [],
  // 操作前的任务列表
  prevTaskList: [],
  // 操作相关定制数据
  // 更新定制车牌号
  updateCustomNumber: {
    // 旧车牌
    prev: String,
    // 新车牌
    next: String
  },
  // 更新临时车牌号
  updateTempNumber: {
    prev: String,
    next: String,
  },
  // 更新交管局车牌号
  updateLicenseNumber: {
    prev: String,
    next: String,
  },
  // 更新车架号
  updateVin: {
    prev: String,
    next: String
  },
  // 更换大区
  updateRegion: {
    prev: {
      id: String,
      name: String
    },
    next: {
      id: String,
      name: String
    }
  },
  // 更换车型
  updateStyle: {
    prev: {
      id: String,
      name: String,
      level: Number
    },
    next: {
      id: String,
      name: String,
      level: Number
    }
  },
  // 更换盒子
  updateBox: {
    prev: String,
    next: String,
    reason: Number,
  },
  // 添加损坏
  addDamage: {
    // 损坏记录id
    id: String,
    // 损坏描述
    description: String,
    // 损坏照片
    photo: String,
    // 记录前车辆状态
    prevStockState: Number,
    // 记录后车辆状态
    nextStockState: Number
  },
  // 修复损坏
  repairDamage: {
    // 损坏记录ID
    id: String,
    // 损坏描述
    description: String,
    // 损坏照片
    photo: String,
    // 修复照片
    repairPhoto: String,
    // 修复备注
    repairRemark: String,
    // 修复前车辆状态
    prevStockState: Number,
    // 修复后车辆状态
    nextStockState: Number,
  },
  // 投放车辆
  putOn: {
    // 投放前仓库
    storehouse: {
      id: String,
      name: String,
      lngLat: [Number],
      address: String
    },
    // 投放地址
    putOnLocation: {
      lngLat: [Number],
      address: String
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 回收车辆
  recover: {
    // 回收前地址
    recoverLocation: {
      lngLat: [Number],
      address: String,
    },
    // 回收到仓库
    storehouse: {
      id: String,
      name: String,
      lngLat: [Number],
      address: String
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 预约车辆
  reservation: {
    // 预约人
    user: {
      id: String,
      tel: String,
      name: String,
    },
    // 预约时用户的位置快照
    userLocation: {
      lngLat: [Number],
      address: String,
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 取消预约
  cancelReservation: {
    // 是否预约成功
    succeed: Boolean,
    // 预约人
    user: {
      id: String,
      tel: String,
      name: String,
    },
    // 取消预约时用户的位置快照
    userLocation: {
      lngLat: [Number],
      address: String,
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 租用车辆
  rent: {
    // 订单号
    order: String,
    // 租用人
    user: {
      id: String,
      tel: String,
      name: String,
    },
    // 车辆位置
    location: {
      lngLat: [Number],
      address: String
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 归还车辆
  returnBack: {
    // 订单号
    order: String,
    // 租用人
    user: {
      id: String,
      tel: String,
      name: String
    },
    // 结束时订单的状态
    orderState: Number,
    // 订单总额
    totalAmount: Number,
    // 骑行时长
    duration: Number,
    // 骑行距离
    distance: Number,
    // 停车地点是否在围栏外
    outsideRegion: Boolean,
    // 是否在禁行区内
    insideProhibitedArea: Boolean,
    // 是否在禁停区内
    insideForbiddenArea: Boolean,
    // 是否在停车区内
    insidePark: Boolean,
    // 车辆位置
    location: {
      lngLat: [Number],
      address: String,
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 开始调度
  startDispatch: {
    // 开始调度位置
    location: {
      lngLat: [Number],
      address: String,
    },
    // 开始调度的仓库
    storehouse: {
      id: String,
      name: String,
      lngLat: [Number],
      address: String
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 结束调度
  finishDispatch: {
    // 开始调度位置或仓库
    startLocation: {
      lngLat: [Number],
      address: String,
    },
    startStorehouse: {
      id: String,
      name: String,
      lngLat: [Number],
      address: String
    },
    // 结束调度位置
    location: {
      lngLat: [Number],
      address: String,
    },
    // 结束调度的仓库
    storehouse: {
      id: String,
      name: String,
      lngLat: [Number],
      address: String
    },
    prevPrevLocate: Number,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 车辆被扣上报
  detained: {
    // 被扣地点
    location: {
      lngLat: [Number],
      address: String
    },
    // 照片
    photo: String,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 被扣找回
  detainedFindBack: {
    // 找回地点
    location: {
      lngLat: [Number],
      address: String,
    },
    // 照片
    photo: String,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 申请拖回
  applyReturnBack: {
    // 申请时车辆地点
    location: {
      lngLat: [Number],
      address: String
    },
    // 照片
    photo: String,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 取消拖回
  cancelReturnBack: {
    prevLocate: Number,
    nextLocate: Number,
  },
  // 登记丢失
  setLost: {
    // 最后定位地点
    location: {
      lngLat: [Number],
      address: String,
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 丢失找回
  findBack: {
    // 找回地点
    location: {
      lngLat: [Number],
      address: String,
    },
    // 拍照
    photo: String,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 登记疑似丢失
  setSuspectedLost: {
    // 最后定位地点
    location: {
      lngLat: [Number],
      address: String,
    },
    prevLocate: Number,
    nextLocate: Number,
  },
  // 疑似丢失找回
  suspectedLostFindBack: {
    // 找回地点
    location: {
      lngLat: [Number],
      address: String,
    },
    // 拍照
    photo: String,
    prevLocate: Number,
    nextLocate: Number,
  },
  // 找车打卡
  findStock: {
    // 是否找到车
    hasFind: Boolean,
    // 拍照
    photo: String,
    // 未找到原因
    failedReason: Number
  },
  // 更换电池
  exchangeBattery: {
    // 旧电池
    prev: {
      id: String,
      voltage: Number,
      power: Number,
      mileage: Number,
    },
    // 新电池
    next: {
      id: String,
      voltage: Number,
      power: Number,
      mileage: Number
    }
  },
  // 强制刷新位置
  forceUpdate: {
    // 是否刷新到卫星定位
    isGpsLocation: Boolean,
    // 定位地址
    location: {
      lngLat: [Number],
      address: String
    },
  },
  // 分配巡检人员
  distributeInspector: {
    inspector: String,
    inspectorName: String,
    inspectorTel: String,
  },
  // 解除巡检人员
  releaseInspector: {
    // 之前巡检人员信息
    inspector: String,
    inspectorName: String,
    inspectorTel: String,
  },
  // 驶入巡检区
  intoInspectionArea: {
    inspectionArea: String,
    inspectionAreaName: String,
  },
  // 驶出巡检区
  outInspectionArea: {
    // 之前巡检区
    inspectionArea: String,
    inspectionAreaName: String,
  },
  // 添加特别任务
  addSpecialTask: {
    taskId: String,
    remark: String,
    photo: String,
    time: Date,
    location: {
      lngLat: [Number],
      address: String
    }
  },
  // 完成特别任务
  removeSpecialTask: {
    taskId: String,
    remark: String,
    photo: String,
    time: Date,
    location: {
      lngLat: [Number],
      address: String
    },
    finishRemark: String,
    finishPhoto: String,
    finishLocation: {
      lngLat: [Number],
      address: String
    },
    finishTime: Date,
  },
  // 解除复活任务
  releaseRevival: {
    photo: String
  },
  // 调整定位
  adjustLocation: {
    // 调整前定位
    prev: {},
    // 调整后定位
    next: {}
  },
  // 其他占用
  otherOccupancy: {
    prevLocate: Number,
    nextLocate: Number,
  },
  // 取消占用
  releaseOccupancy: {
    prevLocate: Number,
    nextLocate: Number,
  },
  // 入库
  inBound: {
    prevPrevLocate: Number,
    prevLocate: Number,
    nextLocate: Number,
    nextStation: String
  },
  // 出库
  outBound: {
    prevLocate: Number,
    nextLocate: Number,
    prevStation: String
  },
  // 报失电池
  batteryLost: {
    //电池仓是否完好
    isIntact: Boolean,
    // 备注
    remark: String,
    // 电池仓照片
    batteryImages: [String]
  },
  scrap: {
    prevState: Number,
    nextState: Number
  }
}, {
  shardKey: {
    stock: 1
  },
  read: 'secondaryPreferred'
});

schema.index({ type: 1 });
schema.index({ type: 1, stockNo: 1, operatedAt: 1, _id: -1 });
schema.index({ type: 1, operatedAt: 1 });
schema.index({ type: 1, stock: 1, _id: -1 });

module.exports = conn.record.model('rc_stock_op', schema);
