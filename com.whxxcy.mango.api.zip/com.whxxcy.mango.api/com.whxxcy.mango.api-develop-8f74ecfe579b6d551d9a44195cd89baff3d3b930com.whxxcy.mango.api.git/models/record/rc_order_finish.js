const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  user: { type: String, required: true },
  order: { type: String, required: true },
  tel: { type: String, required: true },
  feedback: [{
    opAt: Date,
    clickType: { type: Number, enums: constants.RC_ORDER_FINISH_CLICK_ENUMS },
    succeed: Boolean,
    lockSuccess: Boolean,
    orderFinished: Boolean,
    error: String,
    polygon: String
  }],
}, {
  read: 'secondaryPreferred'
});

schema.index({ order: -1 });
schema.index({ tel: -1 });

module.exports = conn.record.model('rc_order_finish', schema);