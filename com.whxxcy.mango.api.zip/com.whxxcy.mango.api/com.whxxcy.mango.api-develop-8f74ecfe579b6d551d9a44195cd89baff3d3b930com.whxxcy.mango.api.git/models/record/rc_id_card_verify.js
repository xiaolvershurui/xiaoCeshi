const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 账户
  user: { type: String },
  // 身份证号
  certNo: String,
  // 姓名
  name: String,
  // 手机号
  tel: String,
  // 是否成功
  succeed: { type: Boolean, required: true },
  // 是否扣费
  fee: { type: Boolean },
  // 描述
  description: String,
  // 时间
  verifiedAt: { type: Date, required: true }
}, {
  read: 'secondaryPreferred'
});

module.exports = conn.record.model('rc_id_card_verify', schema);