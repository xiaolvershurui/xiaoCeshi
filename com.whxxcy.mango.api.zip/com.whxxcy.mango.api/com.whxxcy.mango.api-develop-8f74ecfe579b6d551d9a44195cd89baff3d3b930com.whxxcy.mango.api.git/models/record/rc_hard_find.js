const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const constants = require('../../settings/constants');
const betterId = require('mongoose-better-id');

const schema = new Schema({
  // 大区ref
  region: { type: String },
  // 车辆ref
  stock: { type: String },
  // 未找到该车辆巡检员
  notFoundInspector: [{
    // 巡检员 ref
    id: String,
    // 未找到时间
    time: Date,
  }],
  // 是否找到
  findState: { type: Boolean, default: false },
  // 奖金
  bonus: { type: Number },
  // 第一次未找到时间
  firstTime: { type: Date },
  // 找到巡检员 ref
  inspector: String,
  // 车辆被找到时间
  fondTime: { type: Date },
  // 是否已结算费用
  settleState: { type: Boolean, default: false },
  // 结算费用操作人
  operator: { type: String },
  // 结算费用时间
  settleTime: { type: Date },
}, {
  read: 'nearest',
});

schema.index({ inspector: 1, fondTime: -1 });
schema.index({ stock: 1, findState: 1 });

schema.plugin(betterId, { connection: conn.record });
module.exports = conn.record.model('rc_hard_find', schema);
