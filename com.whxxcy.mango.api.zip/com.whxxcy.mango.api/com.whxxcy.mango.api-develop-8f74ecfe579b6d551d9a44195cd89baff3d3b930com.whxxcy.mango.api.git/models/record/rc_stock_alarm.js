const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.Types.ObjectId;
const conn = require('../../connections');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 大区ref
  region: { type: String },
  // 车辆ref
  stock: { type: String },
  // 车型ref
  style: { type: String },
  // 盒子ref
  box: { type: String, required: true },
  // 数据源
  dataSource: {
    type: Number,
    required: true,
    enums: constants.BK_BOX_DATA_SOURCE_ENUMS,
  },
  // 采集点ref
  point: { type: ObjectId, ref: 'rc_stock_point', required: true },
  // 订单ref
  order: { type: String },
  // 账户ref
  user: {
    // 真实姓名
    name: String,
    // 手机号
    tel: String,
    // 身份证号
    certNo: String
  },
  // 警报类型
  type: {
    type: Number,
    required: true,
    enums: constants.RC_ALARM_TYPE_ENUMS
  },
  // 采样点时间
  time: { type: Date, required: true },
  // 采样时acc
  acc: Boolean,
  // 采样时lock
  lock: Boolean,
}, {
  shardKey: {
    stock: 1,
  },
  read: 'secondaryPreferred'
});

schema.index({ type: 1, stock: 1, _id: -1 });

module.exports = conn.record.model('rc_stock_alarm', schema);