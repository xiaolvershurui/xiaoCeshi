const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  // 手机号
  tel: { type: String, required: true },
  // 账户ref
  user: { type: String },
  // 短信模板
  template: { type: String, required: true },
  // 参数
  params: {},
  // 发送时间
  sentAt: { type: Date, required: true },
  // 是否发送成功
  succeed: { type: Boolean, required: true },
  // 发送失败的原因
  error: {
    message: String,
    stack: String
  }
}, {
  read: 'secondaryPreferred'
});

module.exports = conn.record.model('rc_sms', schema);