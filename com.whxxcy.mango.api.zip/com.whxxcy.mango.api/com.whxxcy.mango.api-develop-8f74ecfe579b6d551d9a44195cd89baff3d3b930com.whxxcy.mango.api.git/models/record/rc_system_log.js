const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');

const schema = new Schema({
  creator: { type: String, required: true },
  title: { type: String, required: true },
  content: { type: String, required: true },
  // 最近一次更新人
  updater: { type: String },
}, {
  read: 'secondaryPreferred',
});

schema.index({ updatedAt: -1 });

module.exports = conn.record.model('rc_system_log', schema);
