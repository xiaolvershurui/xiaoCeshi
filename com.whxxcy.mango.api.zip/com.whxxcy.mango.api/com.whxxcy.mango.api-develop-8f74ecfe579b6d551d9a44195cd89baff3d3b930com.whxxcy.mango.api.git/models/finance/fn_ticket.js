const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 类型
  type: {
    type: Number,
    enums: constants.FN_TICKET_TYPE_ENUMS,
    required: true,
  },
  // 支付状态
  state: {
    type: Number,
    enums: constants.FN_TICKET_STATE_ENUMS,
    default: constants.FN_TICKET_STATE.待支付,
  },
  // 支付金额
  amount: { type: Number, min: 0, required: true },
  // 支付渠道
  channel: { type: String, required: true, enums: constants.FN_TICKET_CHANNEL_ENUMS },
  // api渠道
  apiChannel: {
    type: String, required: true,
    default: constants.FN_TICKET_PAYMENT_API_CHANNEL.pingxx,
    enums: constants.FN_TICKET_PAYMENT_API_CHANNEL_ENUMS,
  },
  // ping++支付凭据
  pingpp: {
    // 支付凭据
    charge: { type: String },
    // 退款凭据
    refund: { type: String },
  },
  // 支付宝渠道额外信息
  alipayExtra: {},
  // 微信渠道额外信息
  wxpayExtra: {},
  // ping++渠道额外信息
  pingppExtra: {},
  // 渠道订单号
  tradeNo: { type: String },
  // 支付过期时间
  expires: { type: Date, required: true },
  // 完成支付时间
  finishedAt: { type: Date },
  // 取消时间
  cancelledAt: { type: Date },
  // 取消原因
  cancelReason: String,
  // 错误信息
  cancelError: String,
  // 取消人
  canceller: {
    type: Number,
    enums: constants.FN_TICKET_CANCLLER_ENUMS,
  },
  // 退款信息
  refund: {
    // 退款请求ID
    requestId: String,
    // 申请退款时间 （主要对于押金退款）
    appliedAt: { type: Date },
    // 退款金额
    amount: { type: Number, min: 0 },
    // 系统判断的退款原因
    reason: String,
    // 失败时间
    failedAt: { type: Date },
    // 失败原因
    failedReason: String,
    // 自动确认时间（为空的话必须手动确认）
    willProcessAt: { type: Date },
    // 实际确认时间 (好像根本没用上这个字段，弃用)
    confirmedAt: { type: Date },
    // 退款处理人
    processor: String,
    // 退款处理人类型
    processorType: {
      type: Number,
      enums: constants.FN_REFUND_PROCESSOR_TYPE_ENUMS,
    },
    // 处理时间
    processedAt: { type: Date },
    // 退款完成时间
    finishedAt: { type: Date },
    // 人工转账退款
    manualFinished: {
      // 人工退款处理人 ref
      processor: { type: String },
      // 人工退款流水号
      tradeNo: { type: String },
    },
    // 用户填写的退款原因
    userReason: String,
    // 用户填写其他时的退款原因
    userReasonExtra: String,
    // 退款账号
    refundAccount: {
      type: { type: Number },
      account: { type: String },
      // 填写账户姓名
      name: { type: String },
    },
  },
  // 备注
  subject: String,
  // 驳回理由
  rejectReason: String,
}, {
  shardKey: {
    _id: 'hashed',
  },
  read: 'primary',
});

schema.index({ _id: 'hashed' });
schema.index({ user: 1 });
schema.index({ finishedAt: 1 });
schema.index({ state: 1, 'refund.willProcessAt': 1 });
schema.index({ state: 1, 'refund.failedAt': 1 });
schema.index({ 'refund.appliedAt': -1 });
schema.index({ 'refund.finishedAt': -1 });
schema.index({ createdAt: -1, 'refund.appliedAt': -1, type: 1, state: 1 });
schema.index({ state: 1,'refundAccount.account': 1, _id: -1 });

schema.plugin(betterId, { connection: conn.finance });
module.exports = conn.finance.model('fn_ticket', schema);
