const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');
const ObjectId = Schema.Types.ObjectId;

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 类型
  type: {
    type: Number,
    enums: constants.FN_BALANCE_BILL_TYPE,
    required: true,
  },
  // 大区
  region: { type: String },
  // 车型
  style: { type: String },
  // 标记
  signal: {
    type: Number,
    enums: constants.FN_BALANCE_BILL_SIGNAL_ENUMS,
    required: true,
  },
  // 订单ref
  order: { type: String },
  // 第三方支付凭据ref
  ticket: { type: String, ref: 'fn_ticket' },
  // 流水凭据 ref
  flow: { type: ObjectId },
  // 账单总额
  amount: { type: Number, min: 0, required: true },
}, {
  shardKey: {
    _id: 'hashed',
  },
  read: 'primaryPreferred',
});

schema.index({ _id: 'hashed' });
schema.index({ user: 1 });
schema.index({ createdAt: -1, signal: 1, region: 1 });

schema.plugin(betterId, { connection: conn.finance });
module.exports = conn.finance.model('fn_balance_bill', schema);
