const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  // 账户ref
  user: { type: String, required: true },
  // 类型
  type: {
    type: Number,
    enums: constants.FN_DEPOSIT_BILL_TYPE_ENUMS,
    required: true,
  },
  // 第三方支付凭据ref
  ticket: { type: String, ref: 'fn_ticket', required: true },
  // 账单总额
  amount: { type: Number, min: 0, required: true },
}, {
  shardKey: {
    _id: 'hashed',
  },
  read: 'primaryPreferred',
});

schema.index({ _id: 'hashed' });
schema.index({ user: 1 });
schema.index({ createdAt: -1, type: 1 });
schema.plugin(betterId, { connection: conn.finance });
module.exports = conn.finance.model('fn_deposit_bill', schema);
