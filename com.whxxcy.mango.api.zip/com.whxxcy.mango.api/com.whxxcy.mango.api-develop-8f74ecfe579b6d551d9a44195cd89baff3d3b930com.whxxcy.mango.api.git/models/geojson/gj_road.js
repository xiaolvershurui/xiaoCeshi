const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const conn = require('../../connections/index');
const betterId = require('mongoose-better-id');
const constants = require('../../settings/constants');

const schema = new Schema({
  hash: String,
  wgs84: {
    road: Schema.Types.LineString,
    furniture: Schema.Types.LineString,
    laneDivider: Schema.Types.LineString,
  },
  gcj02: {
    road: Schema.Types.LineString,
    furniture: Schema.Types.LineString,
    laneDivider: Schema.Types.LineString,
  },
}, {
  read: 'secondaryPreferred',
});

schema.index({ hash: 1 }, { unique: true });
schema.index({ 'wgs84.road': '2dsphere' });
schema.index({ 'gcj02.road': '2dsphere' });

schema.plugin(betterId, { connection: conn.operation });
module.exports = conn.operation.model('gj_road', schema);
