module.exports = {
  "parserOptions": {
    "ecmaVersion": 8
  },
  "env": {
    "node": true,
    "es6": true
  },
  "extends": "eslint:recommended",
  "rules": {
    "no-unused-vars": "off",
    "require-yield": "off",
    "no-console": "error",
    "no-extend-native": "off"
  }
};
