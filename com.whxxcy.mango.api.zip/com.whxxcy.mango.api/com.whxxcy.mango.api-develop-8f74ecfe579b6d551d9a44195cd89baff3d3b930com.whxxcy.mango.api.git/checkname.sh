#!/usr/bin/env bash
function getdir(){
  for element in `ls $1`
  do
    dirOrFile=$1"/"$element
    if [ -d $dirOrFile ]
    then
      getdir $dirOrFile
    elif [ $dirOrFile != ${dirOrFile//:/#} ]
    then
      echo $dirOrFile
    fi
  done
}
getdir $1