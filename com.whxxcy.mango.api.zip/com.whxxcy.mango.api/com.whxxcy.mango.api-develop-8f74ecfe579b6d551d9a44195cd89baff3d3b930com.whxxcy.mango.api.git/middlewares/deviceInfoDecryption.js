const { crypto } = require('xx-utils');
const RCUserCaptureController = require('../controllers/record/RCUserCaptureController');
const amap = require('../services/amap');

module.exports = function ({ key, iv }) {
  return function * (next) {
    const encryptedInfo = this.get('mg-dvi');
    if (encryptedInfo) {
      try {
        const stuff = crypto.aes256(key, iv).decode(encryptedInfo);
        this.state.deviceInfo = JSON.parse(stuff);
      } catch (err) {
        // noop.
      }
    }
    if (this.state.deviceInfo) {
      const { id } = this.state.user || {};
      const { plat, ver, mdl, udid, name, appv, lat, lng, city, ip = this.ip, accuracy = 0, head, bt, spd, alt } = this.state.deviceInfo || {};
      const lngLat = (lng && lat) ? [lng, lat] : null;
      let address = '';
      // if (lngLat) {
      //   address = yield amap.findAddressByLocation(lngLat);
      // }
      this.state.deviceInfo.lngLat = lngLat;
      this.state.deviceInfo.address = address;
      yield RCUserCaptureController.create({
        user: id,
        deviceInfo: {
          platform: plat,
          version: ver,
          modal: mdl,
          udid,
          name,
          heading: head,
          battery: bt,
          speed: spd,
          alt
        },
        appVersion: appv,
        ip,
        lngLat,
        address,
        city,
        accuracy
      });
    }
    yield next;
  }
};
