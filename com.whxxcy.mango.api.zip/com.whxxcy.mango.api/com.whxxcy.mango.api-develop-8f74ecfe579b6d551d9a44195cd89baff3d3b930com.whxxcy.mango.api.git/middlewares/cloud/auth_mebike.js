const CLAppController = require('../../controllers/cloud/CLAppController');
const Error = require('errrr');
const { judgement } = require('xx-utils');
const authMethods = require('../../services/cloud/authMethods');

module.exports = function () {
  return function * (next) {
    const data = Object.assign({}, this.query, this.request.body, this.params);
    const appKey = this.get('bdd-appkey') || data.appKey;
    const sign = this.get('bdd-sign') || data.sign;
    const timestamp = this.get('mg-cloud-ts') || data.timestamp;
    const time = new Date(parseInt(timestamp));
    if (!appKey) throw new Error('AppKey should exists');
    if (!sign) throw new Error('Signature should exists');
    if (time.toString() === 'Invalid Date') throw new Error('Timestamp should exists');
    if (new Date().is.over('10 minutes'.after(time))) throw new Error('Timestamp is expired');
    const app = yield CLAppController.findByIdAndCheckAvailable(appKey);
    Reflect.deleteProperty(data, 'sign');

    const mySign = authMethods.MD5.sign(data, app.secretKey);
    if (mySign !== sign) throw new Error('Invalid signature');

    this.state.app = app;

    try {
      yield next;
      if (!this.body) this.body = {};
      if (judgement.isEmpty(this.body.rtCode)) this.body.rtCode = 0;
    } catch (err) {
      this.status = 200;
      this.set('bdd-error', encodeURIComponent(err.message));
      this.body = {
        rtCode: 1,
      };
    }

    this.body.timestamp = Date.now();
    this.body.sign = authMethods.MD5.sign(this.body, app.secretKey);
  }
};