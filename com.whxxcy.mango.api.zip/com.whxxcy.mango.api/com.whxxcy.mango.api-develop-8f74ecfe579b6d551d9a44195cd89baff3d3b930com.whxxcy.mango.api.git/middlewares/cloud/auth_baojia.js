const CLAppController = require('../../controllers/cloud/CLAppController');
const Error = require('errrr');
const authMethods = require('../../services/cloud/authMethods');
const constants = require('../../settings/constants');
const errorHandler = require('../../services/errorHandler');

module.exports = function () {
  return function * (next) {
    const data = Object.assign({}, this.query, this.request.body, this.params);
    const appKey = this.get('mg-appkey') || data.client_id;
    const sign = this.get('mg-sign') || data.sign;
    const timestamp = this.get('mg-cloud-ts') || data.timestamp;
    const time = new Date(parseInt(timestamp) * 1000);
    if (!appKey) throw new Error('AppKey should exists');
    if (!sign) throw new Error('Signature should exists');
    if (time.toString() === 'Invalid Date') throw new Error('Timestamp should exists');
    if (new Date().is.over('10 minutes'.after(time))) throw new Error('Timestamp is expired');
    const app = yield CLAppController.findByIdAndCheckAvailable(appKey);
    yield CLAppController.checkServiceAvailable(app._id, constants.CL_APP_SERVICE.开放订单);
    Reflect.deleteProperty(data, 'sign');

    const mySign = authMethods.MD5_B.sign(data, app.secretKey);
    if (mySign !== sign) throw new Error('Invalid signature');

    this.state.app = app;

    try {
      yield next;
      this.status = 200;
      this.body = {
        code: 0,
        msg: '成功',
        data: this.body
      };
    } catch (err) {
      this.status = 200;
      this.set('mg-error', encodeURIComponent(err.message));
      errorHandler(err);
      this.body = {
        code: -1,
        msg: err.message
      };
    }

  }
};