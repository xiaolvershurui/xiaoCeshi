const CLAppController = require('../../controllers/cloud/CLAppController');
const Error = require('errrr');

module.exports = function (service) {
  return function * (next) {
    const { app } = this.state;
    if (!app || !app._id) throw new Error('还未进行认证或应用不存在');
    yield CLAppController.checkServiceAvailable(app._id, service);
    yield next;
  }
};