const CLAppController = require('../../controllers/cloud/CLAppController');
const Error = require('errrr');
const authMethods = require('../../services/cloud/authMethods');

module.exports = function() {
  return function *(next) {
    if (!this.state.user) {
      const data = Object.assign({}, this.query, this.request.body, this.params);
      const appId = this.get('mg-appId') || data.appKey;

      const sign = this.get('mg-sign') || data.sign;
      const timestamp = this.get('mg-ts') || data.timestamp;
      const time = new Date(parseInt(timestamp));

      if (!appId) throw new Error('AppId should exists');
      if (!sign) throw new Error('Signature should exists');
      if (time.toString() === 'Invalid Date') throw new Error('Timestamp should exists');
      if (new Date().is.over('5 minutes'.after(time))) throw new Error('Timestamp is expired');
      const app = yield CLAppController.findByIdAndCheckAvailable(appId);
      Reflect.deleteProperty(data, 'sign');

      const mySign = authMethods.MD5.sign((data.tel ? { tel: data.tel } : {}), app.secretKey);
      if (mySign !== sign) throw new Error('Invalid signature');

      this.state.app = app;

      try {
        yield next;
        if (!this.body) this.body = {};
      } catch (err) {
        this.status = 200;
        this.set('bdd-error', encodeURIComponent(err.message));
      }

    } else {
      yield next;
    }
  };
};
