const Joi = require('joi');
const Error = require('errrr');

module.exports.parse = function () {
  return function * (next) {
    const region = this.get('mg-region');
    const style = this.get('mg-style');
    if (region) {
      const { regionIds } = this.state.user;
      if (!regionIds || !regionIds.includes(region)) {
        // this.body = null;
        const { error, value } = Joi.validate({ region, style }, Joi.object({
          region: Joi.string().empty(''),
          style: Joi.string().empty('')
        }));
        if (error) throw error;
        this.state.filter = value;
        yield next;
      } else {
        const { error, value } = Joi.validate({ region, style }, Joi.object({
          region: Joi.string().empty(''),
          style: Joi.string().empty('')
        }));
        if (error) throw error;
        this.state.filter = value;
        yield next;
      }
    } else {
      yield next;
    }
  }
};

module.exports.check = function () {
  return function * (next) {
    if (!this.state.filter) throw new Error('未指定大区');
    yield next;
  }
};