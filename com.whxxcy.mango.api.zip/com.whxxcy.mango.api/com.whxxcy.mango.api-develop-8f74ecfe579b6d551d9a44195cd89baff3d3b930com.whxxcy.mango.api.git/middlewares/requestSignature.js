const isDev = process.env.NODE_ENV === 'development';
const Error = require('errrr');
const { verify } = require('show-your-ticket');

module.exports = function ({ expires, key }) {
  return function * (next) {
    const signature = this.get('mg-sig');
    let timestamp = this.get('mg-ts');
    const stuffKeys = this.get('mg-sk');
    if (!isDev || signature) {
      if (!signature) throw new Error('Require signature in headers');
      if (!timestamp) throw new Error('Require timestamp in headers');
      timestamp = new Date(parseFloat(timestamp));
      try {
        verify({
          payload: {
            body: Object.assign({}, this.request.body || {}, this.request.params || {}),
            query: this.request.query,
          },
          method: this.method,
          path: this.path,
          signature,
          timestamp,
          stuffKeys,
          secretKey: key,
          expires,
        });
      } catch (error) {
        throw new Error(error.message);
      }
    }
    yield next;
  }
};
