const isDev = process.env.NODE_ENV !== 'production';
const settings = require('../settings');

module.exports = function ({ key, iv }) {
  return function * (next) {
    yield next;
    const encrypt = this.get('mg-eyt');
    if((!isDev || encrypt) && this.body) {
      this.state.encryption = { key, iv };
    }
  }
};
