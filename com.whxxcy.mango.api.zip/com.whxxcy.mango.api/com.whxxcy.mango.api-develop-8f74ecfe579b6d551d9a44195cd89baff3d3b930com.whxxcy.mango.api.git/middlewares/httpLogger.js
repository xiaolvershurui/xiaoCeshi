const logger = require('../services/logger').http;
const RCScanQRController = require('../controllers/record/RCScanQRController');
const RCErrorController = require('../controllers/record/RCErrorController');
const constants = require('../settings/constants');
const uploader = require('../services/metricsUploader');

module.exports = function() {
  return function *(next) {
    const time = new Date();
    if (!this.state.deviceInfo) this.state.deviceInfo = {};
    yield next;
    const method = this.method;
    const path = this.path;
    // 心跳请求不打log，远程调用不打log
    if (['/', '/call'].includes(path)) return;
    const ip = this.get('X-Forwarded-For') || this.ip;
    const status = this.status;
    const duration = Date.now() - time.getTime();
    const params = this.params;
    const query = this.query;
    const body = this.request.body;
    const parts = this.request.parts;
    const headers = this.headers;
    const responseHeaders = this.response.headers;
    const responseBody = this.body || {};
    const auth = this.state.user;
    const deviceInfo = this.state.deviceInfo || {};
    const { plat, ver, mdl, udid, name, appv, lngLat, address, city, accuracy = 0 } = deviceInfo;

    if (process.env.NODE_ENV === 'production') {
      uploader.appendRaw(9010, 'api', { r: status }, duration);
    } else {
      logger.info({
        ip,
        method,
        path,
        duration,
        params,
        query,
        body,
        parts,
        status,
        deviceInfo,
      });
    }
    // 扫码记录
    if (auth && [
      '/client/v1/ebike/stock/number',
      '/client/v2/ebike/stock/number',
      '/client/v3/ebike/stock/number',
    ].includes(path)) {
      yield RCScanQRController.create({
        user: auth.id,
        scanContent: query.number,
        isScanQR: query.isScanQR,
        succeed: responseBody.succeed,
        error: responseBody.error,
        errorCode: responseBody.code,
        issuedCoupon: responseBody.issuedCoupon,
        lngLat,
        address,
        accuracy,
        deviceInfo: {
          platform: plat,
          version: ver,
          modal: mdl,
          udid,
          name,
        },
        appVersion: appv,
        city,
      });
    }

    if (auth && [
      '/client/v1/order/reservation',
    ].includes(path) && responseBody.error) {
      yield RCErrorController.create({
        user: auth.id,
        errorInfo: responseBody.error,
        errorType: constants.RC_ERROR_TYPE.预约,
        errorDescription: responseBody.error && responseBody.error.extra && responseBody.error.extra.description,
        lngLat,
        address,
        accuracy,
        deviceInfo: {
          platform: plat,
          version: ver,
          modal: mdl,
          udid,
          name,
        },
        city,
        appVersion: appv,
      });
    }

    if (auth && [
      '/client/v3/ebike/stock/number',
    ].includes(path) && responseBody.error) {
      yield RCErrorController.create({
        user: auth.id,
        errorInfo: responseBody.error,
        errorType: constants.RC_ERROR_TYPE.扫码,
        errorDescription: responseBody.error && responseBody.error.extra && responseBody.error.extra.description,
        lngLat,
        address,
        accuracy,
        deviceInfo: {
          platform: plat,
          version: ver,
          modal: mdl,
          udid,
          name,
        },
        city,
        appVersion: appv,
      });
    }
    if (auth && [
      '/client/v3/order',
    ].includes(path) && responseBody.error) {
      yield RCErrorController.create({
        user: auth.id,
        errorInfo: responseBody.error,
        errorType: constants.RC_ERROR_TYPE.下单,
        errorDescription: responseBody && responseBody.extra && responseBody.extra.description,
        lngLat,
        address,
        accuracy,
        deviceInfo: {
          platform: plat,
          version: ver,
          modal: mdl,
          udid,
          name,
        },
        city,
        appVersion: appv,
      });
    }

  };
};
