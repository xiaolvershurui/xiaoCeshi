const jwtSetting = require('../settings/jwt');
const url = require('url');

module.exports = function () {
  const cookie = jwtSetting.jwtOptions.cookie;
  const tokenKey = jwtSetting.tokenInQuery;
  return function * (next) {
    if (this.query[tokenKey]) {
      this.cookies.set(cookie, this.query[tokenKey], { signed: true });
      const parsedUrl = url.parse(this.originalUrl);
      const query = this.query;
      Reflect.deleteProperty(query, 'token');
      this.redirect(url.format({
        pathname: parsedUrl.pathname,
        query,
      }));
      return;
    }
    yield next;
  };
};
