const transaction = require('../services/transaction');

module.exports = function () {
  return function * (next) {
    this.transaction = transaction(null, {
      uid: this.state.user && this.state.user.id
    });
    yield next;
  }
};
