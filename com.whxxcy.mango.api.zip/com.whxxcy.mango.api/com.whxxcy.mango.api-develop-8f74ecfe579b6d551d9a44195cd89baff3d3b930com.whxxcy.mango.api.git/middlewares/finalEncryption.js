const { crypto, judgement } = require('xx-utils');

module.exports = function () {
  return function * (next) {
    yield next;
    if (this.state.encryption) {
      let body = this.body;
      const { key, iv } = this.state.encryption;
      if (judgement.isObject(body)) body = JSON.stringify(body);
      const encryptedStuff = crypto.aes256(key, iv).encode(body);
      this.body = {
        joker: true,
        body: encryptedStuff
      };
    }
  }
};
