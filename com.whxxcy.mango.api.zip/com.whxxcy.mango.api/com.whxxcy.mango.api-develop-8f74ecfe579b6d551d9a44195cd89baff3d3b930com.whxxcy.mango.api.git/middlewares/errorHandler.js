const Errrr = require('errrr');
const MError = require('mongostate').MError;
const RCNotificationController = require('../controllers/record/RCNotificationController');
const errorHandler = require('../services/errorHandler');

module.exports = function () {
  return function * (next) {
    let err;
    try {
      yield next;
      if (this.body && this.body.error) {
        err = this.body.error;
        if (!(err instanceof Errrr)) {
          err.message = '服务器忙，请稍后再试！';
        } else {
          this.body.code = err.extra && err.extra.code;
        }
        this.body.error = err.message;
      }
      if (this.status >= 400) this.throw(this.status);
    } catch (error) {
      let status = error.status || 500;
      let message = error.message;
      if (error instanceof Errrr) { // 这种类型的错误是需要展示给用户看的
        status = 400;
      } else if (error instanceof MError || status >= 500) {
        // 这类错误不需要展示错误信息给用户看，认为是服务器异常，需要抛出错误用于日志记录
        message = '服务器忙，请稍后再试！';
        status = 500;
      } else {
        if (status === 403) {
          if (!this.state.user || this.state.user.roles.toString() === 'guest') {
            // 这种情况认为用户未登录，重写status为401
            status = 401;
            message = `您还未登录!`;
          } else {
            message = '您没有权限！'
          }
        } else if (status === 429) {
          // 请求量过大
          message = '您的操作太快啦！请歇会儿再试！';
        } else if (status === 401) {
          message = '您还未登录！';
        }
      }
      this.body = { error: message };
      if ([
          '/client/v1/order/reservation',
          '/client/v3/ebike/stock/number',
          '/client/v3/order',
        ].includes(this.path)) {
        Object.assign(this.body, {
          extra: error.extra
        })
      }
      this.status = status;

      err = error;
    }

    if (err) {
      // 记录错误日志
      const user = this.state.user;
      const deviceInfo = this.state.deviceInfo;
      const ip = this.get('X-Forwarded-For') || this.ip;
      const query = this.query;
      const body = (this.request || {}).body;
      const method = this.method;
      const path = this.path;
      errorHandler(err, 'APP');
      if (err.errors) {
        Object.keys(err.errors).forEach(key => {
          errorHandler(err.errors[key], 'APP');
        });
      }
      if (this.status >= 500) {
        RCNotificationController.createInternalError(err, { ip, user, deviceInfo, method, path, body, query });
      } else if (![401, 403, 404].includes(this.status)) {
        RCNotificationController.createRequestError(err, { ip, user, deviceInfo, method, body, query, path });
      }
    }
  }
};
