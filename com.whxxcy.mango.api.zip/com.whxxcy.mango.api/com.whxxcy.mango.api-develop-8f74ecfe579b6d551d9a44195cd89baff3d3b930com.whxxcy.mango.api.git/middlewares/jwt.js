const jwt = require('koa-jwt-mongo');
const jwtSettings = require('../settings/jwt');

module.exports = jwt(jwtSettings);