switch (process.env.DB_ENV || process.env.NODE_ENV) {
  case 'production':
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz9edcf0cda584941.mongodb.rds.aliyuncs.com:3717,dds-wz9edcf0cda584942.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-4957105',
      name: 'pro_mango_operation',
      mongo: {
        user: 'mango',
        pass: 'G27Dj4M6BPjPN2aJkrZHwkHYftpWyBik',
        auth: {
          authSource: 'admin'
        },
      }
    };
    break;
  case 'development':
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz95810df6a4b5c41924.mongodb.rds.aliyuncs.com:3717,dds-wz95810df6a4b5c42997.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-4409033',
      name: 'mango_operation',
      mongo: {
        user: 'test',
        pass: '987412365',
        auth: {
          authSource: 'admin'
        }
      }
    };
    break;
  case 'local':
    module.exports = {
      uri: 'localhost',
      name: 'mango_operation'
    };
    break;
  default:
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz95810df6a4b5c41801-pub.mongodb.rds.aliyuncs.com:3717,dds-wz95810df6a4b5c42467-pub.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-4409033',
      name: 'mango_operation',
      mongo: {
        user: 'test',
        pass: '987412365',
        auth: {
          authSource: 'admin'
        }
      }
    };
}
