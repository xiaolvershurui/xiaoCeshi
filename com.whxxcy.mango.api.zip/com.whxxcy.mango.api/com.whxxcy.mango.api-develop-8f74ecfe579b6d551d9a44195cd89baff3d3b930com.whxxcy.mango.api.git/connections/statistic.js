switch (process.env.DB_ENV || process.env.NODE_ENV) {
  case 'production':
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz93b95345e1eba41.mongodb.rds.aliyuncs.com:3717,dds-wz93b95345e1eba42.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-6946953',
      name: 'pro_mango_statistic',
      mongo: {
        user: 'mango',
        pass: 'G27Dj4M6BPjPN2aJkrZHwkHYftpWyBik',
        auth: {
          authSource: 'admin',
        },
      },
    };
    break;
  case 'development':
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz95810df6a4b5c41924.mongodb.rds.aliyuncs.com:3717,dds-wz95810df6a4b5c42997.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-4409033',
      name: 'mango_statistic',
      mongo: {
        user: 'test',
        pass: '987412365',
        auth: {
          authSource: 'admin',
        },
      },
    };
    break;
  case 'local':
    module.exports = {
      uri: 'localhost',
      name: 'mango_statistic',
    };
    break;
  default:
    module.exports = {
      replica: true,
      uri: 'mongodb://dds-wz95810df6a4b5c41801-pub.mongodb.rds.aliyuncs.com:3717,dds-wz95810df6a4b5c42467-pub.mongodb.rds.aliyuncs.com:3717?replicaSet=mgset-4409033',
      name: 'mango_statistic',
      mongo: {
        user: 'test',
        pass: '987412365',
        auth: {
          authSource: 'admin',
        },
      },
    };
}
