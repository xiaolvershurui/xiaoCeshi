const mongoose = require('mongoose');
const Connector = require('xx-mongo-connector');
const logger = require('../services/logger').database;

class MangoConnector extends Connector {
  constructor (options) {
    super(options);
    const { name, host, uri } = this._options;
    this.on('connected', _ => logger.info(`Database [${uri || host}] [${name}] has connected`));
    this.on('timeout', error => logger.warn(`Database [${uri || host}] [${name}] connect timeout: ${error.message}`));
    this.on('error', error => logger.warn(`Database [${uri || host}] [${name}] throw an error: ${error.message}`));
    this.on('close', _ => logger.info(`Database [${uri || host}] [${name}] closed`));
  }
}

const wrapOptions = options => {
  options.mongo = Object.assign({
    db: { native_parser: true },
    server: {
      auto_reconnect: true,
    },
  }, options.mongo || {});
  return options;
};

// 预加载geo schema插件
require('mongoose-geojson-schema');
// 全局添加timestamp插件
mongoose.plugin(require('mongoose-timestamp'));

// 芒果-账户管理
module.exports.account = new MangoConnector(wrapOptions(require('./account'))).connection;
// 芒果-车辆管理
module.exports.ebike = new MangoConnector(wrapOptions(require('./ebike'))).connection;
// 芒果-开放云管理
module.exports.cloud = new MangoConnector(wrapOptions(require('./cloud'))).connection;
// 芒果-财务管理
module.exports.finance = new MangoConnector(wrapOptions(require('./finance'))).connection;
// 芒果-运营管理
module.exports.operation = new MangoConnector(wrapOptions(require('./operation'))).connection;
// 芒果-订单管理
module.exports.order = new MangoConnector(wrapOptions(require('./order'))).connection;
// 芒果-数据记录
module.exports.record = new MangoConnector(wrapOptions(require('./record'))).connection;
// 芒果-系统设置
module.exports.setting = new MangoConnector(wrapOptions(require('./setting'))).connection;
// 芒果-事务管理/任务管理
module.exports.state = new MangoConnector(wrapOptions(require('./state'))).connection;
// 芒果-token管理
module.exports.token = new MangoConnector(wrapOptions(require('./jwt'))).connection;
// 芒果-统计
module.exports.statistic = new MangoConnector(wrapOptions(require('./statistic'))).connection;
