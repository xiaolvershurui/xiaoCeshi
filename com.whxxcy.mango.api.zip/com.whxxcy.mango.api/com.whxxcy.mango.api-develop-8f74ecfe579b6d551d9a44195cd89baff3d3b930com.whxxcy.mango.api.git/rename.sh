#!/usr/bin/env bash
function getdir(){
  for element in `ls $1 | tr ' '  '+'`
  do
    dirOrFile="$1/$element"
    if [ -d $dirOrFile ]
    then
      newDir=${dirOrFile//:/#}
      if [ $newDir != $dirOrFile ]
      then
        mv $dirOrFile $newDir
      fi
      getdir $newDir
    else
      trimedFileName="`echo $dirOrFile | sed 's/+//g' `"
      newFileName=${trimedFileName//:/#}
      if [ $newFileName != $dirOrFile ]
      then
        mv "`echo $dirOrFile | sed 's/+/ /g' `" "$newFileName"
      fi
    fi
  done
}
getdir $1