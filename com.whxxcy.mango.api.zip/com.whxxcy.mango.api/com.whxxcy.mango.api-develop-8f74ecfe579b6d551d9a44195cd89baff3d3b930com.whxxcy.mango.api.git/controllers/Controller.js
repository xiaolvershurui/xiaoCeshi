class Controller {
  constructor (transaction) {
    if (!transaction) throw new Error('transaction should pass to controller.');
    this.transaction = transaction;
  }

  T (Model) {
    return this.transaction.use(Model);
  }

}

module.exports = Controller;