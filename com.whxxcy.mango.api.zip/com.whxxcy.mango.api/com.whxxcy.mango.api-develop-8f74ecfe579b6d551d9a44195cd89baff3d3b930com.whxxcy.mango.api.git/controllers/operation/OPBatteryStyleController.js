const Controller = require('../Controller');
const OPBatteryStyle = require('../../models/operation/op_battery_style');
const Error = require('errrr');

class OPBatteryStyleController extends Controller {


}

OPBatteryStyleController.Model = OPBatteryStyle;
module.exports = OPBatteryStyleController;
