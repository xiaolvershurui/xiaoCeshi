const Controller = require('../Controller');
const OPBatteryStation = require('../../models/operation/op_battery_station');
const OPRegionController = require('../../controllers/operation/OPRegionController');
const ACUserController = require('../account/ACUserController');
const Error = require('errrr');

class OPBatteryStationController extends Controller {

  static * findByIdAndCheckExists (id) {
    const station = yield OPBatteryStation.findById(id);
    if (!station) throw new Error('运营站不存在');
    return station;
  }

}

OPBatteryStationController.Model = OPBatteryStation;
module.exports = OPBatteryStationController;