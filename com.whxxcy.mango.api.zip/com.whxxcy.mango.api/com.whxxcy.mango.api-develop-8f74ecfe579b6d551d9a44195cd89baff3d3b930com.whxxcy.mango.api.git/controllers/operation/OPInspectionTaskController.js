const OPInspectionTask = require('../../models/operation/op_inspection_task');
const OPRegionController = require('../../controllers/operation/OPRegionController');
const ACUserController = require('../account/ACUserController');
const BKStockController = require('../ebike/BKStockController');
const RCStockPointController = require('../record/RCStockPointController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const oss = require('../../services/oss');
const co = require('co');

class OPInspectionTaskController extends Controller {
  static * create ({ stock, region, type }) {
    let rate = 0;
    if (type === constants.OP_INSPECTION_TASK_TYPE.围栏外) {
      if ((yield this.countOutsideRegion(stock)) > 0) return;
    } else if (type === constants.OP_INSPECTION_TASK_TYPE.无卫星定位) {
      if ((yield this.countNoLocation(stock)) > 0) return;
    } else if (type === constants.OP_INSPECTION_TASK_TYPE.低电量) {
      yield this.releaseLowPowerWarning(stock);
    } else if (type === constants.OP_INSPECTION_TASK_TYPE.电量预警) {
      yield this.releaseLowPower(stock);
    } else if (type === constants.OP_INSPECTION_TASK_TYPE.两天未使用) {
      if ((yield this.countNoOrderInTwoDay(stock)) > 0) return;
    }
    return yield OPInspectionTask.create({
      stock,
      region,
      type,
      rate
    });
  }

  static * findUnprocessedByStock (stock) {
    return yield OPInspectionTask.find({
      stock,
      processed: false
    });
  }

  static * findLatest (stock, type) {
    return yield OPInspectionTask.findOne({ stock, type }).sort({ createdAt: -1 }).populate({
      path: 'processor',
      model: ACUserController.Model
    });
  }

  static * integrateUnprocessedByStock (stock) {
    const tasks = yield this.findUnprocessedByStock(stock);
    const items = tasks.reduce((memo, task) => {
      memo[task.type] = memo[task.type] || { times: 0, rate: 0 };
      memo[task.type].times += 1;
      memo[task.type].rate += task.rate;
      return memo;
    }, []);
    const result = {
      offline: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.车机离线) },
      noGpsLocation: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.无卫星定位) },
      powerOff: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.车辆断电) },
      illegalMovement: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.连续位移) },
      lowPower: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.低电量) },
      lowPowerWarning: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.电量预警) },
      damage: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.车辆损坏) },
      notUsedInTwoDay: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.两天未使用) },
      outsideRegion: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.围栏外) },
      insideClosedArea: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.禁停区内) },
      insideProhibitedArea: { state: false, times: 0, latest: yield this.findLatest(stock, constants.OP_INSPECTION_TASK_TYPE.禁行区内) },
      abnormal: false,
      totalRate: 0
    };
    items.forEach((item, type) => {
      if (item) {
        result.abnormal = true;
        if (result.totalRate === 0) {
          result.totalRate = item.rate;
        } else if (result.totalRate >= 0) {
          result.totalRate *= item.rate;
        }
        const resultType = [
          'offline',
          'noGpsLocation',
          'powerOff',
          'illegalMovement',
          'lowPower',
          'lowPowerWarning',
          'damage',
          'notUsedInTwoDay',
          'outsideRegion',
          'insideCloseArea',
          'insideProhibitedArea'
        ][type];
        result[resultType].state = true;
        result[resultType].times = item.times;
      }
    });
    return result;
  }

  static * findAbnormalStocks (regionIds) {
    const stocks = yield OPInspectionTask.find({
      processed: false,
      region: { $in: regionIds }
    }).distinct('stock');
    const result = (yield stocks.map(co.wrap(function * (stock) {
      const stockData = yield BKStockController.Model.findById(stock);
      if (!stockData) return null;
      return {
        stock: stockData,
        state: yield this.integrateUnprocessedByStock(stock)
      }
    }.bind(this)))).filter(item => !!item);
    return result.sort((s1, s2) => {
      if (s1.state.totalRate !== s2.state.totalRate) {
        return s1.state.totalRate - s2.state.totalRate;
      } else {
        return s1.stock.number.custom > s2.stock.number.custom ? 1 : -1;
      }
    });
  }

  static * findAbnormalStocksAndExportCSV (regionId) {
    const region = yield OPRegionController.Model.findById(regionId);
    if (!region) throw new Error('该大区不存在');
    const result = yield this.findAbnormalStocks([region._id]);
    if (result.length === 0) return;
    const header = ['name', 'address', 'x', 'y', 'telephone'];
    const rows = [header.join(',')];
    for (let item of result) {
      let { stock, state } = item;
      stock = stock.toJSON();
      if (!stock.enable) continue;
      stock.location = stock.location || {};
      stock.location.lngLat = stock.location.lngLat || [];
      stock.location.locatedAt = stock.location.locatedAt || new Date(0);
      stock.battery = stock.battery || {};
      let reasons = [];
      if (state.offline.state) {
        reasons.push('车机离线');
      }
      if (state.lowPower.state) {
        reasons.push('5km续航，极度低电');
      }
      if (state.lowPowerWarning.state) {
        reasons.push('16km续航，低电预警');
      }
      if (state.noGpsLocation.state) {
        reasons.push('30分钟无卫星定位，车机故障');
      }
      if (state.outsideRegion.state) {
        reasons.push('围栏外');
      }
      if (state.notUsedInTwoDay.state) {
        reasons.push('两天未被使用');
      }
      if (state.powerOff.state) {
        reasons.push('断电');
      }
      if (state.illegalMovement.state) {
        reasons.push('非法移动');
      }
      if (state.damage.state) {
        reasons.push('损坏');
      }
      rows.push([
        stock.number.custom.slice(-3),
        reasons.join('|'),
        stock.location.lngLat[0],
        stock.location.lngLat[1],
        stock.location.locatedAt && stock.location.locatedAt.toSimpleString(),
      ].join(','));
    }
    return yield oss.private.putAbnormalStocks(rows.join('\n'), `${region.name}【新】`);
  }

  static * countOutsideRegion (stock) {
    return yield OPInspectionTask.count({
      stock,
      processed: false,
      type: constants.OP_INSPECTION_TASK_TYPE.围栏外
    });
  }

  static * countNoLocation (stock) {
    return yield OPInspectionTask.count({
      stock,
      processed: false,
      type: constants.OP_INSPECTION_TASK_TYPE.无卫星定位
    });
  }

  static * countNoOrderInTwoDay (stock) {
    return yield OPInspectionTask.count({
      stock,
      processed: false,
      type: constants.OP_INSPECTION_TASK_TYPE.两天未使用
    });
  }

  static * process (id, processor) {
    return yield OPInspectionTask.findByIdAndUpdate(id, {
      $set: {
        processor,
        processed: true,
        processedAt: new Date()
      }
    });
  }

  // 车机上线解除未完成的历史离线任务
  static * releaseOffline (stock) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.车机离线,
      processed: false
    }, {
      $set: {
        processed: true,
        processedAt: new Date()
      }
    }, {
      multi: true
    });
  }

  // 车机产生卫星定位信号解除未完成的无定位任务
  static * releaseNoLocation (stock) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.无卫星定位,
      processed: false
    }, {
      $set: {
        processed: true,
        processedAt: new Date()
      }
    }, {
      multi: true
    });
  }

  // 车辆恢复电力解除未完成的断电任务
  static * releasePowerOff (stockId, processor, {
    operator,
    operateLocation,
  } = {}) {
    yield BKStockController.updatePowerUnlink(stockId, false, {
      operator,
      operateLocation
    });
    const { box, stock } = yield BKStockController.findBoxById(stockId);
    const RCStockPointController = require('../record/RCStockPointController');
    yield RCStockPointController.create({
      isOnline: stock.isOnline,
      box: box._id,
      dataSource: box.info.dataSource,
      alarms: [constants.RC_ALARM_TYPE.解除断电],
      time: new Date()
    });
    return yield OPInspectionTask.update({
      stock: stockId,
      type: constants.OP_INSPECTION_TASK_TYPE.车辆断电,
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date()
      }
    }, {
      multi: true
    });
  }

  // 解除连续位移
  static * releaseMovement (stockId, processor) {
    yield BKStockController.updateIllegalMovement(stockId, false);
    const { box, stock } = yield BKStockController.findBoxById(stockId);
    const RCStockPointController = require('../record/RCStockPointController');
    yield RCStockPointController.create({
      isOnline: stock.isOnline,
      box: box._id,
      dataSource: box.info.dataSource,
      alarms: [constants.RC_ALARM_TYPE.解除非法位移],
      time: new Date()
    });
    return yield OPInspectionTask.update({
      stock: stockId,
      type: constants.OP_INSPECTION_TASK_TYPE.连续位移,
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date()
      }
    }, {
      multi: true
    });
  }

  // 解除低电
  static * releaseLowPower (stock, processor) {
    return yield OPInspectionTask.update({
      stock,
      type: {
        $in: [
          constants.OP_INSPECTION_TASK_TYPE.低电量,
          constants.OP_INSPECTION_TASK_TYPE.电量预警
        ]
      },
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date()
      }
    }, {
      multi: true
    });
  }

  // 解除低电预警
  static * releaseLowPowerWarning (stock, processor) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.电量预警,
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date()
      }
    }, { multi: true });
  }

  // 损坏修复
  static * releaseDamage (stock, processor) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.车辆损坏,
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date(),
      }
    }, {
      multi: true
    });
  }

  // 解除2天无订单
  static * releaseNoOrderInTwoDay (stock, processor) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.两天未使用,
      processed: false
    }, {
      $set: {
        processed: true,
        processor,
        processedAt: new Date()
      }
    }, { multi: true });
  }

  // 驶入围栏
  static * releaseOutsideRegion (stock) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.围栏外,
      processed: false
    }, {
      $set: {
        processed: true,
        processedAt: new Date()
      }
    }, { multi: true });
  }

  // 驶出禁行区
  static * releaseInsideProhibitedArea (stock) {
    return yield OPInspectionTask.update({
      stock,
      type: constants.OP_INSPECTION_TASK_TYPE.禁行区内,
      processed: false
    }, {
      $set: {
        processed: true,
        processedAt: new Date()
      }
    }, { multi: true });
  }

}

OPInspectionTaskController.Model = OPInspectionTask;
module.exports = OPInspectionTaskController;