const OPReportedAbuse = require('../../models/operation/op_reported_abuse');
const ACCreditController = require('../account/ACCreditController');
const Controller = require('../Controller');
const BKStockController = require('../ebike/BKStockController');
const amap = require('../../services/amap');
const constants = require('../../settings/constants');
const Error = require('errrr');
const dingRobot = require('../../services/dingRobot');
const ACUserController = require('../account/ACUserController');

class OPReportedAbuseController extends Controller {
  static * create ({ bikeNo, type, lngLat, abuseLocation, photos = [], description = '', reporter }) {
    let bike;
    if (bikeNo) {
      bike = yield BKStockController.Model.findOne({ 'number.custom': bikeNo });
      if(bike) {
        const userData = yield ACUserController.findByIdAndCheckExists(reporter);
        dingRobot.feedback({
          tel: userData.auth.tel,
          name: userData.cert.name,
          type: 0,
          stockNo: bikeNo,
          pic: photos[0],
          content: `${constants.OP_REPORTED_ABUSE_TYPE_MAP[type] || ''} ${description}`
        });
      }
    }
    return yield OPReportedAbuse.create({
      bikeNo,
      bike: bike && bike._id,
      type,
      abuseLocation,
      userLocation: {
        lngLat,
        address: yield amap.findAddressByLocation(lngLat)
      },
      photos,
      description,
      reporter,
      reportedAt: new Date()
    });
  }

  static * findByIdAndCheckExists (id) {
    const record = yield OPReportedAbuse.findById(id);
    if (!record) throw new Error('记录不存在');
    return record;
  }

  * process (id, { result, processor, remark }) {
    const record = yield OPReportedAbuseController.findByIdAndCheckExists(id);
    if (result === constants.OP_REPORTED_ABUSE_RESULT.属实) {
      yield new ACCreditController(this.transaction).create(Object.assign({
        user: record.reporter
      }, constants.AC_CREDIT_RECORD_INFO.举报滥用));
    }
    return yield this.T(OPReportedAbuse).findByIdAndUpdate(id, {
      $set: {
        state: constants.OP_REPORTED_ABUSE_STATE.已处理,
        processor,
        processedAt: new Date(),
        result,
        remark
      }
    }, { new: true });
  }
}

OPReportedAbuseController.Model = OPReportedAbuse;
module.exports = OPReportedAbuseController;