const OPRegion = require('../../models/operation/op_region');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');
const ACUserController = require('../account/ACUserController');
const Core = require('../../services/shark/core');

class OPRegionController extends Controller {

  static * create ({ name, city, path, prices }) {
    if (yield OPRegion.findOne({ name })) throw new Error(`大区名称[${name}]已经存在`);
    return yield OPRegion.create({
      _id: yield OPRegion.genId(),
      name,
      city,
      path: {
        type: "Polygon",
        coordinates: path
      },
      prices
    });
  }

  static * createDefault ({ name, city, path, enable, prices = [] }) {
    if (yield OPRegion.findOne({ name })) throw new Error(`大区名称[${name}]已经存在`);
    if (enable && !prices.length) throw new Error('启用大区时需要设定价格');
    return yield OPRegion.create({
      _id: yield OPRegion.genId(),
      name,
      city,
      path: {
        type: "Polygon",
        coordinates: path
      },
      enable,
      prices
    });
  }

  static * update (id, data) {
    const region = yield OPRegion.findById(id);
    if (!region) throw new Error('大区不存在');
    if (data.enable) {
      if (region.prices.length < 3) throw new Error('大区缺少必要的价格设定');
    }
    const path = data.path;
    Reflect.deleteProperty(data, 'path');
    yield Core.sendSync({
      c: 'operation/region/updatePath.a.1',
      params: {
        id,
        coordinates: path[0],
        coordinateSystem: 'gcj02',
      },
    });
    yield OPRegion.findByIdAndUpdate(id, { $set: data });
    return yield OPRegion.findById(id);
  }

  static * updatePath (id, path) {
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        path: {
          type: 'Polygon',
          coordinates: path
        }
      }
    }, { new: true });
  }

  static * findByIdAndCheckExists (id) {
    const region = yield OPRegion.findById(id);
    if (!region) throw new Error('大区不存在');
    return region;
  }

  static * updateEnable (id, enable) {
    const region = yield this.findByIdAndCheckExists(id);
    if (region.prices.length < 3) throw new Error('大区缺少必要的价格设定');
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        enable
      }
    }, { new: true });
  }

  static * updateName (id, name) {
    if (yield OPRegion.findOne({ name, _id: { $ne: id } })) throw new Error(`大区名称[${name}]已经存在`);
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        name
      }
    }, { new: true });
  }

  static * updateCity (id, city) {
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        city
      }
    }, { new: true });
  }

  static * updateIsFactory (id, isFactory) {
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        isFactory
      }
    }, { new: true });
  }

  static * setDefault (id) {
    yield OPRegion.update({ isDefault: true }, { isDefault: false }, { multi: true });
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        isDefault: true
      }
    });
  }

  * addManager (id, user) {
    yield ACUserController.findByIdAndCheckExists(user);
    return yield this.T(OPRegion).findByIdAndUpdate(id, {
      $addToSet: {
        managers: user
      }
    }, { new: true });
  }

  * removeManager (id, user) {
    return yield this.T(OPRegion).findByIdAndUpdate(id, {
      $pull: {
        managers: user,
      }
    }, { new: true });
  }

  static * updatePrice (id, { level, price }) {
    if (!constants.OP_STYLE_LEVEL_ENUMS.includes(level)) {
      throw new Error(`Level [${level}] 不正确`);
    }
    return yield OPRegion.findByIdAndUpdate(id, {
      $set: {
        [`prices.${level}`]: price
      }
    }, { new: true });
  }

  static * findIntersect (center, query) {
    return yield OPRegion.findOne(query).where('path').intersects().geometry({
      type: 'Point',
      coordinates: center
    })
  }

  static * findInCircle (center, radius = 5000) {
    return yield OPRegion.find({
      enable: true,
      path: {
        $nearSphere: {
          $geometry: {
            type: 'Point',
            coordinates: center,
          },
          $maxDistance: radius,
        },
      },
    });
  }

}

OPRegionController.Model = OPRegion;
module.exports = OPRegionController;
