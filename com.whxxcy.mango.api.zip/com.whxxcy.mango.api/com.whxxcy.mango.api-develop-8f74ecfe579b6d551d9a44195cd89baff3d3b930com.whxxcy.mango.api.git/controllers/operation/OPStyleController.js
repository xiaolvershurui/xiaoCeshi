const OPStyle = require('../../models/operation/op_style');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');

class OPStyleController extends Controller {
  static * create ({ name, number, thumbnail, level, maxMileage, ratedVoltage }) {
    if (yield OPStyle.findOne({ name })) throw new Error(`车型[${name}]已经存在`);
    return yield OPStyle.create({
      name,
      number,
      thumbnail,
      level,
      maxMileage,
      ratedVoltage
    });
  }

  static * findByIdAndCheckExists (id) {
    const style = yield OPStyle.findById(id);
    if (!style) throw new Error('车型不存在');
    return style;
  }

  static * setDefault (id) {
    yield OPStyle.update({ isDefault: true }, { isDefault: false }, { multi: true });
    return yield OPStyle.findByIdAndUpdate(id, {
      $set: {
        isDefault: true
      }
    });
  }

  static * update (id, data) {
    if (data.name && (yield OPStyle.findOne({ name: data.name, _id: { $ne: id } }))) {
      throw new Error(`车型[${data.name}]已经存在`);
    }
    return yield OPStyle.findByIdAndUpdate(id, {
      $set: data
    }, { new: true });
  }
}

OPStyleController.Model = OPStyle;
module.exports = OPStyleController;