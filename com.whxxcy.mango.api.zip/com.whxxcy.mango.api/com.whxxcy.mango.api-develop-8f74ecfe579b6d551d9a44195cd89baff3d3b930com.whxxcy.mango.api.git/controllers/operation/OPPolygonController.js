const OPPolygon = require('../../models/operation/op_polygon');
const OPRegion = require('../../models/operation/op_region');
const ACUserController = require('../account/ACUserController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');
const geolib = require('geolib');
const Core = require('../../services/shark/core');

class OPPolygonController extends Controller {

  static isLocationInsidePath(lngLat, path) {
    return geolib.isPointInside({
      latitude: lngLat[1],
      longitude: lngLat[0],
    }, path[0].map(lngLat => ({
      latitude: lngLat[1],
      longitude: lngLat[0],
    })));
  }

  static *create({
    enable,
    name,
    type,
    neighborhood,
    city,
    area,
    address,
    lngLat,
    path,
    directionLine,
    creator,
  }) {
    // if (yield OPPolygon.findOne({ name })) throw new Error(`区域名称[${name}]已经存在`);
    // if (!this.isLocationInsidePath(lngLat, path)) throw new Error('位置点不在区域内');
    return yield OPPolygon.create({
      _id: yield OPPolygon.genId(),
      enable,
      name,
      type,
      neighborhood,
      location: {
        city,
        area,
        address,
        lngLat,
      },
      path: {
        type: 'Polygon',
        coordinates: path,
      },
      directionLine: directionLine && {
        type: 'LineString',
        coordinates: directionLine,
      },
      creator,
    });
  }

  static *updateLocation(id, location) {
    yield this.checkLock(id);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        location,
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *updatePath(id, path) {
    // yield this.checkLock(id);
    // return yield OPPolygon.findByIdAndUpdate(id, {
    //   $set: {
    //     path: {
    //       type: 'Polygon',
    //       coordinates: path,
    //     },
    //   },
    // }, { new: true }).populate({
    //   path: 'creator',
    //   model: ACUserController.Model,
    // });
    yield Core.sendSync({
      c: 'operation/polygon/updatePath.a.1',
      params: {
        polygonId: id,
        polygon: {
          type: 'Polygon',
          coordinates: path,
        },
        coordinateSystem: 'gcj02',
      },
    });
    return yield OPPolygon.findById(id).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *update(id, data) {
    yield this.checkLock(id);
    if (data.path) {
      yield this.updatePath(id, data.path);
      Reflect.deleteProperty(data, 'path');
    }
    if (data.directionLine) data.directionLine = {
      type: 'LineString',
      coordinates: data.directionLine,
    };
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: data,
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    }).populate({
      path: 'reviewer',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    });
  }

  static *updateEnable(id, enable) {
    yield this.checkLock(id);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        enable,
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *updateName(id, name) {
    yield this.checkLock(id);
    if (yield OPPolygon.findOne({ name, _id: { $ne: id } })) throw new Error(`大区名称[${name}]已经存在`);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        name,
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *updateType(id, type) {
    yield this.checkLock(id);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        type,
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *updateNeighborhood(id, neighborhood) {
    yield this.checkLock(id);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        neighborhood,
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
    });
  }

  static *checkLock(id) {
    const polygon = yield this.findByIdAndCheckExists(id);
    if (polygon.state === constants.OP_POLYGON_STATE.锁定) throw new Error('该区块已锁定，管理员解锁后可编辑');
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        state: constants.OP_POLYGON_STATE.待审,
      },
    });
  }

  // 锁定后将不能进行任何编辑操作
  static *updateState(id, { state, proposedChanges, reworkReasons }, reviewer) {
    const rework = state === constants.OP_POLYGON_STATE.返工;
    const polygon = yield OPPolygon.findById(id);
    return yield OPPolygon.findByIdAndUpdate(id, {
      $set: {
        state,
        proposedChanges: rework ? proposedChanges : null,
        reworkReasons: rework ? reworkReasons : [],
        reviewer,
        reviewedAt: polygon.reviewedAt || new Date(),
      },
    }, { new: true }).populate({
      path: 'creator',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    }).populate({
      path: 'reviewer',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    });
  }

  static *findByIdAndCheckExists(id) {
    const region = yield OPPolygon.findById(id).populate({
      path: 'creator',
      model: ACUserController.Model,
    }).populate({
      path: 'reviewer',
      model: ACUserController.Model,
    });
    if (!region) throw new Error('大区不存在');
    return region;
  }

  static *searchNear(center, query = {}, searchRadius = constants.POLYGON_SEARCH_RADIUS, limit = 10000) {
    query = Object.assign({}, query, { isCleaned: false });
    return yield OPPolygon.find(query).near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).populate({
      path: 'creator',
      model: ACUserController.Model,
    }).populate({
      path: 'reviewer',
      model: ACUserController.Model,
    }).limit(limit);
  }

  static *searchNearInRegion({ center, type, searchRadius = constants.POLYGON_SEARCH_RADIUS, limit = 10000 }) {
    const region = yield OPRegion.findOne({
      enable: true,
      path: {
        $geoIntersects: {
          $geometry: {
            'type': 'Point',
            'coordinates': center,
          },
        },
      },
    });
    if (!region) return [];
    return yield OPPolygon.find({
      type,
      enable: true,
      isCleaned: false,
    }).near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).where('path').intersects().geometry(region.path)
      .populate({
        path: 'creator',
        model: ACUserController.Model,
      }).populate({
        path: 'reviewer',
        model: ACUserController.Model,
      }).limit(limit);
  }

  static *findIntersect(center, query) {
    query = Object.assign({}, query, { isCleaned: false });
    return yield OPPolygon.findOne(query).where('path').intersects().geometry({
      type: 'Point',
      coordinates: center,
    });
  }

  static transformBaojia(polygon) {
    return {
      stationId: polygon._id,
      stationName: polygon.name,
      stationLat: polygon.location.lngLat[1],
      stationLng: polygon.location.lngLat[0],
      stationAddress: polygon.location.address,
      startTime: 0,
      endTime: 2359,
      radius: 0,
      parkType: 2,
      coordinatePoints: polygon.path.coordinates[0].slice(0, -1).map(lngLat => lngLat.join(',')).join('|'),
      coordinateCenter: polygon.location.lngLat.join(','),
    };
  }

  static *findIntersectWithParkingLot({ path }) {
    return yield OPPolygon.find({
      path: {
        $geoIntersects: {
          $geometry: {
            type: 'Polygon',
            coordinates: path
          }
        }
      },
      enable: true,
      isCleaned: false,
    })
  }
}

OPPolygonController.Model = OPPolygon;
module.exports = OPPolygonController;
