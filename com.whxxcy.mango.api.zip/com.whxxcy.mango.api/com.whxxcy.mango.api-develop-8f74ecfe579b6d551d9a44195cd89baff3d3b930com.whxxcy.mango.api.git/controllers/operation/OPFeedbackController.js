const OPFeedback = require('../../models/operation/op_feedback');
const Controller = require('../Controller');
const dingRobot = require('../../services/dingRobot');
const ACUserController = require('../account/ACUserController');
const constants = require('../../settings/constants');

class OPFeedbackController extends Controller {
  static * create ({ user, photos = [], description }) {
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    dingRobot.feedback({
      tel: userData.auth.tel,
      name: userData.cert.name,
      type: 3,
      content: description,
      pic: photos[0]
    });
    return yield OPFeedback.create({
      user,
      photos,
      description
    });
  }

  static * process (id, { result, reply, processor }) {
    return yield OPFeedback.findByIdAndUpdate(id, {
      $set: {
        result,
        reply,
        state: constants.OP_REPORT_STATE.已处理,
        processedAt: new Date(),
        processor
      }
    });
  }
}

OPFeedbackController.Model = OPFeedback;
module.exports = OPFeedbackController;