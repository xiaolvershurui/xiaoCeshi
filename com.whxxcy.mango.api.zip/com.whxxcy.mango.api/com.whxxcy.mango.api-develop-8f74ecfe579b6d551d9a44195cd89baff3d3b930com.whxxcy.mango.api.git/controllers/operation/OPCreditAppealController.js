const OPCreditAppeal = require('../../models/operation/op_credit_appeal');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const ACCreditController = require('../account/ACCreditController');
const dingRobot = require('../../services/dingRobot');
const ACUserController = require('../account/ACUserController');
const Error = require('errrr');

class OPCreditAppealController extends Controller {
  * create ({ creditId, reason, photos = [] }) {
    if (yield OPCreditAppeal.findOne({ credit: creditId })) {
      throw new Error('该记录已经申诉过！');
    }
    const credit = yield ACCreditController.findByIdAndCheckExists(creditId);
    if (credit.type !== constants.AC_CREDIT_RECORD_TYPE.扣分) {
      throw new Error('只有扣分记录可以申诉！');
    }

    const user = yield ACUserController.findByIdAndCheckExists(credit.user);

    dingRobot.feedback({
      tel: user.auth.tel,
      name: user.cert.name,
      type: 2,
      content: reason,
      pic: photos[0]
    });

    yield new ACCreditController(this.transaction).appeal(creditId);
    return yield this.T(OPCreditAppeal).create({
      _id: yield OPCreditAppeal.genId(),
      credit: creditId,
      order: credit.order,
      reason,
      user: credit.user,
      photos,
      appealedAt: new Date(),
    });
  }

  static * findByIdAndCheckExists (id) {
    const creditAppeal = yield OPCreditAppeal.findById(id);
    if (!creditAppeal) throw new Error('信用申诉记录不存在');
    return creditAppeal;
  }

  * pass (id, { processor, passRemark }) {
    const creditAppeal = yield OPCreditAppealController.findByIdAndCheckExists(id);
    if (creditAppeal.state !== constants.OP_CREDIT_APPEAL_STATE.待处理) {
      throw new Error('该记录当前无法处理');
    }
    yield new ACCreditController(this.transaction).pass(creditAppeal.credit);
    return yield this.T(OPCreditAppeal).findByIdAndUpdate(id, {
      $set: {
        state: constants.OP_CREDIT_APPEAL_STATE.已处理,
        result: constants.OP_CREDIT_APPEAL_RESULT.通过,
        processor,
        passRemark,
        passedAt: new Date()
      }
    }, { new: true });
  }

  * reject (id, { processor, rejectReason }) {
    const creditAppeal = yield OPCreditAppealController.findByIdAndCheckExists(id);
    if (creditAppeal !== constants.OP_CREDIT_APPEAL_STATE.待处理) {
      throw new Error('该记录当前无法处理');
    }
    yield new ACCreditController(this.transaction).reject(id, rejectReason);
    return yield this.T(OPCreditAppeal).findByIdAndUpdate(id, {
      $set: {
        state: constants.OP_CREDIT_APPEAL_STATE.已处理,
        result: constants.OP_CREDIT_APPEAL_RESULT.驳回,
        processor,
        rejectReason,
        rejectedAt: new Date()
      }
    }, { new: true });
  }

}

OPCreditAppealController.Model = OPCreditAppeal;
module.exports = OPCreditAppealController;