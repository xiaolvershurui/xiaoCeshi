const OPReportedDamage = require('../../models/operation/op_reported_damage');
const Controller = require('../Controller');
const BKStockController = require('../ebike/BKStockController');
const amap = require('../../services/amap');
const constants = require('../../settings/constants');
const Error = require('errrr');
const ACCreditController = require('../account/ACCreditController');
const BKDamageController = require('../ebike/BKDamageController');
const dingRobot = require('../../services/dingRobot');
const ACUserController = require('../account/ACUserController');

class OPReportedDamageController extends Controller {
  static * create ({bikeNo, type, damageDetail, lngLat, photos = [], description = '', reporter}) {
    let bike;
    if (bikeNo) {
      bike = yield BKStockController.Model.findOne({'number.custom': bikeNo});
      if (bike) {
        const userData = yield ACUserController.findByIdAndCheckExists(reporter);
        dingRobot.feedback({
          tel: userData.auth.tel,
          name: userData.cert.name,
          type: 1,
          stockNo: bikeNo,
          pic: photos[0],
          content: `${constants.OP_REPORTED_DAMAGES_TYPE_MAP[type] || ''} ${constants.OP_REPORTED_DAMAGES_DETAIL_MAP[damageDetail] || ''} ${description}`
        });
      }
    }
    return yield OPReportedDamage.create({
      bikeNo,
      bike: bike && bike._id,
      type,
      damageDetail,
      userLocation: {
        lngLat,
        address: yield amap.findAddressByLocation(lngLat)
      },
      photos,
      description,
      reporter,
      reportedAt: new Date()
    });
  }

  static * findByIdAndCheckExists (id) {
    const record = yield OPReportedDamage.findById(id);
    if (!record) throw new Error('记录不存在');
    return record;
  }

  * process (id, {result, processor, remark}) {
    const record = yield OPReportedDamageController.findByIdAndCheckExists(id);
    if (result === constants.OP_REPORTED_ABUSE_RESULT.属实) {
      yield new ACCreditController(this.transaction).create(Object.assign({
        user: record.reporter
      }, constants.AC_CREDIT_RECORD_INFO.上报故障));
    }
    return yield this.T(OPReportedDamage).findByIdAndUpdate(id, {
      $set: {
        state: constants.OP_REPORTED_ABUSE_STATE.已处理,
        processor,
        processedAt: new Date(),
        result,
        remark
      }
    }, {new: true});
  }
}

OPReportedDamageController.Model = OPReportedDamage;
module.exports = OPReportedDamageController;