const OPInspectionOrder = require('../../models/operation/op_inspection_order');
const Controller = require('../Controller');

class OPInspectionOrderController extends Controller {

  *calculateUrgentTaskDeductAmount(id, amount) {
    yield this.T(OPInspectionOrder).findByIdAndUpdate(id, {
      $set: {
        'payment.urgentTask.unFinishedUrgentTaskDeductAmount': amount,
      },
    });
  }

  *recordUnInspectionStocks(id, unFinishedUrgencyTask) {
    yield this.T(OPInspectionOrder).findByIdAndUpdate(id, {
      $set: {
        unInspectedStocks: unFinishedUrgencyTask,
        unFixedUnInspectedStocks: unFinishedUrgencyTask,
      },
    });
  }

  * updateBackToStationTime (id) {
    yield this.T(OPInspectionOrder).findByIdAndUpdate(id, {
      $set: {
        'times.backToStationAt': new Date(),
      },
    });
  }

  static *calculateProject({ id }) {
    const inspectionOrder = yield OPInspectionOrderController.Model.findById(id);
    const { payment, fixedStatistic } = inspectionOrder;
    payment.projects = [];
    payment.projects.push({
      name: '拖回',
      unit: payment.unit.returnBack,
      count: fixedStatistic.returnBack,
      value: payment.unit.returnBack * fixedStatistic.returnBack,
    }, {
      name: '换电',
      unit: payment.unit.exchangeBattery,
      count: fixedStatistic.exchangeBattery,
      value: payment.unit.exchangeBattery * fixedStatistic.exchangeBattery,
    }, {
      name: '回栏',
      unit: payment.unit.backIntoRegion,
      count: fixedStatistic.backIntoRegion,
      value: payment.unit.backIntoRegion * fixedStatistic.backIntoRegion,
    }, {
      name: '难寻',
      unit: payment.unit.hardToFindButFound,
      count: fixedStatistic.hardToFindButFound,
      value: payment.unit.hardToFindButFound * fixedStatistic.hardToFindButFound,
    }, {
      name: '投放',
      unit: payment.unit.putOn,
      count: fixedStatistic.putOn,
      value: payment.unit.putOn * fixedStatistic.putOn,
    }, {
      name: '普通',
      unit: payment.unit.normal,
      count: fixedStatistic.normal,
      value: payment.unit.normal * fixedStatistic.normal,
    }, {
      name: '拖回未完成',
      unit: payment.unit.returnBackUnfinished,
      count: Math.max(0, fixedStatistic.returnBackUnfinished),
      value: -payment.unit.returnBackUnfinished * Math.max(0, fixedStatistic.returnBackUnfinished),
    }, {
      name: '错误换电',
      unit: payment.unit.wrongChange,
      count: fixedStatistic.wrongChange,
      value: -payment.unit.wrongChange * fixedStatistic.wrongChange,
    }, {
      name: '丢失电池',
      unit: payment.unit.lostBattery,
      count: Math.max(0, fixedStatistic.lostBattery),
      value: -payment.unit.lostBattery * Math.max(0, fixedStatistic.lostBattery),
    });
    yield OPInspectionOrderController.Model.findByIdAndUpdate(id, {
      $set: {
        'payment.projects': payment.projects,
      },
    });
    // 触发重新计算金额
    yield OPInspectionOrderController.calculateAmount({ id });
  }

  static *calculateAmount({ id }) {
    const inspectionOrder = yield OPInspectionOrderController.Model.findById(id);
    const totalAmount = [...inspectionOrder.payment.projects, ...inspectionOrder.payment.extraProjects].reduce((memo, item) => {
      return memo + (item.value || 0);
    }, 0);

    yield OPInspectionOrderController.Model.findByIdAndUpdate(id, {
      $set: {
        'payment.totalAmount': totalAmount,
      },
    });
  }
}

OPInspectionOrderController.Model = OPInspectionOrder;
module.exports = OPInspectionOrderController;
