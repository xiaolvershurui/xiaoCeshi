const OPGEOInspectionPoint = require('../../models/operation/op_geo_inspection_point');
const ACUserController = require('../account/ACUserController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class OPGEOInspectionPointController extends Controller {
  static * searchNear (center, query = {}, searchRadius = 2000, limit = 10000) {
    return yield OPGEOInspectionPoint.find(query).near('lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).populate({
      path: 'user',
      model: ACUserController.Model,
    });
  }
}

OPGEOInspectionPointController.Model = OPGEOInspectionPoint;
module.exports = OPGEOInspectionPointController;
