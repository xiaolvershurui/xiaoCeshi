const Controller = require('../Controller');
const OPRideOrder = require('../../models/operation/op_ride_order');
const Error = require('errrr');

class OPRideOrderController extends Controller {
  *calculateUrgentTaskDeductAmount(id, amount) {
    yield this.T(OPRideOrder).findByIdAndUpdate(id, {
      $set: {
        'payment.urgentTask.unFinishedUrgentTaskDeductAmount': amount,
      },
    });
  }

  *recordUnInspectionStocks(id, unFinishedUrgencyTask) {
    yield this.T(OPRideOrder).findByIdAndUpdate(id, {
      $set: {
        unInspectedStocks: unFinishedUrgencyTask,
        unFixedUnInspectedStocks: unFinishedUrgencyTask,
      },
    });
  }

  static *calculateProject({ id }) {
    const riderOrder = yield OPRideOrderController.Model.findById(id).select('payment updatedAt fixedStatistic');
    if (!riderOrder) throw new Error(`不存在骑手单${id}`);
    const { payment, fixedStatistic } = riderOrder;
    payment.projects = [];
    payment.projects.push({
      name: '拖回',
      count: fixedStatistic.returnBack || 0,
    }, {
      name: '换电',
      count: fixedStatistic.exchangeBattery || 0,
    }, {
      name: '回栏',
      count: fixedStatistic.backIntoRegion || 0,
    }, {
      name: '难寻',
      count: fixedStatistic.hardToFindButFound || 0,
    }, {
      name: '投放',
      count: fixedStatistic.putOn || 0,
    }, {
      name: '普通',
      count: fixedStatistic.normal || 0,
    }, {
      name: '拖回未完成',
      count: Math.max(0, fixedStatistic.returnBackUnfinished),
    }, {
      name: '错误换电',
      count: fixedStatistic.wrongChange || 0,
    }, {
      name: '丢失电池',
      count: Math.max(0, fixedStatistic.lostBattery),
    }, {
      name: '难寻巡检',
      count: fixedStatistic.hardToFind || 0,
    }, {
      name: '难寻找到',
      count: fixedStatistic.hardToFindButFound || 0,
    }, {
      name: '难寻未找到',
      count: fixedStatistic.hardToFindButNotFound || 0,
    }, {
      name: '离线巡检',
      count: fixedStatistic.offline || 0,
    }, {
      name: '离线找到',
      count: fixedStatistic.offlineButFound || 0,
    }, {
      name: '离线未找到',
      count: fixedStatistic.offlineButNotFound || 0,
    }, {
      name: '断电巡检',
      count: fixedStatistic.powerOff || 0,
    }, {
      name: '断电找到',
      count: fixedStatistic.powerOffButFound || 0,
    }, {
      name: '断电未找到',
      count: fixedStatistic.powerOffButNotFound || 0,
    }, {
      name: '挪车唤醒找到',
      count: fixedStatistic.moveAndWakeUp || 0,
    });
    yield OPRideOrderController.Model.findByIdAndUpdate(id, {
      $set: {
        'payment.projects': payment.projects,
      }
    });
  }

}

OPRideOrderController.Model = OPRideOrder;
module.exports = OPRideOrderController;
