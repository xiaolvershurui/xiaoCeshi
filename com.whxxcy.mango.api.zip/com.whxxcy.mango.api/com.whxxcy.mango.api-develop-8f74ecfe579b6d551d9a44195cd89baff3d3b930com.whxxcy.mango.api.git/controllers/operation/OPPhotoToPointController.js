const OPPhotoToPoint = require('../../models/operation/op_photo_to_point');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');
const geolib = require('geolib');

class OPPhotoToPointController extends Controller {

}

OPPhotoToPointController.Model = OPPhotoToPoint;
module.exports = OPPhotoToPointController;
