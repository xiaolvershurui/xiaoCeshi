const OPWorkOrder = require('../../models/operation/op_work_order');
const ACCouponController = require('../../controllers/account/ACCouponController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const BKStockController = require('../ebike/BKStockController');
const ODOrderController = require('../order/ODOrderController');
const Error = require('errrr');
const dingRobot = require('../../services/dingRobot');
const ACUserController = require('../account/ACUserController');
const RCMessageSystemController = require('../../controllers/record/RCMessageSystemController');

class OPWorkOrderController extends Controller {
  static *create({ user, order = {}, deviceInfo = {}, type = constants.OP_WORK_ORDER_TYPE.软件反馈, stock = {}, photos = [], description, processed, processedAt, processor }) {
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    dingRobot.feedback({
      tel: userData.auth.tel,
      name: userData.cert.name,
      type: 4,
      workOrderType: type,
      stockNo: stock.number && stock.number.custom,
      orderId: order._id,
      pic: photos[0],
      content: `${constants.OP_WORK_ORDER_TYPE_MAP[type] || ''} ${description}`,
    });
    return yield OPWorkOrder.create({
      _id: yield OPWorkOrder.genId(),
      user,
      userName: userData.cert.name,
      userTel: userData.auth.tel,
      region: order.region || stock.region,
      order,
      stock,
      deviceInfo,
      type,
      processed,
      processedAt,
      processor,
      photos,
      description,
    });
  }

  static *createByStock({ user, stock, deviceInfo, photos = [], description }) {
    stock = yield BKStockController.findByIdAndCheckExists(stock);
    return yield this.create({ user, stock, deviceInfo, type: constants.OP_WORK_ORDER_TYPE.车辆问题, photos, description });
  }

  static *createByOrder({ user, order, deviceInfo, photos = [], description }) {
    order = yield ODOrderController.findByIdAndCheckExists(order);
    const stock = yield BKStockController.findByIdAndCheckExists(order.stock);
    if (order.user !== user) throw new Error('订单选择错误');
    return yield this.create({
      user,
      order,
      stock,
      deviceInfo,
      type: constants.OP_WORK_ORDER_TYPE.订单问题,
      photos,
      description,
    });
  }

  static *createByDispatchCost({ user, order, deviceInfo, photos = [], description }) {
    order = yield ODOrderController.findByIdAndCheckExists(order);
    const stock = yield BKStockController.findByIdAndCheckExists(order.stock);
    if (order.user !== user) throw new Error('订单选择错误');
    if (description === '无疑问') {
      return yield this.create({
        user,
        order,
        stock,
        deviceInfo,
        processed: true,
        processedAt: new Date(),
        processor: '1',
        type: constants.OP_WORK_ORDER_TYPE.调度费无问题,
        photos,
        description,
      });
    } else {
      return yield this.create({
        user,
        order,
        stock,
        deviceInfo,
        type: constants.OP_WORK_ORDER_TYPE.调度费问题,
        photos,
        description,
      });
    }
  }

  static *findByIdAndCheckExists(id) {
    const workOrder = yield OPWorkOrder.findById(id);
    if (!workOrder) throw new Error('工单不存在');
    return workOrder;
  }

  static *process(id, { processor, reply, reason }) {
    const workOrder = yield this.findByIdAndCheckExists(id);
    if (workOrder.processed) throw new Error('该工单已经处理');
    const now = new Date();
    yield OPWorkOrder.findByIdAndUpdate(id, {
      $set: {
        processor,
        processed: true,
        processedAt: now,
        reply,
        reason,
        timeCost: now.getTime() - workOrder.createdAt.getTime(),
      },
    });

    const result = yield OPWorkOrder.findById(id).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    }).populate({
      path: 'processor',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    }).populate({
      path: 'order._id',
      model: ODOrderController.Model,
      select: 'state free grantCoupon freeDispatch price.dispatchCost',
    }).populate({
      path: 'stock._id',
      model: BKStockController.Model,
      select: 'state locate',
    }).select('-order.route.path');
    // 工单回复进入消息通知
    RCMessageSystemController.WorkOrderNotify({ id, user: result.user._id }).catch(error => {
      //
    });
    return result;
  }

  *processAndFreeDispatchCost({ id, processedAt, type, description, nearParkingLots }) {
    const workOrder = yield OPWorkOrderController.findByIdAndCheckExists(id);
    if (!workOrder.processed) {
      if (type === constants.OP_WORK_ORDER_TYPE.订单问题 && description === '停车处适合停车但未划定停车区' && nearParkingLots.length) {
        yield this.T(OPWorkOrder).findByIdAndUpdate(id, {
          $set: {
            processor: '1',
            processed: true,
            processedAt,
            reply: '很抱歉给您带来不好的体验，小芒果检测发现您附近是有停车区的哦，如仍有疑问，请致电客服。',
            reason: '附近无停车区',
            timeCost: processedAt.getTime() - workOrder.createdAt.getTime(),
          },
        });
      } else {
        yield new ODOrderController(this.transaction).freeForDispatchCost(workOrder.order._id, {
          reason: '停车区定位错误',
          processor: '1',
        });
        yield this.T(OPWorkOrder).findByIdAndUpdate(id, {
          $set: {
            processor: '1',
            processed: true,
            processedAt,
            reply: '很抱歉给您带来不好的体验，小芒果停车区目前在测试阶段，后期会不断的优化改进，您此订单调度费已为您退回到您的余额中，期待您的理解~',
            reason: '定位不准',
            timeCost: processedAt.getTime() - workOrder.createdAt.getTime(),
          },
        });
      }
    }
  }

  static *comment(id, result) {
    const workOrder = yield this.findByIdAndCheckExists(id);
    if (!workOrder.processed) throw new Error('该工单还未处理');
    return OPWorkOrder.findByIdAndUpdate(id, {
      $set: {
        commented: true,
        commentedAt: new Date(),
        commentResult: result,
      },
    }, { new: true });
  }

  *grantCoupon({ workOrder, amount, name, granter, count, validateDay }) {
    for (let i = 0; i < count; i += 1) {
      yield new ACCouponController(this.transaction).create({
        name,
        user: workOrder.user,
        amount,
        type: constants.AC_COUPON_TYPE.租金抵扣券,
        validDuration: validateDay,
        isSystem: false,
        granter,
      });
    }
    yield this.T(ODOrderController.Model).findByIdAndUpdate(workOrder.order._id, {
      $set: {
        grantCoupon: true,
      },
    });
  }
}

OPWorkOrderController.Model = OPWorkOrder;
module.exports = OPWorkOrderController;
