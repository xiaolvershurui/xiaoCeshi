const FNTicket = require('../../models/finance/fn_ticket');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');
const Payment = require('../../services/payment');
const FNBalanceBillController = require('./FNBalanceBillController');
const FNDepositBillController = require('./FNDepositBillController');
const ACUserController = require('../account/ACUserController');
const ACWalletController = require('../account/ACWalletController');
const RCNotificationController = require('../record/RCNotificationController');
const SSFlowInHourController = require('../statistic/SSFlowInHourController');
const RCDepositRefundController = require('../record/RCDepositRefundController');
const RCDepositRefund = require('../../models/record/rc_deposit_refund');
const transaction = require('../../services/transaction');
const RCMessageSystemController = require('../../controllers/record/RCMessageSystemController');

class FNTicketController extends Controller {

  *create({ user, type, channel, amount, useApiChannel }) {
    const id = yield FNTicket.genId();
    const subject = constants.FN_TICKET_SUBJECTS[type];
    const { charge, expires, apiChannel } = yield Payment.create({
      ticket: id,
      apiChannel: useApiChannel,
      channel,
      amount,
      subject,
    });
    const data = {
      _id: id,
      user,
      type,
      channel,
      apiChannel,
      amount,
      expires,
      subject,
    };
    if (apiChannel === constants.FN_TICKET_PAYMENT_API_CHANNEL.pingxx) {
      data.pingpp = { charge: charge.id };
    }
    const ticket = yield this.T(FNTicket).create(data);
    return {
      ticket,
      charge,
    };
  }

  *findRefundingByUser(user) {
    return yield this.T(FNTicket).findOne({
      user,
      state: constants.FN_TICKET_STATE.退款中,
      type: constants.FN_TICKET_TYPE.支付押金,
    });
  }

  static *findNoRefundingByUser(user) {
    return yield FNTicket.findOne({
      user,
      state: constants.FN_TICKET_STATE.已支付,
      type: constants.FN_TICKET_TYPE.支付押金,
    });
  }

  *createDeposit({ user, channel, useApiChannel, amount }) {
    // 如果已经缴纳，无需再缴纳

    // const ACWalletController = require('../account/ACWalletController');
    const wallet = yield ACWalletController.findByUserAndCheckExists(user);
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      throw new Error('押金正在退款中，请等待退款完成再进行缴纳');
    }
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.可退款) throw new Error('押金已经交纳成功，请前往钱包查看');
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.未缴纳) throw new Error('当前不能进行押金交纳');
    const processingTicket = yield FNTicket.findOne({
      user,
      state: constants.FN_TICKET_STATE.待支付,
      type: constants.FN_TICKET_TYPE.支付押金,
    });

    // 取消未完成的账单
    if (processingTicket) {
      const t = transaction();
      const { paid } = yield t.try(function *() {
        return yield new FNTicketController(t).check(processingTicket._id);
      });
      if (paid) throw new Error('已经成功缴纳押金，请退出应用后重新打开刷新钱包查看。');
      yield this.cancel(processingTicket._id, {
        canceller: constants.FN_TICKET_CANCLLER.系统,
        cancelReason: '交易关闭',
      });
    }
    return yield this.create({ user, type: constants.FN_TICKET_TYPE.支付押金, amount, channel, useApiChannel });
  }

  *createRecharge({ user, channel, useApiChannel, amount }) {
    return yield this.create({ user, type: constants.FN_TICKET_TYPE.充值, amount, channel, useApiChannel });
  }

  static *findByIdAndCheckExists(id) {
    const ticket = yield FNTicket.findById(id);
    if (!ticket) throw new Error('账单不存在');
    return ticket;
  }

  *findByIdAndCheckExists(id) {
    const ticket = yield this.T(FNTicket).findById(id);
    if (!ticket) throw new Error('账单不存在');
    if (ticket.apiChannel === constants.FN_TICKET_PAYMENT_API_CHANNEL.pingxx) {
      ticket.apiChannel = ticket.channel;
    }
    return ticket;
  }

  static *findByIdAndPopulate(id) {
    return FNTicket.findById(id).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    }).populate({
      path: 'refund.processor',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    }).populate({
      path: 'refund.manualFinished.processor',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    });
  }

  *cancel(id, { cancelReason, canceller, cancelError }) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if (ticket.state === constants.FN_TICKET_STATE.已取消) return ticket;
    if (ticket.state !== constants.FN_TICKET_STATE.待支付) {
      throw new Error('当前账单不能取消');
    }
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.已取消,
        cancelledAt: new Date(),
        canceller,
        cancelReason,
        cancelError,
      },
    }, { new: true });
  }

  *finish(id) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if (ticket.state !== constants.FN_TICKET_STATE.待支付) {
      throw new Error('当前账单不能完成');
    }
    if (ticket.type === constants.FN_TICKET_TYPE.充值) {
      yield new FNBalanceBillController(this.transaction).create({
        user: ticket.user,
        signal: constants.FN_BALANCE_BILL_SIGNAL.充值,
        ticket: id,
        amount: ticket.amount,
      });
      SSFlowInHourController.trigger(constants.SS_FLOW_IN_HOUR_TYPE.充值, ticket.amount).catch(error => {
        // console.error(error);
      });
    } else {
      yield new FNDepositBillController(this.transaction).create({
        user: ticket.user,
        type: constants.FN_DEPOSIT_BILL_TYPE.支付押金,
        ticket: id,
        amount: ticket.amount,
      });
      SSFlowInHourController.trigger(constants.SS_FLOW_IN_HOUR_TYPE.支付押金, ticket.amount).catch(error => {
        //
      });
    }
    const ACUserController = require('../account/ACUserController');
    const user = yield ACUserController.findByIdAndCheckExists(ticket.user);
    new RCNotificationController(this.transaction).create({
      channel: constants.RC_NOTIFICATION_CHANNEL.钉钉机器人,
      type: constants.RC_NOTIFICATION_TYPE.支付通知,
      data: {
        name: user.cert && user.cert.name,
        tel: user.auth.tel,
        type: ticket.type,
        amount: ticket.amount,
      },
    }).catch(error => {
      //
    });
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.已支付,
        finishedAt: new Date(),
      },
    }, { new: true });
  }

  *check(id) {
    let ticket = yield this.findByIdAndCheckExists(id);
    const result = yield Payment.retrieve({
      apiChannel: ticket.apiChannel,
      ticket: id,
      chargeId: ticket.pingpp.charge,
    });
    return yield this.checkChargeAndProcess(result);
  }

  *updateChannelExtra({ ticket, apiChannel, extra }) {
    const updateData = {
      tradeNo: extra.tradeNo,
    };
    if (apiChannel === constants.FN_TICKET_PAYMENT_API_CHANNEL.支付宝) {
      updateData.alipayExtra = extra;
    } else if (apiChannel === constants.FN_TICKET_PAYMENT_API_CHANNEL.微信) {
      updateData.wxpayExtra = extra;
    } else if (apiChannel === constants.FN_TICKET_PAYMENT_API_CHANNEL.pingxx) {
      updateData.pingppExtra = extra;
    }
    return yield this.T(FNTicket).findByIdAndUpdate(ticket, updateData, { new: true });
  }

  *checkChargeAndProcess({ paid, totalAmount, ticket, apiChannel, extra = {} }) {
    ticket = yield this.findByIdAndCheckExists(ticket);
    if (![
        constants.FN_TICKET_STATE.待支付,
        constants.FN_TICKET_STATE.已支付,
        constants.FN_TICKET_STATE.已取消,
      ].includes(ticket.state)) {
      return {
        paid: false,
        ticket,
      };
    }
    if (ticket.state === constants.FN_TICKET_STATE.已支付) return {
      paid: true,
      ticket,
    };
    yield this.updateChannelExtra({
      ticket: ticket._id,
      extra,
      apiChannel,
    });
    if (paid) {
      if (ticket.state === constants.FN_TICKET_STATE.已取消) {
        // 对于支付成功但凭据取消的情况，直接自动退款
        yield this.applyRefund(ticket._id, { willProcessAt: new Date() });
        return {
          paid: false,
          ticket,
        };
      } else if (totalAmount !== ticket.amount) {
        // 如果支付凭据和渠道凭据的金额不一致，直接退款
        yield this.cancel(ticket._id, {
          canceller: constants.FN_TICKET_CANCLLER.系统,
          cancelReason: '渠道金额不一致',
          cancelError: '渠道金额不一致',
        });
        yield this.applyRefund(ticket._id, { willProcessAt: new Date() });
        return {
          paid: false,
          ticket,
        };
      } else {
        ticket = yield this.finish(ticket._id);
      }
    } else {
      if (ticket.state === constants.FN_TICKET_STATE.已取消) {
        return {
          paid: false,
          ticket,
        };
      }
      if (new Date().is.over(ticket.expires)) {
        // 过期
        ticket = yield this.cancel(ticket._id, {
          canceller: constants.FN_TICKET_CANCLLER.系统,
          cancelReason: '交易关闭',
          cancelError: '账单过期',
        });
      } else if (extra.failureCode) {
        // ticket = yield this.cancel(ticket._id, {
        //   canceller: constants.FN_TICKET_CANCLLER.系统,
        //   cancelReason: '支付失败',
        //   cancelError: extra.failureMsg
        // });
      }
    }
    return {
      paid,
      ticket,
      totalAmount,
    };
  }

  *checkRefund(id) {
    let ticket = yield this.findByIdAndCheckExists(id);
    const result = yield Payment.retrieveRefund({
      ticket: id,
      apiChannel: ticket.apiChannel,
      chargeId: ticket.pingpp.charge,
      requestId: ticket.refund.requestId || ticket.pingpp.refund,
    });
    if (!result) throw new Error('未查询到支付凭据');
    return yield this.checkRefundAndProcess(result);
  }

  *checkRefundAndProcess({ succeed, pending, failed, refundAmount, ticket, requestId, extra }) {
    ticket = yield this.findByIdAndCheckExists(ticket);
    if (ticket.state !== constants.FN_TICKET_STATE.退款已确认) return;
    if (succeed) {
      return yield this.finishRefund(ticket._id);
    } else if (failed) {
      return yield this.refundFailed(ticket._id, extra);
    }
  }

  *applyRefund(id, { willProcessAt, refundReason } = {}, { reason, refundReasonExtra, account, type, name } = {}) {
    let ticket = yield this.findByIdAndCheckExists(id);
    if (![constants.FN_TICKET_STATE.已支付, constants.FN_TICKET_STATE.已取消].includes(ticket.state)) {
      throw new Error('当前账单无法申请退款');
    }
    let amount = ticket.amount;
    if (ticket.state === constants.FN_TICKET_STATE.已支付) {
      if (ticket.type === constants.FN_TICKET_TYPE.支付押金) {
        refundReason = '申请退还押金';
      } else {
        // const ACWalletController = require('../account/ACWalletController');
        const wallet = yield ACWalletController.findByUserAndCheckExists(ticket.user);
        amount = Math.min(wallet.balance, amount);
        if (amount <= 0) throw new Error('余额不足');
        yield new FNBalanceBillController(this.transaction).create({
          user: ticket.user,
          signal: constants.FN_BALANCE_BILL_SIGNAL.充值退款,
          ticket: id,
          amount,
        });
        refundReason = refundReason || '申请退还余额';
      }
    } else {
      refundReason = '交易关闭';
    }
    const now = new Date();
    const ticketUpdate = {
      state: constants.FN_TICKET_STATE.退款中,
      'refund.appliedAt': now,
      'refund.amount': amount,
      'refund.reason': refundReason,
      'refund.willProcessAt': willProcessAt,
      'refund.userReason': reason,
      'refund.userReasonExtra': refundReasonExtra,
      rejectReason: "",
    };
    if (account) {
      if (type || type === 0) ticketUpdate['refund.refundAccount.type'] = type;
      if (account) ticketUpdate['refund.refundAccount.account'] = account;
      if (name) ticketUpdate['refund.refundAccount.name'] = name;
    }
    ticket = yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: ticketUpdate,
    }, { new: true });
    if (now.is.over(willProcessAt)) { // 如果是秒退，那就秒退
      yield this.confirmRefund(id);
    }
    const ODOrderController = require('../order/ODOrderController');
    // 退款记录
    const lastOrder = yield ODOrderController.Model.findOne({ user: ticket.user }).sort({ _id: -1 }).select('region');
    // 上次退押金
    const lastRefundRecord = yield RCDepositRefundController.Model.findOne({
      user: ticket.user,
    }).select('createdAt').sort({ _id: -1 });
    // 计算注册天数
    const ACUserController = require('../account/ACUserController');
    const ticketUser = yield ACUserController.findByIdAndCheckExists(ticket.user);
    const data = {
      user: ticket.user,
      refundCount: yield RCDepositRefundController.Model.count({
        user: ticket.user,
      }),
      refundDate: ticket.refund.appliedAt,
      historySuccessOrderCount: yield ODOrderController.Model.count({ user: ticket.user, isBad: false }),
      registeredDays: parseInt((now.getTime() - ticketUser.createdAt.getTime()) / (24 * 3600 * 1000)),
    };
    if (lastOrder) data.region = lastOrder.region;
    if (lastRefundRecord) {
      data.lastRefundDate = lastRefundRecord.createdAt;
      data.refundInterval = parseInt((ticket.refund.appliedAt.getTime() - lastRefundRecord.createdAt.getTime()) / (24 * 3600 * 1000));
      data.successOrderCountInSection = yield ODOrderController.Model.count({
        user: ticket.user,
        createdAt: { $gte: lastRefundRecord.createdAt, $lt: ticket.refund.appliedAt },
        isBad: false,
      });
    }
    yield this.T(RCDepositRefund).create(data);

    return ticket;
  }

  *updateRefundReason(id, { willProcessAt, reason, refundReasonExtra, account, type, name }) {
    const ticketUpdate = {
      state: constants.FN_TICKET_STATE.退款中,
      'refund.appliedAt': Date.now(),
      'refund.willProcessAt': willProcessAt,
      'refund.userReason': reason,
      'refund.userReasonExtra': refundReasonExtra,
      rejectReason:"",
    };
    if (account) {
      if (type || type === 0) ticketUpdate['refund.refundAccount.type'] = type;
      if (account) ticketUpdate['refund.refundAccount.account'] = account;
      if (name) ticketUpdate['refund.refundAccount.name'] = name;
    }
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: ticketUpdate,
    });
  }

  *cancelRefund(id) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if ([
        constants.FN_TICKET_STATE.退款已确认,
        constants.FN_TICKET_STATE.退款失败,
      ].includes(ticket.state)) {
      throw new Error('退款申请已经提交到支付渠道，无法撤销');
    }
    if (ticket.state !== constants.FN_TICKET_STATE.退款中) throw new Error('还未申请退款');
    if (ticket.type === constants.FN_TICKET_TYPE.充值) {
      yield new FNBalanceBillController(this.transaction).create({
        user: ticket.user,
        signal: constants.FN_BALANCE_BILL_SIGNAL.撤销退款,
        ticket: id,
        amount: ticket.refund.amount,
      });
    }
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.已支付,
        'refund.appliedAt': null,
        'refund.amount': null,
        'refund.reason': null,
        'refund.willProcessAt': null,
      },
    }, { new: true });
  }

  *resetRefund(id, processor) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if (ticket.state !== constants.FN_TICKET_STATE.退款失败) {
      throw new Error('未退款失败，无法重置退款申请');
    }
    const { refunded } = yield Payment.retrieve({ ticket: id, apiChannel: ticket.apiChannel });
    if (refunded) {
      return yield this.finishRefund(id);
    }
    const { failed, requestId, extra } = yield Payment.refund({
      ticket: id,
      apiChannel: ticket.apiChannel,
      chargeId: ticket.pingpp.charge,
      requestId: yield FNTicket.genId(),
      amount: ticket.refund.amount,
      totalAmount: ticket.amount,
      refundReason: ticket.refund.reason,
      operator: processor,
    });
    if (failed) {
      return yield this.refundFailed(id, extra);
    }
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.退款已确认,
        'refund.requestId': requestId,
        'refund.processedAt': new Date(),
        'refund.processor': processor,
        'refund.processorType': processor ? constants.FN_REFUND_PROCESSOR_TYPE.运营人员 : constants.FN_REFUND_PROCESSOR_TYPE.系统,
      },
    }, { new: true });
  }

  *confirmRefund(id, processor) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if (ticket.state !== constants.FN_TICKET_STATE.退款中) {
      throw new Error('当前账单还未申请退款或已经退款');
    }
    if (ticket.refund.amount === 0) return yield this.finishRefund(id);
    const { refunded } = yield Payment.retrieve({ ticket: id, apiChannel: ticket.apiChannel });
    if (refunded) {
      return yield this.finishRefund(id);
    }
    const { failed, requestId, extra } = yield Payment.refund({
      ticket: id,
      apiChannel: ticket.apiChannel,
      chargeId: ticket.pingpp.charge,
      requestId: yield FNTicket.genId(),
      amount: ticket.refund.amount,
      totalAmount: ticket.amount,
      refundReason: ticket.refund.reason,
      operator: processor,
    });
    if (failed) {
      return yield this.refundFailed(id, extra);
    }
    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.退款已确认,
        'refund.requestId': requestId,
        'refund.processedAt': new Date(),
        'refund.processor': processor,
        'refund.processorType': processor ? constants.FN_REFUND_PROCESSOR_TYPE.运营人员 : constants.FN_REFUND_PROCESSOR_TYPE.系统,
      },
    }, { new: true });
  }

  *finishRefund(id, { processor, tradeNo } = {}) {
    const ticket = yield this.findByIdAndCheckExists(id);
    if (![constants.FN_TICKET_STATE.退款中, constants.FN_TICKET_STATE.退款已确认, constants.FN_TICKET_STATE.退款失败].includes(ticket.state)) {
      throw new Error('当前状态无法退款');
    }
    const now = new Date();
    if (ticket.type === constants.FN_TICKET_TYPE.支付押金) {
      yield new FNDepositBillController(this.transaction).create({
        user: ticket.user,
        type: constants.FN_DEPOSIT_BILL_TYPE.退还押金,
        ticket: id,
        amount: ticket.amount,
      });
      yield SSFlowInHourController.trigger(constants.SS_FLOW_IN_HOUR_TYPE.退款押金, ticket.amount);
    } else {
      yield SSFlowInHourController.trigger(constants.SS_FLOW_IN_HOUR_TYPE.退款余额, ticket.amount);
    }

    // const wallet = yield ACWalletController.Model.findOne({ 'user': ticket.user });
    // yield this.T(ACWalletController.Model).findByIdAndUpdate(wallet._id, {
    //   refundFailed: false,
    // });
    const result = yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.已退款,
        'refund.finishedAt': now,
        'refund.manualFinished': {
          processor,
          tradeNo,
        },
      },
    }, { new: true });
    // 退款通知
    RCMessageSystemController.refundNotify({ id, user: ticket.user }).catch();
    return result;
  }

  *refundFailed(id, extra = {}) {
    // const ticket = yield FNTicketController.findByIdAndCheckExists(id);

    // const ACWalletController = require('../account/ACWalletController');
    // const wallet = yield ACWalletController.Model.findOne({ 'user': ticket.user });

    // yield this.T(ACWalletController.Model).findByIdAndUpdate(wallet._id, {
    //   refundFailed: true,
    // });

    return yield this.T(FNTicket).findByIdAndUpdate(id, {
      $set: {
        state: constants.FN_TICKET_STATE.退款失败,
        'refund.failedAt': new Date(),
        'refund.failedReason': extra.failureMsg,
      },
    }, { new: true });
  }

  static *addRejectReason(id,rejectReason){
    return yield FNTicket.findByIdAndUpdate(id,{
      $set:{
        rejectReason
      }
    },{new: true});
  }
}

FNTicketController.Model = FNTicket;
module.exports = FNTicketController;
