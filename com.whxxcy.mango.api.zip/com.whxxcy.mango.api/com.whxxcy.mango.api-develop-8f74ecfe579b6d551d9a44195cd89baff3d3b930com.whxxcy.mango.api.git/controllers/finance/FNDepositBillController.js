const FNDepositBill = require('../../models/finance/fn_deposit_bill');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const ACWalletController = require('../account/ACWalletController');

class FNDepositBillController extends Controller {
  * create ({ user, type, ticket, amount }) {
    const ACWalletController = require('../account/ACWalletController');
    const acWalletController = new ACWalletController(this.transaction);
    const id = yield FNDepositBill.genId();
    if (type === constants.FN_DEPOSIT_BILL_TYPE.支付押金) {
      yield acWalletController.payDeposit(user, { amount, ticket });
    } else {
      yield acWalletController.confirmRefund(user);
    }
    // TODO: 充退押金 对于te加盟商的处理
    return yield this.T(FNDepositBill).create({
      _id: id,
      user,
      type,
      ticket,
      amount
    });
  }
}

FNDepositBillController.Model = FNDepositBill;
module.exports = FNDepositBillController;
