const FNBalanceBill = require('../../models/finance/fn_balance_bill');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const ACWalletController = require('../account/ACWalletController');
const RCDivideSolutionController = require('../../controllers/record/RCDivideSolutionController');
const BKStockController = require('../../controllers/ebike/BKStockController');

class FNBalanceBillController extends Controller {
  * create ({ user, signal, order, ticket, flow, amount }) {
    const type = constants.FN_BALANCE_BILL_SIGNAL_MAP[signal];
    const acWalletController = new ACWalletController(this.transaction);
    if (type === constants.FN_BALANCE_BILL_TYPE.收入) {
      yield acWalletController.increaseBalance(user, amount);
    } else {
      yield acWalletController.decreaseBalance(user, amount);
    }
    const data = {
      _id: yield FNBalanceBill.genId(),
      type,
      signal,
      user,
      ticket,
      flow,
      amount,
    };
    if (order) {
      const ODOrderController = require('../order/ODOrderController');
      order = yield ODOrderController.Model.findById(order).populate({
        path: 'stock',
        model: BKStockController.Model,
        select: 'solution cost putOnAt region',
      }).select('stock region style');
      data.order = order._id;
      data.region = order.region;
      data.style = order.style;
      if ([constants.FN_BALANCE_BILL_SIGNAL.订单免单, constants.FN_BALANCE_BILL_SIGNAL.支付订单保险, constants.FN_BALANCE_BILL_SIGNAL.支付订单租金].includes(signal)) {
        yield new RCDivideSolutionController(this.transaction).findAndGenerate({ stock: order.stock, amount: signal === constants.FN_BALANCE_BILL_SIGNAL.订单免单 ? -amount : amount });
      }
    }
    return yield this.T(FNBalanceBill).create(data);
  }

  * createRent ({ user, order, amount }) {
    // TODO: 生成并绑定流水
    // TODO: 加盟商账单
    return yield this.create({
      user,
      order,
      amount,
      signal: constants.FN_BALANCE_BILL_SIGNAL.支付订单租金,
    });
  }

  * createInsurance ({ user, order, amount }) {
    // TODO: 生成并绑定流水
    // TODO: 加盟商账单
    return yield this.create({
      user,
      order,
      amount,
      signal: constants.FN_BALANCE_BILL_SIGNAL.支付订单保险,
    });
  }

  * createDispatch ({ user, order, amount }) {
    return yield this.create({
      user,
      order,
      amount,
      signal: constants.FN_BALANCE_BILL_SIGNAL.支付停车调度费用,
    });
  }

  * createFree ({ user, order, amount }) {
    return yield this.create({
      user,
      order,
      amount,
      signal: constants.FN_BALANCE_BILL_SIGNAL.订单免单,
    });
  }

  * createFreeForDispatchCost ({ user, order, amount }) {
    return yield this.create({
      user,
      order,
      amount,
      signal: constants.FN_BALANCE_BILL_SIGNAL.订单免调度费,
    });
  }

}

FNBalanceBillController.Model = FNBalanceBill;
module.exports = FNBalanceBillController;
