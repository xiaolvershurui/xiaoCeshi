const RCDepositRefund = require('../../models/record/rc_deposit_refund');
const Controller = require('../Controller');

class RCDepositRefundController extends Controller {

}

RCDepositRefundController.Model = RCDepositRefund;
module.exports = RCDepositRefundController;