const RCUserOp = require('../../models/record/rc_user_op');
const Controller = require('../Controller');

class RCUserOpController extends Controller {

}

RCUserOpController.Model = RCUserOp;
module.exports = RCUserOpController;
