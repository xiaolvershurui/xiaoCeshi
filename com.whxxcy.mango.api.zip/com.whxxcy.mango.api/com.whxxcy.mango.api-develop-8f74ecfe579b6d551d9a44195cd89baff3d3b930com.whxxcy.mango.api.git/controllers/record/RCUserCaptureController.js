const RCUserCapture = require('../../models/record/rc_user_capture');
const ACUserController = require('../account/ACUserController');
const OPPolygonController = require('../operation/OPPolygonController');
const ACUser = require('../../models/account/ac_user');
const RCLoginController = require('./RCLoginController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const { OTSUserCapture } = require('../../services/ots');
const ODReservation = require('../../models/order/od_reservation');
const ODOrder = require('../../models/order/od_order');
const FNDepositBill = require('../../models/finance/fn_deposit_bill');
const SSLivenessInDayController = require('../statistic/SSLivenessInDayController');
const SSRetentionInWeekController = require('../statistic/SSRetentionInWeekController');

class RCUserCaptureController extends Controller {
  static *create({ user, deviceInfo, appVersion, ip, lngLat, address, city, accuracy }) {
    // if (user) {
    //   // if (yield RCLoginController.findToday(user)) {
    //   //   return;
    //   // }
    //   const date = new Date((new Date()).setHours(0, 0, 0, 0));
    //   let isNewUser = false;
    //   let reservationInterval = 0;
    //   let orderInterval = 0;
    //   let depositInterval = 0;
    //   let registerInterval = 0;
    //   let freshDays = 0;
    //   freshDays = yield RCLoginController.getOneMonthCount(user);
    //   const acUser = yield ACUser.findOne({_id: user}).select('createdAt');
    //   const odOrder = yield ODOrder.findOne({
    //     user: user
    //   }).select('createdAt').sort({_id: -1});
    //   const fnDepositBill = yield FNDepositBill.findOne({
    //     user: user,
    //     type: constants.FN_DEPOSIT_BILL_TYPE.支付押金
    //   }).select('createdAt').sort({_id: -1});
    //   if (acUser && acUser.createdAt) {
    //     if (new Date(acUser.createdAt) > date) {
    //       isNewUser = true
    //     } else {
    //       registerInterval = Math.floor((new Date().getTime() - acUser.createdAt.getTime()) / (24 * 3600 * 1000));
    //     }
    //   }
    //   const odReservation = yield ODReservation.findOne({
    //     user: user
    //   }).select('createdAt').sort({_id: -1});
    //   if (odReservation && odReservation.createdAt) {
    //     reservationInterval = Math.floor((new Date().getTime() - odReservation.createdAt.getTime()) / (24 * 3600 * 1000));
    //   }
    //   if (odOrder && odOrder.createdAt) {
    //     orderInterval = Math.floor((new Date().getTime() - odOrder.createdAt.getTime()) / (24 * 3600 * 1000));
    //   }
    //   if (fnDepositBill && fnDepositBill.createdAt) {
    //     depositInterval = Math.floor((new Date().getTime() - fnDepositBill.createdAt.getTime()) / (24 * 3600 * 1000));
    //   }
    //   (async () => {
    //     // 新用户留存
    //     const rcLogoinNewUser = await RCLoginController.Model.find({
    //       user,
    //       date: {$lt: date},
    //       isNewUser: true
    //     }).sort({date: -1}).select('date').limit(30);
    //     for (let newUserLog of rcLogoinNewUser) {
    //       const obj = {};
    //       const day = SSLivenessInDayController.getRelDate(newUserLog.date, date);
    //       if (day > 0 && day <= 30) {
    //         obj[`newRegisterUserInterval.${day}`] = 1;
    //         await SSLivenessInDayController.Model.findOneAndUpdate({
    //           date: newUserLog.date
    //         }, {$inc: obj});
    //       }
    //     }
    //     let rcLoginDeposit = await RCLoginController.Model.find({
    //       user,
    //       date: {$lt: date},
    //       isDeposit: true
    //     }).select("date lastDepositWeekTime").sort({date: -1}).limit(1);
    //     if (rcLoginDeposit.length === 0) return;
    //     // 记录当日
    //     for (let i of rcLoginDeposit) {
    //       let obj = {};
    //       const day = SSLivenessInDayController.getRelDate(i.date, date);
    //       if (day > 0 && day <= 30) {
    //         obj[`depositRetentionInterval.${day}`] = 1;
    //         await SSLivenessInDayController.Model.findOneAndUpdate({
    //           date: i.date
    //         }, {$inc: obj});
    //       }
    //     }
    //     const weekDate = SSRetentionInWeekController.getNearestWeekDate(date);
    //     let isAlready = false;
    //     let rcLoginDepositWeekObj = rcLoginDeposit.reduce((memo, item) => {
    //       let updateWeek;
    //       const week = SSRetentionInWeekController.getWeek(item.date, weekDate);
    //       if (item.lastDepositWeekTime) {
    //         updateWeek = SSRetentionInWeekController.getWeek(weekDate, item.lastDepositWeekTime);
    //       } else {
    //         updateWeek = weekDate
    //       }
    //       if (updateWeek === 0) {
    //         isAlready = true;
    //       }
    //       memo.add(week);
    //       return memo;
    //     }, new Set());
    //     if (isAlready) {
    //       return
    //     }
    //     rcLoginDepositWeekObj = [...rcLoginDepositWeekObj].map(s => {
    //       return {week: s, weekDate: weekDate - (s * 7 * 24 * 3600 * 1000)}
    //     });
    //     // 更新历史
    //     for (let i of rcLoginDepositWeekObj) {
    //       const obj = {};
    //       obj[`depositRetentionInterval.${i.week}`] = 1;
    //       if (i.week > 0 && i.week <= 8) {
    //         await SSRetentionInWeekController.Model.findOneAndUpdate({
    //           date: new Date(i.weekDate)
    //         }, {
    //           $inc: obj
    //         })
    //       }
    //       // 修改原记录该周内不再记录
    //       await RCLoginController.Model.findOneAndUpdate({_id: rcLoginDeposit[0]._id}, {
    //         $set: {
    //           lastDepositWeekTime: weekDate
    //         }
    //       });
    //     }
    //   })();

    if (user && !(yield RCLoginController.findToday(user))) {
        const date = new Date((new Date()).setHours(0, 0, 0, 0));
      yield RCLoginController.create({
        date, user,
        deviceInfo, appVersion, ip, lngLat, address, city, accuracy,
      });
    }
    //   // 如果当日没有记录则创建
    //   const ssLivenessInDay = yield SSLivenessInDayController.Model.findOne({
    //     date
    //   });
    //   if (ssLivenessInDay === null) {
    //     yield SSLivenessInDayController.create(date)
    //   }
    //   // 记录到当日
    //   const obj = {};
    //   if (registerInterval > 0 && registerInterval <= 30) {
    //     obj[`registerInterval.${registerInterval}`] = 1;
    //   }
    //   if (freshDays > 0 && freshDays <= 30) {
    //     obj[`freshInterval.${freshDays}`] = 1;
    //   }
    //   yield SSLivenessInDayController.Model.findOneAndUpdate({date}, {
    //     $inc: Object.assign(obj, {"totalCount": 1})
    //   });
    //   // 记录到历史日
    //   const rcLogin = yield RCLoginController.Model.find({user, date: {$lt: date}}).select('date').limit(30);
    //   for (let i of rcLogin) {
    //     const day = SSLivenessInDayController.getRelDate(i.date, date);
    //     if (day <= 30 && day !== 0) {
    //       const obj = {};
    //       obj[`loginRetentionInterval.${day}`] = 1;
    //       yield SSLivenessInDayController.Model.findOneAndUpdate({date: i.date}, {
    //         $inc: obj
    //       });
    //     }
    //   }
    //   // 如果没有当周目录则创建
    //   const weekDate = SSRetentionInWeekController.getNearestWeekDate(date);
    //   const ssRetentionInWeek = yield SSRetentionInWeekController.Model.findOne({
    //     date: weekDate
    //   });
    //   if (!ssRetentionInWeek) {
    //     yield SSRetentionInWeekController.create(weekDate)
    //   }
    // }
    if (!deviceInfo.udid) return;
    if (yield this.findLatestByUDID(deviceInfo.udid)) return;
    const userUpdate = {
      lngLat,
      address,
      accuracy,
    };
    if (lngLat) {
      const administrativeArea = yield OPPolygonController.Model.findOne({
        type: constants.OP_POLYGON_TYPE.行政区,
        enable: true,
        isCleaned: false,
      }).where('path').intersects().geometry({
        type: 'Point',
        coordinates: lngLat,
      });
      if (administrativeArea) {
        userUpdate.administrativeAreaName = administrativeArea.location.area;
        userUpdate.city = administrativeArea.location.city;
      }
    }
    yield ACUserController.updateLocation(user, userUpdate);
    try {
      yield OTSUserCapture.create({
        user_month: `${user}_${new Date().getMonth()}`,
        time: Date.now(),
        user,
        snappedAt: new Date(),
        deviceInfo,
        appVersion,
        ip,
        lngLat,
        address,
        city,
        accuracy,
      });
    } catch (err) {
      //
    }
    return yield RCUserCapture.create({
      user,
      snappedAt: new Date(),
      deviceInfo,
      appVersion,
      ip,
      lngLat,
      address,
      city,
      accuracy,
    });
  }

  static *findLatestByUDID(udid) {
    return yield RCUserCapture.findOne({
      'deviceInfo.udid': udid,
      snappedAt: { $gte: '4 seconds'.before(new Date()) },
    });
  }

  static *findPath(user, { startTime, endTime }) {
    return yield RCUserCapture.find({
      user,
      snappedAt: {
        $gte: startTime,
        $lte: endTime,
      },
      lngLat: { $ne: null },
    }).sort({ snappedAt: 1 });
  }
}

RCUserCaptureController.Model = RCUserCapture;
module.exports = RCUserCaptureController;
