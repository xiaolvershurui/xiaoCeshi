const RCStockRemould = require('../../models/record/rc_stock_remould');
const Controller = require('../Controller');
const Error = require('errrr');

class RCStockRemouldController extends Controller {
  static *findByIdAndCheckExists(id) {
    const stock = yield RCStockRemould.findById(id);
    if (!stock) throw new Error(`车辆改造记录${id}不存在`);
    return stock;
  }
}

RCStockRemouldController.Model = RCStockRemould;
module.exports = RCStockRemouldController;
