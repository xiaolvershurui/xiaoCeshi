const RCMountingOp = require('../../models/record/rc_mounting_op');
const BKMountingController = require('../../controllers/ebike/BKMountingController');
const Controller = require('../Controller');

class RCMountingOpController extends Controller {

  static * create ({ operator, mounting, count }) {
    yield BKMountingController.findByIdAndCheckExists(mounting);
    return yield this.Model.create({
      mounting,
      count,
      operator
    })
  }

}

RCMountingOpController.Model = RCMountingOp;
module.exports = RCMountingOpController;