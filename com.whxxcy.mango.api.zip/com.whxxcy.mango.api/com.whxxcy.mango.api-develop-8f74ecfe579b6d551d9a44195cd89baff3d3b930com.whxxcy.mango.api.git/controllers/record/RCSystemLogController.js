const RCSystemLog = require('../../models/record/rc_system_log.js');
const Controller = require('../Controller');

class RCSystemLogController extends Controller {


}

RCSystemLogController.Model = RCSystemLog;
module.exports = RCSystemLogController;
