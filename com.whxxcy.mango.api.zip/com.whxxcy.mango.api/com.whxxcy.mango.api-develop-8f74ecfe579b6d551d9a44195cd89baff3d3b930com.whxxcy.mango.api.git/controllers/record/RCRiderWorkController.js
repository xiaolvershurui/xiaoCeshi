const RCRiderWork = require('../../models/record/rc_rider_work.js');
const Controller = require('../Controller');
const oss = require('../../services/oss');
const uuid = require('node-uuid');
const co = require('co');


class RCRiderWorkController extends Controller {


}

RCRiderWorkController.Model = RCRiderWork;
module.exports = RCRiderWorkController;
