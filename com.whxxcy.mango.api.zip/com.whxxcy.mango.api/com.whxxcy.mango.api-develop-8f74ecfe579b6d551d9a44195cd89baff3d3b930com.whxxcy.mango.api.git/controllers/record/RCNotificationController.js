const RCNotification = require('../../models/record/rc_notification');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const { asyncTask } = require('xx-utils');
const logger = require('../../services/logger');
const oss = require('../../services/oss');
const email = require('../../services/email');
const xlsx = require('node-xlsx').default;

class RCNotificationController extends Controller {
  async create ({ channel, type, data }) {
    return await this.T(RCNotification).create({
      channel,
      type,
      data
    });
  }

  static * create ({ channel, type, data }) {
    return yield RCNotification.create({
      channel,
      type,
      data
    });
  }

  static * createDataExport ({ emailTo, name, data, sender }) {
    if(process.env.NODE_ENV !== 'production') return;
    const buffer = xlsx.build([{ name, data }]);
    const ossResult = yield oss.private.putData('数据导出存档', buffer, name, '.xlsx');
    yield email.notify({
      to: emailTo,
      subject: `导出数据-${name}`,
      attachments: [{
        filename: `${name}.xlsx`,
        content: buffer,
      }]
    });
    return yield RCNotification.create({
      channel: constants.RC_NOTIFICATION_CHANNEL.邮件,
      type: constants.RC_NOTIFICATION_TYPE.报表导出,
      data: Object.assign({}, ossResult, sender ? { sender } : { sender: '定时任务' }, { emailTo }),
      notified: true,
      notifiedAt: new Date()
    });
  }

  static createInternalError (error, { ip, user, deviceInfo, method, path, query, body } = {}) {
    asyncTask(function * () {
      return yield this.create({
        channel: constants.RC_NOTIFICATION_CHANNEL.钉钉机器人,
        type: constants.RC_NOTIFICATION_TYPE.系统错误,
        data: { error: { message: error.message, stack: error.stack }, ip, user, deviceInfo, method, path, query, body }
      });
    }.bind(this), error => logger.error({
      error: {
        message: error.message,
        stack: error.stack
      }
    }));
  }

  static createRequestError (error, { ip, user, deviceInfo, method, path, query, body } = {}) {
    error.extra = error.extra || {};
    asyncTask(function * () {
      return yield this.create({
        channel: constants.RC_NOTIFICATION_CHANNEL.钉钉机器人,
        type: constants.RC_NOTIFICATION_TYPE.请求错误,
        data: {
          ip,
          error: error.message,
          errorExtra: error.extra,
          user, method, path, query, body, deviceInfo
        }
      });
    }.bind(this), error => logger.error({
      error: {
        message: error.message,
        stack: error.stack
      }
    }));
  }

  static * findAndSetNotified (query) {
    const notifications = yield RCNotification.find(Object.assign(query, {
      notified: false
    }));
    yield RCNotification.update({ _id: { $in: notifications.map(notification => notification._id) } }, {
      $set: {
        notified: true,
        notifiedAt: new Date()
      }
    }, { multi: true });
    return notifications;
  }

}

RCNotificationController.Model = RCNotification;
module.exports = RCNotificationController;
