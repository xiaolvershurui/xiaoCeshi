const RCStockPoint = require('../../models/record/rc_stock_point');
const Controller = require('../Controller');
const BKStockController = require('../ebike/BKStockController');
const RCStockAlarmController = require('./RCStockAlarmController');
const constants = require('../../settings/constants');
const forwarding = require('../../services/cloud/forwarding');
const shark = require('../../services/shark').database;

class RCStockPointController extends Controller {
  static * create ({
    isOnline, box, dataSource, gps, alarms, extra, acc, lock, batteryLock, powerUnlink,
    wheelLock, time, expired, expires, sim, appVersion, deviceType, deltaMileage, mdis,
    lastLngLat, lastSnappedAt, illegalLngLat, nodeId, sampleSpeed, cmd, bin,
  }) {
    const { stock } = (yield BKStockController.findBoxByBoxId(box)) || {};
    const region = stock && stock.region;
    const style = stock && stock.style;
    const stockId = stock && stock._id;
    // 记录历史点
    const point = yield RCStockPoint.create({
      isOnline,
      region,
      style,
      stock: stockId,
      stockPower: stock && stock.battery && stock.battery.power,
      box, gps, alarms, extra, acc, lock, batteryLock, wheelLock, powerUnlink, time, dataSource, sim,
      appVersion, deviceType,
      expires, expired, deltaMileage, mdis, lastLngLat, lastSnappedAt, illegalLngLat, nodeId,
      sampleSpeed, cmd, bin,
    });
    // 记录警报
    for (let alarm of alarms) {
      yield RCStockAlarmController.create({
        box,
        dataSource,
        point: point._id,
        type: alarm,
        time,
        region, style, stock,
        acc,
        lock,
        expired
      });
    }
    // 数据转发
    // if (stockId) {
    //   yield forwarding(stockId, {
    //     box, dataSource, gps, isOnline,
    //     alarms, extra, acc, lock, time,
    //     battery: stock && stock.battery
    //   });
    // }
    return point;
  }

  static * findPath (box, { startTime, endTime }) {
    return yield shark.sendSync({
      c: 'record/stockPoint/findPathWithGPSInfo',
      params: {
        box,
        startTime,
        endTime
      }
    });
    // return yield RCStockPoint.find({
    //   box,
    //   time: {
    //     $gte: startTime,
    //     $lte: endTime
    //   },
    //   'gps.locationType': constants.BK_BOX_LOCATION_TYPE.卫星
    // }).sort({ time: 1 });
  }

  static * findLatestPath (box, limit) {
    return yield shark.sendSync({
      c: 'record/stockPoint/findLatestPath',
      params: {
        box,
        limit
      }
    });
    // return yield RCStockPoint.find({
    //   box,
    //   'gps.locationType': constants.BK_BOX_LOCATION_TYPE.卫星
    // }).sort({ time: -1 }).limit(limit);
  }

  static * findLatestPathByDuration ({ box, startTime, endTime }) {
    return yield shark.sendSync({
      c: 'record/stockPoint/findPath',
      params: {
        box,
        startTime,
        endTime
      }
    });
    // return yield RCStockPoint.find({
    //   box,
    //   time: { $gte: startTime, $lte: endTime },
    //   'gps.locationType': constants.BK_BOX_LOCATION_TYPE.卫星,
    // }).sort({ time: -1 });
  }

  // 性能问题 弃用
  static * searchNear (center, searchRadius = constants.POLYGON_SEARCH_RADIUS, limit = 1000) {
    return [];
    // return yield RCStockPoint.find({
    //   'gps.locationType': constants.BK_BOX_LOCATION_TYPE.卫星,
    //   acc: true,
    //   lock: false,
    // }).near('gps.lngLat', {
    //   center,
    //   spherical: true,
    //   maxDistance: searchRadius / constants.EARTH_RADIUS,
    //   distanceMultiplier: constants.EARTH_RADIUS
    // }).limit(limit);
  }
}

RCStockPointController.Model = RCStockPoint;
module.exports = RCStockPointController;
