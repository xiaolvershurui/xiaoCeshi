const RCOplog = require('../../models/record/rc_oplog');
const Controller = require('../Controller');

class RCOplogController extends Controller {

}

RCOplogController.Model = RCOplog;
module.exports = RCOplogController;