const RCBatteryLost = require('../../models/record/rc_battery_lost');
const Controller = require('../Controller');

class RCBatteryLostController extends Controller {

  static * create ({ battery, stock, operator, address }) {
    yield this.Model.create({
      battery: battery._id,
      lostAddress: address,
      stock,
      QRCode: battery.QRCode,
      mark: battery.mark,
      lostAt: new Date(),
      operator
    })
  }

  * findBack (id, { operator, address }) {
    return yield this.Model.findByIdAndUpdate(id, {
      $set: {
        finder: operator,
        findAddress: address,
        foundedAt: new Date(),
        hasFind: true
      }
    })
  }
}

RCBatteryLostController.Model = RCBatteryLost;
module.exports = RCBatteryLostController;