const Controller = require('../Controller');
const RCIdCardVerify = require('../../models/record/rc_id_card_verify');

class RCIdCardVerifyController extends Controller {
  static async create ({ user, tel, certNo, name, transId, succeed, fee, description }) {
    return await RCIdCardVerify.create({
      _id: transId,
      user,
      tel,
      certNo,
      name,
      succeed,
      fee,
      description,
      verifiedAt: new Date()
    });
  }
}

RCIdCardVerifyController.Model = RCIdCardVerify;
module.exports = RCIdCardVerifyController;