const RCLogin = require('../../models/record/rc_login');

const Controller = require('../Controller');

class RCLoginController extends Controller {
  static* create ({ date, isNewUser, reservationInterval, orderInterval, registerInterval, depositInterval, freshDays, user, deviceInfo, appVersion, ip, address, lngLat, city, accuracy }) {
    // // 恢复账单+钱包数据
    // const bills = yield FNBalanceBill.find({ user });
    // let balance = 0;
    // const payOrder = [];
    // const freeOrder = [];
    // const payTicket = [];
    // const refundTicket = [];
    // for (let bill of bills) {
    //   if (bill.type === constants.FN_BALANCE_BILL_TYPE.支出) {
    //     if (bill.order) {
    //       const order = yield ODOrder.findById(bill.order);
    //       if (order) {
    //         if (payOrder.includes(bill.order)) {
    //           yield FNBalanceBill.findByIdAndRemove(bill._id);
    //           continue;
    //         } else {
    //           payOrder.push(bill.order);
    //           if ((order.payInfo.totalAmount + order.payInfo.freeDiscount) !== bill.amount) {
    //             bill = yield FNBalanceBill.findByIdAndUpdate(bill._id, {
    //               $set: {
    //                 amount: order.payInfo.totalAmount + order.payInfo.freeDiscount
    //               }
    //             }, { new: true });
    //           }
    //         }
    //       }
    //     } else if (bill.ticket) {
    //       const ticket = yield FNTicket.findById(bill.ticket);
    //       if (ticket) {
    //         if (refundTicket.includes(bill.ticket)) {
    //           yield FNBalanceBill.findByIdAndRemove(bill._id);
    //           continue;
    //         } else {
    //           refundTicket.push(bill.ticket);
    //           if (ticket.amount !== bill.amount) {
    //             bill = yield FNBalanceBill.findByIdAndUpdate(bill._id, {
    //               $set: {
    //                 amount: ticket.amount
    //               }
    //             }, { new: true });
    //           }
    //         }
    //       }
    //     }
    //     balance -= bill.amount;
    //   } else {
    //     if (bill.order) {
    //       const order = yield ODOrder.findById(bill.order);
    //       if (order) {
    //         if (freeOrder.includes(bill.order)) {
    //           yield FNBalanceBill.findByIdAndRemove(bill._id);
    //         } else {
    //           freeOrder.push(bill.order);
    //           if (order.payInfo.freeDiscount !== bill.amount) {
    //             bill = yield FNBalanceBill.findByIdAndUpdate(bill._id, {
    //               $set: {
    //                 amount: order.payInfo.freeDiscount
    //               }
    //             }, { new: true });
    //           }
    //         }
    //       }
    //     } else if (bill.ticket) {
    //       const ticket = yield FNTicket.findById(bill.ticket);
    //       if (ticket) {
    //         if (payTicket.includes(bill.ticket)) {
    //           yield FNBalanceBill.findByIdAndRemove(bill._id);
    //         } else {
    //           payTicket.push(bill.ticket);
    //           if (ticket.amount !== bill.amount) {
    //             bill = yield FNBalanceBill.findByIdAndUpdate(bill._id, {
    //               $set: {
    //                 amount: ticket.amount
    //               }
    //             }, { new: true });
    //           }
    //         }
    //       }
    //     }
    //     balance += bill.amount;
    //   }
    // }
    // const wallet = yield ACWallet.findById(user);
    // if (wallet && balance !== wallet.balance) {
    //   yield ACWallet.findByIdAndUpdate(user, {
    //     $set: {
    //       balance
    //     }
    //   });
    // } else if (!wallet) {
    //   yield ACWallet.create({
    //     _id: user,
    //     user,
    //     balance
    //   });
    // }
    const lastLoginInterval = yield this.getLastLoginInterval(user);
    const Interval = yield this.findOnceLogin(user);
    const loginRecord = Object.assign({}, Interval, lastLoginInterval, {
      user,
      date,
      isNewUser,
      reservationInterval,
      orderInterval,
      registerInterval,
      depositInterval,
      freshDays,
      loggedAt: new Date(),
      deviceInfo,
      appVersion,
      ip,
      lngLat,
      address,
      city,
      accuracy
    });
    return yield RCLogin.create(loginRecord);
  }

  static* findToday (user) {
    return yield RCLogin.findOne({
      user,
      date: { $gte: 'today'.beginning }
    });
  }

  static* getOneMonthCount (user) {
    return yield RCLogin.count({
      user,
      loggedAt: { $gte: '30 day'.before('today'.beginning) }
    });
  }

  static async updateData (id, data) {
    await RCLogin.findByIdAndUpdate(id, {
      $set: data
    });
  }

  static* getLastLoginInterval (user) {
    const record = yield RCLogin.findOne({ user });
    if (record) {
      let interval = Math.floor((new Date().getTime() - record.loggedAt.getTime()) / (24 * 3600 * 1000));
      return {
        lastLoginInterval: interval
      }
    } else {
      return {
        lastLoginInterval: 0
      }
    }
  }

  static* findOnceLogin (user) {
    const record = yield RCLogin.findOne({ user });
    if (record) {
      let interval = Math.floor((new Date().getTime() - record.loggedAt.getTime()) / (24 * 3600 * 1000));
      if (interval >= 7 && interval < 30) {
        interval = 7;
      } else if (interval >= 30 && interval < 90) {
        interval = 8
      } else if (interval >= 90 && interval < 360) {
        interval = 9
      } else if (interval > 360) {
        interval = 10;
      }
      return {
        lastTimeInterval: interval
      }
    } else {
      return {
        lastTimeInterval: 0
      }
    }
  }
}

RCLoginController.Model = RCLogin;
module.exports = RCLoginController;