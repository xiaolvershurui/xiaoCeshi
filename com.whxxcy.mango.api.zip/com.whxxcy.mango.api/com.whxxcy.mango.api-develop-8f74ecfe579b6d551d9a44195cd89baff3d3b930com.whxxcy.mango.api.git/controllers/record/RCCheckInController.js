const RCCheckIn = require('../../models/record/rc_check_in');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const ACOperatorController = require('../account/ACOperatorController');
const BKStockController = require('../ebike/BKStockController');
const SSInspectInDayController = require('../statistic/SSInspectInDayController');
const Error = require('errrr');
const { asyncTask } = require('xx-utils');
const errorHandler = require('../../services/errorHandler');

class RCCheckInController extends Controller {
  static * create ({ user, location }) {
    const operator = yield ACOperatorController.Model.findOne({ user });
    if (!operator) throw new Error('运营账户不存在，请联系管理员');
    const data = {
      user,
      operator: operator._id,
      location,
      checkedAt: new Date()
    };
    const latestCheck = yield RCCheckIn.findOne({
      user
    }).sort({ checkedAt: -1 });
    if (operator.isWorking && latestCheck) {
      // 签退必须手头没有调度待处理的任务
      const dispatchingStock = yield BKStockController.Model.findOne({
        inspector: user,
        locate: constants.BK_LOCATE.调度
      });
      if (dispatchingStock) throw new Error('您还有调度待处理的任务未完成，请完成后再签退');
      data.type = constants.RC_CHECK_IN_TYPE.签退;
      data.totalWorkTime = Math.ceil((data.checkedAt.getTime() - latestCheck.checkedAt.getTime()).msTo.minute);
      asyncTask(function * () {
        yield SSInspectInDayController.trigger({
          user,
          checkInAt: latestCheck.checkedAt,
          checkOutAt: data.checkedAt,
          totalWorkTime: data.totalWorkTime,
        });
      }, errorHandler);
    } else {
      data.type = constants.RC_CHECK_IN_TYPE.签到;
    }
    yield ACOperatorController.toggleWorking(operator._id, data.type === constants.RC_CHECK_IN_TYPE.签到, location.lngLat);
    return yield RCCheckIn.create(data);
  }

  static * forceCheckIn (operator) {
    const latestCheck = yield RCCheckIn.findOne({
      operator: operator._id
    }).sort({ checkedAt: -1 });
    if (latestCheck && latestCheck.type === constants.RC_CHECK_IN_TYPE.签到) return;
    return yield RCCheckIn.create({
      user: operator.user,
      operator: operator._id,
      checkedAt: new Date(),
      type: constants.RC_CHECK_IN_TYPE.签到,
      isForceCheckIn: true
    });
  }

  static * kickOff (operator, wrongCount, missCount, wrongStock) {
    const latestCheck = yield RCCheckIn.findOne({
      operator: operator._id
    }).sort({ checkedAt: -1 });
    if (latestCheck && latestCheck.type === constants.RC_CHECK_IN_TYPE.签退) return;
    const now = new Date();
    const totalWorkTime = Math.ceil((now.getTime() - latestCheck.checkedAt.getTime()).msTo.minute);
    asyncTask(function * () {
      yield SSInspectInDayController.trigger({
        user: operator.user,
        checkInAt: latestCheck.checkedAt,
        checkOutAt: now,
        totalWorkTime: totalWorkTime,
        wrongCount,
        missCount,
        wrongStock
      });
    }, errorHandler);
    return yield RCCheckIn.create({
      user: operator.user,
      operator: operator._id,
      checkedAt: now,
      type: constants.RC_CHECK_IN_TYPE.签退,
      totalWorkTime,
      isKickedOff: true
    });
  }

  static * findLatestCheckByUser (user) {
    const checkIn = yield RCCheckIn.findOne({ user, type: constants.RC_CHECK_IN_TYPE.签到 }).sort({ checkedAt: -1 });
    const checkOut = yield RCCheckIn.findOne({ user, type: constants.RC_CHECK_IN_TYPE.签退 }).sort({ checkedAt: -1 });
    if (checkIn && checkOut && checkIn.checkedAt.is.over(checkOut.checkedAt)) {
      return { checkIn };
    } else return {
      checkIn,
      checkOut
    };
  }
}

RCCheckInController.Model = RCCheckIn;
module.exports = RCCheckInController;