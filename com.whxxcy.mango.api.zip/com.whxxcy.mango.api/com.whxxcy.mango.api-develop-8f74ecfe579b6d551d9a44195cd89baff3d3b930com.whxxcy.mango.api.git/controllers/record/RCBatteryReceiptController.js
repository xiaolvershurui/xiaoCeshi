const RCBatteryReceipt = require('../../models/record/rc_battery_receipt');
const Controller = require('../Controller');

class RCBatteryReceiptController extends Controller {

}

RCBatteryReceiptController.Model = RCBatteryReceipt;
module.exports = RCBatteryReceiptController;