const RCBatteryInStockPoint = require('../../models/record/rc_battery_in_stock_point');
const Controller = require('../Controller');

class RCBatteryInStockPointController extends Controller {

}

RCBatteryInStockPointController.Model = RCBatteryInStockPoint;
module.exports = RCBatteryInStockPointController;
