const RCHardFind = require('../../models/record/rc_hard_find.js');
const Controller = require('../Controller');

class RCHardFindController extends Controller {
}

RCHardFindController.Model = RCHardFind;
module.exports = RCHardFindController;
