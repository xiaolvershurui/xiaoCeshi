const RCNewLogin = require('../../models/record/rc_new_login');

const Controller = require('../Controller');

class RCNewLoginController extends Controller {

}

RCNewLoginController.Model = RCNewLogin;
module.exports = RCNewLoginController;
