const Controller = require('../Controller');
const RCOutFactory = require('../../models/record/rc_out_factory');
const BKStockController = require('../../controllers/ebike/BKStockController');
const constants = require('../../settings/constants');
const Error = require('errrr');

class RCOutFactoryController extends Controller {

  static * findByIdAndCheckExists (id) {
    const outFactoryRecord = yield RCOutFactoryController.Model.findById(id);
    if (!outFactoryRecord) throw new Error('不存在出库记录');
    return outFactoryRecord;
  }

  static * finish (id) {
    yield RCOutFactoryController.Model.findByIdAndUpdate(id, {
      $set: {
        isFinished: true,
        finishedAt: new Date(),
      },
    });
  }

  * outbound ({ number, outFactoryRecord }) {
    const { toRegion, operator } = outFactoryRecord;
    const stock = yield BKStockController.findByNumberOrLicense(number);
    try {
      if (stock.region !== '1802101223850') throw new Error('车辆不在成品大区');
      // yield new BKStockController(this.transaction).updateRegion(stock._id, toRegion, { operator });
      yield new BKStockController(this.transaction).updateLocate(stock._id, constants.BK_LOCATE.跨区运输中, {
        operator,
        opOutBound: {
          check: 1,
        },
      });
      yield BKStockController.Model.findByIdAndUpdate(stock._id, {
        $unset: {
          station: 1
        }
      });
      const data = {
        $unset: {
          [`failed.${number}`]: 1,
        },
        $addToSet: {
          success: number,
        },
      };
      const newRecord = yield RCOutFactory.findByIdAndUpdate(outFactoryRecord._id, data, { new: true });
      if (newRecord.success.length === newRecord.numbers.length) {
        yield this.constructor.finish(outFactoryRecord._id);
      }
    } catch (err) {
      yield RCOutFactory.findByIdAndUpdate(outFactoryRecord._id, {
        $set: {
          [`failed.${number}`]: err.message,
        },
      });
    }
  }
}

RCOutFactoryController.Model = RCOutFactory;
module.exports = RCOutFactoryController;
