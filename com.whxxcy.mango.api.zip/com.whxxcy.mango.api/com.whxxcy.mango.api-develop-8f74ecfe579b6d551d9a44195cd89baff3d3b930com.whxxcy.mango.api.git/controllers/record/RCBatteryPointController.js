const RCBatteryPoint = require('../../models/record/rc_battery_point');
const Controller = require('../Controller');

class RCBatteryPointController extends Controller {

}

RCBatteryPointController.Model = RCBatteryPoint;
module.exports = RCBatteryPointController;