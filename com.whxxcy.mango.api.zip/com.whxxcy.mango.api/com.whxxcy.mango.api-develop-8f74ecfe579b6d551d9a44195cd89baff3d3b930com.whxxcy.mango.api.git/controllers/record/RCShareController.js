const RCShare = require('../../models/record/rc_share');
const Controller = require('../Controller');
const ACCouponController = require('../../controllers/account/ACCouponController');
const ACCreditController = require('../../controllers/account/ACCreditController');
const constants = require('../../settings/constants');

class RCShareController extends Controller {
  * create ({ user, type, channel }) {
    if (user) {
      if (type === constants.RC_SHARE_TYPE.分享应用) {
        // 1天只能得到一次红包
        const record = yield RCShare.findOne({ user, type, sharedAt: { $lte: 'today'.ending, $gte: 'today'.beginning } });
        if (!record) {
          yield new ACCouponController(this.transaction).issueShareApp(user);
        }
      } else if (type === constants.RC_SHARE_TYPE.分享订单) {
        // 首次分享订单可以增加信用分
        const record = yield RCShare.findOne({ user, type });
        if (!record) {
          yield new ACCreditController(this.transaction).create(Object.assign({
            user
          }, constants.AC_CREDIT_RECORD_INFO.首次分享行程));
        }
        yield new ACCouponController(this.transaction).issueShareOrder(user);
      }
    }
    return yield this.T(RCShare).create({
      user,
      type,
      channel,
      sharedAt: new Date(),
    });
  }
}

RCShareController.Model = RCShare;
module.exports = RCShareController;