const RCOperatorCapture = require('../../models/record/rc_operator_capture');
const ACUserController = require('../account/ACUserController');
const Controller = require('../Controller');

class RCOperatorCaptureController extends Controller {
  static * create ({ user, regionIds, deviceInfo, appVersion, ip, lngLat, address, city, isAdmin, accuracy }) {
    const ACOperatorController = require('../account/ACOperatorController');
    yield ACOperatorController.updateLocation(user, { lngLat, address });
    return yield RCOperatorCapture.create({
      user,
      regions: regionIds,
      snappedAt: new Date(),
      deviceInfo,
      appVersion,
      ip,
      lngLat,
      address,
      city,
      isAdmin,
      accuracy
    });
  }

  static * findLatestAll (regionIds, isAdmin) {
    const query = {
      regions: { $in: regionIds },
    };
    if (!isAdmin) query.isAdmin = false;
    const users = yield RCOperatorCapture.find(query).distinct('user');
    return yield users.map(function * (user) {
      return {
        user: yield ACUserController.findByIdAndCheckExists(user),
        latestCapture: yield this.findLatestByUser(user)
      };
    }.bind(this));
  }

  static * findLatestByUser (user) {
    return yield RCOperatorCapture.findOne({
      user,
    }).sort({ snappedAt: -1 });
  }

  static * findLatestPathByUser (user, { startTime, endTime }) {
    const query = { user };
    if (startTime) {
      query.snappedAt = {};
      query.snappedAt.$gte = startTime;
    }
    if (endTime) {
      query.snappedAt = query.snappedAt || {};
      query.snappedAt.$lte = endTime;
    }
    return yield RCOperatorCapture.find(query).sort({ snappedAt: -1 });
  }
}

RCOperatorCaptureController.Model = RCOperatorCapture;
module.exports = RCOperatorCaptureController;