const RCBatteryOp = require('../../models/record/rc_battery_op');
const ACUserController = require('../account/ACUserController');
const BKStockController = require('../ebike/BKStockController');
const OPPolygonController = require('../operation/OPPolygonController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const dingRobot = require('../../services/dingRobot');

class RCBatteryOpController extends Controller {
  * createNew ({ id, station, region, QRCode, operator, fromStation, mark, underVoltage, fromAccount }) {
    yield this.T(RCBatteryOp).create({
      battery: id,
      region,
      QRCode,
      inStation: station._id,
      mark,
      description: `将${underVoltage ? '馈电' : '满电'}电池${QRCode}录入到${station.name}`,
      fromStation,
      fromAccount,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.创建电池,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
    });
  }

  static * createNew ({ id, station, region, QRCode, mark, operator, fromStation, underVoltage, fromAccount }) {
    yield RCBatteryOp.create({
      battery: id,
      region,
      QRCode,
      inStation: station._id,
      description: `将${underVoltage ? '馈电' : '满电'}电池${QRCode}录入到${station.name}`,
      fromStation,
      fromAccount,
      mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.创建电池,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
    });
  }

  * updateQRCode ({ battery, QRCode, operator }) {
    yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      mark: battery.mark,
      inStation: battery.station,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.更换二维码,
      description: `将二维码${battery.QRCode}更换为${QRCode}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateQRCode: {
        prev: battery.QRCode,
        next: QRCode,
      },
    });
  }

  * opUpdateCharge ({ battery, QRCode, operator, charge }) {
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      inStation: battery.station,
      type: charge ? constants.RC_BATTERY_OP_RECORD_TYPE.开始充电 : constants.RC_BATTERY_OP_RECORD_TYPE.结束充电,
      description: `对${QRCode}进行${charge ? '开始充电' : '结束充电'}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
    });
  }

  * opInbound ({ battery, QRCode, operator, station, underVoltage, fromStation, fromAccount }) {
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.接收电池到站,
      inStation: station._id,
      description: `将${underVoltage ? '馈电' : '满电'}电池${QRCode}接收到${station.name}`,
      fromStation,
      fromAccount,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateLocate: {
        prev: battery.locate,
        next: constants.BK_BATTERY_LOCATE.在运营站,
      },
    });
  }

  * opOutBoundToStation ({
    battery,
    QRCode,
    operator,
    toStation,
    inStation,
  }) {
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.分配电池到站,
      inStation: inStation._id,
      description: `将${QRCode}电池由${inStation.name}发至${toStation.name}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateStation: {
        prev: {
          id: inStation._id,
          name: inStation.name,
        },
        next: {
          id: toStation._id,
          name: toStation.name,
        },
      },
    });
  }

  * opOutBoundToOperator ({
    battery,
    QRCode,
    operator,
    toAccount,
    inStation,
  }) {
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.分发电池到巡检,
      inStation: inStation._id,
      description: `将${QRCode}电池分发给${toAccount.cert.name}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateLocate: {
        prev: battery.locate,
        next: constants.BK_BATTERY_LOCATE.巡检人员携带,
      },
    });
  }

  * opDamage ({ battery, QRCode, operator, station }) {
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      QRCode,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池报损,
      description: `将${QRCode}电池报损`,
      inStation: station,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateState: {
        prev: battery.state,
        next: constants.BK_BATTERY_STATE.损坏,
      },
    });
  }

  * change ({ battery, oldBattery, stock, operator, description }) {
    if (oldBattery) {
      yield this.T(RCBatteryOp).create({
        battery: oldBattery._id,
        region: battery.region,
        QRCode: oldBattery.QRCode,
        mark: oldBattery.mark,
        stock: stock._id,
        type: constants.RC_BATTERY_OP_RECORD_TYPE.电池更换下车,
        description: `将${oldBattery.QRCode}更换下车`,
        operator: operator.user._id,
        operatorName: operator.user.cert.name,
        operatedAt: new Date(),
        updateLocate: {
          prev: constants.BK_BATTERY_LOCATE.安装于车辆,
          next: constants.BK_BATTERY_LOCATE.巡检人员携带,
        },
      });
    }
    return yield this.T(RCBatteryOp).create({
      battery: battery._id,
      region: battery.region,
      stock: stock._id,
      QRCode: battery.QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池更换到车,
      description: description || `将${battery.QRCode}更换到车${stock.number.custom}上`,
      operator: operator.user._id,
      operatorName: operator.user.cert.name,
      operatedAt: new Date(),
      updateLocate: {
        prev: constants.BK_BATTERY_LOCATE.巡检人员携带,
        next: constants.BK_BATTERY_LOCATE.安装于车辆,
      },
    });
  }

  * bindMark ({ id, region, QRCode, mark, operator }) {
    yield this.T(RCBatteryOp).create({
      battery: id,
      region,
      QRCode,
      mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.更换标记,
      description: `将${QRCode}更新标记为${mark}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
    });
  }

  * bindQRCode ({ id, region, QRCode, mark, operator }) {
    yield this.T(RCBatteryOp).create({
      battery: id,
      region,
      QRCode,
      mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.更换二维码,
      description: `将${mark}二维码更新为${QRCode}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
    });
  }

  static * unbind ({ battery, operator, stock }) {
    yield this.Model.create({
      stock,
      battery: battery.id,
      region: battery.region,
      QRCode: battery.QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.解绑电池,
      description: `将${battery.QRCode}从车上解绑`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateLocate: {
        prev: constants.BK_BATTERY_LOCATE.安装于车辆,
        next: constants.BK_BATTERY_LOCATE.巡检人员携带,
      },
    });
  }

  * createLost ({ operator, battery, stock, location, address, batteryImages, remark }) {
    yield this.T(RCBatteryOp).create({
      battery: battery.id,
      region: battery.region,
      QRCode: battery.QRCode,
      mark: battery.mark,
      stock: stock._id,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池丢失,
      description: `${stock.number.custom}车辆电池报失`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      location,
      address,
      batteryImages,
      remark,
      updateLocate: {
        prev: constants.BK_BATTERY_LOCATE.安装于车辆,
        next: constants.BK_BATTERY_LOCATE.丢失,
      },
    });
  }

  static * confirm ({ battery, stock, operator, description }) {
    return yield RCBatteryOpController.Model.create({
      battery: battery._id,
      region: battery.region,
      stock: stock._id,
      QRCode: battery.QRCode,
      mark: battery.mark,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池更换到车,
      description: description || `将${battery.QRCode}更换到车${stock.number.custom}上`,
      operator: operator.user._id,
      operatorName: operator.user.cert.name,
      operatedAt: new Date(),
      updateLocate: {
        prev: constants.BK_BATTERY_LOCATE.巡检人员携带,
        next: constants.BK_BATTERY_LOCATE.安装于车辆,
      },
    });
  }

  static * updateRegion ({ battery, stock, operator, operatorName, nextRegion, description }) {
    return yield RCBatteryOpController.Model.create({
      battery: battery._id,
      region: battery.region,
      stock: stock._id,
      QRCode: battery.QRCode,
      mark: battery.mark,
      inStation: battery.station,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.更换大区,
      description: description || `将电池从${battery.region}更换到${nextRegion}`,
      operator,
      operatorName,
      operatedAt: new Date(),
      updateRegion: {
        prev: battery.region,
        next: nextRegion,
      },
    });
  }

  static * updateStation ({ battery, stock, operator, nextStation, description }) {
    return yield RCBatteryOpController.Model.create({
      battery: battery._id,
      region: battery.region,
      stock: stock._id,
      QRCode: battery.QRCode,
      mark: battery.mark,
      inStation: battery.station,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.更换仓库,
      description: description || `将电池从${battery.station}更换到${nextStation}`,
      operator: operator._id,
      operatorName: operator.cert.name,
      operatedAt: new Date(),
      updateStation: {
        prev: {
          id: battery.station
        },
        next: {
          id: nextStation
        },
      },
    });
  }
}

RCBatteryOpController.Model = RCBatteryOp;
module.exports = RCBatteryOpController;
