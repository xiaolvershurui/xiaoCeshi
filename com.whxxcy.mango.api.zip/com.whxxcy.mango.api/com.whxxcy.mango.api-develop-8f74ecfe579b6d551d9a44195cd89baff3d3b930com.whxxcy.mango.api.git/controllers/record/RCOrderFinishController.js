const RCOrderFinish = require('../../models/record/rc_order_finish');
const ODOrderController = require('../../controllers/order/ODOrderController');
const ACUserController = require('../../controllers/account/ACUserController');
const Controller = require('../Controller');

class RCOrderFinishController extends Controller {

  static * findAndGenerator ({ order, error, clickType, opAt, succeed, lockSuccess, orderFinished, polygon }) {
    opAt = new Date(opAt);
    const record = yield this.Model.findOne({ order });
    if (!record) {
      const odOrder = yield ODOrderController.Model.findById(order).populate({
        path: 'user',
        model: ACUserController.Model,
        select: 'auth.tel'
      }).select('user');
      yield this.Model.create({
        order,
        user: odOrder.user._id,
        tel: odOrder.user.auth.tel,
        feedback: [{
          error,
          clickType,
          opAt,
          succeed,
          lockSuccess,
          orderFinished,
          polygon
        }]
      })
    } else {
      yield this.Model.findByIdAndUpdate(record._id, {
        $push: {
          feedback: {
            error,
            clickType,
            opAt,
            succeed,
            lockSuccess,
            orderFinished,
            polygon
          }
        }
      })
    }
  }

}

RCOrderFinishController.Model = RCOrderFinish;
module.exports = RCOrderFinishController;