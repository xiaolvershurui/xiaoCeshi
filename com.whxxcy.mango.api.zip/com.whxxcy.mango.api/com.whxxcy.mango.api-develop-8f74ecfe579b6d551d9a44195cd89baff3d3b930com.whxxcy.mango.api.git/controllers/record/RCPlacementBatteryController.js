const RCPlacementBattery = require('../../models/record/rc_placement_battery');
const Controller = require('../Controller');

class RCPlacementBatteryController extends Controller {

}

RCPlacementBatteryController.Model = RCPlacementBattery;
module.exports = RCPlacementBatteryController;
