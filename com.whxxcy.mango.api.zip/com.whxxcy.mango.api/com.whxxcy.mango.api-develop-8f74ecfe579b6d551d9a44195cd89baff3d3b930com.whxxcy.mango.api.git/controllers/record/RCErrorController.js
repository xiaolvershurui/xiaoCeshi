const RCError = require('../../models/record/rc_error');
const ACUserController = require('../../controllers/account/ACUserController');
const BKStockController = require('../../controllers/ebike/BKStockController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class RCErrorController extends Controller {
  static * create ({ user, errorInfo, errorType, errorDescription, lngLat, address, accuracy, deviceInfo, city, appVersion }) {
    const userData = yield ACUserController.Model.findById(user);
    return yield RCError.create({
      user,
      userName: userData && userData.cert && userData.cert.name,
      userTel: userData && userData.auth.tel,
      errorInfo,
      errorType,
      errorDescription,
      lngLat,
      address,
      accuracy,
      deviceInfo,
      city,
      appVersion,
    });
  }
}

RCErrorController.Model = RCError;
module.exports = RCErrorController;
