const RCParkingLotPointAmendment = require('../../models/record/rc_parkingLot_point_amendment');
const ODOrderController = require('../order/ODOrderController');
const BKStockController = require('../ebike/BKStockController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Core = require('../../services/shark/core');
const OTSParkingLotPointAmendment = require('../../services/ots/RCParkingLotPointAmendment');
const moment = require('moment');

class RCParkingLotPointAmendmentController extends Controller {

  static * trigger ({ user, opType = constants.RC_PARKINGLOT_POINT_TYPE.刷新位置, userLocation }) {
    const order = yield ODOrderController.Model.findOne({
      user,
      state: constants.OD_ORDER_STATE.租用中,
    }).populate({
      path: 'stock',
      model: BKStockController.Model,
      select: 'location.lngLat',
    }).select('stock region route.end.parkingLot');
    if (!order) return;
    const now = Date.now();
    try {
      OTSParkingLotPointAmendment.create({
        region_date: `${order.region}_${moment(now).format('YYYYMM')}`,
        time: now,
        region: order.region,
        order: order._id,
        opType,
        stock: {
          id: order.stock._id,
          lngLat: order.stock.location.lngLat,
        },
        user: {
          id: user,
          lngLat: userLocation,
        },
        inParkingLot: !!order.route.end.parkingLot,
      });
    } catch (error) {
      //
    }
  }
}

RCParkingLotPointAmendmentController.Model = RCParkingLotPointAmendment;
module.exports = RCParkingLotPointAmendmentController;
