const RCStockOp = require('../../models/record/rc_stock_op');
const ACUserController = require('../account/ACUserController');
const OPPolygonController = require('../operation/OPPolygonController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const dingRobot = require('../../services/dingRobot');

class RCStockOpController extends Controller {
  static * create ({
    stock, type, description, releasedTasks, addedTasks, prevTaskList,
    operator, operateLocation, operateRemark, extra = {}
  }) {
    const user = yield ACUserController.Model.findById(operator);
    const BKStockController = require('../ebike/BKStockController');
    const stockData = yield BKStockController.findByIdAndCheckExists(stock);
    let inspector;
    if (stockData.inspector) {
      inspector = yield ACUserController.Model.findById(stockData.inspector);
    }
    let inspectionArea;
    if (stockData.location && stockData.location.intersectInspectionArea) {
      inspectionArea = yield OPPolygonController.Model.findById(stockData.location.intersectInspectionArea);
    }

    const baseInfo = {
      stock,
      stockNo: stockData.number && stockData.number.custom,
      stockLocation: stockData.location,
      region: stockData.region,
      style: stockData.style,
      locate: stockData.locate,
      accOn: stockData.accOn,
      lockOn: stockData.lockOn,
      voltage: stockData.battery.voltage,
      batteryLockOn: stockData.batteryLockOn,
      type,
      description,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operatedAt: new Date(),
      operatorName: user && user.cert.name,
      operatorTel: user && user.auth.tel,
      operatorAvator: (user && user.profile.avator) || constants.AC_DEFAULT_AVATOR,
      inspector: inspector && inspector._id,
      inspectorName: inspector && inspector.cert.name,
      inspectorTel: inspector && inspector.auth.tel,
      inspectorAvator: (inspector && inspector.profile.avator) || constants.AC_DEFAULT_AVATOR,
      inspectionArea: inspectionArea && inspectionArea._id,
      inspectionAreaName: inspectionArea && inspectionArea.name,
      operateLocation,
      operateRemark,
    };

    dingRobot.stockOp(`${baseInfo.operatorName ? `${baseInfo.operatorName}[${baseInfo.operatorTel}]` : '系统'}：${baseInfo.description}。车牌号为[${baseInfo.stockNo}]，当前分配巡检人员为[${baseInfo.inspectorName || '无'}]`);

    return yield RCStockOp.create(Object.assign(baseInfo, extra));
  }

  static * opCreateStock ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.创建车辆,
      description: '创建了车辆',
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation
    });
  }

  static * opUpdateCustomNumber ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = '',
    next = ''
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更新定制车牌号,
      description: `将二维码车牌号更新为[${next}]，更新前为[${prev}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateCustomNumber: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateTempNumber ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = '',
    next = ''
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更新临时车牌号,
      description: `将临时车牌号更新为[${next}]，更新前为[${prev}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateTempNumber: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateLicenseNumber ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = '',
    next = ''
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更新交管局车牌号,
      description: `将交管局车牌号更新为[${next}]，更新前为[${prev}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateLicenseNumber: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateVin ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = '',
    next = ''
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更新车架号,
      description: `将车架号更新为[${next}]，更新前为[${prev}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateVin: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateRegion ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = {},
    next = {}
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更换大区,
      description: `将大区更换为[${next.name || ''}]，更换前为[${prev.name || ''}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateRegion: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateStyle ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = {},
    next = {}
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更换车型,
      description: `将车型更换为[${next.name || ''}]，更换前为[${prev.name || ''}]`,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      extra: {
        updateStyle: {
          prev,
          next
        }
      }
    });
  }

  static * opUpdateBox ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList }, {
    prev = '',
    next = '',
    reason = ''
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.更换盒子,
      description: `将盒子更换为[${next}]，更换前为[${prev}]`,
      operateLocation,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      extra: {
        updateBox: {
          prev,
          next,
          reason
        }
      }
    });
  }

  static * opEnable ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.启用车辆,
      description: '将车辆启用',
    });
  }

  static * opDisable ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.禁用车辆,
      description: '将车辆禁用'
    });
  }

  static * opAddDamage ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    damage,
    prevStockState,
    nextStockState
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.添加损坏,
      description: `添加了损坏记录：${damage.description}；该损坏${damage.stockState === constants.BK_STATE.损坏可租 ? '不' : ''}影响租赁`,
      extra: {
        addDamage: {
          id: damage._id,
          description: damage.description,
          photo: damage.photo,
          prevStockState,
          nextStockState
        }
      }
    });
  }

  static * opRepairDamage ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    damage,
    prevStockState,
    nextStockState
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.修复损坏,
      description: `修复了损坏记录：${damage.description}；修复说明：${damage.repairRemark}`,
      extra: {
        repairDamage: {
          id: damage._id,
          description: damage.description,
          photo: damage.photo,
          repairPhoto: damage.repairPhoto,
          repairRemark: damage.repairRemark,
          prevStockState,
          nextStockState
        }
      }
    });
  }

  static * opPutOn ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark, station }, {
    storehouse,
    putOnLocation = {},
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operateLocation,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.投放车辆,
      description: `将车辆从[${station ? station.name : '未知'}]仓库投放到了[${putOnLocation.address || '未知地点'}]`,
      extra: {
        putOn: {
          storehouse,
          putOnLocation,
          prevLocate,
          nextLocate,
        }
      }
    });
  }

  static * opRecover ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark, station }, {
    recoverLocation = {},
    storehouse,
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.回收车辆,
      description: `将车辆从[${recoverLocation.address || '未知地点'}]回收到了[${station ? station.name : '未知'}]仓库`,
      extra: {
        recover: {
          recoverLocation,
          storehouse,
          prevLocate,
          nextLocate,
        }
      }
    });
  }

  static * opReservation ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    user = {},
    userLocation = {},
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.预约车辆,
      description: `预约车辆；用户位置[${userLocation.address || '未知地点'}]`,
      extra: {
        reservation: {
          user,
          userLocation,
          prevLocate,
          nextLocate,
        }
      }
    });
  }

  static * opCancelReservation ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    user = {},
    userLocation = {},
    succeed,
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.取消预约,
      description: `${succeed ? '成功预约' : '取消预约'}；用户位置[${userLocation.address || '未知地点'}]`,
      extra: {
        cancelReservation: {
          succeed,
          user,
          userLocation,
          prevLocate,
          nextLocate,
        }
      }
    });
  }

  static * opRent ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    order,
    user = {},
    location = {},
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.租用车辆,
      description: `租用车辆；车辆位置[${location.address || '未知地点'}]`,
      extra: {
        rent: {
          order,
          user,
          location,
          nextLocate,
          prevLocate
        }
      }
    });
  }

  static * opReturnBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark }, {
    order,
    user = {},
    location = {},
    orderState,
    totalAmount = 0,
    duration = 0,
    distance = 0,
    outsideRegion,
    insideProhibitedArea,
    insideForbiddenArea,
    insidePark,
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.归还车辆,
      description: `归还车辆；车辆位置[${location.address || '未知地点'}]。共使用${duration}分钟，行驶${distance}米，消费${totalAmount.toCNY()}`,
      extra: {
        returnBack: {
          order,
          user,
          location,
          orderState,
          totalAmount,
          duration,
          distance,
          outsideRegion,
          insideProhibitedArea,
          insideForbiddenArea,
          insidePark,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opSetLost ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.登记丢失,
      description: `登记丢失；丢失地点[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        setLost: {
          location,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opFindBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    photo,
    prevLocate,
    nextLocate
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.丢失找回,
      description: `找回车辆；找回地点[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        findBack: {
          location,
          photo,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opSetSuspectedLost ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.登记疑似丢失,
      description: `登记疑似丢失；丢失地点[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        setSuspectedLost: {
          location,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opSuspectedLostFindBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    photo,
    prevLocate,
    nextLocate
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.疑似丢失找回,
      description: `找回疑似丢失车辆；找回地点[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        suspectedLostFindBack: {
          location,
          photo,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opApplyReturnBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    photo,
    prevLocate,
    nextLocate
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.申请拖回,
      description: `申请拖回；车辆位置[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        returnBack: {
          location,
          photo,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opCancelReturnBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.取消拖回,
      description: `取消拖回申请；${operateRemark}`,
      extra: {
        cancelReturnBack: {
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opDetained ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    photo,
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.被扣上报,
      description: `上报车辆被扣；被扣押位置[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        detained: {
          location,
          photo,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opDetainedFindBack ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    photo,
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.被扣找回,
      description: `找回被扣车辆；找回地点[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        detainedFindBack: {
          location,
          photo,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opStartDispatch ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '', station, region }, {
    location = {},
    storehouse,
    prevLocate,
    nextLocate,
  }) {
    // TODO: 查询storehouse数据
    return yield this.create({
      region,
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.开始调度,
      description: `开始调度车辆；开始调度位置[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        startDispatch: {
          location,
          storehouse,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opFinishDispatch ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    location = {},
    storehouse,
    prevLocate,
    nextLocate,
  }) {
    // TODO: 查询storehouse数据
    // 查询最近一次开始调度记录
    const startOp = yield RCStockOp.findOne({
      stock,
      type: constants.RC_STOCK_OP_TYPE.开始调度
    }).sort({ _id: -1 });
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.结束调度,
      description: `结束调度车辆；结束调度位置[${location.address || '未知地点'}]；${operateRemark}`,
      extra: {
        finishDispatch: {
          startLocation: startOp && startOp.startDispatch.location,
          startStorehouse: startOp && startOp.startDispatch.storehouse,
          location,
          storehouse,
          prevPrevLocate: startOp && startOp.startDispatch.prevLocate,
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opOtherOccupancy ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.其他占用,
      description: `设为其他占用，占用原因：${operateRemark}`,
      extra: {
        otherOccupancy: {
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opReleaseOccupancy ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    prevLocate,
    nextLocate,
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.取消占用,
      description: `取消占用`,
      extra: {
        releaseOccupancy: {
          prevLocate,
          nextLocate
        }
      }
    });
  }

  static * opFindStock ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    hasFind,
    photo,
    failedReason,
    locate
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.找车打卡,
      description: `进行了巡检，${hasFind ? '找到了车辆' : `但未找到车辆，${constants.RC_STOCK_OP_FIND_FAILED_REASON_MAP[failedReason]}`}；${operateRemark}`,
      extra: {
        findStock: {
          hasFind,
          photo,
          failedReason,
          locate
        }
      }
    });
  }

  static * opExchangeBattery ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    prev = {},
    next = {}
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.更换电池,
      description: `更换电池；电量变化：[${parseInt(prev.power * 100)}%]=>[${parseInt(next.power * 100)}%]`,
      extra: {
        exchangeBattery: {
          prev,
          next
        }
      }
    });
  }

  static * opForceUpdate ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    isGpsLocation,
    location = {}
  }) {
    // return yield this.create({
    //   stock,
    //   operator,
    //   operateLocation,
    //   operateRemark,
    //   type: constants.RC_STOCK_OP_TYPE.强制刷新位置,
    //   description: `强制刷新位置；${isGpsLocation ? `获取到卫星定位，定位地址为[${location.address || '未知地点'}]` : `未获取到卫星定位，基站定位地址为[${location.address || '未知地点'}]`}`,
    //   extra: {
    //     forceUpdate: {
    //       isGpsLocation,
    //       location
    //     }
    //   }
    // });
  }

  static * opAccOn ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.打开电门,
      description: '打开电门成功',
    });
  }

  static * opAccOff ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.关闭电门,
      description: '关闭电门成功',
    });
  }

  static * opLockOn ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.设防,
      description: '设防成功',
    });
  }

  static * opLockOff ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.撤防,
      description: '撤防成功',
    });
  }

  static * opUnlockBattery ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.打开电池锁,
      description: '打开电池锁',
    });
  }

  static * opReleasePowerUnlink ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.解除断电,
      description: '解除断电',
    });
  }

  static * opDistributeInspector ({ stock, operator, operateLocation, prevTaskList, operateRemark = '' }, {
    inspector,
    inspectorName,
    inspectorTel,
  }) {
    return yield this.create({
      stock,
      operator,
      operateLocation,
      operateRemark,
      prevTaskList,
      type: constants.RC_STOCK_OP_TYPE.分配巡检人员,
      description: `分配巡检人员 ${inspectorName}[${inspectorTel}]`,
      extra: {
        distributeInspector: {
          inspector,
          inspectorTel,
          inspectorName
        }
      }
    });
  }

  static * opReleaseInspector ({ stock, operator, operatorLocation, prevTaskList, operatorRemark }, {
    inspector,
    inspectorName,
    inspectorTel,
  }) {
    return yield this.create({
      stock,
      operator,
      operatorLocation,
      operatorRemark,
      prevTaskList,
      type: constants.RC_STOCK_OP_TYPE.解除巡检人员,
      description: `解除巡检人员 ${inspectorName}[${inspectorTel}]`,
      extra: {
        releaseInspector: {
          inspector,
          inspectorName,
          inspectorTel,
        }
      }
    });
  }

  static * opIntoInspectionArea ({ stock }, {
    inspectionArea,
    inspectionAreaName
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.驶入巡检区,
      description: `驶入巡检区[${inspectionAreaName}]`,
      extra: {
        intoInspectionArea: {
          inspectionAreaName,
          inspectionArea
        }
      }
    });
  }

  static * opOutInspectionArea ({ stock }, {
    inspectionArea,
    inspectionAreaName
  }) {
    return yield this.create({
      stock,
      type: constants.RC_STOCK_OP_TYPE.驶出巡检区,
      description: `驶出巡检区[${inspectionAreaName}]`,
      extra: {
        outInspectionArea: {
          inspectionArea,
          inspectionAreaName
        }
      }
    });
  }

  static * opAddSpecialTask ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    taskId,
    remark,
    photo,
    location,
    time
  }) {
    return yield this.create({
      stock,
      operator,
      operateLocation,
      operateRemark,
      releasedTasks,
      addedTasks,
      prevTaskList,
      type: constants.RC_STOCK_OP_TYPE.添加特别任务,
      description: `添加特别任务；${remark}`,
      extra: {
        addSpecialTask: {
          time,
          taskId,
          remark,
          photo,
          location
        }
      }
    });
  }

  static * opRemoveSpecialTask ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    taskId,
    remark,
    photo,
    location,
    time
  }) {
    // 查询添加特别任务记录
    const op = yield RCStockOp.findOne({
      stock,
      type: constants.RC_STOCK_OP_TYPE.添加特别任务,
      'addSpecialTask.taskId': taskId
    });
    const task = op && op.addSpecialTask;
    if (!task) return;
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateLocation,
      operateRemark,
      type: constants.RC_STOCK_OP_TYPE.完成特别任务,
      description: `完成特别任务；${task && task.remark}；备注：${operateRemark}`,
      extra: {
        removeSpecialTask: {
          taskId,
          time: task.time,
          remark: task.description,
          photo: task.photo,
          location: task.location,
          finishRemark: remark,
          finishPhoto: photo,
          finishLocation: location,
          finishTime: time,
        }
      }
    });
  }

  static * opReleaseRevivalTask ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    photo
  }) {
    return yield this.create({
      stock,
      operator,
      releasedTasks,
      addedTasks,
      prevTaskList,
      operateRemark,
      operateLocation,
      type: constants.RC_STOCK_OP_TYPE.解除复活任务,
      description: `解除了复活任务；${operateRemark}`,
      extra: {
        releaseRevival: {
          photo
        }
      }
    });
  }

  static * opAdjustLocation ({ stock, operator, operateLocation, releasedTasks, addedTasks, prevTaskList, operateRemark = '' }, {
    prev = {},
    next = {},
  }) {
    return yield this.create({
      stock,
      operator,
      operateLocation,
      operateRemark,
      addedTasks,
      releasedTasks,
      prevTaskList,
      type: constants.RC_STOCK_OP_TYPE.调整定位,
      description: `调整了定位到：${next.address || '未知地点'}`,
      extra: {
        prev,
        next
      }
    });
  }

  static * opChangeStation ({ stock, station, operator }) {
    return yield this.create({
      stock: stock._id,
      operator,
      type: constants.RC_STOCK_OP_TYPE.仓库转移,
      description: `从仓库${stock.station && stock.station.name}强制变更为${station.name}`
    })
  }

  static * opInBound ({ stock, operator, station, releasedTasks, addedTasks, prevTaskList }, { prevStation, nextStation, prevLocate, nextLocate }) {
    const startOp = yield RCStockOp.findOne({
      stock,
      type: constants.RC_STOCK_OP_TYPE.开始调度
    }).sort({ _id: -1 });
    return yield this.create({
      stock: stock,
      operator,
      type: constants.RC_STOCK_OP_TYPE.入库,
      description: `入库到${station && station.name}`,
      releasedTasks,
      addedTasks,
      prevTaskList,
      extra: {
        inBound: {
          prevPrevLocate: startOp && startOp.startDispatch.prevLocate,
          prevLocate,
          nextLocate,
          prevStation,
          nextStation,
        }
      }
    })
  }

  static * opOutBound ({ stock, operator, station }, { prevStation, nextStation, prevLocate, nextLocate }) {
    return yield this.create({
      stock: stock,
      operator,
      type: constants.RC_STOCK_OP_TYPE.出库,
      description: `从${(station && station.name) || "未知仓库"}出库`,
      extra: {
        outBound: {
          prevLocate,
          nextLocate,
          prevStation,
          nextStation
        }
      }
    })
  }

  static * opBindVin ({ stock, operator }, { vin }) {
    return yield this.create({
      stock: stock,
      operator,
      type: constants.RC_STOCK_OP_TYPE.更新车架号,
      description: `将车架号从[${stock.number.vin}]更新为[${vin}]`,
      extra: {
        updateVin: {
          prev: `${stock.number.vin}`,
          next: vin
        }
      }
    })
  }
}

RCStockOpController.Model = RCStockOp;
module.exports = RCStockOpController;
