const Controller = require('../Controller');
const RCStockCheck = require('../../models/record/rc_stock_check');

class RCStockCheckController extends Controller {
}

RCStockCheckController.Model = RCStockCheck;
module.exports = RCStockCheckController;