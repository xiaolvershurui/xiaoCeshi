const RCDivideSolution = require('../../models/record/rc_divide_solution.js');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

/*eslint-disable*/
// 分成方案
// solution 1 2017年6月开始	10000台
//  period 1.1 自每台车投放之日起的36个月，新日为全部收入的25%
// solution 2 2018年3月开始，具体以投放时间为准 10000台
//  period 2.1 自每台车投放之日起 每天25% 每月至少0.0833  100%后不再分成
//  period 2.2 自每台车投放之日起第13个月-24个月, 新日为全部收入的25%；当新日收入达到成本的80%时，当期不再分成
// solution 3 2018年4月开始,具体以投放时间为准 50000台
//  period 3.1 自每台车投放之日起 12个月，每天25% 每月至少 0.0694 100%后不再分成
//  period 3.2 自每台车投放之日起第13个月-24个月，新日为全部收入的25%；当新日收入达到成本的80%时，当期不再分成
/*eslint-enable*/

class RCDivideSolutionController extends Controller {

  static calculate(stock, date, amount, record, handleAmount) {
    const time = parseInt(Date.now() - new Date(stock.putOnAt).getTime()) / (24 * 3600 * 1000);
    const yearTime = 365;
    const data = {
      stock: stock._id,
      date,
      solution: stock.solution,
      isCapping: false,
      rentAmount: 0,
      rentAmountInPeriodTwo: 0,
      totalAmount: amount,
    };
    if (stock.solution === 1) {
      // 方案一
      data.rentAmount = handleAmount * 0.25;
      data.period = 1;
    } else if ([2, 3].includes(stock.solution)) {
      // 方案二
      // 投放至今时间
      const xinriAmount = handleAmount * 0.25;
      if (time < yearTime) {
        data.rentAmount = stock.solution === 2 ? stock.cost / 365 / 2 : stock.cost / 365 / 2 * 0.833;
        data.period = 1;
        data.isFloor = true;
      } else if (time >= yearTime && time < 2 * yearTime) {
        data.period = 2;
        // 已经封顶
        if (record.isCapping) {
          data.rentAmount = 0;
          data.isFloor = false;
        } else {
          // 未封顶
          data.isFloor = true;
          const cappingAmount = stock.cost * 0.8 / 2;
          // 最后一次可能超过封顶
          if (record.rentAmountInPeriodTwo + xinriAmount >= cappingAmount) {
            data.rentAmount = cappingAmount - record.rentAmountInPeriodTwo;
            data.isCapping = true;
            data.rentAmountInPeriodTwo = cappingAmount;
          } else {
            data.rentAmount = xinriAmount;
            data.isCapping = false;
            data.rentAmountInPeriodTwo = record.rentAmountInPeriodTwo + xinriAmount;
          }
        }
      } else if (time >= 3 * yearTime) {
        data.rentAmount = xinriAmount;
        data.period = 3;
        data.isCapping = true;
      }
    }
    return data;
  }

  *findAndGenerate({ stock, amount, date = 'today'.beginning, handleAmount }) {
    if (!handleAmount) handleAmount = amount;
    if (stock.solution && stock.putOnAt) {
      const record = yield RCDivideSolution.findOne({ stock: stock._id, date }).sort({ _id: -1 });
      // 已经存在记录
      if (record) {
        // 已存在记录 重新计算一次 更新
        const data = RCDivideSolutionController.calculate(stock, date, amount, record, handleAmount);
        yield this.T(RCDivideSolution).findByIdAndUpdate(record._id, {
          $set: {
            isCapping: data.isCapping,
            rentAmountInPeriodTwo: data.rentAmountInPeriodTwo,
          },
          $inc: {
            totalAmount: Math.round(data.totalAmount),
            rentAmount: ([2, 3].includes(record.solution) && record.period === 1 && record.rentAmount !== 0) ? 0 : Math.round(data.rentAmount),
          },
        });
      } else {
        // 计算 创建一条新记录
        const data = RCDivideSolutionController.calculate(stock, date, amount, {
          rentAmountInPeriodTwo: 0,
          isCapping: false,
        }, handleAmount);
        data.rentAmount = Math.round(data.rentAmount);
        data.region = stock.region;
        yield this.T(RCDivideSolution).create(data);
      }
    }
  }

}

RCDivideSolutionController.Model = RCDivideSolution;
module.exports = RCDivideSolutionController;
