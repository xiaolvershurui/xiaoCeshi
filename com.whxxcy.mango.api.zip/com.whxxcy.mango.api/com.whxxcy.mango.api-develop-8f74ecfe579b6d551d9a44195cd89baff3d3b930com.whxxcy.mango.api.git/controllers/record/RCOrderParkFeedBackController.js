const RCOrderParkFeedBack = require('../../models/record/rc_order_park_feedback');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class RCOrderParkFeedBackController extends Controller {


}

RCOrderParkFeedBackController.Model = RCOrderParkFeedBack;
module.exports = RCOrderParkFeedBackController;
