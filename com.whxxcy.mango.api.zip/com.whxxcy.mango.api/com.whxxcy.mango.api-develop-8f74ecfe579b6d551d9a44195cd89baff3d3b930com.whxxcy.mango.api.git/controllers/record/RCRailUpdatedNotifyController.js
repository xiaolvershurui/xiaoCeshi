const RCRailUpdatedNotify = require('../../models/record/rc_rail_updated_notify');
const Controller = require('../Controller');
const ODOrderController = require('../order/ODOrderController');
const RCMessageSystemController = require('./RCMessageSystemController');

class RCRailUpdatedNotifyController extends Controller {

  // 通知所有用户
  static *notifyAllUsers({ title, content, expiredAt, inscribeDate, isNotifyAllUsers }) {
    const notifyAllMessage = {
      notifyAllUsers: {
        title, content, expiredAt, inscribeDate,
      },
      isNotifyAllUsers,
    };
    const result = yield RCRailUpdatedNotifyController.Model.create(notifyAllMessage);
    RCMessageSystemController.railUpdateNotify({ id: result._id, isNotifyAllUsers, expiredAt }).catch(error => {
      //
    });
  }

  // 通知部分用户
  static *notifyPartUsers({ title, content, grids, region, expiredAt, inscribeDate, isNotifyAllUsers }) {
    const oneWeekTime = '7 days'.before('today'.beginning);
    const oneMonthTime = '30 days'.before('today'.beginning);
    // 7天用户
    const oneWeekUsers = yield ODOrderController.Model.aggregate([
      {
        $match: {
          region: region,
          finishedAt: { $gt: oneWeekTime },
          grids: { $in: grids },
        },
      },
      {
        $project: {
          user: 1,
        },
      },
      {
        $group: {
          _id: '$user',
          user: { $push: '$user' },
        },
      },
    ]).read('secondary');

    // 30天用户
    const oneMonthUsers = yield ODOrderController.Model.aggregate([
      {
        $match: {
          region: region,
          finishedAt: { $gt: oneMonthTime },
          grids: { $in: grids },
        },
      },
      {
        $project: {
          user: 1,
        },
      },
      {
        $group: {
          _id: '$user',
          user: { $push: '$user' },
          count: { $sum: 1 },
        },
      },
    ]).match({
      count: { $gte: 2 },
    }).read('secondary');

    const usersUnique = new Set([]);
    const allUsers = [];
    let result = null;
    // 用户进行去重
    // 添加7天用户
    for (let item of oneWeekUsers) {
      usersUnique.add(item._id);
    }
    // 添加30天用户
    for (let item of oneMonthUsers) {
      usersUnique.add(item._id);
    }
    for (let item of usersUnique) {
      const userTemp = {
        notifyPartUsers: {
          title,
          content,
          expiredAt,
          inscribeDate,
          read: false,
          user: item,
        },
        isNotifyAllUsers,
      };
      allUsers.push(userTemp);
    }
    if (allUsers.length > 0) {
      result = yield RCRailUpdatedNotifyController.Model.create(allUsers);
    }
    if (result) {
      for (let items of result) {
        //  围栏更新消息通知
        RCMessageSystemController.railUpdateNotify({ id: items._id, user: items.notifyPartUsers.user, isNotifyAllUsers, expiredAt }).catch(error => {
          //
        });
      }
    }
  }

  // 查找用户发送消息
  static *findUserSendMessage(id) {
    const date = 'today'.beginning;
    const message = yield RCRailUpdatedNotifyController.Model.find({
      $or: [
        {
          $and: [
            { isNotifyAllUsers: true },
            { 'notifyAllUsers.expiredAt': { $gte: date } },
          ],
        }, {
          $and: [
            { isNotifyAllUsers: false },
            {
              'notifyPartUsers.expiredAt': { $gte: date },
              'notifyPartUsers.user': id,
            },
          ],
        },
      ],
    }, {
      'notifyAllUsers.expiredAt': 0,
      'notifyPartUsers.expiredAt': 0,
      'notifyPartUsers.user': 0,
      createdAt: 0,
      updatedAt: 0,
      _id: 0,
      __v: 0,
    }).read('secondary');
    if (!message) {
      return false;
    } else {
      return message;
    }
  }

  // 设置修改已读状态
  static *findByUserAndUpdateRead(id, { read }) {
    yield RCRailUpdatedNotifyController.Model.update({ 'notifyPartUsers.user': id }, { $set: { 'notifyPartUsers.read': read } }).read('secondary');
  }
}

RCRailUpdatedNotifyController.Model = RCRailUpdatedNotify;
module.exports = RCRailUpdatedNotifyController;
