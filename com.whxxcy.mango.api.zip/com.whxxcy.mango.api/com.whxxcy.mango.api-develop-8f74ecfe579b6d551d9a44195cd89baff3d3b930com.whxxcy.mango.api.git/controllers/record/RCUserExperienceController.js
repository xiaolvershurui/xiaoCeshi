const RCUserExperience = require('../../models/record/rc_user_experience');
const RCOrderFinishController = require('../../controllers/record/RCOrderFinishController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class RCUserExperienceController extends Controller {

  static * create ({ user, stock, region, succeed, error, errorCode }) {
    const lastOne = yield RCUserExperienceController.Model.findOne({
      user,
      stock,
      scannedAt: { $gte: new Date(Date.now() - (60 * 60 * 1000)) },
    });
    if (!lastOne) {
      yield RCUserExperience.create({
        user,
        stock,
        scannedAt: new Date(),
        succeed,
        region,
        error,
        errorCode
      });
    } else {
      // 只要有一次扫码成功了 就算1条扫码成功
      if (!lastOne.succeed && succeed) {
        yield RCUserExperience.findByIdAndUpdate(lastOne._id, {
          $set: {
            succeed,
          },
        });
      }
    }
  }

  static async rent ({ user, stock, order }) {
    const lastOne = await RCUserExperienceController.Model.findOne({
      user,
      stock,
      scannedAt: { $gte: new Date(Date.now() - (60 * 60 * 1000)) },
      succeed: true,
    });
    if (lastOne) {
      await RCUserExperience.findByIdAndUpdate(lastOne._id, {
        $set: {
          order,
        },
      });
    }
  }

  static async finish ({ order, isFreeTrip, isBad, actualTotal, forceFinish, isOnline }) {
    const record = await RCUserExperienceController.Model.findOne({
      order,
    });
    if (record) {
      const updateData = {
        rentFinish: actualTotal > 0 || (isFreeTrip && !isBad),
      };
      const finishRecord = await RCOrderFinishController.Model.findOne({ order });
      if (forceFinish) {
        if (finishRecord) {
          // 后台结束 停止时间积累
          const lastFeedback = finishRecord.feedback[finishRecord.feedback.length - 1];
          updateData.returnFailedByArea = [
            constants.RC_ORDER_FINISH_CLICK.禁停区,
            constants.RC_ORDER_FINISH_CLICK.禁行区,
            constants.RC_ORDER_FINISH_CLICK.服务区外].includes(lastFeedback.clickType) && !lastFeedback.succeed;
        }
        // 后台结束时 车子离线
        updateData.returnFailedByOffline = !isOnline;
        updateData.lastPowerUnlink = null;
      }
      if (record.lastPowerUnlink) updateData[`${record.lastPowerUnlink}.noPowerForSeconds`] = Math.max(record[record.lastPowerUnlink].noPowerForSeconds || 0, Date.now() - new Date(record[record.lastPowerUnlink].lastNoPoweredAt).getTime());
      await RCUserExperienceController.Model.findByIdAndUpdate(record._id, {
        $set: updateData,
      });
    }
  }

  static * outage ({ order }) {

  }

}

RCUserExperienceController.Model = RCUserExperience;
module.exports = RCUserExperienceController;
