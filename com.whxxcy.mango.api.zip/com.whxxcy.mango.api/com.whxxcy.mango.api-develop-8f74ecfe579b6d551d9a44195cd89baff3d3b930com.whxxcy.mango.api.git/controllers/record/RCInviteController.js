const Controller = require('../Controller');
const RCInvite = require('../../models/record/rc_invite');

class RCInviteController extends Controller {
  * create ({ user, invitedUser }) {
    return yield this.T(RCInvite).create({
      user,
      invitedUser,
      invitedAt: new Date()
    });
  }
}

RCInviteController.Model = RCInvite;
module.exports = RCInviteController;