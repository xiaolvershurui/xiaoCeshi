const RCBatteryInStockPoint = require('../../models/record/rc_battery_in_stock_point.js');
const OTSRCBatteryInStockPoints = require('../../services/ots/RCBatteryInStockPoints');
const OPRegionController = require('../../controllers/operation/OPRegionController');
const BKStockController = require('../../controllers/ebike/BKStockController');
const Controller = require('../Controller');
const oss = require('../../services/oss');
const uuid = require('node-uuid');
const moment = require('moment');
const co = require('co');

const fetchData = async ({ battery_stock, start, end, _id }) => {
  let ret = await OTSRCBatteryInStockPoints.find({ battery_stock: battery_stock, time: [start, end], _id });
  let lastRecordId = ret[ret.length - 1] && ret[ret.length - 1]._id;
  if (ret.length === 5000) {
    const newRet = await fetchData({ battery_stock, start: ret[ret.length - 1].time, end, _id: lastRecordId._id + 1 });
    ret = ret.concat(newRet);
  }
  return ret;
};

class RCBatteryInStockPointController extends Controller {

  static async trigger({ battery, stock, start, end, region }) {
    const regionMap = {};
    (await OPRegionController.Model.find()).forEach(region => {
      regionMap[region._id] = region.name;
    });
    const { box } = await BKStockController.Model.findById(stock).select('box');
    const lastRecord = await this.Model.findOne({ battery, stock, start });
    // 未生成过
    const startTime = new Date(start);
    if (!lastRecord) {
      const otsPoints = await fetchData({ battery_stock: `${battery}_${stock}`, startTime });
      if (otsPoints.length > 500) {
        const points = [];
        otsPoints.forEach(item => {
          points.push({
            acc: item.acc,
            lock: item.lock,
            voltage: item.extra.voltage,
            mileageInAll: item.extra.mileageInAll,
            lngLat: item.gps && item.gps.gpsLngLat,
            time: item.time,
          });
        });
        const url = `${regionMap[region]}/${battery}_${stock}_${moment(startTime).format('YYYYMMDD')}.json`;
        const ret = {
          battery,
          stock,
          box,
          region,
          startTime: start,
          endTime: end,
          finished: true,
        };
        ret.points = points;
        co(function *() {
          yield oss.private.putData('电池换电周期', JSON.stringify(ret), url);
        });
        Reflect.deleteProperty(ret, 'points');
        ret.url = `电池换电周期/${url}`;
        await this.Model.create(ret);
      }
    }
  }

}

RCBatteryInStockPointController.Model = RCBatteryInStockPoint;
module.exports = RCBatteryInStockPointController;
