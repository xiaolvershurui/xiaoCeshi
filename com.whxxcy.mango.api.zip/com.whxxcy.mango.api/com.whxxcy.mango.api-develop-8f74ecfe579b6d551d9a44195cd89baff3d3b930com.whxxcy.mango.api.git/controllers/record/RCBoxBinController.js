const { Client } = require('ots-server');
const Controller = require('../Controller');
const TableStore = require('tablestore');
const RCBoxBin = require('../../models/record/rc_box_bin');

const client = new Client({
  accessKeyId: 'LTAI1D2eRWXYNEXN',
  secretAccessKey: '6p4iArNqy7H5PpaiHxsvbz04jdMxT4',
  instanceName: 'mango-track',
  endPoint: 'https://mango-track.cn-shenzhen.ots.aliyuncs.com'
});


// (async _ => {
//   const ret = await client.createTable();
// const boxBin = await RCBoxBin.findOne().skip(5);
// const datetime = new Date();
// const ret = await client.putRow({
//   tableName: 'sampleTable',
//   primaryKey: [{
//     name: 'imei_month',
//     value: `${boxBin.deviceId}_${datetime.getYear()}${datetime.getMonth() + 1}`
//   }, {
//     name: '_id',
//     value: TableStore.PK_AUTO_INCR,
//   }, {
//     name: 'datetime',
//     value: datetime.getTime()
//   }]
// });
// console.log(ret);
// })();
//

class RCBoxBinController extends Controller {

  static * createTable () {
    const params = {
      tableMeta: {
        tableName: 'sampleTable',
        primaryKey: [
          {
            name: 'imei_month',
            type: 'STRING'
          },
          {
            name: '_id',
            type: 'INTEGER',
            option: 'AUTO_INCREMENT'
          },
          {
            name: 'datetime',
            type: 'INTEGER'
          }
        ]
      },
      reservedThroughput: {
        capacityUnit: {
          read: 0,
          write: 0
        }
      },
      tableOptions: {
        timeToLive: -1, // 数据的过期时间, 单位秒, -1代表永不过期. 假如设置过期时间为一年, 即为 365 * 24 * 3600.
        maxVersions: 1 // 保存的最大版本数, 设置为1即代表每列上最多保存一个版本(保存最新的版本).
      }
    };
    yield client.createTable(params)
  }

  static * putRow ({ primaryKey, attributeColumns }) {
    return yield client.putRow({
      tableName: 'rc_box_bin',
      primaryKey,
      attributeColumns
    })
  }

  // 固定盒子 不同时间区间
  static * getRangeWithBox ({ box, min, max, limit }) {
    return yield client.getRange({
      tableName: 'rc_box_bin',
      inclusiveStartPrimaryKey: [{
        imei_month: `${box}_${min.dateTime.getYear()}${min.dateTime.getMonth() + 1}` || TableStore.INF_MIN,
        _id: min._id || TableStore.INF_MIN,
        datetime: min.dateTime || TableStore.INF_MIN
      }],
      exclusiveEndPrimaryKey: [{
        imei_month: `${box}_${max.dateTime.getYear()}${max.dateTime.getMonth() + 1}` || TableStore.INF_MAX,
        _id: max._id || TableStore.INF_MAX,
        datetime: max.dateTime || TableStore.INF_MAX
      }],
      limit: limit || 50
    })
  }

}

module.exports = RCBoxBinController;
