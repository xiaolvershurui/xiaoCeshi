const RCStockAlarm = require('../../models/record/rc_stock_alarm');
const Controller = require('../Controller');
const ODOrderController = require('../order/ODOrderController');
const ACUserController = require('../account/ACUserController');
const OPRegionController = require('../operation/OPRegionController');
const OPStyleController = require('../operation/OPStyleController');
const BKStockController = require('../ebike/BKStockController');
const RCNotificationController = require('./RCNotificationController');
const constants = require('../../settings/constants');
const IoT = require('../../IoT');

class RCStockAlarmController extends Controller {
  static * create ({ box, dataSource, point, type, region, style, stock, time, acc, lock, expired }) {
    if (stock) {
      const order = yield ODOrderController.findRentingByBox(box);
      let user;
      if (order) {
        user = yield ACUserController.Model.findById(order.user);
      }
      // 判断是否需要记录该警报记录
      if (yield this.check({ stock, box, dataSource, type, lock, acc, time, order, user, expired })) {
        const alarm = yield RCStockAlarm.create({
          region,
          style,
          stock: stock._id,
          type,
          box,
          dataSource,
          point,
          order: order && order._id,
          user: user && {
            name: user.cert.name,
            tel: user.auth.tel,
            certNo: user.cert.certNo
          },
          time,
          acc,
          lock
        });
        // 10分钟内出现3次以上移动报警 则发送通知 否则不发送
        if ([constants.RC_ALARM_TYPE.位移警报, constants.RC_ALARM_TYPE.移动警报].includes(type)) {
          const latestMovementCount = yield this.countLatestMovement(box);
          if (latestMovementCount <= 3) return;
          yield BKStockController.updateIllegalMovement(stock._id, true);
        }
        const OPInspectionTaskController = require('../operation/OPInspectionTaskController');
        // 创建巡检任务
        if (type === constants.RC_ALARM_TYPE.两天未使用) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.两天未使用 });
        } else if (type === constants.RC_ALARM_TYPE.解除两天未使用) {
          yield OPInspectionTaskController.releaseNoOrderInTwoDay(stock._id);
        } else if (type === constants.RC_ALARM_TYPE.低电预警) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.电量预警 });
        } else if (type === constants.RC_ALARM_TYPE.低电警报) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.低电量 });
        } else if (type === constants.RC_ALARM_TYPE.解除低电) {
          yield OPInspectionTaskController.releaseLowPower(stock._id);
        } else if ([constants.RC_ALARM_TYPE.位移警报, constants.RC_ALARM_TYPE.移动警报].includes(type)) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.连续位移 });
        } else if (type === constants.RC_ALARM_TYPE.断电警报) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.车辆断电 });
        } else if (type === constants.RC_ALARM_TYPE.电量恢复) {
          yield OPInspectionTaskController.releasePowerOff(stock._id);
        } else if (type === constants.RC_ALARM_TYPE.设备上线) {
          yield OPInspectionTaskController.releaseOffline(stock._id);
        } else if (type === constants.RC_ALARM_TYPE.设备下线) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.车机离线 });
        } else if (type === constants.RC_ALARM_TYPE.驶入围栏) {
          yield OPInspectionTaskController.releaseOutsideRegion(stock._id);
        } else if (type === constants.RC_ALARM_TYPE.驶出围栏) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.围栏外 });
        } else if (type === constants.RC_ALARM_TYPE.解除无定位) {
          yield OPInspectionTaskController.releaseNoLocation(stock._id);
        } else if (type === constants.RC_ALARM_TYPE.近期无定位) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.无卫星定位 });
        } else if (type === constants.RC_ALARM_TYPE.驶入禁行区) {
          yield OPInspectionTaskController.create({ stock: stock._id, region, type: constants.OP_INSPECTION_TASK_TYPE.禁行区内 });
        } else if (type === constants.RC_ALARM_TYPE.驶出禁行区) {
          yield OPInspectionTaskController.releaseInsideProhibitedArea(stock._id);
        }
        // 没有订单 撤防状态下 不发送 断电警报 低电警报 低电预警 解除低电
        if ([
            constants.RC_ALARM_TYPE.低电警报,
            constants.RC_ALARM_TYPE.断电警报,
            constants.RC_ALARM_TYPE.低电预警,
            constants.RC_ALARM_TYPE.解除低电,
          ].includes(type)) {
          if (!order && lock === false) return;
        }
        // 发送钉钉通知
        yield this.createNotification(alarm._id);
      }
    }
  }

  static * createNotification (id) {
    const RCStockPointController = require('./RCStockPointController');
    const alarm = yield RCStockAlarm.findById(id).populate({
      path: 'region',
      model: OPRegionController.Model,
      select: 'name'
    }).populate({
      path: 'style',
      model: OPStyleController.Model,
      select: 'name'
    }).populate({
      path: 'stock',
      model: BKStockController.Model,
      select: 'number'
    }).populate({
      path: 'point',
      model: RCStockPointController.Model,
      select: 'gps'
    });
    if(!alarm) return;
    if (alarm.stock && alarm.stock.locate === constants.BK_LOCATE.仓库) return;
    let type = constants.RC_NOTIFICATION_TYPE.其他警报;
    switch (alarm.type) {
      case constants.RC_ALARM_TYPE.低电预警:
      case constants.RC_ALARM_TYPE.一天未使用:
      case constants.RC_ALARM_TYPE.两天未使用:
        type = constants.RC_NOTIFICATION_TYPE.巡检预警;
        break;
      case constants.RC_ALARM_TYPE.解除低电:
      case constants.RC_ALARM_TYPE.低电警报:
        type = constants.RC_NOTIFICATION_TYPE.低电警报;
        break;
      case constants.RC_ALARM_TYPE.位移警报:
      case constants.RC_ALARM_TYPE.移动警报:
      case constants.RC_ALARM_TYPE.解除非法位移:
        type = constants.RC_NOTIFICATION_TYPE.位移警报;
        break;
      case constants.RC_ALARM_TYPE.断电警报:
      case constants.RC_ALARM_TYPE.解除断电:
      case constants.RC_ALARM_TYPE.电量恢复:
        type = constants.RC_NOTIFICATION_TYPE.断电警报;
        break;
      case constants.RC_ALARM_TYPE.设备上线:
      case constants.RC_ALARM_TYPE.设备下线:
        type = constants.RC_NOTIFICATION_TYPE.离线警报;
        break;
      case constants.RC_ALARM_TYPE.驶入围栏:
      case constants.RC_ALARM_TYPE.驶出围栏:
      case constants.RC_ALARM_TYPE.驶出禁行区:
      case constants.RC_ALARM_TYPE.驶入禁行区:
        type = constants.RC_NOTIFICATION_TYPE.围栏警报;
        break;
      default:
    }
    yield RCNotificationController.create({
      channel: constants.RC_NOTIFICATION_CHANNEL.钉钉机器人,
      type,
      data: alarm.toJSON()
    });
  }

  static * findLatestToggleOnline (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.设备上线,
          constants.RC_ALARM_TYPE.设备下线
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestToggleInRegion (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.驶入围栏,
          constants.RC_ALARM_TYPE.驶出围栏
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestToggleInProhibitedArea (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.驶出禁行区,
          constants.RC_ALARM_TYPE.驶入禁行区
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestToggleLowPower (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.解除低电,
          constants.RC_ALARM_TYPE.低电预警,
          constants.RC_ALARM_TYPE.低电警报,
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestLowPowerWarning (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.解除低电,
          constants.RC_ALARM_TYPE.低电预警
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestShake (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: constants.RC_ALARM_TYPE.震动警报
    }).sort({ _id: -1 });
  }

  static * findLatestSilent (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: constants.RC_ALARM_TYPE.静音警报
    }).sort({ _id: -1 });
  }

  static * countLatestMovement (stock) {
    return yield RCStockAlarm.count({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.移动警报,
          constants.RC_ALARM_TYPE.位移警报
        ]
      },
      time: { $gte: '10 minutes'.before(new Date()) }
    });
  }

  static * findLatestPowerUnlink (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.断电警报,
          constants.RC_ALARM_TYPE.电量恢复
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestMovement (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: {
        $in: [
          constants.RC_ALARM_TYPE.位移警报,
          constants.RC_ALARM_TYPE.移动警报
        ]
      }
    }).sort({ _id: -1 });
  }

  static * findLatestReleaseNotUsedInTwoDay (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: constants.RC_ALARM_TYPE.解除两天未使用
    }).sort({ _id: -1 });
  }

  static * findLatestReleaseNotUsedInOneDay (stock) {
    return yield RCStockAlarm.findOne({
      stock,
      type: constants.RC_ALARM_TYPE.解除一天未使用
    }).sort({ _id: -1 });
  }

  static * check ({ box, stock, dataSource, type, lock, acc, time, order, user, expired }) {
    const stockId = stock._id;
    const now = new Date();
    switch (type) {
      case constants.RC_ALARM_TYPE.设备上线: {
        const record = yield this.findLatestToggleOnline(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.设备下线) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.设备下线: {
        const record = yield this.findLatestToggleOnline(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.设备上线) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.低电警报: {
        const record = yield this.findLatestToggleLowPower(stockId);
        if (!record || record.type !== constants.RC_ALARM_TYPE.低电警报) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.解除低电: {
        const record = yield this.findLatestToggleLowPower(stockId);
        if (!record || record.type !== constants.RC_ALARM_TYPE.解除低电) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.低电预警: {
        const record = yield this.findLatestLowPowerWarning(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.解除低电) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.驶入围栏: {
        const record = yield this.findLatestToggleInRegion(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.驶出围栏) { // 若之前触发过驶出围栏，才触发驶入围栏
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.驶出围栏: {
        const record = yield this.findLatestToggleInRegion(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.驶入围栏) { // 若之前触发过驶入围栏，才触发驶出围栏
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.驶入禁行区: {
        const record = yield this.findLatestToggleInProhibitedArea(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.驶出禁行区) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.驶出禁行区: {
        const record = yield this.findLatestToggleInProhibitedArea(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.驶入禁行区) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.震动警报: {
        const record = yield this.findLatestShake(stockId);
        if (!record || now.is.over('30 minutes'.after(record.time))) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.静音警报: {
        return false
      }
      case constants.RC_ALARM_TYPE.位移警报:
      case constants.RC_ALARM_TYPE.移动警报: {
        if (lock) {
          const record = yield this.findLatestMovement(stockId);
          if (!record || now.is.over('2 minutes'.after(record.time))) {
            return true;
          }
        }
        break;
      }
      case constants.RC_ALARM_TYPE.两天未使用: {
        const record = yield this.findLatestReleaseNotUsedInTwoDay(stockId);
        if (!record || now.is.over('2 days'.after(record.time))) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.断电警报: {
        const record = yield this.findLatestPowerUnlink(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.电量恢复) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.电量恢复: {
        const record = yield this.findLatestPowerUnlink(stockId);
        if (!record || record.type === constants.RC_ALARM_TYPE.断电警报) {
          return true;
        }
        break;
      }
      case constants.RC_ALARM_TYPE.一天未使用:
      case constants.RC_ALARM_TYPE.解除一天未使用:
      case constants.RC_ALARM_TYPE.电门关:
      case constants.RC_ALARM_TYPE.电门开: {
        return false;
      }
      case constants.RC_ALARM_TYPE.近期无定位:
      case constants.RC_ALARM_TYPE.解除无定位:
      case constants.RC_ALARM_TYPE.解除两天未使用:
      case constants.RC_ALARM_TYPE.天线异常:
      case constants.RC_ALARM_TYPE.模块异常:
      case constants.RC_ALARM_TYPE.解除断电:
      case constants.RC_ALARM_TYPE.解除非法位移:
      case constants.RC_ALARM_TYPE.低电压警报:
      case constants.RC_ALARM_TYPE.严重低电压警报:
      case constants.RC_ALARM_TYPE.仓锁关闭:
      case constants.RC_ALARM_TYPE.仓锁开启:
      default:
        return true;
    }
    return false;
  }
}

RCStockAlarmController.Model = RCStockAlarm;
module.exports = RCStockAlarmController;