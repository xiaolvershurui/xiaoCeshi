const RCElectric = require('../../models/record/rc_electric');
const Controller = require('../Controller');
const OPBatteryStationController = require('../../controllers/operation/OPBatteryStationController');
const Error = require('errrr');

class RCElectricController extends Controller {

  static async create ({
    year,
    month,
    operator,
    electricMeterBoxImage,
    electricQuantity,
    temperature,
  }) {
    const station = await OPBatteryStationController.Model.findOne({
      storeManagers: operator,
    }).select('_id');
    if (!station) throw new Error('您还不是电站管理员');
    const lastRecord = await this.Model.findOne({ station: station._id }).sort({ _id: -1 });
    if (lastRecord && electricQuantity <= lastRecord.electricQuantity) throw new Error('电表数目比以往低,请核对后再试。');
    return await this.Model.create({
      year,
      month,
      operator,
      station: station._id,
      electricMeterBoxImage,
      electricQuantity,
      temperature,
      diffElectric: parseFloat((electricQuantity - (lastRecord ? lastRecord.electricQuantity : 0)).toFixed(2)),
    });
  }

}

RCElectricController.Model = RCElectric;
module.exports = RCElectricController;
