const RCFeedLoss = require('../../models/record/rc_feed_loss');
const Controller = require('../Controller');

class RCFeedLossController extends Controller {

  static * findAndGenerate ({ user, region, stock, location }) {
    const lastOne = yield RCFeedLoss.findOne({ scannedAt: { $gte: new Date(Date.now() - (20 * 60 * 1000)) }, user });
    if (!lastOne) {
      yield RCFeedLoss.create({
        date: 'today'.beginning,
        region,
        user,
        stock,
        location,
        scannedAt: new Date(),
        rentSuccess: false
      })
    }
  }

  static async trigger (user) {
    const lastOne = await RCFeedLoss.findOne({ scannedAt: { $gte: new Date(Date.now() - (20 * 60 * 1000)) }, user });
    if (lastOne) {
      await RCFeedLoss.findByIdAndUpdate(lastOne._id, {
        $set: {
          rentSuccess: true
        }
      })
    }
  }

}

RCFeedLossController.Model = RCFeedLoss;
module.exports = RCFeedLossController;