const RCMessageSystem = require('../../models/record/rc_message_system');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class RCMessageSystemController extends Controller {

  // 工单回复通知
  static async WorkOrderNotify({ id, user }) {
    const WorkOrderNotifyMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.工单回复结果通知,
      style: constants.RC_MESSAGE_STYLE.消息通知,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      workOrderNotify: {
        id,
        user,
      },
      isNotifyAllUsers: false,
    };
    await RCMessageSystemController.Model.create(WorkOrderNotifyMessage);
  }

  // 订单免单通知
  static async orderFreeNotify({ id, user }) {
    const orderFreeMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.订单免单通知,
      style: constants.RC_MESSAGE_STYLE.消息通知,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      orderFreeNotify: {
        id,
        user,
      },
      isNotifyAllUsers: false,
    };
    await RCMessageSystemController.Model.create(orderFreeMessage);
  }

  // 优惠券到账通知
  static async couponNotify({ id, user }) {
    const couponMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.优惠券到账通知,
      style: constants.RC_MESSAGE_STYLE.消息通知,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      couponNotify: {
        id,
        user,
      },
      isNotifyAllUsers: false,
    };
    await RCMessageSystemController.Model.create(couponMessage);
  }

  // 重大活动通知
  static *importActivityNotify({ creator, updater, title, content, image, releaseTime, expiredAt, linkUrl }) {
    const importActivityMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.重大活动通知,
      style: constants.RC_MESSAGE_STYLE.主页弹窗,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.网页,
      importActivityNotify: {
        creator,
        updater,
        title,
        content,
        image,
        releaseTime,
        expiredAt,
        linkUrl,
      },
      isNotifyAllUsers: true,
    };
    yield RCMessageSystemController.Model.create(Object.assign(importActivityMessage));
  }

  // 围栏更新通知
  static async railUpdateNotify({ id, isNotifyAllUsers, user, expiredAt }) {
    const railUpdateMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.围栏调整通知,
      style: constants.RC_MESSAGE_STYLE.主页弹窗,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      railUpdateNotify: {
        id,
        user,
        expiredAt,
      },
      isNotifyAllUsers,
    };
    await RCMessageSystemController.Model.create(railUpdateMessage);
  }

  // 押金退还通知
  static async refundNotify({ id, user }) {
    const refundNotifyMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.押金退款结果通知,
      style: constants.RC_MESSAGE_STYLE.消息通知,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      refundNotify: {
        id,
        user,
      },
      isNotifyAllUsers: false,
    };
    await RCMessageSystemController.Model.create(refundNotifyMessage);
  }

  // 信用减分通知
  static async creditDecreaseNotify({ user, order }) {
    const creditDecreaseNotifyMessage = {
      type: constants.RC_MESSAGE_SYSTEM_TYPE.信用减分通知,
      style: constants.RC_MESSAGE_STYLE.消息通知,
      linkStyle: constants.RC_MESSAGE_LINK_STYLE.app页面,
      creditDecreaseNotify: {
        user,
        order,
      },
      isNotifyAllUsers: false,
    };
    await RCMessageSystemController.Model.create(creditDecreaseNotifyMessage);
  }

  // 查找用户发送消息
  static *findUserSendMessage({ user, query }) {
    const date = 'today'.beginning;
    const oneMonthTime = '30 days'.before('today'.beginning);
    let newNotify = false;
    const message = yield RCMessageSystemController.Model.find({
      $or: [
        {
          // 重大活动通知所有用户
          $and: [
            { isNotifyAllUsers: true },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'importActivityNotify.releaseTime': { $lte: date } },
          ],
        },
        {
          // 围栏更新通知所有用户
          $and: [
            { isNotifyAllUsers: true },
            { 'createdAt': { $gte: oneMonthTime } },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 1、押金退还
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'refundNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 2、工单回复
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'workOrderNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 3、订单免单
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'orderFreeNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 4、违规骑行
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'orderIllegalNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 5、信用减分
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'creditDecreaseNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 6、优惠券到账
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'couponNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 7、围栏调整通知
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'railUpdateNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 8、计价变更通知
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'priceChangeNotify.id': user },
          ],
        },
      ],
    }, {
      'updatedAt': 0,
      'importActivityNotify.creator': 0,
      'importActivityNotify.updater': 0,
    }).skip(query.skip).limit(query.limit).sort(query.sort).read('secondary');
    for (let item of message) {
      if (item.type < 8 && !item.isNotifyAllUsers && !item.isRead) {
        newNotify = true;
        break;
      }
    }
    if (!message) {
      return false;
    } else {
      return {
        newNotify,
        message,
      };
    }
  }

  // 设置修改已读状态
  static *settingRead({ user, read }) {
    const oneMonthTime = '30 days'.before('today'.beginning);
    // 如果用户进行打开就将他的所有消息标记为已读
    yield RCMessageSystemController.Model.updateMany({
      $or: [
        {
          // 通知部分用户
          $and: [
            // 1、押金退还
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'refundNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 2、工单回复
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'workOrderNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 3、订单免单
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'orderFreeNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 4、违规骑行
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'orderIllegalNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 5、信用减分
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'creditDecreaseNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 6、优惠券到账
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'couponNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 7、围栏调整通知
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'railUpdateNotify.user': user },
          ],
        },
        {
          // 通知部分用户
          $and: [
            // 8、计价变更通知
            { isNotifyAllUsers: false },
            { 'createdAt': { $gte: oneMonthTime } },
            { 'priceChangeNotify.id': user },
          ],
        },
      ],
    }, {
      $set: {
        'isRead': read,
      },
    }).read('secondary');
  }
}

RCMessageSystemController.Model = RCMessageSystem;
module.exports = RCMessageSystemController;
