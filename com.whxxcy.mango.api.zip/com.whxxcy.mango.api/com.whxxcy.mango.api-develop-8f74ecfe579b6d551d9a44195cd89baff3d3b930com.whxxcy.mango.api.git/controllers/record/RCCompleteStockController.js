const RCCompleteStock = require('../../models/record/rc_complete_stock');
const BKStockController = require('../../controllers/ebike/BKStockController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');

class RCCompleteStockController extends Controller {

  static async createAndCheck ({ id, stocks, uploader, url }) {
    // 目前都是新日生产仓到出厂仓
    let completeRecord;
    if (!id) {
      completeRecord = await this.Model.create({
        uploader,
        prevRegion: '1704062319008',
        nextRegion: '1802101223850',
        status: constants.OD_COMPLETE_STOCK_STATUS.完善中,
        files: [],
      });
    } else {
      completeRecord = this.Model.findById(id);
    }
    (async _ => {
      let hasFinished = true;
      const stocksRet = [];
      for (let stock of stocks) {
        stock.status = 1;
        if (!stock.custom) {
          stock.reason = '表格中车辆二维码不存在';
          stock.status = 2;
          hasFinished = false;
        } else if (!stock.vin) {
          stock.reason = '表格中车架号不存在';
          stock.status = 2;
          hasFinished = false;
        } else {
          let existStock = await BKStockController.Model.findOne({ 'number.custom': stock.custom });
          if (!existStock) {
            stock.reason = '系统中查无此车';
            stock.status = 2;
            hasFinished = false;
          } else if (existStock.region !== '1704062319008') {
            stock.reason = '车辆不在新日生产大区';
            stock.status = 3;
          } else if (existStock.number.vin) {
            stock.reason = '车辆车架号等已经绑定';
            stock.status = 3;
          } else {
            const stockWithVin = await BKStockController.Model.findOne({ 'number.vin': stock.vin });
            if (stockWithVin) {
              stock.reason = '信息中车架号与系统中重复';
              stock.status = 2;
              hasFinished = false;
            }
          }
        }
        if (stock.status === 1) {
          await BKStockController.Model.findOneAndUpdate({ 'number.custom': stock.custom }, {
            $set: {
              'number.vin': stock.vin,
              region: '1802101223850',
              lockVin: {
                isLocked: true,
                lockedAt: new Date(),
              },
              factoryInfo: {
                partCode: stock.partCode,
                completeCode: stock.completeCode,
                electricalCode: stock.electricalCode,
                controlCode: stock.controlCode,
                finishDate: stock.finishDate,
                shipmentDate: stock.shipmentDate,
              },
            },
          });
        }
        stocksRet.push(stock);
        await RCCompleteStockController.Model.findByIdAndUpdate(completeRecord._id, {
          stocks: stocksRet,
          status: (stocksRet.length === stocks.length) && hasFinished ? 1 : 0,
          files: {
            $push: {
              url,
              uploadedAt: new Date(),
            },
          },
        });
      }
    })().catch(error => {
      //
    });
  }
}

RCCompleteStockController.Model = RCCompleteStock;
module.exports = RCCompleteStockController;
