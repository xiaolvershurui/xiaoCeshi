const RCScanQR = require('../../models/record/rc_scan_qr');
const ACUserController = require('../account/ACUserController');
const BKStockController = require('../ebike/BKStockController');
const RCUserExperienceController = require('../record/RCUserExperienceController');
const Controller = require('../Controller');
const getCache = require('../../utils/cache-new');

const cache = getCache('mg.cache.stockInfoInDay', 1);
const moment = require('moment');
const errorHandler = require('../../services/errorHandler');

class RCScanQRController extends Controller {
  static * create ({ user, scanContent, isScanQR, issuedCoupon, succeed, error, errorCode, lngLat, address, accuracy, deviceInfo, city, appVersion }) {
    const userData = yield ACUserController.Model.findById(user);
    const stockData = yield BKStockController.Model.findOne({ 'number.custom': scanContent });
    if (stockData && isScanQR) {
      yield BKStockController.updateLatestScannedAt(stockData._id);
      if (errorCode === 'controller.bkStock.stockLowPower') {
        const key = `${stockData.region}_${moment().format('YYYYMMDD')}_${stockData._id}`;
        (async _ => {
          const info = await cache.getJSON(key);
          if (!info || info.hasThrownLowPowerError) return;
          cache.setJSON(key, Object.assign(info, {
            hasThrownLowPowerError: true,
          }), 'EX', moment.duration(30, 'days').asSeconds());
        })().catch(error => errorHandler(error, 'SET_STOCK_HAS_THROWN_LOW_POWER_ERROR'));
      }
      yield RCUserExperienceController.create({ user, stock: stockData._id, region: stockData.region, succeed, error, errorCode });
    }
    return yield RCScanQR.create({
      user,
      userName: userData && userData.cert && userData.cert.name,
      userTel: userData && userData.auth.tel,
      region: stockData && stockData.region,
      scanContent,
      isScanQR,
      issuedCoupon,
      succeed,
      error,
      errorCode,
      stock: stockData && stockData._id,
      stockNo: stockData && stockData.number && stockData.number.custom,
      lngLat,
      address,
      accuracy,
      scannedAt: new Date(),
      deviceInfo,
      city,
      appVersion,
    });
  }

  static * findSuspicious (stock) {
    const stockData = yield BKStockController.findByIdAndCheckExists(stock);
    const query = {
      stock,
      isScanQR: true,
      scannedAt: { $gte: '7 days'.before(new Date()) },
    };
    if (stockData.latestUsedAt) {
      query.scannedAt = { $gt: stockData.latestUsedAt };
    }
    return yield RCScanQR.find(query);
  }

  static * findLatestSuspicious (stock) {
    return yield RCScanQR.findOne({
      stock,
      isScanQR: true,
    }).sort({ scannedAt: -1 });
  }

  static * findLatestValidRecords (user) {
    return yield RCScanQR.find({
      user,
      stock: { $exists: true },
      scannedAt: { $gte: '10 minutes'.before(new Date()) },
    }).sort({ scannedAt: -1 });
  }

  static * trigger (user) {
    const now = Date.now();
    const lastScanErrors = yield RCScanQR.find({
      user,
      scannedAt: { $gte: new Date(now - (20 * 60 * 1000)), $lt: now },
      error: '车辆电量低，暂无法提供服务，请换辆车试试！',
    });
    if (lastScanErrors) {
      yield RCScanQR.update({ _id: { $in: lastScanErrors.map(scanError => scanError._id) } }, {
        $set: {
          rentSuccess: true,
        },
      }, {
        multi: true,
      });
    }
  }
}

RCScanQRController.Model = RCScanQR;
module.exports = RCScanQRController;
