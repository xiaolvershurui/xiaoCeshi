const RCSystemShit = require('../../models/record/rc_system_shit.js');
const Controller = require('../Controller');

class RCSystemShitController extends Controller {
  static * findByIdAndCheckExists (id) {
    const systemShit = yield RCSystemShit.findById(id);
    if (!systemShit) throw new Error(`该条反馈${id}不存在`);
    return systemShit;
  }
}

RCSystemShitController.Model = RCSystemShit;
module.exports = RCSystemShitController;
