const RCNotificationController = require('../record/RCNotificationController');
/*eslint-disable*/
const co = require('co');

co(function * () {
  yield RCNotificationController.createDataExport({
    emailTo: 'miserylee@foxmail.com',
    name: '测试/哈哈哈',
    data: [
      ['表头1', '表头2', '表头3'],
      ['第一行', '1', '2'],
      ['第二行', 'hello', 'world']
    ]
  });
}).catch(console.error);