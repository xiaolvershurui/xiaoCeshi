/*eslint-disable*/

require('xx-utils');

const prevTasks = [{
  issuedAt: new Date(),
  code: 1,
}, {
  issuedAt: '1 hour'.before(new Date()),
  code: 2,
}, {
  issuedAt: '1 day'.before(new Date()),
  code: 3
}];

const newTasks = [];
const now = new Date();

newTasks.push(prevTasks.search({ code: 4 }) || { issuedAt: now, code: 4 });
newTasks.push(prevTasks.search({ code: 2 }) || { issuedAt: now, code: 2 });

console.log(prevTasks);

console.log(newTasks);

const releasedTasks = prevTasks.filter(task => !newTasks.search({ code: task.code }));
const addedTasks = newTasks.filter(task => !prevTasks.search({ code: task.code }));

console.log(releasedTasks);
console.log(addedTasks);