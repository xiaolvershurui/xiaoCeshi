const CLDeveloper = require('../../models/cloud/cl_developer');
const ACUserController = require('../../controllers/account/ACUserController');
const Controller = require('../Controller');
const Error = require('errrr');

class CLDeveloperController extends Controller {
  static * findByIdAndCheckExists (id) {
    const developer = yield CLDeveloper.findById(id);
    if (!developer) throw new Error('开发者账户不存在');
    return developer;
  }

  static get role () {
    return 'developer';
  }

  * create ({ user, name, contact }) {
    // 添加权限
    yield new ACUserController(this.transaction).addRole(user, CLDeveloperController.role);
    // 创建账户
    if (yield CLDeveloper.findOne({ user })) throw new Error('已经存在该开发者账户');
    return yield this.T(CLDeveloper).create({
      _id: yield CLDeveloper.genId(),
      user,
      name,
      contact
    });
  }

  * toggleEnable (id, enable) {
    const developer = yield CLDeveloperController.findByIdAndCheckExists(id);
    if (enable) {
      yield new ACUserController(this.transaction).addRole(developer.user, CLDeveloperController.role);
    } else {
      yield new ACUserController(this.transaction).removeRole(developer.user, CLDeveloperController.role);
    }
    return yield this.T(CLDeveloper).findByIdAndUpdate(id, {
      $set: {
        enable
      }
    }, { new: true });
  }
}

CLDeveloperController.Model = CLDeveloper;
module.exports = CLDeveloperController;