const CLForwarding = require('../../models/cloud/cl_forwarding');
const Controller = require('../Controller');
const CLAppController = require('./CLAppController');
const CLDeveloperController = require('./CLDeveloperController');
const BKStockController = require('../ebike/BKStockController');
const Error = require('errrr');

class CLForwardingController extends Controller {
  static * create ({ app, stock }) {
    const appData = yield CLAppController.findByIdAndCheckExists(app);
    yield BKStockController.findByIdAndCheckExists(stock);
    if (yield CLForwarding.findOne({ app, stock })) {
      throw new Error('该车辆已经转发');
    }
    return yield CLForwarding.create({
      _id: yield CLForwarding.genId(),
      developer: appData.developer,
      app,
      stock
    });
  }

  static * remove (id) {
    yield CLForwarding.findByIdAndRemove(id);
  }

  static * findAvailableByStock (stock) {
    const availableDevelopers = yield CLDeveloperController.Model.find({ enable: true });
    const availableApps = yield CLAppController.Model.find({
      enable: true,
      'service.forwarding.enable': true,
      'service.forwarding.forwardGate': { $exists: true }
    });
    return yield CLForwarding.find({
      stock,
      developer: { $in: availableDevelopers.map(developer => developer._id) },
      app: { $in: availableApps.map(app => app._id) }
    }).populate('app');
  }

}

CLForwardingController.Model = CLForwarding;
module.exports = CLForwardingController;