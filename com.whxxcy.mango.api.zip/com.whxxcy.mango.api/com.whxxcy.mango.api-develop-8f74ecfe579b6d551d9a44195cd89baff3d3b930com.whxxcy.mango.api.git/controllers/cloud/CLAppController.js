const CLApp = require('../../models/cloud/cl_app');
const CLDeveloperController = require('../../controllers/cloud/CLDeveloperController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');
const { produce } = require('xx-utils');

class CLAppController extends Controller {
  static * findByIdAndCheckExists (id) {
    const app = yield CLApp.findById(id);
    if (!app) throw new Error('应用不存在');
    return app;
  }

  static * create ({ developer, name, authMethod }) {
    yield CLDeveloperController.findByIdAndCheckExists(developer);
    if (yield CLApp.findOne({ name })) throw new Error('应用名称已存在');
    return yield CLApp.create({
      _id: yield CLApp.genId(),
      name,
      developer,
      authMethod,
      secretKey: produce.nonceString(),
    });
  }

  static * resetSecretKey (id) {
    return yield CLApp.findByIdAndUpdate(id, {
      $set: {
        secretKey: produce.nonceString(),
      }
    }, { new: true });
  }

  static * toggleEnable (id, enable) {
    return yield CLApp.findByIdAndUpdate(id, {
      $set: {
        enable
      }
    }, { new: true });
  }

  static * updateForwardingService (id, forwarding) {
    return yield CLApp.findByIdAndUpdate(id, {
      $set: {
        'service.forwarding': forwarding
      }
    }, { new: true });
  }

  static * updateOpenOrderService (id, openOrder) {
    return yield CLApp.findByIdAndUpdate(id, {
      $set: {
        'service.openOrder': openOrder,
      },
    }, { new: true });
  }

  static * findByIdAndCheckAvailable (id) {
    const app = yield this.findByIdAndCheckExists(id);
    if (!app.enable) throw new Error('应用未启用');
    const developer = yield CLDeveloperController.findByIdAndCheckExists(app.developer);
    if (!developer.enable) throw new Error('开发者账号未启用');
    return app;
  }

  static * checkServiceAvailable (id, service) {
    const app = yield this.findByIdAndCheckAvailable(id);
    switch (service) {
      case constants.CL_APP_SERVICE.数据转发:
        if (!app.service.forwarding.enable) throw new Error('转发服务未启用');
        break;
      case constants.CL_APP_SERVICE.开放订单:
        if (!app.service.openOrder || !app.service.openOrder.enable) throw new Error('开放订单服务未启用');
        break;
      default:
        throw new Error('暂不支持该服务');
    }
  }
}

CLAppController.Model = CLApp;
module.exports = CLAppController;