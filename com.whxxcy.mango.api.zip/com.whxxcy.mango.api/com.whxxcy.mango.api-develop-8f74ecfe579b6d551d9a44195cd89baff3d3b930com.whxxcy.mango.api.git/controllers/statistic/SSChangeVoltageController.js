const SSChangeVoltage = require('../../models/statistic/ss_change_voltage');
const Controller = require('../Controller');

class SSChangeVoltageController extends Controller {


}

SSChangeVoltageController.Model = SSChangeVoltage;
module.exports = SSChangeVoltageController;
