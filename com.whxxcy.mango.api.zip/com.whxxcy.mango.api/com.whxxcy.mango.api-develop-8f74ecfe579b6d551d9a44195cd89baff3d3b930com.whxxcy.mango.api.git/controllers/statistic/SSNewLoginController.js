const SSNewLogin = require('../../models/statistic/ss_new_login');
const ACUserController = require('../../controllers/account/ACUserController');
const ACWalletController = require('../../controllers/account/ACWalletController');
const RCNewLoginController = require('../../controllers/record/RCNewLoginController');
const ODOrderController = require('../../controllers/order/ODOrderController');
const FNTicketController = require('../../controllers/finance/FNTicketController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class SSNewLoginController extends Controller {

  static *findAndGenerate() {
    const date = 'today'.beginning;
    let data = yield this.Model.findOne({ date });
    if (!data) {
      data = yield this.Model.create({
        date,
        totalUserCount: yield ACUserController.Model.count(),
        totalOrderCount: 0,
        'userCount.yesterday': yield ACUserController.Model.count({ lastLoginAt: { $gte: '1 day'.before('today'.beginning), $lt: 'today'.beginning } }),
        'userCount.oneWeekBefore': yield ACUserController.Model.count({ lastLoginAt: { $gte: '7 days'.before('today'.beginning), $lt: 'today'.beginning } }),
        'userCount.oneMonthBefore': yield ACUserController.Model.count({ lastLoginAt: { $gte: '30 days'.before('today'.beginning), $lt: 'today'.beginning } }),
      });
    }
    return data;
  }

  static *trigger({ user, newUdid, newUser, isActive }) {
    const staticLogin = yield this.findAndGenerate();
    const updateInfo = { $inc: {} };
    if (newUdid) updateInfo.$inc.increaseUdidCount = 1;
    if (newUser) updateInfo.$inc.increaseUserCount = 1;
    if (isActive) {
      updateInfo.$inc.totalActiveCount = 1;
      const now = Date.now();
      const userData = yield ACUserController.Model.findById(user).select('createdAt');
      const loginRecords = yield RCNewLoginController.Model.find({ user }).sort({ _id: -1 }).limit(365).select('createdAt');
      const activeKeep = staticLogin.activeKeep || [];
      loginRecords.forEach(record => {
          const day = Math.floor((now - record.createdAt.getTime()) / (24 * 3600 * 1000));
          if (day <= 365) {
            // activeKeep[day] = activeKeep[day] ? activeKeep[day] + 1 : 1;
            if (activeKeep[day]) {
              updateInfo.$inc[`activeKeep.${day}`] = 1;
            } else {
              updateInfo[`activeKeep.${day}`] = 1;
            }
          }
        },
      );
      updateInfo.activeKeep = activeKeep;
      const lastLoginRecord = loginRecords[0];
      const walletData = yield ACWalletController.Model.findById(userData._id).populate({
        path: 'ticket',
        model: FNTicketController.Model,
        select: 'state finishedAt',
      }).select('deposit.paid');
      // 与注册时间差
      const registerInterval = Math.floor((now - new Date(userData.createdAt).getTime()) / (24 * 3600 * 1000));
      if (lastLoginRecord && registerInterval <= 365) {
        const registerKeep = staticLogin.registerKeep || [];
        registerKeep[registerInterval] = registerKeep[registerInterval] ? registerKeep[registerInterval] + 1 : 1;
        if (registerKeep[registerInterval]) {
          updateInfo.$inc[`registerKeep.${registerInterval}`] = 1;
        } else {
          updateInfo[`registerKeep.${registerInterval}`] = 1;
        }

      }
      if (walletData.deposit.ticket && walletData.deposit.ticket.finishedAt && walletData.deposit.ticket.state === constants.FN_TICKET_STATE.已支付) {
        const depositInterval = Math.floor((now - new Date(walletData.deposit.ticket.finishedAt).getTime()) / (24 * 3600 * 1000));
        const depositKeep = staticLogin.depositKeep || [];
        depositKeep[depositInterval] = depositKeep[depositInterval] ? depositKeep[depositInterval] + 1 : 1;
        if (depositKeep[depositInterval]) {
          updateInfo.$inc[`depositKeep.${depositInterval}`] = 1;
        } else {
          updateInfo[`depositKeep.${depositInterval}`] = 1;
        }
      }
    }
    yield this.Model.findByIdAndUpdate(staticLogin._id, updateInfo);
  }

  // 下单时候触发
  static *createOrder({ user, id }) {
    // 上次下单时间差
    const staticLogin = yield this.findAndGenerate();
    const keep = staticLogin.orderKeep || [];
    const orderRecords = yield ODOrderController.Model.find({ user, _id: { $ne: id } }).sort({ _id: -1 }).limit(0).select('createdAt');
    let totalOrderCount = staticLogin.totalOrderCount;
    if (orderRecords[0].createdAt.getTime() < 'today'.beginning.getTime()) {
      totalOrderCount += 1;
    }
    orderRecords.forEach(record => {
      const day = Math.floor((Date.now() - record.createdAt.getTime()) / (24 * 3600 * 1000));
      if (day <= 365) {
        keep[day] = keep[day] ? keep[day] + 1 : 1;
      }
    });
    yield this.Model.findByIdAndUpdate(staticLogin._id, {
      $set: {
        orderKeep: keep,
        totalOrderCount,
      },
    });
  }

}

SSNewLoginController.Model = SSNewLogin;
module.exports = SSNewLoginController;
