const SSDriverFound = require('../../models/statistic/ss_driver_found');
const Controller = require('../Controller');

class SSDriverFoundController extends Controller {

  static * create ({ stock, operator, noFoundOperator }) {
    yield this.Model.create({
      region: stock.region,
      stock: stock._id,
      operator,
      noFoundOperator,
      taskGroup: stock.taskGroup,
      highestTask: stock.highestTask
    })
  }
}

SSDriverFoundController.Model = SSDriverFound;
module.exports = SSDriverFoundController;