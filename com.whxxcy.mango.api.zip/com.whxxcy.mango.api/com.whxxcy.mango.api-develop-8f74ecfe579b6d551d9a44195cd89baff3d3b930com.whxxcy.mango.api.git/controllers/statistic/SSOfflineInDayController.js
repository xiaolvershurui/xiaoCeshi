const SSOfflineInDay = require('../../models/statistic/ss_offline_in_day');
const Controller = require('../Controller');

class SSOfflineInDayController extends Controller {

}

SSOfflineInDayController.Model = SSOfflineInDay;
module.exports = SSOfflineInDayController;