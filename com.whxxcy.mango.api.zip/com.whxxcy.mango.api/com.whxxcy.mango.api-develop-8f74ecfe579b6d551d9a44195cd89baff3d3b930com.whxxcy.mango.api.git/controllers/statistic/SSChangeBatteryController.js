const SSChangeBattery = require('../../models/statistic/ss_change_battery');
const ODOrderController = require('../../controllers/order/ODOrderController');
const RCBatteryOpController = require('../../controllers/record/RCBatteryOpController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class SSChangeBatteryController extends Controller {

  static * trigger ({ stock, rcId }) {
    const batteryOp = yield RCBatteryOpController.Model.findOne({
      _id: { $ne: rcId },
      stock: stock._id,
      type: constants.RC_BATTERY_OP_RECORD_TYPE.电池更换到车
    }).sort({ _id: -1 });
    if (batteryOp) {
      const now = new Date();
      const data = {
        region: stock.region,
        stock: stock._id,
        prevChangeDate: batteryOp.createdAt,
        changeDate: now,
        prevVoltage: stock.battery.voltage,
        orders: [],
        totalAmount: 0,
        totalDistance: 0,
        totalDuration: 0,
        voltage: {}
      };
      const lastChange = yield SSChangeBattery.findOne({ stock: stock._id }).sort({ _id: -1 }).select('nextVoltage');
      if (lastChange) {
        data.voltage.start = lastChange.nextVoltage;
        data.voltage.end = stock.battery.voltage;
      }
      (yield ODOrderController.Model.find({
        stock: stock._id,
        createdAt: { $gte: new Date(batteryOp.createdAt), $lt: now }
      })).forEach(order => {
        data.orders.push(order._id);
        data.totalAmount += order.payInfo.totalAmount;
        data.totalDuration += order.lease.totalDuration;
        data.totalDistance += order.route.distance;
      });
      yield SSChangeBattery.create(data);
    }
  }
}

SSChangeBatteryController.Model = SSChangeBattery;
module.exports = SSChangeBatteryController;