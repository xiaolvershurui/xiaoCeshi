const SSSnapInMinute = require('../../models/statistic/ss_snap_in_minute');
const Controller = require('../Controller');

class SSSnapInMinuteController extends Controller {
  static async create (data) {
    return await SSSnapInMinute.create(data);
  }
}

SSSnapInMinuteController.Model = SSSnapInMinute;
module.exports = SSSnapInMinuteController;