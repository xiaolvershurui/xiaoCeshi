const SSBatteryOpInDay = require('../../models/statistic/ss_battery_op_in_day');
const Controller = require('../Controller');

class SSBatteryOpInDayController extends Controller {

}

SSBatteryOpInDayController.Model = SSBatteryOpInDay;
module.exports = SSBatteryOpInDayController;