const SSUserInDay = require('../../models/statistic/ss_user_in_day');
const Controller = require('../Controller');

class SSUserInDayController extends Controller {

}

SSUserInDayController.Model = SSUserInDay;
module.exports = SSUserInDayController;