const SSIllegal = require('../../models/statistic/ss_illegal');
const ODOrderController = require('../../controllers/order/ODOrderController');
const ODIllegalController = require('../../controllers/order/ODIllegalController');
const Controller = require('../Controller');

class SSIllegalController extends Controller {

  static *trigger({ date, region }) {
    const start = '1 day'.before(new Date(date).beginning);
    const end = new Date(date).beginning;
    /*eslint-disable*/
    const result = yield ODIllegalController.Model.mapReduce({
      query: {
        createdAt: { $gte: start, $lt: end },
        region,
      },
      map: function() {
        const ret = {
          wrongDirectionAndAcrossMotorway: 0,
          wrongDirection: 0,
          acrossMotorway: 0,
          niceOrder: 0,
        };
        if (this.wrongDirectionTimes > 0 && this.acrossMotorwayTimes > 0) {
          ret.wrongDirectionAndAcrossMotorway = 1;
        } else if (this.wrongDirectionTimes > 0) {
          ret.wrongDirection = 1;
        } else if (this.acrossMotorwayTimes > 0) {
          ret.acrossMotorway = 1;
        } else {
          ret.niceOrder = 1;
        }
        emit(1, ret);
      },
      reduce: function(key, values) {
        return values.reduce(function(memo, item) {
          memo.wrongDirectionAndAcrossMotorway += item.wrongDirectionAndAcrossMotorway;
          memo.wrongDirection += item.wrongDirection;
          memo.acrossMotorway += item.acrossMotorway;
          memo.niceOrder += item.niceOrder;
          return memo;
        }, {
          wrongDirectionAndAcrossMotorway: 0,
          wrongDirection: 0,
          acrossMotorway: 0,
          niceOrder: 0,
        });
      },
      readPreference: 'secondary',
    });
    // TODO: 订单查询效率
    const ret = {
      date: start,
      region,
      totalCount: yield ODOrderController.Model.count({ region, finishedAt: { $gte: start, $lt: end } }),
      inParkCount: yield ODOrderController.Model.count({
        region,
        finishedAt: { $gte: start, $lt: end },
        'route.inPark': true,
      }),
      niceOrder: result[0] ? result[0].value.niceOrder : 0,
      wrongDirectionAndAcrossMotorway: result[0] ? result[0].value.wrongDirectionAndAcrossMotorway : 0,
      wrongDirection: result[0] ? result[0].value.wrongDirection : 0,
      acrossMotorway: result[0] ? result[0].value.acrossMotorway : 0,
    };
    yield this.create(ret);
  }


  static *create(data) {
    return SSIllegalController.Model.create(data);
  }
}

SSIllegalController.Model = SSIllegal;
module.exports = SSIllegalController;
