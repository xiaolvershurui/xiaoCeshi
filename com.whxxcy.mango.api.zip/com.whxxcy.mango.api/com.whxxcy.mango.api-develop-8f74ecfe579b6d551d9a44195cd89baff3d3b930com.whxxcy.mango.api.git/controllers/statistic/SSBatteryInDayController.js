const SSBatteryInDay = require('../../models/statistic/ss_battery_in_day');
const Controller = require('../Controller');

class SSBatteryInDayController extends Controller {

  static async trigger ({ station }) {
    return await SSBatteryInDayController.Model.create({
      date: 'today'.beginning,
      station,
    });
  }

}

SSBatteryInDayController.Model = SSBatteryInDay;
module.exports = SSBatteryInDayController;
