const SSRentDetailInDay = require('../../models/statistic/ss_rent_detail_in_day');
const Controller = require('../Controller');

class SSRentDetailInDayController extends Controller {
}

SSRentDetailInDayController.Model = SSRentDetailInDay;
module.exports = SSRentDetailInDayController;