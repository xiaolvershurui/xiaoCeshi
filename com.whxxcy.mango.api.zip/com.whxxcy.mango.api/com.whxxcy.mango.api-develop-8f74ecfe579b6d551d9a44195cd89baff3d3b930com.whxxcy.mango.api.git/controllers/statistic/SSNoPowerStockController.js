const SSNoPowerStock = require('../../models/statistic/ss_no_power_stock');
const Controller = require('../Controller');

class SSNoPowerStockController extends Controller {

}

SSNoPowerStockController.Model = SSNoPowerStock;
module.exports = SSNoPowerStockController;