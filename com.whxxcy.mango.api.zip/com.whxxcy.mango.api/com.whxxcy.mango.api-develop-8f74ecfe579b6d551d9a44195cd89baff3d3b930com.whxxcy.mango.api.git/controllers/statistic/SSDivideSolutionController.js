const SSDivideSolution = require('../../models/statistic/ss_divide_solution');
const Controller = require('../Controller');
const BKStockController = require('../../controllers/ebike/BKStockController');
const FNBalanceBillController = require('../../controllers/finance/FNBalanceBillController');
const constants = require('../../settings/constants');

class SSDivideSolutionController extends Controller {
}

SSDivideSolutionController.Model = SSDivideSolution;
module.exports = SSDivideSolutionController;
