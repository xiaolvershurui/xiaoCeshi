const SSSuspectedOrderInDay = require('../../models/statistic/ss_suspected_order_in_day');
const Controller = require('../Controller');

class SSSuspectedOrderInDayController extends Controller {

  static * trigger (suspectedOrders) {
    for (let suspectedOrder of suspectedOrders) {
      const exist = yield this.Model.findOne({ order: suspectedOrder._id });
      if (!exist) {
        yield this.Model.create({
          date: new Date(suspectedOrder.createdAt).format('yyyy/MM/dd'),
          order: suspectedOrder._id,
          distance: suspectedOrder.route.distance,
          totalDuration: suspectedOrder.lease.totalDuration,
          totalAmount: suspectedOrder.payInfo.totalAmount
        })
      } else {
        yield this.Model.findByIdAndUpdate(exist._id, {
          distance: suspectedOrder.route.distance,
          totalDuration: suspectedOrder.lease.totalDuration,
          totalAmount: suspectedOrder.payInfo.totalAmount
        })
      }
    }
  }
}

SSSuspectedOrderInDayController.Model = SSSuspectedOrderInDay;
module.exports = SSSuspectedOrderInDayController;