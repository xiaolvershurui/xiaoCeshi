const SSChangeBatteryInDay = require('../../models/statistic/ss_change_battery_in_day');
const Controller = require('../Controller');

class SSChangeBatteryInDayController extends Controller {


}
SSChangeBatteryInDayController.Model = SSChangeBatteryInDay;
module.exports = SSChangeBatteryInDayController;