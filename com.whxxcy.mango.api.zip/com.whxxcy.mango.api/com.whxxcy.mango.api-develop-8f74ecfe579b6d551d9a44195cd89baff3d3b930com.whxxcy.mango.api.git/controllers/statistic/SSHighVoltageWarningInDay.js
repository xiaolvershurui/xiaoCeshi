const SSHighVoltageWarningInDay = require('../../models/statistic/ss_high_voltage_warning_in_day');
const Controller = require('../Controller');

class SSHighVoltageWarningInDayController extends Controller {

}

SSHighVoltageWarningInDayController.Model = SSHighVoltageWarningInDay;
module.exports = SSHighVoltageWarningInDayController