const SSTaskMonitor = require('../../models/statistic/ss_task_monitor');
const Controller = require('../Controller');

class SSTaskMonitorController extends Controller {

}

SSTaskMonitorController.Model = SSTaskMonitor;
module.exports = SSTaskMonitorController;