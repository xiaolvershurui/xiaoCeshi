const SSTaskInCreaseInDay = require('../../models/statistic/ss_task_increase_in_day');
const Controller = require('../Controller');

class SSTaskIncreaseInDayController extends Controller {

}

SSTaskIncreaseInDayController.Model = SSTaskInCreaseInDay;
module.exports = SSTaskIncreaseInDayController;