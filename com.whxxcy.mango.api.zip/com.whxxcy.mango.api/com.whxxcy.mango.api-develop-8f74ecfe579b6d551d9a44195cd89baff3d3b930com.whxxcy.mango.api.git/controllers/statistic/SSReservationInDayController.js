const SSReservationInDay = require('../../models/statistic/ss_reservation_in_day');
const ODReservationController = require('../../controllers/order/ODReservationController')
const RCNotificationController = require('../../controllers/record/RCNotificationController')
const ODOrderController = require('../../controllers/order/ODOrderController')
const RCErrorController = require('../../controllers/record/RCErrorController');
const dateToId = require('../../utils/dateToId');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class SSReservationInDayController extends Controller {

  static * trigger ({ start, end }) {
    const dateQuery = {
      $gte: start,
      $lt: end
    };
    /*eslint-disable*/
    let ret = yield ODReservationController.Model.mapReduce({
      query: {
        _id: {$gte: dateToId(start), $lt: dateToId(end)}
      },
      map: function () {
        var data = {
          totalCount: 1,
          finishWithReservation: 0,
          reservationTimeOut: 0,
          reservationCancel: 0,
          useOtherStock: 0,
          // reservedAt: 1,
          // finishedAt: 1,
        };
        if (this.state === 2) data.finishWithReservation = 1;
        if (this.cancelReason === 0) data.reservationTimeOut = 1;
        else if (this.cancelReason === 2) data.reservationCancel = 1;
        else if (this.cancelReason === 1) data.useOtherStock = 1;
        emit('1', data);
      },
      reduce: function (key, values) {
        return values.reduce(function (memo, item) {
          memo.totalCount += item.totalCount;
          memo.finishWithReservation += item.finishWithReservation;
          memo.reservationTimeOut += item.reservationTimeOut;
          memo.reservationCancel += item.reservationCancel;
          memo.useOtherStock += item.useOtherStock;
          // const reservationTime = (new Date(item.finishedAt).getTime() - new Date(item.reservedAt).getTime());
          // memo.reservationTimeAvg += (new Date(item.finishedAt).getTime() - new Date(item.reservedAt).getTime());
          // const r = item.reservationCountInMinutes.find(m => m.time === Math.ceil(reservationTime / 60 * 1000) );
          // if (r) {
          //   r.finishWithReservation += r.finishWithReservation + item.finishWithReservation;
          //   r.reservationTimeOut += r.reservationTimeOut + item.reservationTimeOut;
          //   r.reservationCancel += r.reservationCancel + item.reservationCancel;
          //   r.useOtherStock += r.useOtherStock + item.useOtherStock
          // } else {
          //   item.reservationCountInMinutes = [...item.reservationCountInMinutes, {
          //     finishWithReservation: item.finishWithReservation,
          //     reservationTimeOut:  item.reservationTimeOut,
          //     reservationCancel:  item.reservationCancel,
          //     useOtherStock:  item.useOtherStock
          //   }]
          // }
          return memo;
        }, {
          totalCount: 0,
          finishWithReservation: 0,
          reservationTimeOut: 0,
          reservationCancel: 0,
          useOtherStock: 0
          // reservationTimeAvg: 0,
          // reservationCountInMinutes: []
        });
        // result.reservationTimeAvg = result.reservationTimeAvg / values.length;
        // return result;
      },
      readPreference: 'secondary'
    });
    ret = ret.length > 0 ? ret[0].value : {
      totalCount: 0,
      finishWithReservation: 0,
      reservationTimeOut: 0,
      reservationCancel: 0,
      useOtherStock: 0
      // reservationTimeAvg: 0,
    };
    let reservationError = yield RCNotificationController.Model.mapReduce({
      query: {
        createdAt: dateQuery,
        'data.errorExtra.description': "车辆已被预约"
      },
      map: function () {
        var data = {
          reservationFailed: 0,
          reservationScanQRFailed: 0,
          rentFailed: 0,
        };
        if (this.data.errorExtra.code === 'controller.bkStock.stockReserved') data.reservationFailed = 1;
        if (this.data.errorExtra.code === 'controller.bkStock.stockScanQRReserved') data.reservationScanQRFailed = 1;
        else if (this.data.errorExtra.code === 'controller.odReservation.stockReserved') data.rentFailed = 1;
        emit('1', data);
      },
      reduce: function (key, values) {
        return values.reduce(function (memo, item) {
          memo.reservationFailed += item.reservationFailed;
          memo.reservationScanQRFailed += item.reservationScanQRFailed;
          memo.rentFailed += item.rentFailed;
          return memo;
        }, {
          reservationFailed: 0,
          reservationScanQRFailed: 0,
          rentFailed: 0
        });
      },
      readPreference: 'secondary'
    });
    reservationError = reservationError.length > 0 ? reservationError[0].value : {
      reservationFailed: 0,
      reservationScanQRFailed: 0,
      rentFailed: 0
    };
    let reservationErrorTotal = yield RCErrorController.Model.aggregate([{
      $match: {
        createdAt: dateQuery
      }
    }, {
      $group: {
        _id: '$errorType',
        count: {
          $sum: 1
        }
      }
    }]);
    reservationErrorTotal = reservationErrorTotal.reduce((memo, item) => {
      switch (item._id) {
        case constants.RC_ERROR_TYPE.预约:
          memo.reservationFailedTotal += item.count;
          break;
        case constants.RC_ERROR_TYPE.扫码:
          memo.reservationScanQRFailedTotal += item.count;
          break;
        case constants.RC_ERROR_TYPE.下单:
          memo.rentFailedTotal += item.count;
          break;
      }
      return memo;
    }, {
      reservationFailedTotal: 0,
      reservationScanQRFailedTotal: 0,
      rentFailedTotal: 0,
    });

    let orderState = yield ODOrderController.Model.mapReduce({
      query: { finishedAt: dateQuery },
      map: function () {
        var data = {
          totalOrderCount: 1,
          abnormalCount: 0,
          finishCount: 0,
          overTimeCount: 0,
          unMoveCount: 0,
          backEndCount: 0,
          systemEndCount: 0,
          forbiddenCount: 0
        };
        if (this.state === 1) data.abnormalCount = 1;
        else if (this.state === 2) data.finishCount = 1;
        else if (this.state === 3) data.overTimeCount = 1;
        else if (this.state === 4) data.unMoveCount = 1;
        else if (this.state === 5) data.backEndCount = 1;
        else if (this.state === 6) data.systemEndCount = 1;
        else if (this.state === 7) data.forbiddenCount = 1;
        emit('1', data)
      },
      reduce: function (key, values) {
        return values.reduce(function (memo, item) {
          memo.totalOrderCount += item.totalOrderCount;
          memo.abnormalCount += item.abnormalCount;
          memo.finishCount += item.finishCount;
          memo.overTimeCount += item.overTimeCount;
          memo.unMoveCount += item.unMoveCount;
          memo.backEndCount += item.backEndCount;
          memo.systemEndCount += item.systemEndCount;
          memo.forbiddenCount += item.forbiddenCount;
          return memo;
        }, {
          totalOrderCount: 0,
          abnormalCount: 0,
          finishCount: 0,
          overTimeCount: 0,
          unMoveCount: 0,
          backEndCount: 0,
          systemEndCount: 0,
          forbiddenCount: 0
        })
      },
      readPreference: 'secondary'
    });
    orderState = orderState.length > 0 ? orderState[0].value : {
      totalOrderCount: 0,
      abnormalCount: 0,
      finishCount: 0,
      overTimeCount: 0,
      unMoveCount: 0,
      backEndCount: 0,
      systemEndCount: 0,
      forbiddenCount: 0
    };
    ret = Object.assign(ret, reservationError, reservationErrorTotal, orderState);
    ret.date = dateQuery.$gte;
    return ret;
  }
}

SSReservationInDayController.Model = SSReservationInDay;
module.exports = SSReservationInDayController;
