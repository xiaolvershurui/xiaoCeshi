const SSBackHaulInDay = require('../../models/statistic/ss_back_haul_in_day');
const ACUserController = require('../account/ACUserController');
const Controller = require('../Controller');

class SSBackHaulInDayController extends Controller {

  static * create ({ stock, operator }) {
    const acOp = yield ACUserController.findByIdAndCheckExists(operator);
    yield this.Model.create({
      region: stock.region,
      stock: stock._id,
      stockNo: stock.number.custom,
      operator: acOp._id,
      operatorName: acOp.cert.name
    })
  }

}

SSBackHaulInDayController.Model = SSBackHaulInDay;
module.exports = SSBackHaulInDayController;