const SSFinalStockState = require('../../models/statistic/ss_final_stock_state');
const Controller = require('../Controller');

class SSFinalStockStateController extends Controller {

}

SSFinalStockStateController.Model = SSFinalStockState;
module.exports = SSFinalStockStateController;