const SSBalanceInDay = require('../../models/statistic/ss_balance_in_day');
const Controller = require('../Controller');

class SSBalanceInDayController extends Controller {

}

SSBalanceInDayController.Model = SSBalanceInDay;
module.exports = SSBalanceInDayController;