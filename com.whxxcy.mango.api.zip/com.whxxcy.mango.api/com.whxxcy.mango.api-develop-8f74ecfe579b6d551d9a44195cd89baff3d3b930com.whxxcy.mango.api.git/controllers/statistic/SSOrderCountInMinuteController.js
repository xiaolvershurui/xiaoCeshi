const SSOrderCountInMinute = require('../../models/statistic/ss_order_count_in_minute');
const Controller = require('../Controller');

class SSOrderCountInMinuteController extends Controller {

}

SSOrderCountInMinuteController.Model = SSOrderCountInMinute;
module.exports = SSOrderCountInMinuteController;