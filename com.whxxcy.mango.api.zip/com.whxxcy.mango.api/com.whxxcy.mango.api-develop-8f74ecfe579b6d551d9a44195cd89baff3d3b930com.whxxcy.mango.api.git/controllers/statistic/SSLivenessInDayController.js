const SSLivenessInDay = require('../../models/statistic/ss_liveness_in_day');
const Controller = require('../Controller');
/*eslint-disable*/

const thirtyDayObj = (function () {
  const obj = {};
  for (let i = 1; i <= 30; i++) {
    obj[i] = 0;
  }
  return obj;
})();

class SSLivenessInDayController extends Controller {
  static* create (date) {
    yield SSLivenessInDay.create({
      date,
      totalCount: 0,
      reservationCount: 0,
      depositCount: 0,
      orderCount: 0,
      freshInterval: thirtyDayObj,
      registerInterval: thirtyDayObj,
      loginRetentionInterval: thirtyDayObj,
      orderRetentionInterval: thirtyDayObj,
      depositRetentionInterval: thirtyDayObj,
      reservationRetentionInterval: thirtyDayObj,
      newRegisterUserInterval: thirtyDayObj
    })
  }

  static getRelDate (date, timestamp) {
    date = new Date(date);
    timestamp = new Date(timestamp);
    const day = (timestamp.getTime() - date.getTime()) / (1000 * 60 * 60 * 24);
    return parseInt(day);
  }

}

SSLivenessInDayController.Model = SSLivenessInDay;
module.exports = SSLivenessInDayController;