const SSWorkOrderInDay = require('../../models/statistic/ss_work_order_in_day');
const Controller = require('../Controller');

class SSWorkOrderInDayController extends Controller {

}

SSWorkOrderInDayController.Model = SSWorkOrderInDay;
module.exports = SSWorkOrderInDayController;