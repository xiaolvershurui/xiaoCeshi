const SSDepositInDay = require('../../models/statistic/ss_deposit_in_day');
const Controller = require('../Controller');

class SSDepositInDayController extends Controller {

}

SSDepositInDayController.Model = SSDepositInDay;
module.exports = SSDepositInDayController;