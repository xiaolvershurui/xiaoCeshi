const SSErrorInDay = require('../../models/statistic/ss_error_in_day');
const Controller = require('../Controller');

class SSErrorInDayController extends Controller {

}

SSErrorInDayController.Model = SSErrorInDay;
module.exports = SSErrorInDayController;