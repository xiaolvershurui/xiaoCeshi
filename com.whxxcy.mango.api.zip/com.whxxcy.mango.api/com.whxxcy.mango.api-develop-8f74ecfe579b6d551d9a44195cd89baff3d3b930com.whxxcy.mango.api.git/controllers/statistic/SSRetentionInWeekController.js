const SSRetentionInWeek = require('../../models/statistic/ss_retention_in_week');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
/*eslint-disable*/
const eightWeekObj = (function () {
  const obj = {};
  for (let i = 1; i <= 8; i++) {
    obj[i] = 0;
    return obj
  }
})();

class SSRetentionController extends Controller {
  static* create (date) {
    yield SSRetentionInWeek.create({
      date,
      depositCount: 0,
      orderCount: 0,
      depositRetentionInterval: eightWeekObj,
      orderRetentionInterval: eightWeekObj
    })
  }

  static getNearestWeekDate (date) {
    return new Date(constants.SS_RETENTION_IN_WEEK_START_DATE.getTime() + parseInt((new Date(date).getTime() - constants.SS_RETENTION_IN_WEEK_START_DATE.getTime()) / (24 * 3600 * 1000 * 7)) * (24 * 3600 * 1000 * 7));
  }

  static getWeek (date, timestamp) {
    return parseInt((new Date(timestamp).getTime() - new Date(date).getTime()) / (24 * 3600 * 1000 * 7));
  }
}

SSRetentionController.Model = SSRetentionInWeek;
module.exports = SSRetentionController;