const SSSupportInDay = require('../../models/statistic/ss_support_in_day');
const Controller = require('../Controller');

class SSSupportInDayController extends Controller {

}

SSSupportInDayController.Model = SSSupportInDay;
module.exports = SSSupportInDayController;