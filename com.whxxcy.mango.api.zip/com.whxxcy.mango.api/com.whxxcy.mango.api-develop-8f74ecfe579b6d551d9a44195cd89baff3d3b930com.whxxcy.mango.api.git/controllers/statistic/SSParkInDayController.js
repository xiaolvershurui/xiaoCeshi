const SSParkInDay = require('../../models/statistic/ss_park_in_day');
const Controller = require('../Controller');

class SSParkInDayController extends Controller {

}

SSParkInDayController.Model = SSParkInDay;
module.exports = SSParkInDayController;