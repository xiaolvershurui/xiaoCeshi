const SSStockInDay = require('../../models/statistic/ss_stock_in_day');
const Controller = require('../Controller');

class SSStockInDayController extends Controller {
  static get date () {
    return 'today'.beginning;
  }

  static * findOrGenerateByStockInDay (stock) {
    const date = this.date;
    const stockInDay = yield SSStockInDay.findOneAndUpdate({
      stock: stock._id,
      date
    }, {
      $set: {
        region: stock.region,
        style: stock.style,
        stockNo: stock.number.custom
      }
    }, { new: true });
    if (!stockInDay) {
      return yield SSStockInDay.create({
        stock: stock._id,
        region: stock.region,
        style: stock.style,
        stockNo: stock.number.custom,
        date,
      });
    }
    return stockInDay;
  }

  static * trigger (stock, valid, renting, mileageInAll, isOnline) {
    const stockInDay = yield this.findOrGenerateByStockInDay(stock);
    const earliest = new Date(0);
    const {
      latestSetInvalidAt = earliest,
      latestSetValidAt = earliest,
      latestSetUsingAt = earliest,
      latestSetNotUsingAt = earliest,
      latestSetOnlineAt = earliest,
      latestSetOfflineAt = earliest,
    } = stockInDay;
    const data = {};
    const now = new Date();
    if (valid) { // 车辆可用
      data.latestSetValidAt = now;
      if (latestSetValidAt.is.over(latestSetInvalidAt)) { // 上次记录可用时间晚于记录不可用时间
        // 则从上次记录可用时间之后，到现在为止都是可用的
        data.validTime = stockInDay.validTime + (now.getTime() - latestSetValidAt.getTime()).msTo.minute;
        data.validTime = data.validTime.toFixed(2);
      }
    } else { // 车辆不可用，则更新记录不可用时间，直到下次可用为止，validTime都不增长
      data.latestSetInvalidAt = now;
    }
    if (renting) {
      data.latestSetUsingAt = now;
      data.latestSetUsingMileage = mileageInAll;
      if (latestSetUsingAt.is.over(latestSetNotUsingAt)) {
        data.usingTime = stockInDay.usingTime + (now.getTime() - latestSetUsingAt.getTime()).msTo.minute;
        data.usingMileage = stockInDay.usingMileage + (mileageInAll - stockInDay.latestSetUsingMileage);
        data.usingTime = data.usingTime.toFixed(2);
      }
    } else {
      data.latestSetNotUsingAt = now;
    }
    // 车辆在线
    if (isOnline) {
      data.latestSetOnlineAt = now;
      if (latestSetOnlineAt.is.over(latestSetOfflineAt)) {
        data.onlineTime = stockInDay.onlineTime + (now.getTime() - latestSetOnlineAt.getTime()).msTo.minute;
        data.onlineTime = data.onlineTime.toFixed(2);
      }
    } else {
      data.latestSetOfflineAt = now;
      data.setOfflineTimes = stockInDay.setOfflineTimes || 0;
      if (latestSetOnlineAt.is.over(latestSetOfflineAt)) {
        data.setOfflineTimes += 1;
      }
    }
    return yield SSStockInDay.findByIdAndUpdate(stockInDay._id, {
      $set: data
    }, { new: true });
  }
}

SSStockInDayController.Model = SSStockInDay;
module.exports = SSStockInDayController;