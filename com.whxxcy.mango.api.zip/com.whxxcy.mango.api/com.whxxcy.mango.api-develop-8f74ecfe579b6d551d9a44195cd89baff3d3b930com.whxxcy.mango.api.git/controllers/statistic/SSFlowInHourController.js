const SSFlowInHour = require('../../models/statistic/ss_flow_in_hour');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class SSFlowInHourController extends Controller {
  static async findOrGenerateByTime (time = new Date()) {
    const date = time.beginning;
    const hour = time.getHours();
    const flowInHour = await SSFlowInHour.findOne({ date, hour });
    if (!flowInHour) {
      return await SSFlowInHour.create({ date, hour });
    }
    return flowInHour;
  }

  static async trigger (type, amount) {
    const flowInHour = await this.findOrGenerateByTime();
    let data = {};
    switch (type) {
      case constants.SS_FLOW_IN_HOUR_TYPE.支付押金:
        data = { depositCount: 1, depositAmount: amount, totalIncome: amount };
        break;
      case constants.SS_FLOW_IN_HOUR_TYPE.退款押金:
        data = { refundDepositCount: 1, refundDepositAmount: amount, totalOutcome: amount };
        break;
      case constants.SS_FLOW_IN_HOUR_TYPE.充值:
        data = { rechargeCount: 1, rechargeAmount: amount, totalIncome: amount };
        break;
      case constants.SS_FLOW_IN_HOUR_TYPE.退款余额:
        data = { refundBalanceCount: 1, refundBalanceAmount: amount, totalOutcome: amount };
        break;
      default:
    }
    return await SSFlowInHour.findByIdAndUpdate(flowInHour._id, {
      $inc: data
    }, { new: true });
  }

  static * check (time = new Date()) {
    const flowInHour = yield this.findOrGenerateByTime(time);
    const start = `${flowInHour.hour}:00`.at(time);
    const end = '1 hour'.after(start);
    if (flowInHour.checked && new Date().is.over(end)) return;
    const FNTicketController = require('../finance/FNTicketController');
    const recharge = yield FNTicketController.Model.aggregate().read('secondary').match({
      finishedAt: { $gte: start, $lt: end },
    }).group({
      _id: '$type',
      count: { $sum: 1 },
      amount: { $sum: '$amount' }
    });
    const refund = yield FNTicketController.Model.aggregate().read('secondary').match({
      'refund.finishedAt': { $gte: start, $lt: end },
    }).group({
      _id: '$type',
      count: { $sum: 1 },
      amount: { $sum: '$refund.amount' }
    });
    const data = {
      checked: true,
      totalIncome: 0,
      totalOutcome: 0,
      depositCount: 0,
      depositAmount: 0,
      refundDepositAmount: 0,
      refundDepositCount: 0,
      rechargeCount: 0,
      rechargeAmount: 0,
      refundBalanceAmount: 0,
      refundBalanceCount: 0
    };
    recharge.forEach(item => {
      if (item._id === constants.FN_TICKET_TYPE.支付押金) {
        data.depositCount = item.count;
        data.depositAmount = item.amount;
      } else if (item._id === constants.FN_TICKET_TYPE.充值) {
        data.rechargeCount = item.count;
        data.rechargeAmount = item.amount;
      }
      data.totalIncome += item.amount;
    });
    refund.forEach(item => {
      if (item._id === constants.FN_TICKET_TYPE.支付押金) {
        data.refundDepositCount = item.count;
        data.refundDepositAmount = item.amount;
      } else if (item._id === constants.FN_TICKET_TYPE.充值) {
        data.refundBalanceCount = item.count;
        data.refundBalanceAmount = item.amount;
      }
      data.totalOutcome += item.amount;
    });
    return yield SSFlowInHour.findByIdAndUpdate(flowInHour._id, {
      $set: data
    }, { new: true });
  }
}

SSFlowInHourController.Model = SSFlowInHour;
module.exports = SSFlowInHourController;
