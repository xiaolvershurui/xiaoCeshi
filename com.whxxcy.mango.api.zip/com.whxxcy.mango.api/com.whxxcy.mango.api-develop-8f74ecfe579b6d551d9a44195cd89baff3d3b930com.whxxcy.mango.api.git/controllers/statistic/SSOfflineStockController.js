const SSOfflineStock = require('../../models/statistic/ss_offline_stock');
const Controller = require('../Controller');

class SSOfflineStockController extends Controller {

  static * trigger (stock) {
    const offlineStock = yield SSOfflineStock.findOne({ stock });
    if (offlineStock) {
      yield SSOfflineStock.findByIdAndRemove(offlineStock._id)
    }
  }

}

SSOfflineStockController.Model = SSOfflineStock;
module.exports = SSOfflineStockController;