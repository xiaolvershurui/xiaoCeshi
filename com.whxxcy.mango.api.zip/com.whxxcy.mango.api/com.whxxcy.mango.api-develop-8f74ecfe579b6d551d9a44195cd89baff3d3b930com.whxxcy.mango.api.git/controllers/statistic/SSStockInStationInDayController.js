const SSStockInStationInDay = require('../../models/statistic/ss_stock_in_station_in_day');
const Controller = require('../Controller');
const RCStockOpController = require('../../controllers/record/RCStockOpController');
const BKStockController = require('../../controllers/ebike/BKStockController');
const OPBatteryStationController = require('../../controllers/operation/OPBatteryStationController');
const constants = require('../../settings/constants');
class SSStockInStationInDayController extends Controller {

  static * trigger ({date = 'today'.beginning}) {
    const stations = yield OPBatteryStationController.Model.find({ enable: true });
    const ret = [];
    for (let station of stations) {
      const data = {
        _id: yield this.Model.genId(),
        date,
        inboundCount: 0,
        outboundCount: 0,
        station: station._id,
        stationName: station.name,
        totalCount: yield BKStockController.Model.count({ station: station._id, locate: constants.BK_LOCATE.仓库 })
      };
      const result = yield RCStockOpController.Model.aggregate()
        .match({
          createdAt: { $gte: date, $lt: date.ending },
          type: { $in: [constants.RC_STOCK_OP_TYPE.入库, constants.RC_STOCK_OP_TYPE.出库] },
          $or: [{ 'inBound.nextStation': station._id }, { 'outBound.prevStation': station._id }]
        })
        .group({
          _id: { stock: '$stock', type: '$type' },
        })
        .group({
          _id: '$_id.type',
          count: { $sum: 1 }
        });
      result.forEach(item => {
        if (item._id === constants.RC_STOCK_OP_TYPE.入库) {
          data.inboundCount = item.count
        } else {
          data.outboundCount = item.count
        }
      });
      ret.push(data);
    }
    return ret;
  }
}

SSStockInStationInDayController.Model = SSStockInStationInDay;
module.exports = SSStockInStationInDayController;