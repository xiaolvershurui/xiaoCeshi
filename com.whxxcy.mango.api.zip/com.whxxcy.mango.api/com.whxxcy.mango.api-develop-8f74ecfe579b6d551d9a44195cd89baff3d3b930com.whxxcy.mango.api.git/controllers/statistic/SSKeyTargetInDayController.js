const SSKeyTargetInDay = require('../../models/statistic/ss_key_target_in_day');
const Controller = require('../Controller');

class SSKeyTargetInDayController extends Controller {


}

SSKeyTargetInDayController.Model = SSKeyTargetInDay;
module.exports = SSKeyTargetInDayController;