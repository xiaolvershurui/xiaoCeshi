const SSInspectInDay = require('../../models/statistic/ss_inspect_in_day');
const Controller = require('../Controller');
const RCStockOpController = require('../record/RCStockOpController');
const RCOperatorCaptureController = require('../record/RCOperatorCaptureController');
const constants = require('../../settings/constants');
const geolib = require('geolib');
const ACUserController = require('../account/ACUserController');
const ACOperatorController = require('../account/ACOperatorController');

class SSInspectInDayController extends Controller {
  static * trigger ({
    user,
    checkInAt,
    checkOutAt,
    totalWorkTime,
    wrongCount,
    missCount,
    wrongStock
  }) {
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    const operator = yield ACOperatorController.Model.findOne({ user: userData._id });
    const findStockOps = yield RCStockOpController.Model.find({
      operator: user,
      operatedAt: {
        $gte: checkInAt,
        $lte: checkOutAt
      },
      type: constants.RC_STOCK_OP_TYPE.找车打卡,
    }).sort({ _id: 1 });
    // 巡检时间
    let inspectTime = 0;
    if (findStockOps.length >= 2) {
      inspectTime = (findStockOps[findStockOps.length - 1].createdAt.getTime() - findStockOps[0].createdAt.getTime()).msTo.minute;
    }
    // 找车情况
    const { total, success, valid, self, info, finish, releasedOffline, returnBack, putIn, driverNotFound, dayNotFound, superiorNotFound, offlineReturnBack, batteryUnLockOn, unHandle } = findStockOps.reduce((memo, op) => {
      const isValid = (_ => {
        if ([
            constants.BK_TASK_TYPE.低电,
            constants.BK_TASK_TYPE.低压预警,
            constants.BK_TASK_TYPE.高压预警,
            constants.BK_TASK_TYPE.围栏外非免单
          ].some(code => op.prevTaskList.search({ code }))) {
          return true;
        }
        return op.prevTaskList.length > 0 && op.inspector === user;
      })();
      if (!memo.info[op.stock]) {
        memo.info[op.stock] = {
          stock: op.stock,
          stockNo: op.stockNo,
          hasFound: op.findStock.hasFind,
          prevLocate: op.locate,
          lastLocate: op.locate,
          foundAt: op.operatedAt,
          prevTaskList: op.prevTaskList,
          lastTaskList: op.prevTaskList,
          addedTasks: [],
          releasedTasks: [],
          inspector: op.inspector,
          inspectorName: op.inspectorName,
          inspectorTel: op.inspectorTel,
          valid: isValid,
          batteryLockOn: op.findStock.batteryLockOn,
          unHandle: [],
          self: op.inspector === user,
        };
        // 有效任务
        if (isValid) {
          memo.valid.add(op.stock);
        }
      }
      // 总数
      memo.total.add(op.stock);
      // 有效任务才计入统计
      if (memo.valid.includes(op.stock)) {
        // 重置巡检结果
        memo.info[op.stock].hasFound = op.findStock.hasFind;
        // 找到的车辆
        if (op.findStock.hasFind) {
          memo.success.add(op.stock);
        } else {
          // 未找到车辆
          memo.success.remove(op.stock);
        }
        // 属于自己任务
        if (op.inspector === user) {
          memo.self.add(op.stock);
        }
        // 是否锁好电池
        if (!op.findStock.batteryLockOn) {
          memo.batteryUnLockOn.add(op.stock)
        }
      }
      // 重置最后打卡时的任务列表
      memo.info[op.stock].lastTaskList = op.prevTaskList;
      if (memo.info[op.stock].lastTaskList.search({ code: constants.BK_TASK_TYPE.断电 }) && !memo.info[op.stock].lastTaskList.search({ code: constants.BK_TASK_TYPE.真离线 })) {
        memo.unHandle.add(op.stock);
      } else {
        memo.unHandle.remove(op.stock);
      }
      memo.info[op.stock].lastLocate = op.locate;
      const prevTaskList = memo.info[op.stock].prevTaskList;
      const lastTaskList = memo.info[op.stock].lastTaskList;
      memo.info[op.stock].addedTasks = lastTaskList.filter(task => !prevTaskList.search({ code: task.code }));
      const releasedTasks = memo.info[op.stock].releasedTasks = prevTaskList.filter(task => !lastTaskList.search({ code: task.code }));
      // 司机未找到: 401,
      //   白班未找到: 402,
      //   高手未找到: 403,
      if (releasedTasks.search({ code: constants.BK_TASK_TYPE.司机未找到 }) && memo.info[op.stock].hasFound) {
        memo.driverNotFound.add(op.stock);
        memo.dayNotFound.remove(op.stock);
        memo.superiorNotFound.remove(op.stock);
      } else if (releasedTasks.search({ code: constants.BK_TASK_TYPE.白班未找到 }) && memo.info[op.stock].hasFound) {
        memo.driverNotFound.remove(op.stock);
        memo.dayNotFound.add(op.stock);
        memo.superiorNotFound.remove(op.stock);
      } else if (releasedTasks.search({ code: constants.BK_TASK_TYPE.高手未找到 }) && memo.info[op.stock].hasFound) {
        memo.driverNotFound.remove(op.stock);
        memo.dayNotFound.remove(op.stock);
        memo.superiorNotFound.add(op.stock);
      } else {
        // if (releasedTasks.search({ code: constants.BK_TASK_TYPE.难寻 }) && memo.info[op.stock].hasFound) {
        //   memo.difficultFind.add(op.stock);
        // } else {
        memo.driverNotFound.remove(op.stock);
        memo.dayNotFound.remove(op.stock);
        memo.superiorNotFound.remove(op.stock);
        // 投放的数量
        if (memo.info[op.stock].prevLocate === constants.BK_LOCATE.仓库 && [constants.BK_LOCATE.空闲, constants.BK_LOCATE.在租, constants.BK_LOCATE.预约].includes(memo.info[op.stock].lastLocate)) {
          memo.putIn.add(op.stock);
        } else if (memo.info[op.stock].prevLocate !== constants.BK_LOCATE.仓库 && memo.info[op.stock].lastLocate === constants.BK_LOCATE.仓库) {
          // 拖回的数量
          memo.returnBack.add(op.stock);
          if (memo.info[op.stock].prevTaskList.search({ code: constants.BK_TASK_TYPE.真离线 })) {
            memo.offlineReturnBack.add(op.stock);
          } else {
            memo.offlineReturnBack.remove(op.stock);
          }
        } else {
          memo.returnBack.remove(op.stock);
          memo.offlineReturnBack.remove(op.stock);
          // 释放的离线任务数量
          if (releasedTasks.search({ code: constants.BK_TASK_TYPE.真离线 })) {
            memo.releasedOffline.add(op.stock);
          } else {
            memo.releasedOffline.remove(op.stock);
          }
          if (releasedTasks.length >= 1 && memo.info[op.stock].hasFound && memo.valid.includes(op.stock)) {
            memo.finish.add(op.stock);
          } else {
            memo.finish.remove(op.stock);
          }
        }
      }
      return memo;
    }, {
      total: [],
      success: [],
      self: [],
      valid: [],
      finish: [],
      releasedOffline: [],
      returnBack: [],
      putIn: [],
      driverNotFound: [],
      dayNotFound: [],
      superiorNotFound: [],
      batteryUnLockOn: [],
      offlineReturnBack: [],
      unHandle: [],
      info: {},
    });

    // 巡检里程
    const points = yield RCOperatorCaptureController.Model.find({
      snappedAt: {
        $gte: checkInAt,
        $lt: checkOutAt,
      },
      user,
      lngLat: { $exists: true }
    }).sort({ snappedAt: 1 });
    const { mileage } = points.reduce((memo, point) => {
      if (!point.lngLat || !point.lngLat[0]) return memo;
      if (memo.prevPoint) {
        memo.mileage += geolib.getDistance({
          longitude: memo.prevPoint.lngLat[0],
          latitude: memo.prevPoint.lngLat[1],
        }, {
          longitude: point.lngLat[0],
          latitude: point.lngLat[1],
        });
      }
      memo.prevPoint = point;
      return memo;
    }, { prevPoint: null, mileage: 0 });

    // 每小时找车数
    const foundPerHour = inspectTime > 0 ? parseFloat((total.length / (inspectTime / 60)).toFixed(2)) : 0;
    // 平均每车通勤里程
    const mileagePerFound = total.length > 0 ? parseFloat((mileage / total.length).toFixed(2)) : 0;

    // 未处理任务数
    const BKStockController = require('../ebike/BKStockController');

    /*eslint-disable*/
    const unresolvedTasks = yield BKStockController.Model.aggregate().match({
      inspector: user,
      hasTask: true
    }).group({
      _id: '$taskGroup',
      count: { $sum: 1 }
    });

    return yield SSInspectInDay.create({
      date: checkOutAt,
      inspector: userData._id,
      inspectorName: userData.cert.name,
      inspectorTel: userData.auth.tel,
      stockType: operator.stockInfo.type,
      stockSource: operator.stockInfo.source,
      checkIn: checkInAt,
      checkOut: checkOutAt,
      workTime: totalWorkTime,
      selfTask: self.length,
      validCount: valid.length,
      firstOp: findStockOps[0] && findStockOps[0].createdAt,
      lastOp: findStockOps[findStockOps.length - 1] && findStockOps[findStockOps.length - 1].createdAt,
      inspectTime,
      taskCount: total.length,
      hasFind: success.length,
      finished: finish.length,
      foundSuccessRate: valid.length > 0 ? parseFloat((success.length / valid.length).toFixed(2)) : 0,
      finishedRate: valid.length > 0 ? parseFloat((finish.length / valid.length).toFixed(2)) : 0,
      distance: mileage,
      foundInfo: Object.keys(info).map(key => info[key]),
      foundPerHour,
      mileagePerFound,
      releasedOffline: releasedOffline.length,
      returnBack: returnBack.length,
      putIn: putIn.length,
      driverNotFound: driverNotFound.length,
      dayNotFound: dayNotFound.length,
      superiorNotFound: superiorNotFound.length,
      offlineReturnBack: offlineReturnBack.length,
      batteryUnLockOn: batteryUnLockOn.length,
      unHandle: unHandle.length,
      unresolvedTasks: unresolvedTasks.reduce((memo, item) => {
        memo[item._id] = item.count;
        return memo;
      }, []),
      wrongCount,
      missCount,
      wrongStock
    });
  }
}

SSInspectInDayController.Model = SSInspectInDay;
module.exports = SSInspectInDayController;