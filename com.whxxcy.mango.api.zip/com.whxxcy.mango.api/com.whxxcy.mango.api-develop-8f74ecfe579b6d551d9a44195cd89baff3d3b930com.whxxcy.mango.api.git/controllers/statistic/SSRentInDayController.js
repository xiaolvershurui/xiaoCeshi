const SSRentInDay = require('../../models/statistic/ss_rent_in_day');
const Controller = require('../Controller');

class SSRentInDayController extends Controller {

}

SSRentInDayController.Model = SSRentInDay;
module.exports = SSRentInDayController;
