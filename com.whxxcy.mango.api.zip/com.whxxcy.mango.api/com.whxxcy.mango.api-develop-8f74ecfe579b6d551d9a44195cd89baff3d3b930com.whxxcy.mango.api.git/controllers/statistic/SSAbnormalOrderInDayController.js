const SSAbnormalOrderInDay = require('../../models/statistic/ss_abnormal_order_in_day');
const Controller = require('../Controller');

class SSAbnormalOrderInDayController extends Controller {

  static * trigger ({ state, stock, user }) {
    const date = 'today'.beginning;
    const ssAbnormal = yield SSAbnormalOrderInDay.findOne({ state, stock: stock._id, date });
    if (ssAbnormal) {
      let data = {
        $inc: {
          orderCount: 1
        }
      };
      if (!ssAbnormal.users.includes(user)) {
        data.$inc.userCount = 1;
        data.$addToSet = { users: user }
      }
      yield SSAbnormalOrderInDay.findByIdAndUpdate(ssAbnormal._id, data)
    } else {
      yield SSAbnormalOrderInDay.create({
        date,
        region: stock.region,
        stock: stock._id,
        stockNo: stock.number.custom,
        state,
        orderCount: 1,
        users: [user],
        userCount: 1
      })
    }
  }
}

SSAbnormalOrderInDayController.Model = SSAbnormalOrderInDay;
module.exports = SSAbnormalOrderInDayController;