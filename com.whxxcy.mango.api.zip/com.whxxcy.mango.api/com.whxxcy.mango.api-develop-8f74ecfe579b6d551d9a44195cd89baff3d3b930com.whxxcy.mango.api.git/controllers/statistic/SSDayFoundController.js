const SSDayFound = require('../../models/statistic/ss_day_found');
const Controller = require('../Controller');

class SSDayFoundController extends Controller {

  static * create ({ stock, operator, noFoundOperator }) {
    yield this.Model.create({
      stock: stock._id,
      region: stock.region,
      operator,
      noFoundOperator,
      taskGroup: stock.taskGroup,
      highestTask: stock.highestTask
    })
  }
}

SSDayFoundController.Model = SSDayFound;
module.exports = SSDayFoundController;