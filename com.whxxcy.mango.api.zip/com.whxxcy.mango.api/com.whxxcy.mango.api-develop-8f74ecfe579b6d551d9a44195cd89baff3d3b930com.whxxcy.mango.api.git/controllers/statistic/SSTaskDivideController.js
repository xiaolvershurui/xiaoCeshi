const SSTaskDivide = require('../../models/statistic/ss_task_divide');
const Controller = require('../Controller');

class SSTaskDivideController extends Controller {

}

SSTaskDivideController.Model = SSTaskDivide;
module.exports = SSTaskDivideController;