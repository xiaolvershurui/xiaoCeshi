const SSShareInDay = require('../../models/statistic/ss_share_in_day');
const Controller = require('../Controller');

class SSShareInDayController extends Controller {
}

SSShareInDayController.Model = SSShareInDay;
module.exports = SSShareInDayController;
