const BKLicense = require('../../models/ebike/bk_license');
const Controller = require('../Controller');
const Error = require('errrr');

class BKLicenseController extends Controller {

}

BKLicenseController.Model = BKLicense;
module.exports = BKLicenseController;