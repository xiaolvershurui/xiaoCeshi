const Controller = require('../Controller');
const BKBox = require('../../models/ebike/bk_box');
const constants = require('../../settings/constants');
const Error = require('errrr');
const BKStockController = require('../../controllers/ebike/BKStockController');
const ODOrderController = require('../../controllers/order/ODOrderController');
const RCStockPointController = require('../../controllers/record/RCStockPointController');
const RCStockOpController = require('../../controllers/record/RCStockOpController');
const IoT = require('../../IoT');
const geolib = require('geolib');
const { judgement, asyncTask } = require('xx-utils');
const logger = require('../../services/logger');
// const pubSubCenter = require('../../IoT/pubSubCenter');
const OPStyleController = require('../../controllers/operation/OPStyleController');
const OPRegionController = require('../../controllers/operation/OPRegionController');
const OPPolygonController = require('../../controllers/operation/OPPolygonController');
const calculateDistanceBetweenPointAndPolygon = require('../../utils/calculateDistanceBetweenPointAndPolygon');
const errorHandler = require('../../services/errorHandler');
const amap = require('../../services/amap');
const simService = require('../../services/sim');
const shark = require('../../services/shark');

// const node = pubSubCenter.getNode();

class BKBoxController extends Controller {
  static * create ({
    deviceId,
    model,
    voltageRange,
    sn,
    dataSource,
    activateExpires,
    number,
    activatedAt
  }) {
    if (yield BKBox.findById(deviceId)) throw new Error('设备已经存在');
    return yield BKBox.create({
      _id: deviceId,
      info: { deviceId, model, voltageRange, sn, dataSource },
      sim: { activatedAt, activateExpires, number }
    });
  }

  static * findByIdAndCheckExists (id) {
    const box = yield BKBox.findById(id);
    if (!box) throw new Error('设备不在线');
    return box;
  }

  static * findAndCreateByDeviceId (deviceId, dataSource = constants.BK_BOX_DATA_SOURCE.小安宝) {
    if (!constants.BK_BOX_DATA_SOURCE_ENUMS.includes(dataSource)) return null;
    if (!deviceId) return null;
    const box = yield BKBox.findById(deviceId);
    if (!box) {
      return yield this.create({ deviceId, dataSource });
    } else if (box.info.dataSource !== dataSource) {
      return yield BKBox.findByIdAndUpdate(deviceId, {
        $set: {
          'info.dataSource': dataSource
        }
      }, { new: true });
    }
    return box;
  }

  static * forceUpdate (deviceId) {
    const data = yield this.getInfo(deviceId);
    yield this.updateRealTimeInfoNew(data);
    return data;
  }


  static * getInfo (id) {
    return yield IoT.at(id).getInfo();
  }

  static * updateRealTimeInfoNew (data = {}) {
    let {
      success, appVersion, deviceType, deviceId, acc, lock, batteryLock,
      powerUnlink, wheelLock, isOnline, time = new Date(),
      location = {}, extra = {}, alarms = [], dataSource = constants.BK_BOX_DATA_SOURCE.小安宝, sim, gateway,
      nodeId, bin, cmd,
    } = data;

    const { lngLat = null, type, address, speed, alt, direction } = location;

    if (judgement.isEmpty(isOnline) || isOnline) {
      shark.send({
        c: 'ebike/box/report',
        params: {
          deviceId,
          ds: dataSource,
          status: {
            accOn: acc,
            lockOn: lock,
            wheelLockOn: wheelLock,
            batteryLockOn: batteryLock,
            powerUnlink,
            voltage: extra.voltage,
            signal: extra.signal,
          },
          gpsLocation: lngLat && lngLat[0] > 0 && lngLat[1] > 0 ? {
              lngLat,
              speed,
              direction,
              time,
              transformed: true,
            } : {},
          nId: nodeId,
          appVersion
        }
      });
    } else if(deviceId) {
      shark.send({
        c: 'ebike/box/logout',
        params: { deviceId }
      });
    }
  }


  static * querySIM (ids) {
    const msisdns = [];
    const boxes = {};
    for (let id of ids) {
      const box = yield this.findByIdAndCheckExists(id);
      if (box.sim.imsi && !box.sim.msisdn) {
        const { success, error, msisdn, ccid, expiryDate, dataUsage, dataBalance } = yield simService.queryCard(box.sim.imsi);
        if (success) {
          box.sim.ccid = ccid;
          box.sim.msisdn = msisdn;
          box.sim.expiryDate = expiryDate;
          box.sim.dataUsage = dataUsage;
          box.sim.dataBalance = dataBalance;
          box.sim.invalid = false;
        } else if (error.message === '物联网卡不存在') {
          box.sim.invalid = true;
        }
      }
      if (box.sim.msisdn) {
        msisdns.push(box.sim.msisdn);
        boxes[box.sim.msisdn] = box;
      }
      yield box.save();
    }
    if (msisdns.length > 0) {
      const { success, sent } = yield simService.sendSMS(msisdns, '1');
      if (success) {
        for (let m of sent) {
          const box = boxes[m];
          const stock = yield BKStockController.Model.findOne({ box: box._id });
          box.sentSMSAt = new Date();
          box.sim.powerOn = false;
          box.sim.working = false;
          if (stock) {
            stock.sim.powerOn = false;
            stock.sim.working = false;
            yield stock.save();
          }
          yield box.save();
        }
      }
    }
  }

  static * triggerSMS (msisdn) {
    const box = yield BKBox.findOne({ 'sim.msisdn': msisdn });
    if (!box) return;
    box.sim.powerOn = true;
    box.sim.working = true;
    const stock = yield BKStockController.Model.findOne({ box: box._id });
    if (stock) {
      stock.sim.powerOn = true;
      stock.sim.working = true;
    }
    return yield box.save();
  }

}

BKBoxController.Model = BKBox;
module.exports = BKBoxController;
