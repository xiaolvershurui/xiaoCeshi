const Controller = require('../Controller');
const BKDamage = require('../../models/ebike/bk_damage');
const BKStock = require('../../models/ebike/bk_stock');
const BKStockController = require('../ebike/BKStockController');
const RCStockOpController = require('../record/RCStockOpController');
const constants = require('../../settings/constants');
const Error = require('errrr');

class BKDamageController extends Controller {

  * updateStockState (stock, damageId, { operator, operateLocation, damage, addDamage }) {
    const damages = yield BKDamage.find({
      _id: { $ne: damageId },
      stock,
      state: { $ne: constants.BK_DAMAGE_STATE.已修复 },
    });
    if (!damageId) {
      damages.push(damage);
    }
    const stockStates = damages.map(damage => damage.stockState);
    let nextState = constants.BK_STATE.完好;
    if (stockStates.includes(constants.BK_STATE.报废)) nextState = constants.BK_STATE.报废;
    else if (stockStates.includes(constants.BK_STATE.损坏不可租)) nextState = constants.BK_STATE.损坏不可租;
    else if (stockStates.includes(constants.BK_STATE.损坏可租)) nextState = constants.BK_STATE.损坏可租;
    return yield new BKStockController(this.transaction).updateState(stock, nextState, {
      operator,
      operateLocation,
      damage,
      addDamage,
    });
  }

  * create ({
    stock,
    description,
    photo,
    state,
    mountings,
    submitter,
  }, {
    operator,
    operateLocation,
  }) {
    const bkStock = yield BKStock.findById(stock);
    if (!bkStock) throw new Error('不存在该库存');
    const now = new Date();
    const damage = yield this.T(BKDamage).create({
      _id: yield BKDamage.genId(),
      stock,
      description,
      recordedAt: now,
      notifiedAt: now,
      mountings,
      photo,
      submitter,
      stockState: state,
    });
    yield this.updateStockState(stock, null, {
      operator,
      operateLocation,
      damage,
      addDamage: true,
    });
    return damage;
  }

  static * findByIdAndCheckExists (id) {
    const damage = yield BKDamage.findById(id);
    if (!damage) throw new Error('损坏记录不存在');
    return damage;
  }

  * repair (id, {
    repairer,
    repairPhoto,
    repairRemark,
    stock,
  }, {
    operator,
    operateLocation,
  }) {
    let damage = yield BKDamageController.findByIdAndCheckExists(id);
    if (stock !== damage.stock) throw new Error('不是该车辆的损坏记录');
    damage = yield this.T(BKDamage).findByIdAndUpdate(id, {
      $set: {
        state: constants.BK_DAMAGE_STATE.已修复,
        repairedAt: new Date(),
        repairRemark,
        repairPhoto,
        repairer,
      },
    }, { new: true });
    yield this.updateStockState(damage.stock, damage._id, {
      operator,
      operateLocation,
      damage,
      addDamage: false,
    });
    return damage;
  }

  static * repairAll (stock, operator) {
    const damages = yield BKDamageController.Model.find({
      stock: stock._id,
      state: { $ne: constants.BK_DAMAGE_STATE.已修复 },
    });
    yield BKStockController.Model.findByIdAndUpdate(stock._id, {
      state: constants.BK_STATE.完好,
    });
    yield BKDamageController.Model.update({ _id: { $in: damages.map(damage => damage._id) } }, {
      $set: {
        state: constants.BK_DAMAGE_STATE.已修复,
      },
    }, { multi: true });
    for (let damage of damages) {
      yield RCStockOpController.opRepairDamage({ stock: stock._id, operator }, {
        damage,
        prevStockState: stock.state,
        nextStockState: constants.BK_STATE.完好,
      });
    }
  }
}

BKDamageController.Model = BKDamage;
module.exports = BKDamageController;
