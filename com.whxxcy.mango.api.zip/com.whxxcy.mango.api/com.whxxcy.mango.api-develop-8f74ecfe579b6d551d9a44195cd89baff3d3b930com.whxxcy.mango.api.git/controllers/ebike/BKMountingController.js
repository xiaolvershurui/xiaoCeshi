const BKMounting = require('../../models/ebike/bk_mounting');
const RCMountingOp = require('../../models/record/rc_mounting_op');
const RCMountingOpController = require('../../controllers/record/RCMountingOpController');
const OPRegionController = require('../operation/OPRegionController');
const OPBatteryStationController = require('../operation/OPBatteryStationController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class BKMountingController extends Controller {

  static * checkValid ({ region, station }) {
    yield OPRegionController.findByIdAndCheckExists(region);
    yield OPBatteryStationController.findByIdAndCheckExists(station);
  }

  * create ({ type, region, station, count }) {
    yield this.checkValid({ region, station });
    // 默认新添加的物资都是完好的
    yield this.Model.create({
      type,
      region,
      station,
      count,
      intactCount: count
    })
  }

  static * findByIdAndCheckExists (id) {
    const mounting = yield this.Model.findById(id);
    if (!mounting) throw new Error('不存在该配件类型');
    return mounting;
  }

  * use ({ mounting, count, operator }) {
    yield this.T(BKMounting).findByIdAndUpdate(mounting, {
      $inc: {
        count: -count
      }
    });
    yield this.T(RCMountingOp).create({
      mounting,
      count,
      operator
    })
  }

}

BKMountingController.Model = BKMounting;
module.exports = BKMountingController;