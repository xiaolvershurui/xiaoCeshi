const BKReceipt = require('../../models/ebike/bk_receipt');
const ACUserController = require('../account/ACUserController');
const BKMountingController = require('../ebike/BKMountingController');
const Controller = require('../Controller');
const constants = require('../../settings/constants');

class BKReceiptController extends Controller {

  * findByIdAndCheckExists (id) {
    const receipt = yield this.Model.findById(id);
    if (!receipt) throw new Error('不存在该单据');
    return receipt;
  }

  static * create ({ id, type, receiver, createWithIntactMounting, createWithDamageMounting, station }) {
    // 调度 领取清单 减去仓库配件数量
    if ([constants.BK_RECEIPT_TYPE.调度清单, constants.BK_RECEIPT_TYPE.领取清单, constants.BK_RECEIPT_TYPE.返修清单].includes(type)) {
      if (createWithIntactMounting) {
        for (let mounting of createWithIntactMounting) {
          yield BKMountingController.Model.findOneAndUpdate({ code: mounting.code, station: station._id }, {
            $inc: {
              intactCount: -mounting.count,
              count: -mounting.count
            }
          })
        }
      }
      if (createWithDamageMounting) {
        for (let mounting of createWithDamageMounting) {
          yield BKMountingController.Model.findOneAndUpdate({ code: mounting.code, station: station._id }, {
            $inc: {
              damageCount: -mounting.count,
              count: -mounting.count
            }
          })
        }
      }
    }
    return yield this.Model.create({
        _id: yield this.Model.genId(),
        creator: id,
        receiver,
        station,
        type,
        createWithIntactMounting,
        createWithDamageMounting
      }
    )
  }


  static * handle ({ handler, id, finishWithIntactMounting, finishWithDamageMounting, remark, purchasePhoto }) {
    const receipt = yield this.Model.findById(id);
    if (finishWithIntactMounting) {
      for (let mounting of finishWithIntactMounting) {
        yield BKMountingController.Model.findOneAndUpdate({ code: mounting.code, station: receipt.station }, {
          $inc: {
            intactCount: mounting.count,
            count: mounting.count
          }
        })
      }
    }
    if (finishWithDamageMounting) {
      for (let mounting of finishWithDamageMounting) {
        yield BKMountingController.Model.findOneAndUpdate({ code: mounting.code, station: receipt.station }, {
          $inc: {
            damageCount: mounting.count,
            count: mounting.count
          }
        })
      }
    }
    yield this.Model.findByIdAndUpdate(id, {
      $set: {
        finishedAt: new Date(),
        handler,
        purchasePhoto,
        finishWithIntactMounting,
        finishWithDamageMounting,
        remark
      }
    })
  }
}

BKReceiptController.Model = BKReceipt;
module.exports = BKReceiptController;