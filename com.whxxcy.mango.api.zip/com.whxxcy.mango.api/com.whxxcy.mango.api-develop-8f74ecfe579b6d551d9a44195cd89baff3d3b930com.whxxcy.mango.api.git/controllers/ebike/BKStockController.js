const BKStock = require('../../models/ebike/bk_stock');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');
const OPRegionController = require('../operation/OPRegionController');
const OPStyleController = require('../operation/OPStyleController');
const SSStockInDayController = require('../statistic/SSStockInDayController');
const OPPolygonController = require('../operation/OPPolygonController');
const OPBatteryStationController = require('../operation/OPBatteryStationController');
const RCStockOpController = require('../record/RCStockOpController');
const ACOperatorController = require('../account/ACOperatorController');
const ACUserController = require('../account/ACUserController');
const SSOfflineStockController = require('../statistic/SSOfflineStockController');
const SSDayFoundController = require('../statistic/SSDayFoundController');
const SSDriverFoundController = require('../statistic/SSDriverFoundController');
const SSBackHaulInDayController = require('../statistic/SSBackHaulInDayController');
const SSNoPowerStockController = require('../statistic/SSNoPowerStockController');
const RCFeedLossController = require('../record/RCFeedLossController');
const BKBikeIdentifierController = require('../ebike/BKBikeIdentifierController');
const utils = require('xx-utils');
const oss = require('../../services/oss');
const { judgement, asyncTask } = require('xx-utils');
const calculateDistanceBetweenPointAndPolygon = require('../../utils/calculateDistanceBetweenPointAndPolygon');
const geolib = require('geolib');
const errorHandler = require('../../services/errorHandler');
const sim = require('../../services/sim');
const amap = require('../../services/amap');

class BKStockController extends Controller {

  static *findByNumberOrLicense(number, license) {
    let stock;
    if (number) {
      stock = yield BKStock.findOne({ 'number.custom': number });
    } else if (license) {
      stock = yield BKStock.findOne({ 'number.license': license });
    }
    return stock;
  }

  *checkNumberValid(number, id) {
    const vinQuery = { 'number.vin': number.vin };
    const customQuery = { 'number.custom': number.custom };
    const licenseQuery = { 'number.license': number.license };
    const certQuery = { 'number.cert': number.cert };
    if (id) {
      const idQuery = { $ne: id };
      vinQuery._id = idQuery;
      customQuery._id = idQuery;
      licenseQuery._id = idQuery;
      certQuery._id = idQuery;
    }
    if (number.vin && (yield BKStock.findOne(vinQuery))) {
      throw new Error('该车架号已被使用');
    }
    if (number.custom && (yield BKStock.findOne(customQuery))) {
      throw new Error('该自定义车牌号已被使用');
    }
    if (number.license && (yield BKStock.findOne(licenseQuery))) {
      throw new Error('该交管局车牌号已被使用');
    }
    if (number.cert && (yield BKStock.findOne(certQuery))) {
      throw new Error('该合格证号已经被使用');
    }
  }

  static *checkNumberValid(number, id) {
    const vinQuery = { 'number.vin': number.vin };
    const customQuery = { 'number.custom': number.custom };
    const licenseQuery = { 'number.license': number.license };
    const certQuery = { 'number.cert': number.cert };
    if (id) {
      const idQuery = { $ne: id };
      vinQuery._id = idQuery;
      customQuery._id = idQuery;
      licenseQuery._id = idQuery;
      certQuery._id = idQuery;
    }
    if (number.vin && (yield BKStock.findOne(vinQuery))) {
      throw new Error('该车架号已被使用');
    }
    if (number.custom && (yield BKStock.findOne(customQuery))) {
      throw new Error('该自定义车牌号已被使用');
    }
    if (number.license && (yield BKStock.findOne(licenseQuery))) {
      throw new Error('该交管局车牌号已被使用');
    }
    if (number.cert && (yield BKStock.findOne(certQuery))) {
      throw new Error('该合格证号已经被使用');
    }
  }

  static *checkBoxValid(box, id) {
    const boxQuery = { box };
    if (id) {
      boxQuery._id = { $ne: id };
    }
    if (yield BKStock.findOne(boxQuery)) {
      throw new Error('该盒子已经被绑定');
    }
    if (yield ACOperatorController.Model.findOne({ box })) {
      throw new Error('该盒子已经被巡检绑定,请到运营账户页面解绑后尝试');
    }
  }

  *checkBoxValid(box, id) {
    const boxQuery = { box };
    if (id) {
      boxQuery._id = { $ne: id };
    }
    if (yield BKStock.findOne(boxQuery)) {
      throw new Error('该盒子已经被绑定');
    }
    if (yield ACOperatorController.Model.findOne({ box })) {
      throw new Error('该盒子已经被巡检绑定,请到运营账户页面解绑后尝试');
    }
  }

  static *checkRelatedInfo({ region, style, box }) {
    if (region) {
      const regionData = yield OPRegionController.findByIdAndCheckExists(region);
      if (regionData.prices.length < 3) throw new Error('大区缺少必要的价格设定');
    }
    // const BKBoxController = require('./BKBoxController');
    // if (box) yield BKBoxController.findByIdAndCheckExists(box);
    if (style) {
      const styleData = yield OPStyleController.findByIdAndCheckExists(style);
      return styleData.level;
    }
  }

  *checkRelatedInfo({ region, style, box }) {
    if (region) {
      const regionData = yield OPRegionController.findByIdAndCheckExists(region);
      if (regionData.prices.length < 3) throw new Error('大区缺少必要的价格设定');
    }
    // const BKBoxController = require('./BKBoxController');
    // if (box) yield BKBoxController.findByIdAndCheckExists(box);
    if (style) {
      const styleData = yield OPStyleController.findByIdAndCheckExists(style);
      return styleData.level;
    }
  }

  static *create({ number = {}, region, style, box }, {
    operator,
    operateLocation,
  }) {
    yield this.checkNumberValid(number);
    yield this.checkBoxValid(box);
    const level = yield this.checkRelatedInfo({ region, style, box });
    const id = yield BKStock.genId();
    const batteryStyle = (/^050/).test(number) ? '1803201830001' : '1803201830000';

    yield BKStock.create({
      _id: id,
      number,
      region,
      style,
      battery: {
        style: batteryStyle,
      },
      styleLevel: level,
      box,
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opCreateStock({
      stock: id,
      operator,
      operateLocation,
      releasedTasks,
      addedTasks,
      prevTaskList,
    });
    return yield this.checkInspector(id);
  }

  static *updateNumber(id, number = {}, { operator, operateLocation }) {
    yield this.checkNumberValid(number, id);
    const stock = yield this.findByIdAndCheckExists(id);
    const data = { number: Object.assign({}, stock.number.toJSON(), number) };
    yield BKStock.findByIdAndUpdate(id, {
      $set: data,
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (stock.number.custom !== data.number.custom) {
      yield RCStockOpController.opUpdateCustomNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
        prevTaskList,
      }, {
        prev: stock.number.custom,
        next: number.custom,
      });
    }
    if (stock.number.temp !== data.number.temp) {
      yield RCStockOpController.opUpdateTempNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.temp,
        next: number.temp,
      });
    }
    if (stock.number.license !== data.number.license) {
      yield RCStockOpController.opUpdateLicenseNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.license,
        next: number.license,
      });
    }
    if (stock.number.vin !== data.number.vin) {
      yield RCStockOpController.opUpdateVin({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.vin,
        next: number.vin,
      });
    }
    return yield this.checkInspector(id);
  }

  *updateNumber(id, number = {}, { operator, operateLocation }) {
    yield this.checkNumberValid(number, id);
    const stock = yield this.findByIdAndCheckExists(id);
    const data = { number: Object.assign({}, stock.number.toJSON(), number) };
    yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: data,
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (stock.number.custom !== data.number.custom) {
      yield new BKBikeIdentifierController(this.transaction).findPreAndUpdateNext({ key: 'number', pre: stock.number.custom, next: data.number.custom });
      yield RCStockOpController.opUpdateCustomNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
        prevTaskList,
      }, {
        prev: stock.number.custom,
        next: number.custom,
      });
    }
    if (stock.number.temp !== data.number.temp) {
      yield RCStockOpController.opUpdateTempNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.temp,
        next: number.temp,
      });
    }
    if (stock.number.license !== data.number.license) {
      yield new BKBikeIdentifierController(this.transaction).findPreAndUpdateNext({ key: 'license', pre: stock.number.license, next: data.number.license });
      yield RCStockOpController.opUpdateLicenseNumber({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.license,
        next: number.license,
      });
    }
    if (stock.number.vin !== data.number.vin) {
      yield new BKBikeIdentifierController(this.transaction).findPreAndUpdateNext({ key: 'vin', pre: stock.number.vin, next: data.number.vin });
      yield RCStockOpController.opUpdateVin({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
      }, {
        prev: stock.number.vin,
        next: number.vin,
      });
    }
    return yield this.checkInspector(id);
  }

  *updateRegion(id, region, {
    operator,
    operateLocation,
  }) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (stock.region === region) return stock;
    if (region) yield this.checkRelatedInfo({ region });
    const data = { region };
    yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: data,
    });
    let prevRegion = {};
    let nextRegion = {};
    if (region) {
      nextRegion = yield OPRegionController.Model.findById(region);
    }
    if (stock.region) {
      prevRegion = yield OPRegionController.Model.findById(stock.region);
    }
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opUpdateRegion({
      stock: id,
      operator,
      operateLocation,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      prev: {
        id: prevRegion._id,
        name: prevRegion.name,
      },
      next: {
        id: nextRegion._id,
        name: nextRegion.name,
      },
    });
    return yield this.checkInspector(id);
  }

  static *updateStation(id, station) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (stock.station !== station) {
      const data = { station };
      yield BKStock.findByIdAndUpdate(id, {
        $set: data,
      });
    }
  }

  static *updateRegion(id, region, {
    operator,
    operateLocation,
  }) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (stock.region === region) return stock;
    if (region) yield this.checkRelatedInfo({ region });
    const data = { region };
    yield BKStock.findByIdAndUpdate(id, {
      $set: data,
    });
    let prevRegion = {};
    let nextRegion = {};
    if (region) {
      nextRegion = yield OPRegionController.Model.findById(region);
    }
    if (stock.region) {
      prevRegion = yield OPRegionController.Model.findById(stock.region);
    }
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opUpdateRegion({
      stock: id,
      operator,
      operateLocation,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      prev: {
        id: prevRegion._id,
        name: prevRegion.name,
      },
      next: {
        id: nextRegion._id,
        name: nextRegion.name,
      },
    });
    return yield this.checkInspector(id);
  }

  static *updateStyle(id, style, {
    operator,
    operateLocation,
  }) {
    if (!style) throw new Error('必须指定车型');
    const stock = yield this.findByIdAndCheckExists(id);
    if (stock.style === style) return stock;
    const level = yield this.checkRelatedInfo({ style });
    yield BKStock.findByIdAndUpdate(id, {
      $set: { style, styleLevel: level },
    });
    let prevStyle = {};
    let nextStyle = {};
    if (stock.style) {
      prevStyle = yield OPStyleController.Model.findById(stock.style);
    }
    if (style) {
      nextStyle = yield OPStyleController.Model.findById(style);
    }
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opUpdateStyle({
      stock: id,
      operator,
      operateLocation,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      prev: {
        id: prevStyle._id,
        name: prevStyle.name,
      },
      next: {
        id: nextStyle._id,
        name: nextStyle.name,
      },
    });
    return yield this.checkInspector(id);
  }

  static *updateBox(id, box, {
    operator,
    operateLocation,
  }, reason) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (stock.box === box) return stock;
    if (box) {
      yield this.checkBoxValid(box, id);
      yield this.checkRelatedInfo({ box });
    }
    if (judgement.isEmpty(box)) {
      yield BKStock.findByIdAndUpdate(id, {
        $set: { isOnline: false },
        $unset: { box: 1 },
      });
    } else {
      yield BKStock.findByIdAndUpdate(id, {
        $set: { box },
      });
    }
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield BKBikeIdentifierController.updateBox({ pre: stock.box, next: box });
    yield RCStockOpController.opUpdateBox({
      stock: id,
      operator,
      operateLocation,
      addedTasks,
      releasedTasks,
      prevTaskList,
    }, {
      prev: stock.box,
      next: box,
      reason,
    });
    return yield this.checkInspector(id);
  }

  *updateBox(id, box, {
    operator,
    operateLocation,
  }, reason) {
    const stock = yield BKStockController.findByIdAndCheckExists(id);
    if (stock.box === box) return stock;
    // const BKBoxController = require('../ebike/BKBoxController');
    // yield BKBoxController.findByIdAndCheckExists(box);
    const bikeIdentifier = yield BKBikeIdentifierController.findByBoxAndCheckExists(box);
    if (box) {
      yield this.checkBoxValid(box, id);
      yield this.checkRelatedInfo({ box });
      yield this.T(BKStockController.Model).findByIdAndUpdate(id, {
        $set: {
          box,
        },
      });
      if (bikeIdentifier) {
        yield this.T(BKBikeIdentifierController.Model).findOneAndRemove({
          box,
        });
      }
      yield this.T(BKBikeIdentifierController.Model).findOneAndUpdate({
        stock: id,
      }, {
        $set: {
          box,
        },
      });
    } else {
      yield this.T(BKStockController.Model).findByIdAndUpdate(id, {
        $unset: {
          box: 1,
        },
      });
      yield this.T(BKBikeIdentifierController.Model).findOneAndUpdate({
        stock: id,
      }, {
        $unset: {
          box: 1,
        },
      });
    }
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);

    yield RCStockOpController.opUpdateBox({
      stock: id,
      operator,
      operateLocation,
      addedTasks,
      releasedTasks,
      prevTaskList,
    }, {
      prev: stock.box,
      next: box,
      reason,
    });
  }

  static *updateEnable(id, enable, {
    operator,
    operateLocation,
    operateRemark,
  }) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (enable === stock.enable) return stock;
    if (enable) {
      if (!stock.box) throw new Error('该车辆还未绑定GPS设备');
      if (!stock.number.custom) throw new Error('该车辆还未绑定自定义车牌号');
      if (!stock.region) throw new Error('该车辆还未分配到大区');
    }
    yield BKStock.findByIdAndUpdate(id, {
      $set: { enable },
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (enable) {
      yield RCStockOpController.opEnable({
        stock: id,
        operator,
        operateLocation,
        operateRemark,
        addedTasks,
        releasedTasks,
        prevTaskList,
      });
    } else {
      yield RCStockOpController.opDisable({
        stock: id,
        operator,
        operateLocation,
        operateRemark,
        addedTasks,
        releasedTasks,
      });
    }
    return yield this.checkInspector(id);
  }

  *updateState(id, state, { operator, operateLocation, addDamage, damage }) {
    const stock = yield this.findByIdAndCheckExists(id);
    const newStock = yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: { state },
    }, { new: true });
    const prevStockState = stock.state;
    const nextStockState = newStock.state;
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController[addDamage ? 'opAddDamage' : 'opRepairDamage']({
      stock,
      operator,
      operateLocation,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      damage,
      prevStockState,
      nextStockState,
    });
    return yield this.checkInspector(id);
  }

  static *checkLocate(stock, nextLocate, {
    operator,
    operateLocation = {},
    operateRemark,
    opPutOn = {},
    opRecover = {},
    opReservation = {},
    opCancelReservation = {},
    opRent = {},
    opReturnBack = {},
    opSetLost = {},
    opFindBack = {},
    opApplyReturnBack = {},
    opCancelReturnBack = {},
    opDetained = {},
    opDetainedFindBack = {},
    opStartDispatch = {},
    opFinishDispatch = {},
    opSuspectedLostFindBack = {},
    opSetSuspectedLost = {},
    opOtherOccupancy = {},
    opReleaseOccupancy = {},
    opInBound = {},
    opOutBound = {},
  }, scannedByUser) {
    let extra, op;
    const operationInfo = {
      stock: stock._id,
      operator,
      operateLocation,
      operateRemark,
    };
    const prevLocate = stock.locate;

    // if (nextLocate === constants.BK_LOCATE.待拖回) {
    //   const BKDamageController = require('./BKDamageController');
    //   const damage = yield BKDamageController.Model.findOne({
    //     stock: stock._id,
    //     state: { $ne: constants.BK_DAMAGE_STATE.已修复 }
    //   });
    //   if (!damage) throw new Error('该车辆没有损坏记录，如需要申请拖回，请先添加损坏记录');
    // }
    if (nextLocate === constants.BK_LOCATE.其他占用) {
      op = RCStockOpController.opOtherOccupancy;
      extra = opOtherOccupancy;
    } else if (prevLocate === constants.BK_LOCATE.其他占用) {
      op = RCStockOpController.opReleaseOccupancy;
      extra = opReleaseOccupancy;
    } else if (prevLocate === constants.BK_LOCATE.调度) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        // 结束调度
        op = RCStockOpController.opFinishDispatch;
        extra = opFinishDispatch;
        if (nextLocate === constants.BK_LOCATE.空闲) {
          // 投放车辆 离线统计解除
          yield SSOfflineStockController.trigger(stock._id);
        }
      } else if (nextLocate === constants.BK_LOCATE.仓库) {
        op = RCStockOpController.opInBound;
        extra = opInBound;
      } else throw new Error('结束调度后车辆状态必须为空闲/在库/待拖回');
    } else if (prevLocate === constants.BK_LOCATE.丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        // 丢失找回
        op = RCStockOpController.opFindBack;
        extra = opFindBack;
      } else if (constants.BK_LOCATE.疑似丢失) {
        // 登记疑似丢失
        op = RCStockOpController.opSetSuspectedLost;
        extra = opSetSuspectedLost;
      } else throw new Error('丢失找回后车辆状态必须为空闲/在库/待拖回/疑似丢失');
    } else if (prevLocate === constants.BK_LOCATE.疑似丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        // 疑似丢失找回
        op = RCStockOpController.opSuspectedLostFindBack;
        extra = opSuspectedLostFindBack;
      } else if (constants.BK_LOCATE.丢失) {
        // 登记丢失
        op = RCStockOpController.opSetLost;
        extra = opSetLost;
      } else throw new Error('疑似丢失找回后车辆状态必须为空闲/在库/待拖回');
    } else if (prevLocate === constants.BK_LOCATE.扣押) {
      // if (!scannedByUser) throw new Error('扣押找回功能已禁用,如有需要,请联系管理员');
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        // 被扣找回
        op = RCStockOpController.opDetainedFindBack;
        extra = opDetainedFindBack;
      } else throw new Error('被扣押车辆找回后状态必须为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(prevLocate)) {
        // 登记丢失
        op = RCStockOpController.opSetLost;
        extra = opSetLost;
      } else throw new Error('车辆当前状态无法进行报失，请确认车辆当前状态为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.调度) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回].includes(prevLocate)) {
        // 开始调度
        op = RCStockOpController.opStartDispatch;
        extra = opStartDispatch;
      } else if (constants.BK_LOCATE.仓库 === prevLocate) {
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        op = RCStockOpController.opOutBound;
        extra = opOutBound;
      } else throw new Error(`车辆当前状态${constants.BK_LOCATE_MAP[stock.locat]}, 无法进行调度，请确认车辆当前状态为空闲/在库/待拖回`);
    } else if (nextLocate === constants.BK_LOCATE.空闲) {
      if (prevLocate === constants.BK_LOCATE.仓库) {
        // 投放车辆
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        op = RCStockOpController.opPutOn;
        extra = opPutOn;
      } else if (prevLocate === constants.BK_LOCATE.预约) {
        // 取消预约
        op = RCStockOpController.opCancelReservation;
        extra = opCancelReservation;
      } else if (prevLocate === constants.BK_LOCATE.待拖回) {
        // 取消拖回
        op = RCStockOpController.opCancelReturnBack;
        extra = opCancelReturnBack;
      } else if (prevLocate === constants.BK_LOCATE.在租) {
        // 归还车辆
        op = RCStockOpController.opReturnBack;
        extra = opReturnBack;
      } else throw new Error(`车辆当前状态不正确 ${stock._id}:${prevLocate}:${nextLocate}`);
    } else if (nextLocate === constants.BK_LOCATE.仓库) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 回收车辆
        op = RCStockOpController.opRecover;
        extra = opRecover;
      } else if (prevLocate === constants.BK_LOCATE.调度) {
        op = RCStockOpController.opInBound;
        extra = opInBound;
      } else throw new Error('车辆当前状态无法进行回收，请确认车辆当前状态为空闲');
    } else if (nextLocate === constants.BK_LOCATE.预约) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 预约车辆
        op = RCStockOpController.opReservation;
        extra = opReservation;
      } else throw new Error('车辆当前不能预约');
    } else if (nextLocate === constants.BK_LOCATE.在租) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.预约].includes(prevLocate)) {
        // 租用车辆
        op = RCStockOpController.opRent;
        extra = opRent;
      } else throw new Error('车辆当前不能租用');
    } else if (nextLocate === constants.BK_LOCATE.扣押) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回, constants.BK_LOCATE.仓库].includes(prevLocate)) {
        // 被扣上报
        op = RCStockOpController.opDetained;
        extra = opDetained;
      } else throw new Error('车辆当前状态无法设置扣押，请确认车辆当前状态为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.待拖回) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 申请拖回
        op = RCStockOpController.opApplyReturnBack;
        extra = opApplyReturnBack;
      } else throw new Error('车辆当前状态无法申请拖回，请确认车辆当前状态为空闲');
    } else if (nextLocate === constants.BK_LOCATE.疑似丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回, constants.BK_LOCATE.仓库].includes(prevLocate)) {
        // 登记疑似丢失
        op = RCStockOpController.opSetSuspectedLost;
        extra = opSetSuspectedLost;
      } else throw new Error('车辆当前状态无法设置疑似丢失，请确认车辆当前状态为空闲/在库/待拖回');
    } else throw new Error('暂无法设置为该状态');
    if (Object.keys(extra).length === 0) {
      throw new Error(`车辆当前状态不正确 ${stock._id}:${prevLocate}:${nextLocate}`);
    }
    return {
      prevLocate,
      op,
      operationInfo,
      extra: Object.assign({
        prevLocate,
        nextLocate,
      }, extra),
    };
  }

  *checkLocate(stock, nextLocate, {
    operator,
    operateLocation = {},
    operateRemark,
    opPutOn = {},
    opRecover = {},
    opReservation = {},
    opCancelReservation = {},
    opRent = {},
    opReturnBack = {},
    opSetLost = {},
    opFindBack = {},
    opApplyReturnBack = {},
    opCancelReturnBack = {},
    opDetained = {},
    opDetainedFindBack = {},
    opStartDispatch = {},
    opFinishDispatch = {},
    opSuspectedLostFindBack = {},
    opSetSuspectedLost = {},
    opOtherOccupancy = {},
    opReleaseOccupancy = {},
    opInBound = {},
    opOutBound = {},
  }) {
    let extra, op;
    const operationInfo = {
      stock: stock._id,
      operator,
      operateLocation,
      operateRemark,
    };
    const prevLocate = stock.locate;

    // if (nextLocate === constants.BK_LOCATE.待拖回) {
    //   const BKDamageController = require('./BKDamageController');
    //   const damage = yield BKDamageController.Model.findOne({
    //     stock: stock._id,
    //     state: { $ne: constants.BK_DAMAGE_STATE.已修复 }
    //   });
    //   if (!damage) throw new Error('该车辆没有损坏记录，如需要申请拖回，请先添加损坏记录');
    // }
    if (nextLocate === constants.BK_LOCATE.其他占用) {
      op = RCStockOpController.opOtherOccupancy;
      extra = opOtherOccupancy;
    } else if (prevLocate === constants.BK_LOCATE.其他占用) {
      op = RCStockOpController.opReleaseOccupancy;
      extra = opReleaseOccupancy;
    } else if (prevLocate === constants.BK_LOCATE.调度) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        // 结束调度
        op = RCStockOpController.opFinishDispatch;
        extra = opFinishDispatch;
        if (nextLocate === constants.BK_LOCATE.空闲) {
          // 投放车辆 离线统计解除
          yield SSOfflineStockController.trigger(stock._id);
        }
      } else if (nextLocate === constants.BK_LOCATE.仓库) {
        op = RCStockOpController.opInBound;
        extra = opInBound;
      } else throw new Error('结束调度后车辆状态必须为空闲/在库/待拖回');
    } else if (prevLocate === constants.BK_LOCATE.丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        // 丢失找回
        op = RCStockOpController.opFindBack;
        extra = opFindBack;
      } else if (constants.BK_LOCATE.疑似丢失) {
        // 登记疑似丢失
        op = RCStockOpController.opSetSuspectedLost;
        extra = opSetSuspectedLost;
      } else throw new Error('丢失找回后车辆状态必须为空闲/在库/待拖回/疑似丢失');
    } else if (prevLocate === constants.BK_LOCATE.疑似丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
        // 疑似丢失找
        op = RCStockOpController.opSuspectedLostFindBack;
        extra = opSuspectedLostFindBack;
      } else if (constants.BK_LOCATE.丢失) {
        // 登记丢失
        op = RCStockOpController.opSetLost;
        extra = opSetLost;
      } else throw new Error('疑似丢失找回后车辆状态必须为空闲/在库/待拖回');
    } else if (prevLocate === constants.BK_LOCATE.扣押) {
      throw new Error('扣押找回功能已禁用,如有需要,请联系管理员');
      // if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(nextLocate)) {
      // 被扣找回
      // op = RCStockOpController.opDetainedFindBack;
      // extra = opDetainedFindBack;
      // } else throw new Error('车辆当前被扣押无法进行报失，请确认车辆当前状态为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.仓库, constants.BK_LOCATE.待拖回].includes(prevLocate)) {
        // 登记丢失
        op = RCStockOpController.opSetLost;
        extra = opSetLost;
      } else throw new Error('车辆当前状态无法进行报失，请确认车辆当前状态为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.调度) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回].includes(prevLocate)) {
        // 开始调度
        op = RCStockOpController.opStartDispatch;
        extra = opStartDispatch;
      } else if (constants.BK_LOCATE.仓库 === prevLocate) {
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        op = RCStockOpController.opOutBound;
        extra = opOutBound;
      } else throw new Error(`车辆当前状态${constants.BK_LOCATE_MAP[stock.locate]}, 无法进行调度，请确认车辆当前状态为空闲/在库/待拖回`);
    } else if (nextLocate === constants.BK_LOCATE.跨区运输中) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回].includes(prevLocate)) {
        // 开始调度
        op = RCStockOpController.opStartDispatch;
        extra = opStartDispatch;
      } else if (prevLocate === constants.BK_LOCATE.仓库) {
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        op = RCStockOpController.opOutBound;
        extra = opOutBound;
      } else throw new Error(`车辆当前状态${constants.BK_LOCATE_MAP[stock.locate]}, 无法进行调度，请确认车辆当前状态为空闲/在库/待拖回`);
    } else if (nextLocate === constants.BK_LOCATE.空闲) {
      if (prevLocate === constants.BK_LOCATE.仓库) {
        // 投放车辆
        if (!stock.number.vin || !stock.lockVin.isLocked) throw new Error('当前车辆车架号未绑定或者未锁定,请重新绑定或锁定');
        if (!stock.box) throw new Error('当前车辆未绑定车机,请绑定后重试');
        op = RCStockOpController.opPutOn;
        extra = opPutOn;
      } else if (prevLocate === constants.BK_LOCATE.预约) {
        // 取消预约
        op = RCStockOpController.opCancelReservation;
        extra = opCancelReservation;
      } else if (prevLocate === constants.BK_LOCATE.待拖回) {
        // 取消拖回
        op = RCStockOpController.opCancelReturnBack;
        extra = opCancelReturnBack;
      } else if (prevLocate === constants.BK_LOCATE.在租) {
        // 归还车辆
        op = RCStockOpController.opReturnBack;
        extra = opReturnBack;
      } else throw new Error(`车辆当前状态不正确 ${stock._id}:${prevLocate}:${nextLocate}`);
    } else if (nextLocate === constants.BK_LOCATE.仓库) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 回收车辆
        op = RCStockOpController.opRecover;
        extra = opRecover;
      } else if (prevLocate === constants.BK_LOCATE.调度) {
        op = RCStockOpController.opInBound;
        extra = opInBound;
      } else throw new Error('车辆当前状态无法进行回收，请确认车辆当前状态为空闲');
    } else if (nextLocate === constants.BK_LOCATE.预约) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 预约车辆
        op = RCStockOpController.opReservation;
        extra = opReservation;
      } else throw new Error('车辆当前不能预约');
    } else if (nextLocate === constants.BK_LOCATE.在租) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.预约].includes(prevLocate)) {
        // 租用车辆
        op = RCStockOpController.opRent;
        extra = opRent;
      } else throw new Error('车辆当前不能租用');
    } else if (nextLocate === constants.BK_LOCATE.扣押) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回, constants.BK_LOCATE.仓库].includes(prevLocate)) {
        // 被扣上报
        op = RCStockOpController.opDetained;
        extra = opDetained;
      } else throw new Error('车辆当前状态无法设置扣押，请确认车辆当前状态为空闲/在库/待拖回');
    } else if (nextLocate === constants.BK_LOCATE.待拖回) {
      if (prevLocate === constants.BK_LOCATE.空闲) {
        // 申请拖回
        op = RCStockOpController.opApplyReturnBack;
        extra = opApplyReturnBack;
      } else throw new Error('车辆当前状态无法申请拖回，请确认车辆当前状态为空闲');
    } else if (nextLocate === constants.BK_LOCATE.疑似丢失) {
      if ([constants.BK_LOCATE.空闲, constants.BK_LOCATE.待拖回, constants.BK_LOCATE.仓库].includes(prevLocate)) {
        // 登记疑似丢失
        op = RCStockOpController.opSetSuspectedLost;
        extra = opSetSuspectedLost;
      } else throw new Error('车辆当前状态无法设置疑似丢失，请确认车辆当前状态为空闲/在库/待拖回');
    } else throw new Error('暂无法设置为该状态');
    if (Object.keys(extra).length === 0) {
      throw new Error(`车辆当前状态不正确 ${stock._id}:${prevLocate}:${nextLocate}`);
    }
    return {
      prevLocate,
      op,
      operationInfo,
      extra: Object.assign({
        prevLocate,
        nextLocate,
      }, extra),
    };
  }

  static *updateLocate(id, locate, operation = {}, station, scannedByUser) {
    const stock = yield this.findByIdAndCheckExists(id);
    const { prevLocate, op, operationInfo, extra } = yield this.checkLocate(stock, locate, operation, scannedByUser);
    const data = {
      locate,
      latestUpdatedLocateAt: new Date(),
      latestScannedAt: null,
      fixedLocation: extra.location,
    };
    if (locate === constants.BK_LOCATE.空闲 && !stock.putOnAt) data.putOnAt = new Date();
    // 出入库操作 更新station
    if (locate === constants.BK_LOCATE.仓库) {
      if (station) {
        data.station = station._id;
        operationInfo.station = station;
      }
    } else if ([constants.BK_LOCATE.调度, constants.BK_LOCATE.空闲].includes(locate)) {
      data.station = '';
      operationInfo.station = station;
    }
    if (prevLocate === constants.BK_LOCATE.调度) {
      data.latestMovedAt = new Date();
    }
    yield BKStock.findByIdAndUpdate(id, {
      $set: data,
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    operationInfo.releasedTasks = releasedTasks;
    operationInfo.addedTasks = addedTasks;
    operationInfo.prevTaskList = prevTaskList;
    yield op.bind(RCStockOpController)(operationInfo, extra);
    return yield this.checkInspector(id);
  }

  *updateLocate(id, locate, operation = {}, station) {
    const stock = yield this.findByIdAndCheckExists(id);
    const { prevLocate, op, operationInfo, extra } = yield this.checkLocate(stock, locate, operation);
    const data = {
      locate,
      latestUpdatedLocateAt: new Date(),
      latestScannedAt: null,
      fixedLocation: extra.location,
    };
    // 出入库操作 更新station
    if (locate === constants.BK_LOCATE.仓库) {
      if (station) {
        data.station = station._id;
        operationInfo.station = station;
      }
    } else if ([constants.BK_LOCATE.调度, constants.BK_LOCATE.空闲].includes(locate)) {
      data.station = '';
      operationInfo.station = station;
    }
    if (prevLocate === constants.BK_LOCATE.调度) {
      data.latestMovedAt = new Date();
    }
    yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: data,
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    operationInfo.releasedTasks = releasedTasks;
    operationInfo.addedTasks = addedTasks;
    operationInfo.prevTaskList = prevTaskList;
    operationInfo.region = stock.region;
    yield op.bind(RCStockOpController)(operationInfo, extra);
    return yield this.checkInspector(id);
  }

  static *updateFindStock(id, hasFind, { operator, operateLocation, operateRemark, photo, failedReason }) {
    const now = new Date();
    let stock;
    let notFindRecords = [];
    const offlineStock = yield SSOfflineStockController.Model.findOne({ stock: id }).sort({ _id: -1 });
    if (offlineStock) {
      const data = {
        $inc: { findCount: 1 },
      };
      if (!offlineStock.findDate) data.$set = { findDate: new Date() };
      yield SSOfflineStockController.Model.findByIdAndUpdate(offlineStock._id, data);
    }
    const noPowerStock = yield SSNoPowerStockController.Model.findOne({ stock: id }).sort({ _id: -1 });
    if (noPowerStock) {
      const data = {
        $inc: { findCount: 1 },
      };
      if (!noPowerStock.findDate) data.$set = { findDate: new Date() };
      yield SSNoPowerStockController.Model.findByIdAndUpdate(noPowerStock._id, data);
    }
    if (hasFind) {
      notFindRecords = (yield BKStockController.Model.findById(id).select('notFindRecords')).notFindRecords;
      stock = yield BKStockController.Model.findByIdAndUpdate(id, {
        $set: {
          hasFind,
          latestFoundAt: now,
          latestFoundSucceedAt: now,
          notFindRecords: [],
          latestScannedAt: null,
          latestIllegalSpeedAt: null,
        },
      }, { new: true });
    } else {
      const op = yield ACOperatorController.findByUserAndPopulate(operator);
      stock = yield BKStockController.Model.findByIdAndUpdate(id, {
        $set: {
          hasFind,
          latestFoundAt: now,
        },
        $push: {
          notFindRecords: {
            time: new Date(),
            finder: {
              id: operator,
              name: op.user.cert.name,
              tel: op.user.auth.tel,
              type: op.type,
            },
            location: operateLocation,
            failedReason,
          },
        },
      }, { new: true });
    }
    //
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (hasFind) {
      if (prevTaskList.search({ code: constants.BK_TASK_TYPE.司机未找到 })) {
        // 创建 司机找到记录
        yield SSDriverFoundController.create({
          stock, operator, noFoundOperator: notFindRecords.map(item => item.finder.id),
        });
      } else if (prevTaskList.search({ code: constants.BK_TASK_TYPE.白班未找到 })) {
        // 创建 白班找到记录
        yield SSDayFoundController.create({
          stock, operator, noFoundOperator: notFindRecords.map(item => item.finder.id),
        });
      }
    }
    // 找车打卡
    yield RCStockOpController.opFindStock({
      stock: id,
      operateLocation,
      operator,
      operateRemark,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      hasFind,
      photo,
      failedReason,
    });
    return yield this.checkInspector(id);
  }

  static *findByIdAndCheckExists(id) {
    const stock = yield BKStock.findById(id);
    if (!stock) throw new Error(`车辆${id}不存在`);
    return stock;
  }

  *findByIdAndCheckExists(id) {
    const stock = yield this.T(BKStock).findById(id);
    if (!stock) throw new Error(`车辆${id}不存在`);
    return stock;
  }

  static *findBoxById(id) {
    const BKBoxController = require('./BKBoxController');
    const stock = yield this.findByIdAndCheckExists(id);
    if (!stock.box) throw new Error('该车辆还未绑定智能设备');
    const box = yield BKBoxController.findByIdAndCheckExists(stock.box);
    return { box, stock };
  }

  static *findBoxByBoxId(boxId) {
    const BKBoxController = require('./BKBoxController');
    const stock = yield BKStock.findOne({ box: boxId });
    if (!stock) return null;
    const box = yield BKBoxController.findByIdAndCheckExists(stock.box);
    return { box, stock };
  }

  // 弃用
  static *updateNotUsedInOneDay(id, notUsedInOneDay) {
    return yield BKStock.findByIdAndUpdate(id, {
      $set: {
        notUsedInOneDay,
      },
    }, { new: true });
  }

  // 弃用
  static *updateNotUsedInTwoDay(id, notUsedInTwoDay) {
    return yield BKStock.findByIdAndUpdate(id, {
      $set: {
        notUsedInTwoDay,
      },
    }, { new: true });
  }

  // 弃用
  static *updateNoGpsLocation(id, noGpsLocation) {
    return yield BKStock.findByIdAndUpdate(id, {
      $set: {
        noGpsLocation,
      },
    }, { new: true });
  }

  static *updatePowerUnlink(id, powerUnlink, {
    operator,
    operateLocation,
    operateRemark,
  } = {}) {
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        powerUnlink,
      },
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (!powerUnlink) {
      yield RCStockOpController.opReleasePowerUnlink({
        stock: id,
        operator,
        operateLocation,
        operateRemark,
        releasedTasks,
        addedTasks,
        prevTaskList,
      });
    }
    return yield this.checkInspector(id);
  }

  // 弃用
  static *updateIllegalMovement(id, illegalMovement) {
    return yield BKStock.findByIdAndUpdate(id, {
      $set: {
        illegalMovement,
      },
    }, { new: true });
  }

  // 弃用
  static *updateLatestMovedAt(id) {
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        latestMovedAt: new Date(),
      },
    });
    yield this.checkIfValid(id);
    yield this.checkIfHasTask(id);
    return yield this.checkInspector(id);
  }

  static *updateLatestUsedAt(id) {
    const now = new Date();
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        latestUsedAt: new Date(),
        latestIllegalOrderAt: null,
        latestIllegalSpeedAt: null,
        hasFind: true,
        latestFoundAt: now,
        latestFoundSucceedAt: now,
        notFindRecords: [],
        latestScannedAt: null,
      },
    });
    yield this.checkIfValid(id);
    yield this.checkIfHasTask(id);
    return yield this.checkInspector(id);
  }

  static *updateRechargeInfo(id, rechargePower, {
    operator,
    operateLocation,
    prevVoltage,
    nextVoltage,
  }) {
    throw new Error('手动校准电量已弃用');
    // const { stock, box } = yield this.findBoxById(id);
    // if (!stock) throw new Error('车辆不存在');
    // if (box.info.dataSource === constants.BK_BOX_DATA_SOURCE.小安宝) {
    //   throw new Error('该设备无需手动校准电量');
    // }
    // const prevPower = stock.battery.power;
    // const prevMileage = stock.battery.mileage;
    // const BKBoxController = require('./BKBoxController');
    // const power = Math.max(Math.min(rechargePower, 1), 0);
    // const style = yield OPStyleController.findByIdAndCheckExists(stock.style);
    // const mileage = Math.floor(style.maxMileage * power);
    // const now = new Date();
    // const isLowPower = mileage <= constants.BK_LOW_POWER_MILEAGE;
    // const changeToLowPower = !stock.battery.isLowPower && isLowPower;
    // const changeToEnoughPower = stock.battery.isLowPower && !isLowPower;
    // let latestLowPower = stock.battery.latestLowPower;
    // if (changeToLowPower) latestLowPower = now;
    // else if (changeToEnoughPower) latestLowPower = null;
    // yield BKStock.findByIdAndUpdate(id, {
    //   $set: {
    //     'battery.lastRechargedAt': now,
    //     'battery.lastRechargePower': power,
    //     'battery.power': power,
    //     'battery.mileage': mileage,
    //     'battery.isLowPower': isLowPower,
    //     'battery.isLowPowerWarning': mileage <= constants.BK_LOW_POWER_WARNING_MILEAGE,
    //     'battery.lastRechargeTotalMileage': stock.record.mileageInAll || 0,
    //     'battery.latestLowPower': latestLowPower
    //   }
    // });
    // yield this.checkIfValid(id);
    // const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    // yield RCStockOpController.opExchangeBattery({
    //   stock: id,
    //   operator,
    //   operateLocation,
    //   releasedTasks,
    //   addedTasks,
    //   prevTaskList,
    // }, {
    //   prev: { power: prevPower, voltage: prevVoltage, mileage: prevMileage },
    //   next: { power, voltage: nextVoltage, mileage }
    // });
    // return yield this.checkInspector(id);
  }

  static *calculatePower(dataSource, {
    maxMileage, ratedVoltage,
  }, {
    mileageInAll, voltage = 0,
  }, alarms, {
    lastRechargedAt, lastRechargeTotalMileage = 0, lastRechargePower = 0, power,
  }) {
    let newPower = 0;
    let truePower = 0;
    if (dataSource === constants.BK_BOX_DATA_SOURCE.一动) {
      if (utils.judgement.isNotEmpty(mileageInAll)) {
        // if (!alarms.includes(constants.RC_ALARM_TYPE.断电警报)) {
        // 距离上次换电池已经过去多久 如果没有记录换电池的时间 则认为过去无限久了。
        const deltaTime = utils.judgement.isEmpty(lastRechargedAt) ? Number.MAX_VALUE : Date.now() - lastRechargedAt.getTime();
        // 距离上次换电池时记录的总里程，到现在行驶了多少里程，如果没有记录，则认为行驶了无限里程。
        const deltaMileage = utils.judgement.isEmpty(lastRechargeTotalMileage) ? Number.MAX_VALUE : (mileageInAll - lastRechargeTotalMileage);
        newPower = lastRechargePower - (deltaMileage / maxMileage) - (deltaTime.msTo.hour * 0.004);
        // }
      } else if (power) {
        newPower = power;
      }
    } else if (dataSource === constants.BK_BOX_DATA_SOURCE.小安宝) {
      // 电压为0 或未传电压的，不需要计算和更新电量
      if (voltage === 0) return {
        shouldUpdate: false,
      };
      switch (ratedVoltage) {
        case constants.BK_RATED_VOLTAGE['84V']:
          newPower = (voltage - 73.5) / (91 - 73.5);
          break;
        case constants.BK_RATED_VOLTAGE['72V']:
          newPower = (voltage - 63) / (78 - 63);
          break;
        case constants.BK_RATED_VOLTAGE['60V']:
          newPower = (voltage - 52.5) / (68 - 52.5);
          break;
        case constants.BK_RATED_VOLTAGE['48V']:
          truePower = (voltage - 41) / (54 - 41);
          newPower = (voltage - constants.BK_LOW_POWER_VOLTAGE) / (54 - 41);
          break;
        case constants.BK_RATED_VOLTAGE['24V']:
          newPower = (voltage - 19.2) / (29.6 - 19.2);
          break;
        default:
          errorHandler(new Error(`暂不支持该额定电压 RatedVoltage[${ratedVoltage}]`));
      }
    } else {
      errorHandler(new Error(`暂不支持该数据源 DataSource[${dataSource}]`));
    }
    newPower = Math.min(1, Math.max(0, newPower));
    truePower = Math.min(1, Math.max(0, truePower));
    return {
      shouldUpdate: true,
      power: Math.round(newPower * 100) / 100,
      truePower: Math.round(truePower * 100) / 100,
      voltage,
      mileage: Math.floor(maxMileage * newPower),
      trueMileage: Math.floor(maxMileage * truePower),
    };
  }

  static *updateLocation(id, { type = constants.BK_BOX_LOCATION_TYPE.卫星, lngLat, address, time = new Date() }, {
    operator,
    operateLocation,
  } = {}) {
    let stock = yield BKStock.findById(id);
    if (!stock) return;
    const prevLocation = stock.location;
    // 重新计算车辆位置 并更新
    let stockLocation = {
      lngLat: stock.location.lngLat,
      address: stock.location.address,
      locatedAt: stock.location.locatedAt,
    };
    let cellLocation;
    let alarms = [];
    if (type === constants.BK_BOX_LOCATION_TYPE.卫星 && lngLat) {
      stockLocation = {
        lngLat,
        address,
        locatedAt: time,
      };
    } else if (type === constants.BK_BOX_LOCATION_TYPE.基站) {
      cellLocation = {
        lngLat,
        address,
        locatedAt: time,
      };
    }
    if (stockLocation.lngLat) {
      lngLat = stockLocation.lngLat;
      const intersectRegion = yield OPRegionController.findIntersect(stockLocation.lngLat, {
        enable: true,
      });
      stockLocation.distanceWithProhibitedArea = null;
      stockLocation.distanceWithForbiddenArea = 0;
      stockLocation.distanceWithPark = null;
      if (intersectRegion) {
        stockLocation.intersectRegion = intersectRegion._id;
        stockLocation.intersectRegionName = intersectRegion.name;
        alarms.push(constants.RC_ALARM_TYPE.驶入围栏);
        // 在大区内，才判断相交区域
        const intersectPolygon = yield OPPolygonController.findIntersect(stockLocation.lngLat, {
          enable: true,
          type: { $ne: constants.OP_POLYGON_TYPE.巡检区 },
        });
        if (intersectPolygon) { // 有相交区域
          stockLocation.intersectPolygon = intersectPolygon._id;
          stockLocation.intersectPolygonType = intersectPolygon.type;
          stockLocation.intersectPolygonNeighborhood = intersectPolygon.neighborhood;
          stockLocation.intersectPolygonName = intersectPolygon.name;
          // 在禁行区 则报警并计算距离
          if (intersectPolygon.type === constants.OP_POLYGON_TYPE.禁行区) {
            alarms.push(constants.RC_ALARM_TYPE.驶入禁行区);
          }
          const path = intersectPolygon.path.coordinates[0];
          if (intersectPolygon.type === constants.OP_POLYGON_TYPE.禁行区) {
            stockLocation.distanceWithProhibitedArea = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
          } else if (intersectPolygon.type === constants.OP_POLYGON_TYPE.禁停区) {
            stockLocation.distanceWithForbiddenArea = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
          } else if (intersectPolygon.type === constants.OP_POLYGON_TYPE.停车区) {
            stockLocation.distanceWithPark = calculateDistanceBetweenPointAndPolygon(path, lngLat);
          }
        } else {
          alarms.push(constants.RC_ALARM_TYPE.驶出禁行区);
          // // 若不在禁行区内，查询附近的禁行区
          // const nearProhibitedAreas = yield OPPolygonController.searchNear(stockLocation.lngLat, {
          //   type: constants.OP_POLYGON_TYPE.禁行区,
          //   enable: true,
          // }, 5000, 1);
          // // 5km范围内最近的禁行区
          // if (nearProhibitedAreas[0]) {
          //   const path = nearProhibitedAreas[0].path.coordinates[0];
          //   stockLocation.distanceWithProhibitedArea = calculateDistanceBetweenPointAndPolygon(path, lngLat);
          // }
          // // 不在停车区，查询附近的停车区
          // const nearParks = yield OPPolygonController.searchNear(stockLocation.lngLat, {
          //   type: constants.OP_POLYGON_TYPE.停车区,
          //   enable: true
          // }, 5000, 1);
          // if (nearParks[0]) {
          //   const path = nearParks[0].path.coordinates[0];
          //   stockLocation.distanceWithPark = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
          // }
        }
      } else if (!intersectRegion) {
        alarms.push(constants.RC_ALARM_TYPE.驶出围栏);
      }
      // 计算距离该大区围栏距离
      if (intersectRegion) {
        const path = intersectRegion.path.coordinates[0];
        stockLocation.distanceWithRegionPath = calculateDistanceBetweenPointAndPolygon(path, lngLat);
      } else {
        const region = yield OPRegionController.Model.findById(stock.region);
        if (region) {
          const path = region.path.coordinates[0];
          stockLocation.distanceWithRegionPath = -calculateDistanceBetweenPointAndPolygon(path, lngLat);
        }
      }

      // 记录相关巡检区
      let intersectInspectionArea = yield OPPolygonController.findIntersect(stockLocation.lngLat, {
        enable: true,
        type: constants.OP_POLYGON_TYPE.巡检区,
      });
      if (!intersectInspectionArea) {
        // 如果没有相交巡检区 搜索50km内最近的巡检区
        const nearInspectionAreas = yield OPPolygonController.searchNear(stockLocation.lngLat, {
          enable: true,
          type: constants.OP_POLYGON_TYPE.巡检区,
        }, constants.INSPECTOR_SEARCH_RADIUS, 1);
        if (nearInspectionAreas[0]) intersectInspectionArea = nearInspectionAreas[0];
      }
      if (intersectInspectionArea) {
        stockLocation.intersectInspectionArea = intersectInspectionArea._id;
        stockLocation.intersectInspectionAreaName = intersectInspectionArea.name;
        if (intersectInspectionArea._id !== stock.location.intersectInspectionArea) {
          yield RCStockOpController.opIntoInspectionArea({ stock: stock._id }, {
            inspectionArea: intersectInspectionArea._id,
            inspectionAreaName: intersectInspectionArea.name,
          });
        }
      } else if (!intersectInspectionArea && stock.location.intersectInspectionArea) {
        yield RCStockOpController.opOutInspectionArea({ stock: stock._id }, {
          inspectionArea: stock.location.intersectInspectionArea,
          inspectionAreaName: stock.location.intersectInspectionAreaName,
        });
      }
      // 更新车辆位置信息
      let outsideRegion = true;
      let insideForbiddenArea = false;
      let insideProhibitedArea = false;
      let insidePark = false;
      if (stockLocation.intersectRegion) outsideRegion = false;
      if (stockLocation.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区) insideForbiddenArea = true;
      if (stockLocation.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区) insideProhibitedArea = true;
      if (stockLocation.intersectPolygonType === constants.OP_POLYGON_TYPE.停车区) insidePark = true;
      stock = yield BKStock.findByIdAndUpdate(stock._id, {
        $set: {
          location: stockLocation,
          outsideRegion,
          insideForbiddenArea,
          insideProhibitedArea,
          insidePark,
        },
      });
    }
    if (cellLocation) {
      stock = yield BKStock.findByIdAndUpdate(stock._id, {
        $set: {
          cellLocation,
        },
      });
    }
    const nextLocation = stock.location;
    yield this.checkIfValid(stock._id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    if (operator) {
      yield RCStockOpController.opAdjustLocation({
        stock: id,
        operator,
        operateLocation,
        releasedTasks,
        addedTasks,
        prevTaskList,
      }, {
        prev: prevLocation,
        next: nextLocation,
      });
    }
    stock = yield this.checkInspector(stock._id);
    return {
      alarms,
      stock,
    };
  }

  static *updateLatestScannedAt(id) {
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        latestScannedAt: new Date(),
      },
    });
    yield this.checkIfValid(id);
    yield this.checkIfHasTask(id);
    return yield this.checkInspector(id);
  }

  static *updateLatestIllegalOrderAt(id, illegal) {
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        latestIllegalOrderAt: illegal ? new Date() : null,
      },
    });
    yield this.checkIfValid(id);
    yield this.checkIfHasTask(id);
    return yield this.checkInspector(id);
  }

  static *searchNear(center, query, searchRadius = constants.STOCK_SEARCH_RADIUS) {
    return yield BKStock.find(query).near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    });
  }

  static *preciseSearchNear(center, query, searchRadius = constants.STOCK_SEARCH_RADIUS) {
    return yield BKStock.find(query).select('_id taskList location.lngLat locate').near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    });
  }

  static availableQuery({ isFree }) {
    const query = {
      enable: true,
      isOnline: true,
      locate: constants.BK_LOCATE.空闲,
      state: {
        $in: [
          constants.BK_STATE.完好,
          constants.BK_STATE.损坏可租,
        ],
      },
      powerUnlink: { $ne: true },
      'battery.isLowPower': false,
      noGpsLocation: false,
      box: { $ne: null },
    };
    if (!isFree) {
      query.outsideRegion = false;
      query.insideProhibitedArea = false;
    } else {
      query['location.distanceWithRegionPath'] = { $gte: constants.BK_FREE_DISTANCE_OUTSIDE_REGION };
    }
    return query;
  }

  static *availableQueryNested({ isFree }) {
    const availableRegions = yield OPRegionController.Model.find({ enable: true });
    const availableStyles = yield OPStyleController.Model.find({ enable: true });
    return Object.assign(this.availableQuery({ isFree }), {
      region: { $in: availableRegions.map(region => region._id) },
      style: { $in: availableStyles.map(style => style._id) },
    });
  }

  static *searchAvailableNear({ center, styleLevel, isFree }) {
    const search = yield this.availableQueryNested({ isFree });
    if (utils.judgement.isNotEmpty(styleLevel)) search.styleLevel = styleLevel;
    if (!isFree) search.isFree = { $ne: true };
    return yield BKStockController.searchNear(center, search);
  }

  static *findByIdAndGetAddress(id) {
    let stock = yield this.findByIdAndCheckExists(id);
    // 重写里程，逆编码车辆位置
    if (judgement.isEmpty(stock.location.address)) {
      const address = yield amap.findAddressByLocation(stock.location.lngLat);
      stock = yield BKStock.findByIdAndUpdate(stock, {
        $set: {
          'location.address': address,
        },
      }, { new: true });
    }
    return stock;
  }

  static *findOneWithReservation({ user, stock, enableFree = false, scanQR }) {
    /*eslint-disable*/
    let stockData = yield BKStock.findById(stock);
    if (!stockData) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.stockNotExists',
      description: '车辆不存在',
    });

    const region = yield OPRegionController.findByIdAndCheckExists(stockData.region);
    if (!region.enable) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.regionNotEnable',
      stock: stockData,
      description: '大区未启用',
    });

    // 检查大区是否停租
    if (region.offHire && !['1703111835006', '1704071317533', '1705091840225'].includes(user)) throw new Error(region.offHireDescription, {
      code: 'controller.bkStock.regionOffHire',
      description: '大区停租',
    });

    const style = yield OPStyleController.findByIdAndCheckExists(stockData.style);
    if (!style.enable) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.styleNotEnable',
      description: '车型未启用',
      stock: stockData,
    });

    const ODReservationController = require('../order/ODReservationController');
    const reservation = yield ODReservationController.findProcessingByUser(user);

    if ((!enableFree || !stockData.isFree)) {
      if (!reservation || (reservation && (reservation.stock !== stock || !reservation.isFree))) {
        if (stockData.outsideRegion && process.env.NODE_ENV === 'production') throw new Error('车辆在服务区外，暂无法提供服务，请换辆车试试！', {
          code: 'controller.bkStock.stockOutsideRegion',
          stock: stockData,
          description: '车辆在围栏外',
        });
        if (stockData.insideProhibitedArea) throw new Error('车辆在禁行区内，暂无法提供服务，请换辆车试试！', {
          code: 'controller.bkStock.stockInProhibitedArea',
          stock: stockData,
          description: '车辆在禁行区',
        });
      }
    }

    if (!stockData.box) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.noBox',
      stock: stockData,
      description: '车辆未绑定盒子',
    });
    if (!stockData.enable) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.stockNotEnable',
      stock: stockData,
      description: '车辆未启用',
    });
    if (!stockData.isOnline) throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.stockOffline',
      stock: stockData,
      description: '车辆设备离线',
    });
    if (stockData.noGpsLocation && process.env.NODE_ENV !== 'development' && stockData.number.custom !== '010177525') throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.noGpsLocation',
      stock: stockData,
      description: '车辆无定位',
    });
    if (stockData.powerUnlink) throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.powerUnlink',
      stock: stockData,
      description: '车辆断电',
    });
    if (stockData.locate === constants.BK_LOCATE.丢失) throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.stockLost',
      stock: stockData,
      description: '车辆已丢失',
    });
    else if (stockData.locate === constants.BK_LOCATE.疑似丢失) throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.stockSuspectedLost',
      stock: stockData,
      description: '车辆疑似丢失',
    });
    else if (stockData.locate === constants.BK_LOCATE.预约 && (!reservation || reservation.stock !== stock)) throw new Error('车辆已被他人预约，下次要快人一步哟！', {
      code: scanQR ? 'controller.bkStock.stockScanQRReserved' : 'controller.bkStock.stockReserved',
      stock: stockData,
      description: '车辆已被预约',
    });
    else if (stockData.locate === constants.BK_LOCATE.在租) throw new Error('车辆正在被他人使用或锁定，若实际无人使用，请报告车辆故障！', {
      code: 'controller.bkStock.stockInUse',
      stock: stockData,
      description: '车辆正在被租用',
    });
    // else if (stockData.locate === constants.BK_LOCATE.扣押) throw new Error('车辆暂时无法使用，请换辆车试试！', {
    //   code: 'controller.bkStock.stock.stockDetained',
    //   stock: stockData,
    //   description: '车辆被扣押',
    // });
    else if (stockData.locate === constants.BK_LOCATE.待拖回) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.stockWaitingReturnBack',
      stock: stockData,
      description: '车辆待拖回',
    });
    if (![constants.BK_LOCATE.丢失, constants.BK_LOCATE.在租, constants.BK_LOCATE.预约, constants.BK_LOCATE.空闲].includes(stockData.locate)) throw new Error('车辆暂时无法使用，请换辆车试试！', {
      code: 'controller.bkStock.stockNotIdle',
      stock: stockData,
      description: '车辆未投放',
    });
    if (![constants.BK_STATE.完好, constants.BK_STATE.损坏可租].includes(stockData.state)) throw new Error('车辆故障，请换辆车试试！', {
      code: 'controller.bkStock.stockDamage',
      stock: stockData,
      description: '车辆损坏',
    });

    if (stockData.battery.isLowPower && process.env.NODE_ENV !== 'development') {
      yield RCFeedLossController.findAndGenerate({
        user,
        region: stockData.region,
        stock: stockData._id,
        location: stockData.location,
      });
      throw new Error('车辆电量低，暂无法提供服务，请换辆车试试！', {
        code: 'controller.bkStock.stockLowPower',
        stock: stockData,
        description: '车辆低电',
      });
    }
    return yield this.findByIdAndGetAddress(stock);
  }

  static *checkValid(stock) {
    const region = yield OPRegionController.Model.findById(stock.region);
    const style = yield OPStyleController.Model.findById(stock.style);
    const prevInvalidReasons = stock.invalidReasons;
    let isValid = true;
    const now = new Date();
    const invalidReasons = [];
    if (!stock.enable) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆未启用);
    }
    if (!region || !region.enable) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.大区未启用);
    }
    if (!style || !style.enable) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车型未启用);
    }
    if (!stock.isOnline) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆设备离线);
    }
    if (stock.powerUnlink) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆断电);
    }
    if (![constants.BK_STATE.完好, constants.BK_STATE.损坏可租].includes(stock.state)) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆损坏);
    }
    if (stock.battery.isLowPower) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆低电);
    }
    if (stock.noGpsLocation) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆无定位);
    }
    let canPutOn = isValid;
    if (stock.locate !== constants.BK_LOCATE.仓库) {
      canPutOn = false;
    }
    if (stock.locate === constants.BK_LOCATE.丢失) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆已丢失);
    } else if (stock.locate === constants.BK_LOCATE.疑似丢失) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆疑似丢失);
    } else if (stock.locate === constants.BK_LOCATE.在租) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆正在被租用);
    } else if (stock.locate === constants.BK_LOCATE.扣押) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆被扣);
    } else if (stock.locate === constants.BK_LOCATE.待拖回) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆待拖回);
    } else if (stock.locate !== constants.BK_LOCATE.空闲 && stock.locate !== constants.BK_LOCATE.预约) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆未投放);
    }

    let isFreeValid = isValid;
    let isFree = false;
    // 如果存在预约中的预约单 并且之前是免单 现在依然免单
    const ODReservationController = require('../order/ODReservationController');
    const reservationOrder = yield ODReservationController.Model.findOne({ state: constants.OD_RESERVATION_STATE.预约中, stock: stock._id });
    if (stock.outsideRegion) {
      if (isFreeValid && stock.location.distanceWithRegionPath >= constants.BK_FREE_DISTANCE_OUTSIDE_REGION || (reservationOrder && reservationOrder.isFree)) {
        isFree = true;
      }
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆在围栏外);
    }
    if (stock.insideProhibitedArea) {
      if (isFreeValid) isFree = true;
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆在禁行区);
    }

    if (stock.locate === constants.BK_LOCATE.预约) {
      isValid = false;
      invalidReasons.push(constants.BK_INVALID_REASON.车辆被预约);
    }

    return {
      isValid,
      canPutOn,
      isFree,
      invalidReasons: invalidReasons.map(code => prevInvalidReasons.search({ code }) || { issuedAt: now, code }),
    };
  }

  static *checkIfValid(id) {
    let stock = yield this.findByIdAndCheckExists(id);
    const { isValid, canPutOn, isFree, invalidReasons } = yield this.checkValid(stock);
    yield SSStockInDayController.trigger(stock, isValid, stock.locate === constants.BK_LOCATE.在租, stock.record.mileageInAll, stock.isOnline);
    return yield BKStock.findByIdAndUpdate(id, {
      $set: { isValid, invalidReasons, canPutOn, isFree },
    }, { new: true });
  }

  *checkIfValid(id) {
    const stock = yield this.findByIdAndCheckExists(id);
    const { isValid, canPutOn, invalidReasons } = yield BKStockController.checkValid(stock);
    yield SSStockInDayController.trigger(stock, isValid, stock.locate === constants.BK_LOCATE.在租, stock.record.mileageInAll, stock.isOnline);
    return yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: { isValid, invalidReasons, canPutOn },
    }, { new: true });
  }

  static *checkTask(stock) {

    const prevHasTask = stock.hasTask;
    const prevTaskList = stock.taskList || [];

    let hasTask = false;
    let taskList = [];
    let taskGroups = [];
    const now = new Date();
    const yesterday = '1 day'.before(now);

    const addTask = code => {
      hasTask = true;
      taskList.push(prevTaskList.search({ code }) || { issuedAt: now, code });
      taskGroups.push(constants.BK_GROUP_OF_TASK[code]);
    };

    // 去向任务
    if (stock.locate === constants.BK_LOCATE.待拖回) addTask(constants.BK_TASK_TYPE.待拖回);
    else if (stock.locate === constants.BK_LOCATE.调度) addTask(constants.BK_TASK_TYPE.调度中);
    else if (stock.locate === constants.BK_LOCATE.扣押) addTask(constants.BK_TASK_TYPE.被扣押);
    else if (stock.canPutOn) addTask(constants.BK_TASK_TYPE.待投放);

    // 未找到
    if (!stock.hasFind) {
      if (stock.notFindRecords.find(v => v.finder.type === constants.AC_OPERATOR_TYPE.高手)) {
        addTask(constants.BK_TASK_TYPE.高手未找到);
      } else if (stock.notFindRecords.find(v => v.finder.type === constants.AC_OPERATOR_TYPE.白班)) {
        addTask(constants.BK_TASK_TYPE.白班未找到);
      } else {
        addTask(constants.BK_TASK_TYPE.司机未找到);
      }
    }

    // 离线
    if (!stock.isOnline) {
      if (!stock.sim.powerOn) { // 不在线 sim卡关机
        const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内真离线 });
        const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天真离线 });
        if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
          addTask(constants.BK_TASK_TYPE.超一天真离线);
        } else {
          addTask(constants.BK_TASK_TYPE.一天内真离线);
        }
      } else if (stock.battery.voltage < 39) {
        const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内疑似离线 });
        const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天疑似离线 });
        if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
          addTask(constants.BK_TASK_TYPE.超一天疑似离线);
        } else {
          addTask(constants.BK_TASK_TYPE.一天内疑似离线);
        }
      } else {
        addTask(constants.BK_TASK_TYPE.高压离线);
      }
    }

    // 扫码车
    if (stock.latestScannedAt) {
      if ([constants.BK_LOCATE.丢失, constants.BK_LOCATE.疑似丢失].includes(stock.locate)) {
        const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内丢失扫码车 });
        const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天丢失扫码车 });
        if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
          addTask(constants.BK_TASK_TYPE.超一天丢失扫码车);
        } else {
          addTask(constants.BK_TASK_TYPE.一天内丢失扫码车);
        }
      } else if (!stock.isOnline && (!stock.sim.powerOn || stock.battery.voltage < 39)) {
        const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内离线扫码车 });
        const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天离线扫码车 });
        if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
          addTask(constants.BK_TASK_TYPE.超一天离线扫码车);
        } else {
          addTask(constants.BK_TASK_TYPE.一天内离线扫码车);
        }
      } else if (stock.noGpsLocation) {
        const oneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.一天内无定位扫码车 });
        const overOneDayTask = prevTaskList.search({ code: constants.BK_TASK_TYPE.超一天无定位扫码车 });
        if (overOneDayTask || (oneDayTask && yesterday.is.over(oneDayTask.issuedAt))) {
          addTask(constants.BK_TASK_TYPE.超一天无定位扫码车);
        } else {
          addTask(constants.BK_TASK_TYPE.一天内无定位扫码车);
        }
      }
    }

    // 换电
    if (stock.battery.isNoPower) {
      addTask(constants.BK_TASK_TYPE.零电);
    } else if (stock.battery.voltage < 41) {
      addTask(constants.BK_TASK_TYPE.困难换电);
    } else if (stock.battery.isLowPower) {
      addTask(constants.BK_TASK_TYPE.低电);
    } else if (stock.battery.isLowPowerWarning) {
      if (stock.battery.voltage >= constants.BK_VERY_LOW_POWER_WARNING_VOLTAGE) {
        addTask(constants.BK_TASK_TYPE.高压预警);
      } else {
        addTask(constants.BK_TASK_TYPE.低压预警);
      }
    } else if (stock.battery.voltage <= 48.3) {
      if (stock.taskList.search({ code: constants.BK_TASK_TYPE.高压预警 })) {
        addTask(constants.BK_TASK_TYPE.高压预警);
      }
    }

    // 断电
    if (stock.powerUnlink) {
      if (stock.battery.voltage >= 41) {
        addTask(constants.BK_TASK_TYPE.被盗断电);
      } else {
        addTask(constants.BK_TASK_TYPE.零电断电);
      }
    }

    // 无定位
    if (stock.noGpsLocation) {
      addTask(constants.BK_TASK_TYPE.无定位);
    }

    // 超速
    if (stock.latestIllegalSpeedAt && stock.locate === constants.BK_LOCATE.空闲) {
      addTask(constants.BK_TASK_TYPE.空闲超速);
    }

    // 损坏
    if ([constants.BK_STATE.损坏不可租, constants.BK_STATE.报废].includes(stock.state)) {
      addTask(constants.BK_TASK_TYPE.损坏不可租);
    } else if (stock.state === constants.BK_STATE.损坏可租) {
      addTask(constants.BK_TASK_TYPE.损坏可租);
    }

    // 唤醒
    let latestWakedUpAt = stock.latestUsedAt;
    if (!latestWakedUpAt || (stock.latestMovedAt && stock.latestMovedAt.is.over(latestWakedUpAt))) {
      latestWakedUpAt = stock.latestMovedAt;
    }
    if (!latestWakedUpAt || '4 days'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.四天未唤醒);
    } else if (!latestWakedUpAt || '2 days'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.两天未唤醒);
    } else if (!latestWakedUpAt || '1 day'.before(now).is.over(latestWakedUpAt)) {
      addTask(constants.BK_TASK_TYPE.一天未唤醒);
    }
    if (!stock.latestFoundSucceedAt || '4 days'.before(now).is.over(stock.latestFoundSucceedAt)) {
      addTask(constants.BK_TASK_TYPE.四天未巡检);
    }

    // 禁行区
    if (stock.insideProhibitedArea) {
      addTask(constants.BK_TASK_TYPE.禁行区);
    }

    // 围栏外
    if (stock.outsideRegion) {
      if (stock.isFree) {
        addTask(constants.BK_TASK_TYPE.围栏外免单);
      } else {
        addTask(constants.BK_TASK_TYPE.围栏外非免单);
      }
    }

    // 禁停区
    if (stock.insideForbiddenArea) {
      addTask(constants.BK_TASK_TYPE.禁停区);
    }

    // 将任务组排序，获得最高优先级组作为最终任务组
    taskGroups = taskGroups.sort((t1, t2) => constants.BK_TASK_GROUP_RATE[t2] - constants.BK_TASK_GROUP_RATE[t1]);
    const taskGroup = taskGroups.length > 0 ? taskGroups[0] : null;

    // 计算任务权重
    let taskRate = 0;
    if (judgement.isNotEmpty(taskGroup) && judgement.isNotEmpty(constants.BK_COUNT_OF_GROUP[taskGroup])) {
      const taskCount = taskGroups.filter(group => group === taskGroup).length;
      taskRate = Math.round((constants.BK_TASK_GROUP_RATE[taskGroup] + (taskCount / constants.BK_COUNT_OF_GROUP[taskGroup])) * 100);
    }

    const releasedTasks = prevTaskList.filter(task => !taskList.search({ code: task.code }));
    const addedTasks = taskList.filter(task => !prevTaskList.search({ code: task.code }));

    // 将任务排序, 最高任务存下来
    taskList = taskList.sort((t1, t2) => constants.BK_TASK_TYPE_RATE[t2.code] - constants.BK_TASK_TYPE_RATE[t1.code]);
    const highestTask = taskList.length > 0 ? taskList[0].code : null;
    return {
      releasedTasks,
      addedTasks,
      taskList,
      hasTask,
      prevHasTask,
      prevTaskList,
      taskGroup,
      taskRate,
      highestTask,
    };
  }

  static *checkIfHasTask(id, source) {
    // let stock = yield this.findByIdAndCheckExists(id);
    let stock = yield this.Model.findById(id).populate({
      path: 'region',
      model: OPRegionController.Model,
      select: 'name',
    });
    const now = new Date();
    let matchTaskGroupAt = stock.matchTaskGroupAt || now;
    const { releasedTasks, addedTasks, taskList, hasTask, prevTaskList, taskGroup, highestTask, taskRate = 0 } = yield this.checkTask(stock);
    if (stock.taskGroup !== taskGroup) {
      matchTaskGroupAt = now;
    }
    stock = yield BKStock.findByIdAndUpdate(id, {
      $set: {
        taskList,
        hasTask,
        taskGroup,
        taskRate,
        matchTaskGroupAt,
        highestTask,
      },
    }, { new: true });
    return { stock, taskList, releasedTasks, addedTasks, hasTask, prevTaskList };
  }

  *checkIfHasTask(id) {
    let stock = yield this.findByIdAndCheckExists(id);
    const now = new Date();
    let matchTaskGroupAt = stock.matchTaskGroupAt || now;
    const { releasedTasks, addedTasks, taskList, hasTask, prevTaskList, taskGroup, highestTask, taskRate = 0 } = yield BKStockController.checkTask(stock);
    if (stock.taskGroup !== taskGroup) {
      matchTaskGroupAt = now;
    }
    stock = yield this.T(BKStock).findByIdAndUpdate(id, {
      $set: {
        taskList,
        hasTask,
        taskGroup,
        taskRate,
        matchTaskGroupAt,
        highestTask,
      },
    }, { new: true });
    return { stock, taskList, releasedTasks, addedTasks, hasTask, prevTaskList };
  }

  static *checkInspector(id) {
    let stock = yield this.findByIdAndCheckExists(id);
    // 在租或在库或无任务则强制取消分配
    if (([constants.BK_LOCATE.在租, constants.BK_LOCATE.仓库].includes(stock.locate) || !stock.hasTask) && stock.inspector) {
      stock = yield this.releaseInspector(stock);
      // 手动分配标记的任务不进行自动分配
    } else if (!stock.manualAssignTask && stock.hasTask && stock.location.lngLat) { // 产生巡检任务，进行分配
      if (!stock.inspector) {
        stock = yield this.distributeInspector(stock);
      } else {
        const operator = yield ACOperatorController.Model.findOne({ user: stock.inspector });
        const operatorLowestTaskGroup = operator.acceptTaskGroups.sort((t1, t2) => constants.BK_TASK_GROUP_RATE[t1] - constants.BK_TASK_GROUP_RATE[t2])[0];
        if (judgement.isNotEmpty(operatorLowestTaskGroup) && (constants.BK_TASK_GROUP_RATE[operatorLowestTaskGroup] > constants.BK_TASK_GROUP_RATE[stock.taskGroup])) {
          stock = yield this.releaseInspector(stock);
        }
      }
    }
    return stock;
  }

  *checkInspector(id) {
    return yield BKStockController.checkInspector.bind(this)(id);
  }

  static *updateInspector(id, inspector, { operator, operateLocation, operateRemark }) {
    const stock = yield this.findByIdAndCheckExists(id);
    if (operator) {
      yield BKStock.findByIdAndUpdate(id, {
        $set: {
          manualAssignTask: true,
        },
      });
    }
    if (!inspector) return yield this.releaseInspector(stock, {
      operator,
      operateLocation,
      operateRemark,
    });
    if (!stock.hasTask) throw new Error('该车辆无异常');
    const user = yield ACUserController.findByIdAndCheckExists(inspector);
    const op = yield ACOperatorController.Model.findOne({ user: inspector });
    if (!op.enable) throw new Error('运营账户未启用');
    if (!op.isWorking) throw new Error('该运营人员不在班');
    if (!op.regions.includes(stock.region)) throw new Error('该运营人员不负责该大区');
    yield RCStockOpController.opDistributeInspector({
      stock: id,
      operator,
      operateLocation,
      operateRemark,
    }, {
      inspector: user._id,
      inspectorName: user.cert.name,
      inspectorTel: user.auth.tel,
      prevTaskList: stock.taskList,
    });
    return yield BKStock.findByIdAndUpdate(id, {
      $set: {
        inspector: user._id,
        inspectorName: user.cert.name,
        inspectorTel: user.auth.tel,
      },
    });
  }

  static *getValidInspector(stock) {
    let operator;
    if (!stock.inspector && stock.location.lngLat && stock.hasTask) {
      // 在租在库丢失不分配
      if (![
          constants.BK_LOCATE.仓库,
          constants.BK_LOCATE.在租,
          constants.BK_LOCATE.丢失,
          constants.BK_LOCATE.疑似丢失,
        ].includes(stock.locate)
        || stock.taskList.includes(constants.BK_TASK_TYPE.待投放)
        || stock.taskList.includes(constants.BK_TASK_TYPE.丢失扫码车)
      ) {
        // 搜索最近的包含有车辆任务分组的巡检人员，对车辆进行分配, 如果车辆在巡检区内， 只分配给有巡检区权限的人
        operator = yield ACOperatorController.findNearestInspector({
          lngLat: stock.location.lngLat,
          region: stock.region,
          taskGroup: stock.taskGroup,
          inspectionArea: stock.location.intersectInspectionArea,
        });
      }
    }
    if (operator && operator.user) {
      yield RCStockOpController.opDistributeInspector({ stock: stock._id }, {
        inspector: operator.user._id,
        inspectorName: operator.user.cert.name,
        inspectorTel: operator.user.auth.tel,
        prevTaskList: stock.taskList,
      });
    }
    return operator && operator.user;
  }

  static *distributeInspector(stock) {
    if ([
        constants.BK_LOCATE.仓库,
        constants.BK_LOCATE.在租,
        constants.BK_LOCATE.丢失,
        constants.BK_LOCATE.疑似丢失,
        constants.BK_LOCATE.内部使用,
        constants.BK_LOCATE.其他占用,
      ].includes(stock.locate)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.待投放)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.一天内丢失扫码车)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.超一天丢失扫码车)
    ) return;
    const inspector = yield this.getValidInspector(stock);
    if (!inspector) return stock;
    return yield BKStock.findByIdAndUpdate(stock._id, {
      $set: {
        inspector: inspector._id,
        inspectorName: inspector.cert.name,
        inspectorTel: inspector.auth.tel,
      },
    }, { new: true });
  }

  *distributeInspector(stock) {
    if ([
        constants.BK_LOCATE.仓库,
        constants.BK_LOCATE.在租,
        constants.BK_LOCATE.丢失,
        constants.BK_LOCATE.疑似丢失,
        constants.BK_LOCATE.内部使用,
        constants.BK_LOCATE.其他占用,
      ].includes(stock.locate)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.待投放)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.一天内丢失扫码车)
      && !stock.taskList.includes(constants.BK_TASK_TYPE.超一天丢失扫码车)
    ) return;
    const inspector = yield BKStockController.getValidInspector(stock);
    if (!inspector) return stock;
    return yield this.T(BKStock).findByIdAndUpdate(stock._id, {
      $set: {
        inspector: inspector._id,
        inspectorName: inspector.cert.name,
        inspectorTel: inspector.auth.tel,
      },
    }, { new: true });
  }

  static *recordReleaseInspectorOperation(stock, inspector, { operator, operatorLocation, operatorRemark } = {}) {
    if (inspector) {
      yield RCStockOpController.opReleaseInspector({
        stock: stock._id,
        operator,
        operatorLocation,
        operatorRemark,
      }, {
        inspector: inspector._id,
        inspectorTel: inspector.auth.tel,
        inspectorName: inspector.cert.name,
        prevTaskList: stock.taskList,
      });
    }
  }

  static *releaseInspector(stock, { operator, operatorLocation, operatorRemark } = {}) {
    const inspector = yield ACUserController.Model.findById(stock.inspector);
    yield BKStockController.recordReleaseInspectorOperation(stock, inspector, {
      operator,
      operatorLocation,
      operatorRemark,
    });
    if (!operator) {
      yield BKStock.findByIdAndUpdate(stock._id, {
        $set: {
          manualAssignTask: false,
        },
      });
    }
    return yield BKStock.findByIdAndUpdate(stock._id, {
      $unset: {
        inspector: 1,
        inspectorName: 1,
        inspectorTel: 1,
      },
    }, { new: true });
  }

  *releaseInspector(...params) {
    return yield BKStockController.releaseInspector.bind(this)(...params);
  }

  static *releaseInspectorByInspector(inspector) {
    const stocks = yield BKStock.find({ inspector });
    for (const stock of stocks) {
      if (stock.inspector) {
        yield this.releaseInspector(stock);
      }
      yield this.distributeInspector(stock);
    }
  }

  static *releaseInvalidByInspector(inspector) {
    const operator = yield ACOperatorController.findByUserAndPopulate(inspector);

    const stocks = yield BKStock.find({
      inspector,
      $or: [{
        region: { $nin: operator.regions },
      }, {
        taskGroup: { $nin: operator.acceptTaskGroups },
      }, {
        'location.intersectInspectionArea': { $nin: operator.inspectionAreas },
      }],
    });
    for (const stock of stocks) {
      if (stock.inspector && stock.locate !== constants.BK_LOCATE.调度) {
        yield this.releaseInspector(stock);
      }
      yield this.distributeInspector(stock);
    }
  }

  static *findNoInspectorAndDistribute(regions, center) {
    const stocks = yield BKStock.find({
      region: { $in: regions },
      hasTask: true,
      inspector: { $not: { $exists: true, $ne: null } },
    }).near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: constants.INSPECTOR_SEARCH_RADIUS / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    });
    for (const stock of stocks) {
      yield this.distributeInspector(stock);
    }
  }

  static *addSpecialTask(id, { remark, location, photo }, { operator, operateLocation }) {
    const taskId = yield BKStock.genId();
    const now = new Date();
    yield BKStock.findByIdAndUpdate(id, {
      $push: {
        specialTasks: {
          id: taskId,
          time: now,
          remark,
          photo,
          location,
        },
      },
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opAddSpecialTask({
      stock: id,
      operator,
      operateLocation,
      operateRemark: remark,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      taskId,
      remark,
      photo,
      location,
      now,
    });
    return yield this.checkInspector(id);
  }

  static *removeSpecialTask(id, { taskId, remark, location, photo }, { operator, operateLocation }) {
    yield BKStock.findByIdAndUpdate(id, {
      $pull: {
        specialTasks: {
          id: taskId,
        },
      },
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opRemoveSpecialTask({
      stock: id,
      operator,
      operateLocation,
      operateRemark: remark,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      taskId,
      remark,
      photo,
      location,
      time: new Date(),
    });
    return yield this.checkInspector(id);
  }

  static *releaseRevival(id, { remark, photo }, { operator, operateLocation }) {
    yield BKStock.findByIdAndUpdate(id, {
      $set: {
        releasedRevivalAt: new Date(),
        latestScannedAt: null,
      },
    });
    yield this.checkIfValid(id);
    const { releasedTasks, addedTasks, prevTaskList } = yield this.checkIfHasTask(id);
    yield RCStockOpController.opReleaseRevivalTask({
      stock: id,
      operator,
      operateLocation,
      operateRemark: remark,
      releasedTasks,
      addedTasks,
      prevTaskList,
    }, {
      photo,
    });
    return yield this.checkInspector(id);
  }

  static transformBaojia(stock) {
    return {
      id: stock._id,
      plateNo: stock.number.custom,
      lng: stock.location.lngLat[0],
      lat: stock.location.lngLat[1],
      mileage: stock.battery.mileage,
      power: stock.battery.power * 100,
      datetime: stock.location.locatedAt.unix,
      startPrice: stock.region.prices[stock.style.level].floorCost,
      minutePrice: stock.region.prices[stock.style.level].timeUnit,
      milePrice: stock.region.prices[stock.style.level].mileageUnit,
      isValid: stock.isValid,
    };
  }

  static *inbound(numbers, station, operator) {
    const errors = [];
    for (let number of numbers) {
      try {
        const stock = yield BKStockController.Model.findOne({ 'number.custom': number });
        if (!stock) throw new Error(`车牌号不存在`);
        yield BKStockController.updateLocate(stock._id, constants.BK_LOCATE.仓库, {
          operator,
          opInBound: {
            prevStation: stock.station,
            nextStation: station._id,
          },
        }, station);
        yield SSBackHaulInDayController.create({ stock, operator });
      } catch (err) {
        errors.push({
          number,
          message: err.message,
        });
      }
    }
    return errors;
  }

  static *outBound(numbers, station, operator) {
    const errors = [];
    for (let number of numbers) {
      try {
        const stock = yield BKStockController.Model.findOne({ 'number.custom': number }).populate({
          path: 'station',
          select: 'name',
          model: OPBatteryStationController.Model,
        });
        if (!stock) throw new Error(`车牌号不存在`);
        // if (!stock.station) throw new Error(`车牌号${number}不在库`);
        else {
          if (stock.station && (stock.station._id !== station._id)) {
            yield RCStockOpController.opChangeStation({ stock, station, operator });
          }
        }
        yield OPBatteryStationController.Model.findByIdAndUpdate(station._id, {
          $inc: {
            outStockCount: 1,
          },
        });
        yield BKStockController.updateLocate(stock._id, constants.BK_LOCATE.调度, {
          operator,
          opOutBound: {
            prevStation: station._id,
            nextStation: '',
          },
        }, station);
      } catch (err) {
        errors.push({
          number,
          message: err.message,
        });
      }
    }
    return errors;
  }

  static *bindVin(stock, vin, operator) {
    yield RCStockOpController.opBindVin({ stock, operator }, { vin });
    return yield BKStockController.Model.findByIdAndUpdate(stock._id,
      {
        $set: {
          'number.vin': vin,
        },
      }, { new: true });
  }

  static *checkOutboundValid(numbers) {
    const errors = [];
    for (let number of numbers) {
      const stock = yield BKStockController.Model.findOne({ 'number.custom': number });
      if (!stock) {
        errors.push({
          number,
          message: '不存在',
        });
      } else {
        const RCOutFactoryController = require('../record/RCOutFactoryController');
        const unfinishedRecord = yield RCOutFactoryController.Model.findOne({
          isFinished: false,
          success: number,
        });
        if (unfinishedRecord) {
          errors.push({
            number,
            message: '正在出库',
          });
        }
        // else if (stock.region !== '1802101223850') {
        //   errors.push({
        //     number,
        //     message: '不在新日成品大区',
        //   });
        //    车架号、车机编号、电机码、成车条码
        // }
        else if (!stock.number.custom) {
          errors.push({
            number,
            message: '未录入二维码',
          });
        } else if (!stock.number.vin) {
          errors.push({
            number,
            message: '未录入车架号',
          });
        } else if (!stock.box) {
          errors.push({
            number,
            message: '未录入车机编号',
          });
        } else if (!stock.lockVin.isLocked) {
          errors.push({
            number,
            message: '车架号未锁定',
          });
        } else if (stock.locate === constants.BK_LOCATE.跨区运输中) {
          errors.push({
            number,
            message: '车辆当前去向不能为跨区运输中',
          });
        }
      }
    }
    return errors;
  }
}

BKStockController.Model = BKStock;
module.exports = BKStockController;
