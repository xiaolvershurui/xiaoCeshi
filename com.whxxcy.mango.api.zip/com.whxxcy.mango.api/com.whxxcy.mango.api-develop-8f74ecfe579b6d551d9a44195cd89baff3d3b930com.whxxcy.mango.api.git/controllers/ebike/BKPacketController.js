const BKPacket = require('../../models/ebike/bk_packet');
const ACUserController = require('../account/ACUserController');
const BKBatteryController = require('../../controllers/ebike/BKBatteryController');
const ACOperatorController = require('../account/ACOperatorController');
const OPRegionController = require('../operation/OPRegionController');
const OPBatteryStationController = require('../operation/OPBatteryStationController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class BKPacketController extends Controller {

  static * checkValid ({QRCode, region, station}) {
    const bkPackage = yield BKPacketController.Model.findOne({QRCode});
    if (bkPackage) throw new Error(`二维码${QRCode}已存在`);
    yield OPRegionController.findByIdAndCheckExists(region);
    yield OPBatteryStationController.findByIdAndCheckExists(station);
  }

  static * findByIdAndCheckExists (id) {
    const packet = yield this.Model.findById(id);
    if (!packet) throw new Error('未携带物资包');
    return packet;
  }

  static * create ({region, QRCode, station, batteryIds, creator}) {
    yield this.checkValid({QRCode, region, station});
    const id = yield BKPacket.genId();
    return yield BKPacket.create({
      _id: id,
      QRCode,
      region,
      station,
      batteryIds,
      creator
    })
  }

  static * take (packet, {operator}) {
    for (let batteryId of packet.batteryIds) {
      yield BKBatteryController.updateLocate(batteryId, constants.BK_BATTERY_LOCATE.巡检人员携带, operator, {
        inspector: operator,
        packet: packet._id
      })
    }
    yield this.Model.findByIdAndUpdate(packet._id, {
      $set: {
        inspector: operator
      }
    })
  }

  static * packet ({batteryIds, QRCode, operator, region, station}) {
    const packet = yield BKPacketController.create({
      QRCode,
      region,
      station,
      batteryIds,
      creator: operator
    });
    const acOp = yield ACOperatorController.Model.findOne({user: operator});
    yield ACOperatorController.updateBatteryBag(acOp._id, {
      batteries: batteryIds,
      total: batteryIds.length,
      available: batteryIds.length,
      unavailable: 0
    });
    yield BKBatteryController.pack(batteryIds, operator, packet._id);
  }

  static * unPacket (packet) {
    yield BKBatteryController.unPack(packet)
  }

  static * install ({stock, battery, inspector, packet}) {
    battery = yield BKBatteryController.Model.findById(battery);
    const oldBattery = yield BKBatteryController.Model.findOne({stock});
    //TODO: 电池被偷
    if (!oldBattery) throw new Error('该车辆没有电池');
    packet = yield BKPacketController.findByIdAndCheckExists(packet);
    const index = packet.batteryIds.indexOf(battery._id);
    if (index === -1) throw new Error('该电池包不存在该电池');
    packet.batteryIds.splice(index, 1, oldBattery._id);
    yield BKPacketController.Model.findByIdAndUpdate(packet._id, {
      $set: packet
    });
    yield BKBatteryController.updateLocate(battery._id, constants.BK_BATTERY_LOCATE.安装于车辆, inspector, {stock});
    yield BKBatteryController.updateLocate(oldBattery._id, constants.BK_BATTERY_LOCATE.巡检人员携带, inspector, {
      inspector: packet.inspector,
      packet: packet._id
    });
  }
}

BKPacketController.Model = BKPacket;
module.exports = BKPacketController;