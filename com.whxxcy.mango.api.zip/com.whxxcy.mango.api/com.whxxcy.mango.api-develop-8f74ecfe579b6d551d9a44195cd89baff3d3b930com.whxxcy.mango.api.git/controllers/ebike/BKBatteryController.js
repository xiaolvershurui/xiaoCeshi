const constants = require('../../settings/constants');
const BKBattery = require('../../models/ebike/bk_battery');
const BKStock = require('../../models/ebike/bk_stock');
const OPBatteryStation = require('../../models/operation/op_battery_station');
const ACOperator = require('../../models/account/ac_operator');
const OPRegionController = require('../operation/OPRegionController');
const ACUserController = require('../account/ACUserController');
const ACOperatorController = require('../account/ACOperatorController');
const OPBatteryStationController = require('../operation/OPBatteryStationController');
const RCBatteryInStockControoller = require('../record/RCBatteryInStockControoller');
const RCBatteryOpController = require('../record/RCBatteryOpController');
const RCBatteryReceipt = require('../../models/record/rc_battery_receipt');
const SSBatteryInDay = require('../../models/statistic/ss_battery_in_day');
const BKStockController = require('../ebike/BKStockController');
const SSChangeBatteryController = require('../statistic/SSChangeBatteryController');
const RCBatteryLostController = require('../record/RCBatteryLostController');
const RCPlacementBattery = require('../../models/record/rc_placement_battery');
const Controller = require('../Controller');
const Error = require('errrr');
const transaction = require('../../services/transaction');
const dingRoot = require('../../services/dingRobot');
const uuid = require('node-uuid');
const shark = require('../../services/shark');

class BKBatteryController extends Controller {

  static *checkCodeValid({ QRCode, region, operator }) {
    const battery = yield BKBatteryController.Model.findOne({ QRCode });
    if (battery) throw new Error(`二维码${QRCode}已存在`);
    yield OPRegionController.findByIdAndCheckExists(region);
    yield ACUserController.findByIdAndCheckExists(operator);
  }

  static *findByCodeAndCheckExists(QRCode) {
    const battery = yield BKBattery.findOne({ QRCode });
    if (!battery) throw new Error(`电池${QRCode}不存在`);
    return battery;
  }

  *updateQRCode({ battery, QRCode, operator }) {
    yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
      $set: {
        QRCode,
      },
    });
    yield new RCBatteryOpController(this.transaction).updateQRCode({ battery, QRCode, operator });
  }

  *charge({ QRCodes, station, operator }) {
    let newBattery = 0;
    let oldBattery = 0;
    for (let QRCode of QRCodes) {
      let battery = yield BKBatteryController.Model.findOne({ QRCode });
      if (!battery) {
        newBattery += 1;
        const id = yield BKBattery.genId();
        battery = yield this.T(BKBattery).create({
          _id: id,
          QRCode,
          station: station._id,
          underVoltage: true,
          fromStation: station._id,
          region: station.region,
        });
        yield new RCBatteryOpController(this.transaction).createNew({
          id,
          station,
          region: station.region,
          QRCode,
          operator,
          underVoltage: true,
        });
      } else {
        oldBattery += 1;
      }
      yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
        $set: {
          charge: true,
        },
        $inc: {
          'useRecord.rechargeCount': 1,
        },
      });
      yield new RCBatteryOpController(this.transaction).opUpdateCharge({
        battery,
        QRCode,
        operator,
        charge: true,
      });
    }
    return {
      newBattery,
      oldBattery,
    };
  }

  *unCharge({ QRCodes, station, operator }) {
    let newBattery = 0;
    let oldBattery = 0;
    for (let QRCode of QRCodes) {
      let battery = yield BKBatteryController.Model.findOne({ QRCode });
      if (!battery) {
        newBattery += 1;
        // throw new Error(`电池${QRCode}还未录入`);
        const id = yield BKBattery.genId();
        battery = yield this.T(BKBattery).create({
          _id: id,
          QRCode,
          station: station._id,
          underVoltage: false,
          fromStation: station._id,
          region: station.region,
        });
        yield new RCBatteryOpController(this.transaction).createNew({
          id, station, QRCode, operator, underVoltage: false, region: station.region,

        });
      } else {
        oldBattery += 1;
      }
      yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
        $set: {
          charge: false,
          underVoltage: false,
        },
      });
      yield new RCBatteryOpController(this.transaction).opUpdateCharge({
        battery,
        QRCode,
        operator,
        charge: false,
        underVoltage: false,
      });
    }
    return {
      newBattery,
      oldBattery,
    };
  }

  checkLocate({ battery, operator, isReceive, nextLocate }) {
    const prevLocate = battery.locate;
    try {
      if (prevLocate === constants.BK_BATTERY_LOCATE.在运营站) {
        if (nextLocate === constants.BK_BATTERY_LOCATE.安装于车辆) throw new Error(`${operator.cert.name}将${battery.QRCode}从在站安装到车辆`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.在运营站) throw new Error(`${operator.cert.name}将${battery.QRCode}从在站${isReceive ? '接收' : '录入'}到库`);
      } else if (prevLocate === constants.BK_BATTERY_LOCATE.巡检人员携带) {
        if (nextLocate === constants.BK_BATTERY_LOCATE.运输途中) throw new Error(`${operator.cert.name}将${battery.QRCode}从巡检变成运输中`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.巡检人员携带) throw new Error(`${operator.cert.name}将${battery.QRCode}从在巡检变成在巡检`);
      } else if (prevLocate === constants.BK_BATTERY_LOCATE.安装于车辆) {
        if (nextLocate === constants.BK_BATTERY_LOCATE.运输途中) throw new Error(`${operator.cert.name}将${battery.QRCode}从在车变成运输中`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.在运营站) throw new Error(`${operator.cert.name}将${battery.QRCode}从在车变成在站`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.安装于车辆) throw new Error(`${operator.cert.name}将${battery.QRCode}从在车变成在车`);
      } else if (prevLocate === constants.BK_BATTERY_LOCATE.运输途中) {
        if (nextLocate === constants.BK_BATTERY_LOCATE.巡检人员携带) throw new Error(`${operator.cert.name}将${battery.QRCode}从运输中变成巡检携带`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.安装于车辆) throw new Error(`${operator.cert.name}将${battery.QRCode}从运输变成在车`);
        else if (nextLocate === constants.BK_BATTERY_LOCATE.运输途中) throw new Error(`${operator.cert.name}将${battery.QRCode}从运输变成运输中`);
      }
    } catch (error) {
      // dingRoot.sendAbnormalBattery(error.message)
    }
  }

  *inboundAndCreate({ QRCodes = [], underVoltage, station, extraCount, sourceStation, sourceAccount, operator }) {
    const QRCodeCount = QRCodes.length;
    const batteries = [];
    const op = yield ACOperatorController.Model.findOne({ user: operator._id });
    // 应还电池 - 实际电池
    const missCount = (op.batteryBag.available + op.batteryBag.unavailable) - (QRCodes.length + extraCount);
    let wrongCount = 0;
    for (let QRCode of QRCodes) {
      let battery = yield BKBatteryController.Model.findOne({ QRCode });
      if (!battery) {
        const id = yield BKBattery.genId();
        battery = yield this.T(BKBattery).create({
          _id: id,
          QRCode,
          station: station._id,
          underVoltage,
          fromStation: station._id,
          region: station.region,
        });
        yield new RCBatteryOpController(this.transaction).createNew({
          id,
          station,
          region: station.region,
          QRCode,
          underVoltage,
          operator,
          fromStation: sourceStation,
          fromAccount: sourceAccount,
        });
      } else {
        if (battery.locate === constants.BK_BATTERY_LOCATE.安装于车辆) {
          // TODO: 错误换电
          wrongCount += 1;
          const stock = yield BKStockController.Model.findById(battery.stock);
          if (stock) {
            // 生成占位电池绑定到车
            const id = yield BKBattery.genId();
            const newCode = `占${uuid.v4()}`;
            yield this.T(BKBattery).create({
              _id: id,
              QRCode: newCode,
              locate: constants.BK_BATTERY_LOCATE.安装于车辆,
              stock: stock._id,
            });
            yield this.T(RCPlacementBattery).create({
              operator: operator._id,
              stock: stock._id,
              locate: constants.BK_BATTERY_LOCATE.安装于车辆,
              region: stock.region,
              battery: id,
              QRCode: newCode,
              reason: constants.RC_PLACEMENT_BATTERY_TYPE.入库时电池在车上,
            });
            yield this.T(BKStock).findByIdAndUpdate(stock._id, {
              $set: {
                'battery.id': id,
              },
            });
          }
        }
        yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
          $set: {
            locate: constants.BK_BATTERY_LOCATE.在运营站,
            station: station._id,
            underVoltage,
            fromStation: station._id,
          },
          $unset: {
            stock: 1,
            inspector: 1,
          },
        });
        yield new RCBatteryOpController(this.transaction).opInbound({
          battery,
          QRCode,
          operator,
          underVoltage,
          fromStation: sourceStation,
          fromAccount: sourceAccount,
          locate: constants.BK_BATTERY_LOCATE.在运营站,
          station,
        });
      }
      batteries.push(battery._id);
    }
    yield this.T(RCBatteryReceipt).create({
      operator: operator._id,
      isInBound: true,
      sourceStation: station._id,
      sourceAccount,
      QRCodeCount,
      noSignCount: extraCount,
      batteries,
    });

    yield this.T(SSBatteryInDay).findOneAndUpdate({
      date: 'today'.beginning,
      station: station._id,
    }, {
      $inc: {
        inboundCount: QRCodeCount,
        inboundExtraCount: extraCount,
      },
    });

    yield this.T(ACOperator).findByIdAndUpdate(op._id, {
      $inc: {
        'batteryBag.total': -extraCount,
        missCount,
        wrongCount,
      },
    });
    if (sourceAccount) {
      const batteryBag = op.batteryBag.batteries.filter(item => !batteries.includes(item));
      yield this.T(ACOperator).findOneAndUpdate({ user: sourceAccount }, {
        $set: {
          'batteryBag.total': batteryBag.length,
          'batteryBag.batteries': batteryBag,
          'batteryBag.available': 0,
          'batteryBag.unavailable': batteryBag.length,
        },
      });
    }
    yield BKBatteryController.Model.update({ inspector: operator._id }, {
      $set: {
        locate: constants.BK_BATTERY_LOCATE.在运营站,
        station: station._id,
        underVoltage,
        fromStation: station._id,
      },
      $unset: {
        stock: '',
        inspector: '',
      },
    }, { multi: true });
  }

  static *inboundCheck({ QRCodes = [], extraCount, id }) {
    const operator = yield ACOperatorController.Model.findOne({ user: id });
    return {
      outBound: operator.batteryBag.total,
      currentCount: operator.batteryBag.available + operator.batteryBag.unavailable,
      actualCount: QRCodes.length + extraCount,
      noSign: extraCount,
      hasSign: QRCodes.length,
    };
  }

  *outbound({ QRCodes, underVoltage, station, toStation, toAccount, operator }) {
    let newBattery = 0;
    let oldBattery = 0;
    // 出库 若不存在 创建再发出 在外数量+1
    const batteries = [];
    for (let QRCode of QRCodes) {
      let battery = yield BKBatteryController.Model.findOne({ QRCode });
      if (!battery) {
        newBattery += 1;
        //电池不存在 自动创建
        const id = yield BKBattery.genId();
        battery = yield this.T(BKBattery).create({
          _id: id,
          QRCode,
          station: station._id,
          underVoltage,
          fromStation: station._id,
          region: station.region,
        });
        yield new RCBatteryOpController(this.transaction).createNew({
          id, station, QRCode, operator, underVoltage, region: station.region,
        });
      } else {
        const stock = yield BKStockController.Model.findById(battery.stock);
        if (stock) {
          // 生成占位电池绑定到车
          const id = yield BKBattery.genId();
          const newCode = `占${uuid.v4()}`;
          yield this.T(BKBattery).create({
            _id: id,
            QRCode: newCode,
            locate: constants.BK_BATTERY_LOCATE.安装于车辆,
            stock: stock._id,
          });
          yield this.T(RCPlacementBattery).create({
            operator: operator._id,
            stock: stock._id,
            battery: id,
            locate: constants.BK_BATTERY_LOCATE.安装于车辆,
            region: stock.region,
            QRCode: newCode,
            reason: constants.RC_PLACEMENT_BATTERY_TYPE.出库时电池在车上,
          });
          yield this.T(BKStock).findByIdAndUpdate(stock._id, {
            $set: {
              'battery.id': id,
            },
          });
        }
        oldBattery += 1;
      }
      batteries.push(battery._id);
      if (toStation) {
        // 站到站 出库检查
        // this.checkLocate({
        //   battery,
        //   operator,
        //   nextLocate: constants.BK_BATTERY_LOCATE.运输途中
        // });
        // 运输到站 电池状态更新
        yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
          $set: {
            locate: constants.BK_BATTERY_LOCATE.运输途中,
            charge: false,
            underVoltage,
            fromStation: station._id,
          },
          $unset: {
            inspector: 1,
            station: 1,
            stock: 1,
          },
        });
        yield new RCBatteryOpController(this.transaction).opOutBoundToStation({
          battery,
          QRCode,
          operator,
          underVoltage,
          toStation,
          inStation: station,
        });
      } else if (toAccount) {
        // 站到人 出库检查
        // this.checkLocate({
        //   battery,
        //   operator,
        //   nextLocate: constants.BK_BATTERY_LOCATE.巡检人员携带
        // });
        const acOp = yield ACOperatorController.Model.findOne({ user: toAccount._id });
        if (!acOp.batteryBag.batteries.includes(battery._id)) {
          // 派发给人 电池更新 巡检员携带电池数量更新
          yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
            locate: constants.BK_BATTERY_LOCATE.巡检人员携带,
            station: '',
            charge: false,
            stock: '',
            underVoltage,
            inspector: toAccount._id,
            fromStation: station._id,
          });

          // 今日发出电池数量增加
          // 二维码和标记均存在才计算
          if (battery.QRCode && battery.mark) {
            yield this.T(OPBatteryStation).findByIdAndUpdate(station._id, {
              $inc: {
                outCount: 1,
              },
            });
            yield this.T(ACOperator).findOneAndUpdate({ user: toAccount._id }, {
              $set: {
                'batteryBag.enable': true,
              },
              $inc: {
                'batteryBag.total': 1,
                'batteryBag.available': 1,
              },
            });
          }
          yield new RCBatteryOpController(this.transaction).opOutBoundToOperator({
            battery,
            QRCode,
            operator,
            toAccount,
            inStation: station,
          });
        }
      }
    }
    yield this.T(RCBatteryReceipt).create({
      operator: operator._id,
      isInBound: false,
      sourceStation: station._id,
      sourceAccount: toAccount,
      QRCodeCount: QRCodes.length,
      batteries,
    });

    yield this.T(SSBatteryInDay).findOneAndUpdate({
      date: 'today'.beginning,
      station: station._id,
    }, {
      $inc: {
        outboundCount: QRCodes.length,
      },
    });

    return {
      newBattery,
      oldBattery,
    };
  }

  *damage({ QRCodes, station, operator }) {
    let newBattery = 0;
    let oldBattery = 0;
    for (let QRCode of QRCodes) {
      let battery = yield BKBatteryController.Model.findOne({ QRCode });
      if (!battery) {
        newBattery += 1;
        //电池不存在 自动创建
        const id = yield BKBattery.genId();
        battery = yield this.T(BKBattery).create({
          _id: id,
          QRCode,
          station: station._id,
          underVoltage: true,
          fromStation: station._id,
          region: station.region,
        });
        yield new RCBatteryOpController(this.transaction).createNew({
          id, station, QRCode, operator, underVoltage: true, region: station.region,

        });
      } else {
        oldBattery += 1;
      }
      yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
        $set: {
          locate: constants.BK_BATTERY_LOCATE.在运营站,
          state: constants.BK_BATTERY_STATE.损坏,
        },
      });
      yield new RCBatteryOpController(this.transaction).opDamage({
        battery, QRCode, operator, station: battery.station,
      });
    }
    return {
      newBattery,
      oldBattery,
    };
  }

  *findByIdAndCheckExists(id) {
    const battery = yield this.T(BKBattery).findById(id);
    if (!battery) throw new Error('电池不存在');
    return battery;
  }

  static *findByIdAndCheckExists(id) {
    const battery = yield BKBattery.findById(id);
    if (!battery) throw new Error('电池不存在');
    return battery;
  }

  // 生成占位电池并且绑定到车上
  *createResistBattery(stock, region, operator) {
    const id = yield BKBattery.genId();
    const newCode = `占${uuid.v4()}`;
    yield this.T(RCPlacementBattery).create({
      operator: operator._id,
      stock: stock,
      battery: id,
      locate: constants.BK_BATTERY_LOCATE.安装于车辆,
      region,
      QRCode: newCode,
      reason: constants.RC_PLACEMENT_BATTERY_TYPE.换电时电池在车上,
    });
    return yield this.T(BKBattery).create({
      _id: id,
      QRCode: newCode,
      locate: constants.BK_BATTERY_LOCATE.安装于车辆,
      stock,
      region,
    });
  }

  *bindStock(id, { operator, stock, batteryInUse, region }) {
    if (operator.constructor.name === 'String') throw new Error('operator should be an object.');
    let battery;
    if (id) {
      battery = yield this.findByIdAndCheckExists(id);
    }
    if (battery) {
      // 有确定的电池
      // 给stock绑定电池
      yield this.T(BKStock).findByIdAndUpdate(stock, {
        $set: {
          'battery.id': id,
        },
      });
      // 给电池绑定stock
      yield this.T(BKBattery).findByIdAndUpdate(id, {
        $set: {
          stock,
          underVoltage: true,
          locate: constants.BK_BATTERY_LOCATE.安装于车辆,
        },
        $unset: {
          inspector: 1,
        },
      });
      // 携带可用电池减少
      if (operator.batteryBag.enable) {
        yield this.T(ACOperator).findByIdAndUpdate(operator._id, {
          $inc: battery.underVoltage ? {
            'batteryBag.unavailable': -1,
          } : {
            'batteryBag.available': -1,
          },
        });
      }
    } else {
      // 没有确定的电池
      // 创建占位电池绑定车
      battery = yield this.createResistBattery(stock, region, operator);
      // 给车绑定占位电池
      yield this.T(BKStock).findByIdAndUpdate(stock, {
        $set: {
          'battery.id': battery._id,
        },
      });
      // 错误换电增加
      yield this.T(ACOperator).findByIdAndUpdate(operator._id, {
        // 错误次数增加
        $inc: {
          wrongCount: 1,
        },
        // 记录错误设备
        $push: {
          wrongStock: {
            stock: stock._id,
            number: stock.number && stock.number.custom,
            battery: batteryInUse.QRCode,
          },
        },
      });
    }
    return battery;
  }

  *unbindStock({ stock, operator, isLost = false, isInbound = false }) {
    if (operator.constructor.name === 'String') throw new Error('operator should be an object.');
    // 给车辆解绑电池
    const stockData = yield this.T(BKStock).findByIdAndUpdate(stock, {
      $unset: {
        'battery.id': 1,
      },
    });
    let oldBattery;
    // 给电池解绑车辆
    if (stockData && stockData.battery.id) {
      oldBattery = yield this.T(BKBattery).findByIdAndUpdate(stockData.battery.id, {
        $set: (_ => {
          if (isLost) return {
            locate: constants.BK_BATTERY_LOCATE.丢失,
            underVoltage: true,
          };
          if (isInbound) return {
            locate: constants.BK_BATTERY_LOCATE.在运营站,
            underVoltage: true,
          };
          return {
            locate: constants.BK_BATTERY_LOCATE.巡检人员携带,
            inspector: operator.user._id,
            underVoltage: true,
          };
        })(),
        $unset: {
          stock: 1,
        },
      });
      if (!isLost && !isInbound) {
        // 携带不可用电池增加
        yield this.T(ACOperator).findByIdAndUpdate(operator._id, {
          $inc: {
            'batteryBag.unavailable': 1,
          },
        });
      }
    }
    return oldBattery;
  }

  *change({ QRCode, mark, stock, operator }) {
    let battery;
    if (mark) {
      battery = yield BKBatteryController.Model.findOne({ mark });
    } else if (QRCode) {
      battery = yield BKBatteryController.Model.findOne({ QRCode });
    }
    if (!battery) throw new Error(`${mark ? `${mark}` : `${QRCode}`}不存在`);
    if (battery.state === constants.BK_BATTERY_STATE.损坏) throw new Error(`电池${QRCode}损坏不能报废`);

    if (battery.locate !== constants.BK_BATTERY_LOCATE.巡检人员携带) throw new Error(`电池去向应为巡检人员携带, 请到仓库领用后重试`);
    const st = yield BKStockController.findByIdAndCheckExists(stock);
    if (battery.region !== st.region) throw new Error('电池大区和车辆的大区不同,请截图发给线上运营协助处理');
    const transaction = this.transaction;
    const exchangeOp = function *({ battery, oldBattery, stock, isWrong, st }) {
      let description;
      if (isWrong) {
        const oldStock = yield BKStockController.findByIdAndCheckExists(battery.stock);
        description = `错误换电: ${battery.QRCode}在车${oldStock.number.custom}上,被换到${st.number.custom}上`;
      }
      const op = yield new RCBatteryOpController(transaction).change({
        battery, oldBattery, stock: st, operator, description,
      });
      yield SSChangeBatteryController.trigger({ stock: st, rcId: op._id });
    };
    // 扫的电池在不在车上
    if (battery.locate === constants.BK_BATTERY_LOCATE.安装于车辆 && battery.stock && battery.stock !== stock) {
      // 解绑当前安装的车
      const oldBattery = yield this.unbindStock({
        stock: battery.stock,
        operator,
      });
      // 给这个车绑定一块占位电池
      const bt = yield this.bindStock(null, {
        stock: battery.stock,
        // 扫的电池在车上的电池信息
        batteryInUse: battery,
        operator,
        region: battery.region,
      });

      yield exchangeOp({ battery: bt, oldBattery, stock: battery.stock, isWrong: true });
    }

    // 解绑当前的车辆电池
    const oldBattery = yield this.unbindStock({
      stock,
      operator,
    });
    // 将扫的电池绑定到车辆上
    yield this.bindStock(battery._id, {
      stock,
      operator,
    });

    yield exchangeOp({ battery, oldBattery, stock, st });
  }

  *confirm({ QRCode, mark, stock, operator }) {
    let battery;
    if (mark) {
      battery = yield BKBatteryController.Model.findOne({ mark });
    } else if (QRCode) {
      battery = yield BKBatteryController.Model.findOne({ QRCode });
    }
    if (!battery) throw new Error(`${mark ? `${mark}` : `${QRCode}`}不存在`);

    const bkStock = yield BKStockController.Model.findById(stock).populate({
      path: 'battery.id',
      model: BKBatteryController.Model,
      select: 'QRCode',
    });
    if (!bkStock) throw new Error(`车辆${stock}不存在`);
    if (bkStock.battery && bkStock.battery.id && (/^占/).test(bkStock.battery.id.QRCode)) {
      yield BKStockController.Model.findByIdAndUpdate(stock, {
        $set: {
          'battery.id': battery._id,
        },
      });
      // 给电池绑定stock
      yield BKBatteryController.Model.findByIdAndUpdate(battery._id, {
        $set: {
          stock,
          underVoltage: true,
          locate: constants.BK_BATTERY_LOCATE.安装于车辆,
        },
        $unset: {
          inspector: 1,
        },
      });

      yield BKBatteryController.Model.findByIdAndUpdate(bkStock.battery.id, {
        $unset: {
          stock: 1,
        },
        $set: {
          region: '1710190829842',
        },
      });
      yield RCBatteryOpController.updateRegion({
        battery: bkStock.battery,
        stock: bkStock,
        operatorName: '系统',
        operator: '1',
        nextRegion: '1710190829842',
      });

      yield RCBatteryOpController.confirm({
        battery: battery._id,
        stock,
        operator,
        description: `电池确认: 将${bkStock.QRCode}车辆上的占位电池替换成${battery._id}电池`,
      });
    }
  }

  *bindMark({ QRCode, mark, operator, station }) {
    let battery = yield BKBatteryController.Model.findOne({ QRCode });
    if (!battery) {
      //电池不存在 自动创建
      const id = yield BKBattery.genId();
      battery = yield this.T(BKBattery).create({
        _id: id,
        QRCode,
        station: station._id,
        underVoltage: true,
        fromStation: station._id,
        region: station.region,
      });
      yield new RCBatteryOpController(this.transaction).createNew({
        id, station, QRCode, operator, underVoltage: true, region: station.region,
      });
    }
    yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
      $set: {
        mark,
      },
    });
    yield new RCBatteryOpController(this.transaction).bindMark({
      id: battery._id, region: battery.region, QRCode, mark, operator,
    });
  }

  *bindQRCode({ QRCode, mark, operator, station }) {
    let battery = yield BKBatteryController.Model.findOne({ mark });
    if (!battery) {
      //电池不存在 自动创建
      const id = yield BKBattery.genId();
      battery = yield this.T(BKBattery).create({
        _id: id,
        QRCode,
        station: station._id,
        underVoltage: true,
        fromStation: station._id,
        region: station.region,
      });
      yield new RCBatteryOpController(this.transaction).createNew({
        id, station, QRCode, operator, underVoltage: true, region: station.region,
      });
    }
    yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
      $set: {
        QRCode,
      },
    });
    yield new RCBatteryOpController(this.transaction).bindQRCode({
      id: battery._id, region: battery.region, QRCode, mark, operator,
    });
  }

  static *bindMarkAndGps({ QRCode, mark, gps, style, operator, station }) {
    let data = {};
    if (!mark) throw new Error(`请输入标记号后重试`);
    // if (mark) {
    //   data.mark = mark;
    //   const bt = yield BKBatteryController.Model.findOne({ mark });
    //   if (bt) throw new Error(`已存在电池${mark},如有疑问, 请咨询管理员`);
    // }
    data.mark = mark;
    const bt = yield BKBatteryController.Model.findOne({ mark });
    if (bt) throw new Error(`已存在电池${mark},如有疑问, 请咨询管理员`);
    gps && (data.gps = gps);
    style && (data.style = style);
    const battery = yield BKBattery.findOne({ QRCode });
    try {
      if (!battery) {
        const id = yield BKBattery.genId();
        yield BKBattery.create(Object.assign(
          {
            _id: id,
            QRCode,
            station: station._id,
            fromStation: station._id,
            region: station.region,
          },
          data,
        ));
        yield RCBatteryOpController.createNew({
          id,
          region: station.region,
          station,
          QRCode,
          operator,
          mark,
          fromStation: station._id,
        });
      } else {
        if (mark || gps) {
          yield BKBattery.findByIdAndUpdate(battery._id, {
            $set: data,
          });
        }
      }
    } catch (error) {
      if (error.name === 'MongoError' && error.code === 11000) {
        throw new Error(`${mark ? `标记${mark}` : `GPS${gps}`} 已经存在,请联系管理员`);
      } else {
        throw error;
      }
    }
  }

  static *unbind({ stock, operator }) {
    const battery = yield BKBatteryController.Model.findOne({ stock });
    if (!battery) throw new Error('电池没有绑定车辆');
    // 电池存在 携带馈电+1
    if (battery) {
      yield BKStockController.Model.findByIdAndUpdate(stock, {
        $unset: {
          'battery.id': 1,
        },
      });
      yield BKBatteryController.Model.findByIdAndUpdate(battery._id, {
        $set: {
          locate: constants.BK_BATTERY_LOCATE.巡检人员携带,
          inspector: operator._id,
        },
        $unset: {
          stock: 1,
        },
      });

      yield RCBatteryOpController.unbind({ battery, operator, stock });
      yield ACOperatorController.Model.findOneAndUpdate({ user: operator._id }, {
        $inc: {
          'batteryBag.unavailable': 1,
        },
      });
    }
  }

  *lost({ id, stock, batteryImages, isIntact, remark, location, address }) {
    const st = yield BKStockController.findByIdAndCheckExists(stock);
    const battery = yield BKBatteryController.Model.findOne({ stock: stock });
    const operator = yield ACUserController.Model.findById(id);
    if (battery) {
      yield this.T(BKBattery).findByIdAndUpdate(battery._id, {
        $set: {
          locate: constants.BK_BATTERY_LOCATE.丢失,
        },
        $unset: {
          stock: 1,
        },
      });
      yield this.T(BKStock).findByIdAndUpdate(stock, {
        $unset: {
          'battery.id': 1,
        },
      });
      yield new RCBatteryOpController(this.transaction).createLost({
        stock: st,
        operator,
        battery,
        location,
        address,
        batteryImages,
        remark,
      });
      yield RCBatteryLostController.create({ battery, stock, operator: id, address });
    }
    dingRoot.sendAbnormalBattery(`电池【${battery && battery.QRCode}】由【${operator.cert.name}】丢失, 之前安装于车辆【${st.number.custom}】`);
    return yield BKStockController.Model.findById(stock);
  }

  static *updateRegion({ id, region, operator }) {
    const battery = yield BKBatteryController.findByIdAndCheckExists(id);
    if (battery.region !== region) {
      yield BKBattery.findByIdAndUpdate(id, {
        $set: { region },
      });
      const stock = yield BKStockController.findByIdAndCheckExists(battery.stock);
      operator = yield ACUserController.findByIdAndCheckExists(operator);
      yield RCBatteryOpController.updateRegion({
        battery,
        stock,
        operator: operator._id,
        operatorName: operator.cert.name,
        nextRegion: region
      });
    } else {
      return battery;
    }
  }

  static *updateStation({ id, station, operator }) {
    const battery = yield BKBatteryController.findByIdAndCheckExists(id);
    if (battery.station !== station) {
      yield BKBattery.findByIdAndUpdate(id, {
        $set: { station },
      });
      const stock = yield BKStockController.findByIdAndCheckExists(battery.stock);
      operator = yield ACUserController.findByIdAndCheckExists(operator);
      yield RCBatteryOpController.updateStation({ battery, stock, operator, nextStation: station });
    } else {
      return battery;
    }
  }

}

BKBatteryController.Model = BKBattery;
module.exports = BKBatteryController;
