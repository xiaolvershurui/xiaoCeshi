const BKBikeIdentifier = require('../../models/ebike/bk_bike_identifier');
const Controller = require('../Controller');
const Error = require('errrr');

class BKBikeIdentifierController extends Controller {

  static *findByBoxAndCheckExists(box) {
    const bikeIdentifier = yield BKBikeIdentifier.findOne({ box });
    // if (!bikeIdentifier) throw new Error('盒子映射不存在,请联系管理员处理');
    return bikeIdentifier;
  }

  *findPreAndUpdateNext({ key, pre, next }) {
    return yield this.T(BKBikeIdentifier).findOneAndUpdate({ [key]: pre }, {
      [key]: next,
    });
  }

  static *updateBox({ pre, next }) {
    const lastOne = yield BKBikeIdentifierController.Model.findOne({
      box: pre,
    });
    const nextOne = yield BKBikeIdentifierController.Model.findOne({
      box: next,
    });
    if (lastOne) {
      yield BKBikeIdentifierController.Model.findByIdAndUpdate(lastOne._id, {
        $set: {
          box: next,
        },
      });
    }

    if (nextOne) {
      if (!nextOne.stock) {
        yield BKBikeIdentifierController.Model.remove({ _id: nextOne._id });
      } else {
        yield BKBikeIdentifierController.Model.findByIdAndUpdate(nextOne._id, {
          box: pre,
        });
      }
    }

  }
}

BKBikeIdentifierController.Model = BKBikeIdentifier;
module.exports = BKBikeIdentifierController;
