const BKBtBox = require('../../models/ebike/bk_bt_box');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class BKBtBoxController extends Controller {

}

BKBtBoxController.Model = BKBtBox;
module.exports = BKBtBoxController;