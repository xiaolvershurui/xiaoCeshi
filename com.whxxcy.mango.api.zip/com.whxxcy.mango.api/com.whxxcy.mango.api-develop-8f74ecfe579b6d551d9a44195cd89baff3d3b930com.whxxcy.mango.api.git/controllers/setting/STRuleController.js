const STRule = require('../../models/setting/st_rule');
const Controller = require('../Controller');

class STRuleController extends Controller {

}

STRuleController.Model = STRule;
module.exports = STRuleController;