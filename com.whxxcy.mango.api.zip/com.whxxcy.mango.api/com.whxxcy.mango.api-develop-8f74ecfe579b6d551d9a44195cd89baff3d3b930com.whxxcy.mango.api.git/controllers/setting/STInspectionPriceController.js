const STInspectionPrice = require('../../models/setting/st_inspection_price');
const Controller = require('../Controller');

class STInspectionPriceController extends Controller {

}

STInspectionPriceController.Model = STInspectionPrice;
module.exports = STInspectionPriceController;