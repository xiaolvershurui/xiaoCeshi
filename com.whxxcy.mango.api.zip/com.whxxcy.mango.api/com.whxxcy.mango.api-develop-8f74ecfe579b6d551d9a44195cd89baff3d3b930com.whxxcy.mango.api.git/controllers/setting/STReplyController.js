const STReply = require('../../models/setting/st_reply');
const Controller = require('../Controller');

class STReplyController extends Controller {
  static * create ({ reply, realReason }) {
    return yield STReply.create({
      _id: yield STReply.genId(),
      reply,
      realReason
    });
  }

  static * findAvailable () {
    return yield STReply.aggregate([
      {
        $match: {
          enable: true
        }
      }, {
        $group: {
          _id: '$realReason',
          reply: {
            $push: '$$CURRENT.reply'
          }
        }
      }
    ]).read('secondary').sort({ _id: -1 });
  }
}

STReplyController.Model = STReply;
module.exports = STReplyController;