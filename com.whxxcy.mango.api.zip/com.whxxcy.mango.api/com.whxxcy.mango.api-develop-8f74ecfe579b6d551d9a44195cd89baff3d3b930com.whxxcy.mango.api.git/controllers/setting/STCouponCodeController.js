const STCouponCode = require('../../models/setting/st_coupon_code');
const Controller = require('../Controller');
const ACUserController = require('../../controllers/account/ACUserController');
const ACCouponController = require('../../controllers/account/ACCouponController');
const Error = require('errrr');
const uploader = require('../../services/metricsUploader');

class STCouponCodeController extends Controller {
  static *create({
    life,
    tels,
    code,
    totalTimes,
    type,
    name,
    amount,
    validDuration,
    validRegions,
    validStyleLevels,
  }) {
    return yield STCouponCode.create({
      _id: yield STCouponCode.genId(),
      life,
      tels,
      code,
      remainTimes: totalTimes,
      type,
      name,
      amount,
      validDuration,
      validRegions,
      validStyleLevels,
    });
  }

  static *findByIdAndCheckExists(id) {
    const couponCode = yield STCouponCode.findById(id);
    if (!couponCode) throw new Error('兑换码不存在');
    return couponCode;
  }

  *findByIdAndCheckExists(id) {
    const couponCode = yield this.T(STCouponCode).findById(id);
    if (!couponCode) throw new Error('兑换码不存在');
    return couponCode;
  }

  static *toggleEnable(id, enable) {
    return yield STCouponCode.findByIdAndUpdate(id, {
      $set: {
        enable,
      },
    }, { new: true });
  }

  *use(code, user) {
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    const now = new Date();
    const couponCode = yield STCouponCode.findOne({
      enable: true,
      code,
      $or: [{
        tels: userData.auth.tel,
      }, {
        'tels.0': { $exists: false },
      }],
    }).sort({ _id: -1 });
    if (!couponCode) {
      uploader.appendRaw(9010, 'coupon_code', { r: 'not_exists' }, 1);
      throw new Error('该兑换码不可用');
    }
    if (couponCode.exchangedTels.includes(userData.auth.tel)) {
      uploader.appendRaw(9010, 'coupon_code', { r: 'has_got' }, 1);
      throw new Error('该兑换码您已经兑换过了哦~');
    }
    if (couponCode.life.start.is.over(now)) {
      uploader.appendRaw(9010, 'coupon_code', { r: 'not_begin' }, 1);
      throw new Error('该兑换码还未开始兑换哦~');
    }
    if (now.is.over(couponCode.life.end)) {
      uploader.appendRaw(9010, 'coupon_code', { r: 'expired' }, 1);
      throw new Error('该兑换码已经结束兑换了哦~');
    }
    if (couponCode.remainTimes <= 0) {
      uploader.appendRaw(9010, 'coupon_code', { r: 'sold_out' }, 1);
      throw new Error('该兑换码已经被抢光啦~');
    }
    uploader.appendRaw(9010, 'coupon_code', { r: 'succeed' }, 1);
    yield new ACCouponController(this.transaction).create({
      name: couponCode.name,
      user,
      type: couponCode.type,
      amount: couponCode.amount,
      validDuration: couponCode.validDuration,
      couponCode: couponCode._id,
    });
    return yield this.T(STCouponCode).findByIdAndUpdate(couponCode._id, {
      $inc: {
        remainTimes: -1,
      },
      $push: {
        exchangedTels: userData.auth.tel,
      },
    }, { new: true });
  }
}

STCouponCodeController.Model = STCouponCode;
module.exports = STCouponCodeController;
