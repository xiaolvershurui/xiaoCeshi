const STRefundReason = require('../../models/setting/st_refund_reason');
const Controller = require('../Controller');

class STRefundReasonController extends Controller {}

STRefundReasonController.Model = STRefundReason;
module.exports = STRefundReasonController;
