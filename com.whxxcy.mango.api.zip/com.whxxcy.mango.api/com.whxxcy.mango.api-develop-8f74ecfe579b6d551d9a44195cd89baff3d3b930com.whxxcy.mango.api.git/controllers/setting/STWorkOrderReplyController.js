const STWorkOrderReply = require('../../models/setting/st_work_order_reply');
const Controller = require('../Controller');

class STWorkOrderReplyController extends Controller {

}

STWorkOrderReplyController.Model = STWorkOrderReply;
module.exports = STWorkOrderReplyController;