const STEvent = require('../../models/setting/st_event');
const Controller = require('../Controller');

class STEventController extends Controller {
  static * create ({
    life, title, description,
    image, link, rule, validRegions, validStyleLevels
  }) {
    return yield STEvent.create({
      _id: yield STEvent.genId(),
      life,
      title,
      description,
      image,
      link,
      rule,
      validRegions,
      validStyleLevels
    });
  }

  static * findLive () {
    const now = new Date();
    return yield STEvent.find({
      enable: true,
      'life.start': { $lte: now },
      'life.end': { $gte: now },
    }).sort({ 'life.start': -1 });
  }

  static * findAvailable ({ region, styleLevel }) {
    const now = new Date();
    return yield STEvent.find({
      enable: true,
      'life.start': { $lte: now },
      'life.end': { $gte: now },
      $or: [{
        validRegions: region,
        validStyleLevels: styleLevel
      }, {
        'validRegions.0': { $exists: false },
        'validStyleLevels.0': { $exists: false }
      }, {
        validRegions: region,
        'validStyleLevels.0': { $exists: false }
      }, {
        'validRegions.0': { $exists: false },
        validStyleLevels: styleLevel
      }]
    });
  }
}

STEventController.Model = STEvent;
module.exports = STEventController;