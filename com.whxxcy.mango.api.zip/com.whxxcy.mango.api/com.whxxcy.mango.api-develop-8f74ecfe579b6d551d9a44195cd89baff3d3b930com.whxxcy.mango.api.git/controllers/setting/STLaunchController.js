const STLaunch = require('../../models/setting/st_launch');
const Controller = require('../Controller');

class STLaunchController extends Controller {
  static * create ({ life, name, image, link, validCities, queue }) {
    return yield STLaunch.create({
      _id: yield STLaunch.genId(),
      life,
      name,
      image,
      link,
      validCities,
      queue
    });
  }

  static * findAvailable (city) {
    const now = new Date();
    return yield STLaunch.findOne({
      enable: true,
      'life.start': { $lte: now },
      'life.end': { $gte: now },
      $or: [{
        validCities: city
      }, {
        'validCities.0': { $exists: false }
      }]
    }).sort({ queue: -1 });
  }
}

STLaunchController.Model = STLaunch;
module.exports = STLaunchController;