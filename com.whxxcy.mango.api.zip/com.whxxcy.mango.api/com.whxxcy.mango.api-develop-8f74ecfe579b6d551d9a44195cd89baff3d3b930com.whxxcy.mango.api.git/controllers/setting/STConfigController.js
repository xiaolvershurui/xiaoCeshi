const Controller = require('../Controller');
const STConfig = require('../../models/setting/st_config');
const constants = require('../../settings/constants');
const Joi = require('joi');
const Error = require('errrr');
const co = require('co');

class STConfigController extends Controller {

  static parseValue ({ value, valueType }) {
    let schema = Joi.string().required();
    switch (valueType) {
      case 'Number':
        schema = Joi.number().required();
        break;
      case 'Boolean':
        schema = Joi.boolean().required();
        break;
      case 'Array':
        schema = Joi.array().required();
        break;
      case 'JSON':
      case 'Object':
        schema = Joi.object().required();
        break;
      case 'Date':
        schema = Joi.date().required();
        break;
      case 'String':
      default:
    }
    const result = Joi.validate(value, schema);
    if (result.error) throw new Error('输入的值与值类型不对应，请检查后重新输入。');
    return result.value;
  }

  static * checkDuplicate ({ id, key }) {
    const query = { key };
    if (id) query._id = { $ne: id };
    if (yield STConfig.findOne(query)) throw new Error('该键已经存在！');
  }

  static * create ({
    platforms,
    iOSLowestVersion,
    androidLowestVersion,
    key,
    valueType,
    value,
    description
  }) {
    yield this.checkDuplicate({ key });
    return yield STConfig.create({
      _id: yield STConfig.genId(),
      valid: {
        platforms,
        iOSLowestVersion,
        androidLowestVersion,
      },
      key,
      valueType,
      value: this.parseValue({ value, valueType }),
      description
    });
  }

  static * findValid ({ platform, version = '0.0.0', key }) {
    const query = {
      enable: true,
      $or: [{
        'valid.platforms': platform
      }, {
        'valid.platforms.0': { $exists: false }
      }]
    };
    if (platform === constants.ST_CONFIG_PLATFORM.iOS) query['valid.iOSLowestVersion'] = { $lte: version };
    else if (platform === constants.ST_CONFIG_PLATFORM.Android) query['valid.androidLowestVersion'] = { $lte: version };
    if (key) {
      query.key = key;
      const result = yield STConfig.findOne(query);
      return result && result.value;
    } else {
      return (yield STConfig.find(query)).reduce((memo, item) => {
        memo[item.key] = item.value;
        return memo;
      }, {});
    }
  }

  static async setKeyValue (key, value, description) {
    const valueType = value.constructor.name;
    if (!constants.ST_CONFIG_VALUE_TYPE_ENUMS.includes(valueType)) throw new Error(`不支持该配置值类型：${valueType}`);
    await co(function * () {
      yield this.create({
        key,
        value,
        valueType,
        description
      });
    }.bind(this));
  }

  static async getValueByKey (key) {
    const config = await STConfig.findOne({ key });
    return config && config.value;
  }

  static async updateValueByKey (key, value = '') {
    const valueType = value.constructor.name;
    if (!constants.ST_CONFIG_VALUE_TYPE_ENUMS.includes(valueType)) throw new Error(`不支持该配置值类型：${valueType}`);
    await STConfig.findOneAndUpdate({ key }, {
      $set: {
        value,
        valueType
      }
    });
  }

  static * findByIdAndCheckExists (id) {
    const config = yield STConfig.findById(id);
    if (!config) throw new Error('配置不存在');
    return config;
  }

  static * updateEnable (id, enable) {
    return yield STConfig.findByIdAndUpdate(id, {
      $set: {
        enable
      }
    }, { new: true });
  }

  static * pushValidPlatform (id, platform) {
    return yield STConfig.findByIdAndUpdate(id, {
      $addToSet: {
        'valid.platforms': platform
      }
    }, { new: true });
  }

  static * removeValidPlatform (id, platform) {
    return yield STConfig.findByIdAndUpdate(id, {
      $pull: {
        'valid.platform': platform
      }
    }, { new: true });
  }

  static * updateLowestVersion (id, { platform, lowestVersion }) {
    const data = {};
    if (platform === constants.ST_CONFIG_PLATFORM.iOS) {
      data['valid.iOSLowestVersion'] = lowestVersion;
    } else if (platform === constants.ST_CONFIG_PLATFORM.Android) {
      data['valid.androidLowestVersion'] = lowestVersion;
    }
    return yield STConfig.findByIdAndUpdate(id, {
      $set: data
    }, { new: true });
  }

  static * updateKey (id, key) {
    yield this.checkDuplicate({ id, key });
    return yield STConfig.findByIdAndUpdate(id, {
      $set: { key }
    }, { new: true });
  }

  static * updateValue (id, { valueType, value }) {
    return yield STConfig.findByIdAndUpdate(id, {
      $set: {
        valueType,
        value: this.parseValue({ value, valueType })
      }
    }, { new: true });
  }

  static * updateDescription (id, description) {
    return yield STConfig.findByIdAndUpdate(id, {
      $set: {
        description,
      }
    }, { new: true });
  }

}

STConfigController.Model = STConfig;
module.exports = STConfigController;