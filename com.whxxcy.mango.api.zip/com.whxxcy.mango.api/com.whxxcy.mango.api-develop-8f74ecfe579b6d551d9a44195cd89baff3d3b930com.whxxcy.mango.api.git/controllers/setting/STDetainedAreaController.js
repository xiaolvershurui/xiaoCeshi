const STDetainedArea = require('../../models/setting/st_detained_area');
const Controller = require('../Controller');

class STDetainedAreaController extends Controller {}

STDetainedAreaController.Model = STDetainedArea;
module.exports = STDetainedAreaController;
