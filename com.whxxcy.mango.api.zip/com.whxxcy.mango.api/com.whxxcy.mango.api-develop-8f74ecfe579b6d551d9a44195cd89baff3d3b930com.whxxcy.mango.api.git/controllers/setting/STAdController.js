const STAd = require('../../models/setting/st_ad');
const Controller = require('../Controller');

class STAdController extends Controller {
  static * create ({ life, name, image, link, validCities, queue }) {
    return yield STAd.create({
      _id: yield STAd.genId(),
      life,
      name,
      image,
      link,
      validCities,
      queue
    });
  }

  static * findAvailable (city) {
    const now = new Date();
    return yield STAd.find({
      enable: true,
      'life.start': { $lte: now },
      'life.end': { $gte: now },
      $or: [{
        validCities: city
      }, {
        'validCities.0': { $exists: false }
      }]
    }).sort({ queue: -1 });
  }
}

STAdController.Model = STAd;
module.exports = STAdController;