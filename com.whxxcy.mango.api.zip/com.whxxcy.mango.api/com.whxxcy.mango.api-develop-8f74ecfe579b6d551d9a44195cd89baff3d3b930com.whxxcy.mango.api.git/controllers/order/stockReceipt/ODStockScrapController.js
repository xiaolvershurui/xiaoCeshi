const ODStockScrap = require('../../../models/order/stockReceipt/od_stock_scrap');
const BKStock = require('../../../models/ebike/bk_stock');
const RCStockOP = require('../../../models/record/rc_stock_op');
const ACUser = require('../../../models/account/ac_user');
const Controller = require('../../Controller');
const constants = require('../../../settings/constants');
const co = require('co');

class ODStockScrapController extends Controller {
  static *check(stocks, station) {
    const bkStocks = yield BKStock.find({
      'number.custom': {
        $in: stocks.map(item => item.number),
      },
    }).select('number.custom state locate station');

    return stocks.reduce((memo, item) => {
      const s = bkStocks.find(i => i.number.custom === item.number);
      if (!s) {
        memo.push({
          number: item.number,
          description: item.description,
          image: item.image,
          shouldNotCommitReason: `${item.number}不存在`,
        });
      } else {
        let shouldNotCommitReason = '';
        if (s.state === constants.BK_STATE.报废) shouldNotCommitReason += '状态应为完好或损坏,';
        if (s.locate !== constants.BK_LOCATE.仓库) shouldNotCommitReason += '去向应为在运营站,';
        if (!s.station || s.station !== station) shouldNotCommitReason += '仓库应为自己当前所在仓库,';

        memo.push({
          number: s.number.custom,
          description: item.description,
          image: item.image,
          shouldNotCommitReason,
        });
      }
      return memo;
    }, []);
  }

  *scrap(id, stocks) {
    let count = 0;
    for (let stock of stocks) {
      count++;
      try {
        yield new ODStockScrapController(this.transaction).scrapOne({
          id,
          stock,
          status: count === stocks.length ? constants.OD_STOCK_SCRAP_STATUS.已经完成 : constants.OD_STOCK_SCRAP_STATUS.正在进行,
          finishedAt: count === stocks.length ? new Date() : undefined,
        });
      } catch (e) {
        count--;
      }
    }
  }

  *scrapOne({ id, stock, status, finishedAt }) {
    const odStockScrap = yield ODStockScrap.findById(id).select('region').populate({
      model: ACUser,
      path: 'storeManager',
      select: 'cert.name auth.tel profile.avator'
    });
    const bkStock = yield BKStock.findOne({
      'number.custom': stock.number
    }).select('number.custom state');

    yield this.T(ODStockScrap).findByIdAndUpdate(id, {
      $set: {
        status,
        finishedAt,
      },
      $push: {
        scrapSuccess: {
          stock: bkStock._id,
          description: stock.description,
          image: stock.image,
        },
      },
      $pull: {
        scrapFailed: {
          stock: bkStock._id
        }
      }
    });

    yield this.T(BKStock).findByIdAndUpdate(bkStock._id, {
      $set: {
        state: constants.BK_STATE.报废
      }
    });

    yield this.T(RCStockOP).create({
      stock: bkStock._id,
      stockNo: bkStock.number && bkStock.number.custom,
      type: constants.RC_STOCK_OP_TYPE.添加报废,
      region: odStockScrap.region,
      style: bkStock.style,
      operatedAt: new Date(),
      operator: odStockScrap.storeManager,
      operatorTel: odStockScrap.storeManager && odStockScrap.storeManager.auth.tel,
      operatorName: odStockScrap.storeManager && odStockScrap.storeManager.cert.name,
      operatorAvator: odStockScrap.storeManager && odStockScrap.storeManager.profile.avator,
      description: `将车牌号为${bkStock.number && bkStock.number.custom}的车辆置为报废`,
      scrap: {
        prevState: bkStock.state,
        nextState: constants.BK_STATE.报废,
      }
    })
  }
}

ODStockScrapController.Model = ODStockScrap;
module.exports = ODStockScrapController;
