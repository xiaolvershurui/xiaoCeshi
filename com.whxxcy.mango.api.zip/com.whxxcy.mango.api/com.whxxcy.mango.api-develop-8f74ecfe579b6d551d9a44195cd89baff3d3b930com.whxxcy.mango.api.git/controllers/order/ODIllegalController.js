const ODIllegal = require('../../models/order/od_illegal');
const Controller = require('../Controller');

class ODIllegalController extends Controller {

}

ODIllegalController.Model = ODIllegal;
module.exports = ODIllegalController;