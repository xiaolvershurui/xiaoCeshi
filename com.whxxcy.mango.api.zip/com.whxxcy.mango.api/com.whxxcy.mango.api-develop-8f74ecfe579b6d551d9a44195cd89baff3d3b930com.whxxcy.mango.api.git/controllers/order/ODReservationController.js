const ODReservation = require('../../models/order/od_reservation');
const Controller = require('../Controller');
const BKStockController = require('../ebike/BKStockController');
const ACWalletController = require('../account/ACWalletController');
const ACUserController = require('../account/ACUserController');
const constants = require('../../settings/constants');
const utils = require('xx-utils');
const Error = require('errrr');

class ODReservationController extends Controller {
  static * findByIdAndCheckExists (id) {
    const reservation = yield ODReservation.findById(id);
    if (!reservation) throw new Error('预约订单不存在');
    return reservation;
  }

  * findByIdAndCheckExists (id) {
    const reservation = yield this.T(ODReservation).findById(id);
    if (!reservation) throw new Error('预约订单不存在');
    return reservation;
  }

  static * findProcessingByUser (user) {
    if (!user) return null;
    return yield ODReservation.findOne({
      user,
      state: constants.OD_RESERVATION_STATE.预约中,
    });
  }

  * findProcessingByUser (user) {
    if (!user) return null;
    return yield this.T(ODReservation).findOne({
      user,
      state: constants.OD_RESERVATION_STATE.预约中,
    });
  }

  * create ({ user, stock, fromBaojia = false, enableFree = true, baojiaId }, {
    operator,
    operateLocation,
  } = {}) {
    if (fromBaojia) {
      if (!baojiaId) throw new Error('宝驾订单需要输入宝驾订单号');
      if (yield ODReservation.findOne({ 'baojia.id': baojiaId })) {
        throw new Error('该订单号已经创建预约单，无法再次创建');
      }
    }
    const processingReservation = yield this.findProcessingByUser(user);
    if (processingReservation) throw new Error('您已经预约了一辆车，如需预约其他车辆请先取消预约。');
    const ODOrderController = require('./ODOrderController');
    const { box, stockData } = yield new ODOrderController(this.transaction).checkAvailable({
      user,
      stock,
      fromBaojia,
      enableFree,
    });
    if (!fromBaojia) {
      // 冻结押金
      yield new ACWalletController(this.transaction).freezeDeposit(user);
    }
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    // 车辆置为预约中
    yield new BKStockController(this.transaction).updateLocate(stock, constants.BK_LOCATE.预约, {
      operator,
      operateLocation,
      opReservation: {
        check: 1,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        userLocation: userData.location,
      },
    });
    // 生成预约订单
    const now = new Date();
    return yield this.T(ODReservation).create({
      _id: yield ODReservation.genId(),
      user,
      stock,
      box: stockData.box,
      boxDataSource: box.info.dataSource,
      region: stockData.region,
      style: stockData.style,
      styleLevel: stockData.styleLevel,
      reservedAt: now,
      expires: constants.OD_RESERVATION_EXPIRE_DURATION.after(now),
      isFree: stockData.isFree,
      stockLocation: {
        lngLat: stockData.location && stockData.location.lngLat,
        lastGpsLocatedAt: stockData.location && stockData.location.lastGpsLocatedAt,
      },
      baojia: {
        isBaojia: fromBaojia,
        id: baojiaId,
      },
    });
  }

  * check ({ user, stock, fromBaojia }, { operator, operateLocation }) {
    const otherReservation = yield ODReservation.findOne({
      stock,
      user: { $ne: user },
      state: constants.OD_RESERVATION_STATE.预约中,
    });
    if (otherReservation) {
      throw new Error('车辆已被他人预约，下次要快人一步哟！', {
        code: 'controller.odReservation.stockReserved',
        description: '车辆已被预约',
      });
    }
    const reservation = yield ODReservation.findOne({
      user,
      state: constants.OD_RESERVATION_STATE.预约中,
    });
    if (!reservation) return;
    if (!fromBaojia && reservation.baojia.isBaojia) {
      yield this.finish(reservation._id, constants.OD_RESERVATION_CANCEL_REASON.未在预约平台用车, {
        operator,
        operateLocation,
      });
    } else if (reservation.stock === stock) { // 预约成功
      yield this.finish(reservation._id, null, {
        operator,
        operateLocation,
      });
      return reservation;
    } else { // 预约失败
      yield this.finish(reservation._id, constants.OD_RESERVATION_CANCEL_REASON.使用了其他的车, {
        operator,
        operateLocation,
      });
    }
  }

  * finish (id, cancelReason, {
    operator,
    operateLocation,
  } = {}) {
    const reservation = yield this.findByIdAndCheckExists(id);
    if (reservation.state !== constants.OD_RESERVATION_STATE.预约中) {
      throw new Error('当前状态无法结束');
    }

    const succeed = utils.judgement.isEmpty(cancelReason);

    const userData = yield ACUserController.findByIdAndCheckExists(reservation.user);
    // 将车辆解锁
    yield new BKStockController(this.transaction).updateLocate(reservation.stock, constants.BK_LOCATE.空闲, {
      operator,
      operateLocation,
      opCancelReservation: {
        check: 1,
        succeed,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        userLocation: userData.location,
      },
    });
    if (!reservation.baojia.isBaojia) {
      // 解冻押金
      yield new ACWalletController(this.transaction).unfreezeDeposit(reservation.user);
    }
    let data = {
      state: constants.OD_RESERVATION_STATE.已完成,
      finishedAt: new Date(),
    };
    if (!succeed) {
      data = {
        state: constants.OD_RESERVATION_STATE.已取消,
        cancelledAt: new Date(),
        cancelReason,
      };
    }
    return yield this.T(ODReservation).findByIdAndUpdate(id, {
      $set: data,
    }, { new: true });
  }

  static transformBaojia (reservation) {
    return {
      orderNo: reservation.baojia.id,
      timestamp: reservation.reservedAt.unix,
      expires: reservation.expires.unix,
      status: reservation.state,
    };
  }

  static * findByBaojiaIdAndCheckExists (baojiaId) {
    const reservation = yield ODReservation.findOne({ 'baojia.id': baojiaId });
    if (!reservation) throw new Error('预约单不存在');
    return reservation;
  }
}

ODReservationController.Model = ODReservation;
module.exports = ODReservationController;
