const ODInsurance = require('../../models/order/od_insurance');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const Error = require('errrr');

class ODInsuranceController extends Controller {

}

ODInsuranceController.Model = ODInsurance;
module.exports = ODInsuranceController;