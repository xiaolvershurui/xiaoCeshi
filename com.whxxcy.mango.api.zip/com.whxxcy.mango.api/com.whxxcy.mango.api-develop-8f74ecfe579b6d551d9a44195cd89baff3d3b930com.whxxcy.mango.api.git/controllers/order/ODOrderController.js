const ODOrder = require('../../models/order/od_order');
const Controller = require('../Controller');
const BKStockController = require('../ebike/BKStockController');
const OPRegionController = require('../operation/OPRegionController');
const OPStyleController = require('../operation/OPStyleController');
const OPPolygonController = require('../operation/OPPolygonController');
const ACUserController = require('../account/ACUserController');
const ACWalletController = require('../account/ACWalletController');
const ACCouponController = require('../account/ACCouponController');
const ACCreditController = require('../account/ACCreditController');
const FNBalanceBillController = require('../finance/FNBalanceBillController');
const ODReservationController = require('./ODReservationController');
const RCShareController = require('../record/RCShareController');
const BKDamageController = require('../ebike/BKDamageController');
const RCMessageSystemController = require('../record/RCMessageSystemController');
const SSNewLoginController = require('../statistic/SSNewLoginController');
const constants = require('../../settings/constants');
const Error = require('errrr');
const { judgement, asyncTask } = require('xx-utils');
const IoT = require('../../IoT');
const errorHandler = require('../../services/errorHandler');
const shark = require('../../services/shark');
const Cache = require('../../utils/cache');
const errorHandle = require('../../services/errorHandler');
const amap = require('../../services/amap');

class ODOrderController extends Controller {
  static *findByIdAndCheckExists(id) {
    const order = yield ODOrder.findById(id);
    if (!order) throw new Error('订单不存在');
    return order;
  }

  *findByIdAndCheckExists(id) {
    const order = yield this.T(ODOrder).findById(id);
    if (!order) throw new Error('订单不存在');
    return order;
  }

  *checkAvailable({ user, stock, enableFree, fromBaojia = false }) {
    // 检查未完成的订单
    if (yield ODOrder.findOne({
        user,
        state: constants.OD_ORDER_STATE.租用中,
      })) {
      throw new Error('您有订单正在租用中，若无法结束请提交反馈。', {
        code: 'controller.odOrder.existsProcessingOrder',
        description: '有未结束订单',
      });
    }
    const now = new Date();
    // 检查实名认证
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    if (!userData.cert.hasVerified) throw new Error('您还未通过实名认证，请先认证再租用车辆！', {
      code: 'controller.odOrder.notVerified',
      description: '还未实名认证',
    });
    // 检查年龄是否合法
    const birthday = userData.cert.certInfo.birthday;
    const deltaYear = now.getFullYear() - birthday.getFullYear();
    const deltaMonth = now.getMonth() - birthday.getMonth();
    const age = deltaYear + (deltaMonth / 12);
    // 预先对车加锁并校验锁，以免同时并发导致下面一句判断出现问题
    yield new BKStockController(this.transaction).findByIdAndCheckExists(stock);
    let stockData = yield BKStockController.findOneWithReservation({
      user, stock, enableFree,
    });
    if (stockData.region === '1703301332007' && age < 18) throw new Error('根据当地规定，未满18周岁用户暂时无法使用本服务。');
    if (stockData.region === '1703110248001' && Date.now() > new Date('2018-02-02 21:00:00').getTime() && Date.now() < new Date('2018-02-03 08:00:00').getTime()) throw new Error('尊敬的用户，很抱歉，因为车辆维护，小芒暂时停止使用啦，具体恢复时间以天气情况而定，祝您一路平安！');
    if (age < constants.AC_LOWEST_USER_AGE || age > constants.AC_HIGHEST_USER_AGE) {
      throw new Error(`根据国家规定，电动单车驾驶员年龄必须满足${constants.AC_LOWEST_USER_AGE}周岁至${constants.AC_HIGHEST_USER_AGE}周岁！很抱歉您暂时无法使用本服务。`, {
        code: 'controller.odOrder.invalidAge',
        description: '年龄不合法',
      });
    }
    // 如果是宝驾订单，不对押金和余额做判断
    if (!fromBaojia) {
      // 检查余额是否欠费
      const wallet = yield new ACWalletController(this.transaction).findByUserAndCheckExists(userData._id);
      if (wallet.balance < 0) throw new Error('您还有未交清的欠款，请交清欠款后再租用车辆！', {
        code: 'controller.odOrder.overdraft',
        description: '欠款未交清',
      });
      // 检查押金
      if (!wallet.deposit.paid) {
        throw new Error('您还未交纳押金，请核实后再试，如有疑问请提交反馈！', {
          code: 'controller.odOrder.unpaidDeposit',
          description: '押金未支付',
        });
      }
      if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.可退款) {
        throw new Error('您的押金已冻结，请核实是否有预约或租用车辆，如有疑问请提交反馈！', {
          code: 'controller.odOrder.frozenDeposit',
          description: '押金已冻结',
        });
      }
    }
    // TODO: 检查车辆位置和用户手机位置距离，不能超过一定的距离
    // 查询价格信息
    const region = yield OPRegionController.findByIdAndCheckExists(stockData.region);
    const BKBoxController = require('../ebike/BKBoxController');
    const box = yield BKBoxController.findByIdAndCheckExists(stockData.box);
    stockData = yield BKStockController.findByIdAndCheckExists(stock);
    let price = region.prices[stockData.styleLevel];
    price = price.toJSON();
    price.stockDiscountRate = stockData.discountRate;
    price.shouldDiscount = {
      lockDiscount: stockData.lockDiscount,
    };
    price.timeUnit = Math.ceil(price.timeUnit * stockData.discountRate);
    price.mileageUnit = Math.ceil(price.mileageUnit * stockData.discountRate);
    price.dispatchCost = region.operationPattern === constants.OP_REGION_PATTERN.可停收费 ? region.dispatchCost : 0;
    return {
      price,
      box,
      stockData,
    };
  }

  *create({ user, stock, fromBaojia = false, baojiaId, enableFree = true, source }, { operator, operateLocation } = {}) {
    if (fromBaojia) {
      if (!baojiaId) throw new Error('宝驾订单需要输入宝驾订单号');
      if (yield ODOrder.findOne({ 'baojia.id': baojiaId })) {
        throw new Error('该订单号已经创建订单，无法再次创建');
      }
    }
    // 完成预约订单
    const reservation = yield new ODReservationController(this.transaction).check({ user, stock, fromBaojia }, {
      operator,
      operateLocation,
    });
    // 检验是否可以下单
    const { price, box, stockData } = yield this.checkAvailable({ user, stock, enableFree, fromBaojia });

    const id = yield ODOrder.genId();
    SSNewLoginController.createOrder({ user, id });
    const now = new Date();
    const userData = yield ACUserController.findByIdAndCheckExists(user);

    // 如果是宝驾订单，不对押金做冻结处理
    if (!fromBaojia) {
      // 冻结押金
      yield new ACWalletController(this.transaction).freezeDeposit(user);
    }
    // 车辆置为租用中
    yield new BKStockController(this.transaction).updateLocate(stockData._id, constants.BK_LOCATE.在租, {
      operator,
      operateLocation,
      opRent: {
        check: 1,
        order: id,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        location: stockData.location,
      },
    });
    // TODO: 查询当前活动信息
    const events = [];
    // TODO: 2分钟后如果订单未结束则进行投保并绑定保单ref

    // 如果是免单车
    const isFreeTrip = stockData.isFree || (reservation && reservation.stock === stock && reservation.isFree);
    const freeTripInfo = {};
    // 如果是宝驾订单，没有免单车优惠
    if (isFreeTrip && !fromBaojia) {
      if (stockData.outsideRegion) {
        freeTripInfo.reason = constants.OD_FREE_TRIP_REASON.服务区外启动;
      } else if (stockData.insideProhibitedArea) {
        freeTripInfo.reason = constants.OD_FREE_TRIP_REASON.禁行区内启动;
      } else {
        freeTripInfo.reason = constants.OD_FREE_TRIP_REASON.标记为免单车;
      }
    }
    try {
      const RCFeedLossController = require('../record/RCFeedLossController');
      const RCUserExperienceController = require('../record/RCUserExperienceController');
      // 馈电损失记录更新
      RCFeedLossController.trigger(userData._id).catch(error => errorHandler(error, 'RC_FEED_LOSS_TRIGGER_ERROR'));
      // 用户体验记录更新
      RCUserExperienceController.rent({
        user: userData._id,
        stock,
        order: id,
      }).catch(error => errorHandler(error, 'RC_USER_EXPERIENCE_RENT_ERROR'));
    } catch (err) {
      //
    }
    return yield this.T(ODOrder).create({
      _id: id,
      user: user,
      stock,
      startVoltage: stockData.battery.voltage,
      stockNo: stockData.number.custom,
      box: stockData.box,
      boxDataSource: box.info.dataSource,
      region: stockData.region,
      style: stockData.style,
      styleLevel: stockData.styleLevel,
      reservation: reservation && reservation._id,
      isBad: true,
      lease: {
        startTime: now,
        endTime: now,
        totalDuration: 0,
        dayDuration: 0,
        nightDuration: 0,
      },
      route: {
        start: {
          address: stockData.location.address,
          lngLat: stockData.location.lngLat,
          distanceWithRegionPath: stockData.location.distanceWithRegionPath,
          distanceWithProhibitedArea: stockData.location.distanceWithProhibitedArea,
          distanceWithForbiddenArea: stockData.location.distanceWithForbiddenArea,
          distanceWithPark: stockData.location.distanceWithPark,
          parkingLot: stockData.parkingLot,
        },
        end: {
          address: stockData.location.address,
          lngLat: stockData.location.lngLat,
          distanceWithRegionPath: stockData.location.distanceWithRegionPath,
          distanceWithProhibitedArea: stockData.location.distanceWithProhibitedArea,
          distanceWithForbiddenArea: stockData.location.distanceWithForbiddenArea,
          distanceWithPark: stockData.location.distanceWithPark,
          parkingLot: stockData.parkingLot,
        },
        startMileage: stockData.record.mileageInAll,
        endMileage: stockData.record.mileageInAll,
        distance: 0,
        calculateDistance: 0,
        latestUpdatedDistanceAt: now,
        userStartCapture: operateLocation,
        userCapture: operateLocation,
        startPhaseMileage: stockData.record.phaseMileage,
        endPhaseMileage: stockData.record.phaseMileage,
        phaseMileage: 0,
        latestUpdatedPhaseMileageAt: now,
      },
      price,
      payInfo: {
        events,
        totalAmount: 0,
      },
      isFreeTrip,
      freeTripInfo,
      baojia: {
        isBaojia: fromBaojia,
        id: baojiaId,
      },
      'orderSource.src': source === constants.OD_SOURCE.斑马快跑 ? constants.OD_SOURCE.斑马快跑 : undefined,
    });
  }

  static isBad({ duration, distance }) {
    return (duration <= constants.OD_BAD_ORDER_BUFFER_TIME) && (distance <= constants.OD_BAD_ORDER_BUFFER_DISTANCE);
  }

  static calculateLease({ startTime, endTime }) {
    if (startTime.is.over(endTime)) throw new Error('结束时间不能比开始时间早');
    const {
      OD_DAY_TO_NIGHT_AT, OD_NIGHT_TO_DAY_AT, OD_ORDER_EXPIRE_DURATION,
      OD_DAY_DURATION, OD_NIGHT_DURATION,
    } = constants;
    let dayDuration = 0;
    let nightDuration = 0;
    let totalDuration = (endTime.getTime() - startTime.getTime()).msTo.minute;
    const todayStart = OD_NIGHT_TO_DAY_AT.at(startTime);
    const todayEnd = OD_DAY_TO_NIGHT_AT.at(startTime);
    const tomorrowStart = '1 day'.after(todayStart);
    const tomorrowEnd = '1 day'.after(todayEnd);
    // 判断是否超过24小时，超过24小时按24小时算，计算使用时长
    if (endTime.is.over('24 hours'.after(startTime))) {
      dayDuration = OD_DAY_DURATION;
      nightDuration = OD_NIGHT_DURATION;
    } else if (todayStart.is.over(startTime)) {
      if (todayStart.is.over(endTime)) { // 全算夜间
        nightDuration = totalDuration;
      } else if (todayEnd.is.over(endTime)) { // 先夜间后白天 todayStart分界
        nightDuration = (todayStart.getTime() - startTime.getTime()).msTo.minute;
        dayDuration = (endTime.getTime() - todayStart.getTime()).msTo.minute;
      } else { // 整个白天，剩下夜间
        dayDuration = OD_DAY_DURATION;
        nightDuration = totalDuration - dayDuration;
      }
    } else if (startTime.is.over(todayEnd)) {
      if (tomorrowStart.is.over(endTime)) { // 全算夜间
        nightDuration = totalDuration;
      } else if (tomorrowEnd.is.over(endTime)) { // 先夜间后白天 tomorrowStart分界
        nightDuration = (tomorrowStart.getTime() - startTime.getTime()).msTo.minute;
        dayDuration = (endTime.getTime() - tomorrowStart.getTime()).msTo.minute;
      } else { // 整个白天，剩下夜间
        dayDuration = OD_DAY_DURATION;
        nightDuration = totalDuration - dayDuration;
      }
    } else {
      if (todayEnd.is.over(endTime)) { // 全算白天
        dayDuration = totalDuration;
      } else if (tomorrowStart.is.over(endTime)) { // 先白天后夜间 todayEnd分界
        dayDuration = (todayEnd.getTime() - startTime.getTime()).msTo.minute;
        nightDuration = (endTime.getTime() - todayEnd.getTime()).msTo.minute;
      } else { // 整个夜间，剩下白天
        nightDuration = OD_NIGHT_DURATION;
        dayDuration = totalDuration - nightDuration;
      }
    }
    dayDuration = Math.ceil(dayDuration);
    nightDuration = Math.ceil(nightDuration);
    totalDuration = Math.ceil(totalDuration);
    return {
      dayDuration,
      nightDuration,
      totalDuration,
    };
  }

  static *calculatePayInfo({ user, calculateDistance, inPark, price, duration, isBad, isFreeTrip }) {
    let {
      timeUnit, mileageUnit, floorCost, enableInsurance, insurance,
      dayCeilingCost, nightCeilingCost,
    } = price;
    const ret = yield new Cache('mg.setup.client').getJSON('parkingRate');
    const parkingRate = (ret && ret.value && parseFloat(ret.value.discount)) || 1;
    const parkingRateContent = (ret && ret.value && ret.value.content) || '无';
    if (isFreeTrip) {
      timeUnit = 0;
      mileageUnit = 0;
      floorCost = 0;
      insurance = 0;
    }

    // 计算租期
    const { dayDuration, nightDuration } = duration;

    // 计时部分租金
    const timeRent = {};
    // 原单价
    timeRent.originalUnit = parseInt(timeUnit);
    // 是否停在停车区
    timeRent.actualUnit = inPark ? Math.ceil(timeUnit * parkingRate) : timeUnit;
    const userData = yield ACUserController.findByIdAndCheckExists(user);
    if (userData.credit < constants.AC_LOW_CREDIT_POINT) {
      // 信用分过低的情况5元/分钟
      timeRent.actualUnit = constants.AC_LOW_CREDIT_TIME_UNIT;
    }
    timeRent.actualUnit = parseInt(timeRent.actualUnit);
    // 白天时长计费活动折前
    timeRent.dayOriginalTotal = parseInt(timeRent.actualUnit * dayDuration);
    // 夜间时长计费活动折前
    timeRent.nightOriginalTotal = parseInt(timeRent.actualUnit * nightDuration);
    // 活动折前总租金
    timeRent.originalTotal = timeRent.dayOriginalTotal + timeRent.nightOriginalTotal;
    // 白天活动折后租金 TODO: 添加活动处理
    timeRent.dayDiscountTotal = timeRent.dayOriginalTotal;
    // 夜间活动折后租金 TODO: 添加活动处理
    timeRent.nightDiscountTotal = timeRent.nightOriginalTotal;
    // 活动折后总租金
    timeRent.discountTotal = timeRent.dayDiscountTotal + timeRent.nightDiscountTotal;
    // 白天是否封顶
    // timeRent.isDayCeiling = timeRent.dayDiscountTotal > dayCeilingCost;
    // 夜间是否封顶
    // timeRent.isNightCeiling = timeRent.nightDiscountTotal > nightCeilingCost;
    // 实际白天租金
    // timeRent.dayActualTotal = parseInt(timeRent.isDayCeiling ? dayCeilingCost : timeRent.dayDiscountTotal);
    timeRent.dayActualTotal = timeRent.dayDiscountTotal;
    // 实际夜间租金
    // timeRent.nightActualTotal = parseInt(timeRent.isNightCeiling ? nightCeilingCost : timeRent.nightDiscountTotal);
    timeRent.nightActualTotal = timeRent.nightDiscountTotal;
    // 实际计时租金
    timeRent.actualTotal = timeRent.dayActualTotal + timeRent.nightActualTotal;

    // 里程部分租金
    const mileageRent = {};
    // 原单价
    mileageRent.originalUnit = parseInt(mileageUnit);
    // 实际单价
    mileageRent.actualUnit = parseInt(inPark ? Math.ceil(mileageUnit * parkingRate) : mileageUnit);
    // 活动折前总租金
    mileageRent.originalTotal = parseInt(mileageRent.actualUnit * calculateDistance);
    // 活动折后总租金 // TODO: 添加活动处理
    mileageRent.discountTotal = mileageRent.originalTotal;

    // 总计租金
    const total = timeRent.actualTotal + mileageRent.discountTotal;
    // 是否保底
    const isFloor = total < floorCost;
    // 保底后实际租金
    const actualTotal = isBad ? 0 : parseInt(isFloor ? floorCost : total);

    // 优惠券减免租金
    // 查找合适的优惠券
    const coupon = {
      actualDiscount: 0,
    };
    if (actualTotal > 0) {
      const validCoupon = yield ACCouponController.findValid({
        amount: actualTotal,
        user,
        type: constants.AC_COUPON_TYPE.租金抵扣券,
      });
      if (validCoupon) {
        coupon.actualDiscount = Math.min(validCoupon.amount, actualTotal);
        coupon.ref = validCoupon._id;
      }
    }

    // 优惠券减免的租金
    const discount = parseInt(coupon.actualDiscount);
    // 最终实付总租金
    const finalTotal = parseInt(actualTotal - discount);

    // 保险费用
    const insuranceAmount = parseInt(!isBad && enableInsurance ? insurance : 0);

    // 结算总金额
    const totalAmount = finalTotal + insuranceAmount;

    return {
      rent: {
        timeRent,
        mileageRent,
        total,
        isFloor,
        actualTotal,
        discount,
        finalTotal,
      },
      parkingRate: inPark ? parkingRate : 1,
      parkingRateContent: inPark ? parkingRateContent : '',
      coupon,
      insurance: {
        amount: insuranceAmount,
      },
      totalAmount,
    };
  }

  static *findBoxByBoxId(boxId) {
    const order = yield this.findRentingByBox(boxId);
    if (!order) return null;
    const BKBoxController = require('../ebike/BKBoxController');
    const box = yield BKBoxController.findByIdAndCheckExists(order.box);
    const stock = yield BKStockController.findByIdAndCheckExists(order.stock);
    return { box, order, stock };
  }

  static *findRentingByBox(boxId) {
    return yield ODOrder.findOne({ box: boxId, state: constants.OD_ORDER_STATE.租用中 });
  }

  static *lockPayment(id) {
    return yield ODOrder.findByIdAndUpdate(id, {
      $set: {
        'payInfo.locked': true,
      },
    }, { new: true });
  }

  static *updateSnap(boxId, { location, extra, userLocation = {} }) {
    const result = yield this.findBoxByBoxId(boxId);
    if (!result) return; // 盒子未产生租用中的订单
    const { order, box, stock } = result;
    if (!location.lngLat) {
      location = {
        lngLat: stock.location.lngLat,
        address: stock.location.address,
      };
    }
    if (!location.lngLat) return;
    // 获取用户快照
    const user = yield ACUserController.findByIdAndCheckExists(order.user);

    let duration = order.lease;
    let distance = order.route.distance;
    const endTime = new Date();

    let highestDeltaDistance = order.highestDeltaDistance || 0;
    let highestDeltaTime = order.highestDeltaTime || 0;
    // 如果计费未锁定， 则重新计算计费信息
    if (!order.payInfo.locked) {
      if (judgement.isEmpty(extra.mileageInAll)) {
        extra.mileageInAll = stock.record.mileageInAll;
      }
      // 计算使用时长
      duration = ODOrderController.calculateLease({
        startTime: order.lease.startTime,
        endTime,
      });
      // 计算骑行距离
      distance = Math.max(Math.round(extra.mileageInAll - order.route.startMileage), 0);
      // 计算两次快照距离差
      const deltaDistance = distance - order.route.distance;
      if (deltaDistance > 0) {
        highestDeltaDistance = Math.max(highestDeltaDistance, deltaDistance);
        const deltaTime = endTime.getTime() - order.lease.endTime.getTime();
        highestDeltaTime = Math.max(highestDeltaTime, deltaTime);
      }
    }
    const { totalDuration, dayDuration, nightDuration } = duration;

    const calculateDistance = Math.ceil(distance / 1000);
    // 计算相位距离
    const phaseMileage = Math.max(stock.record.phaseMileage - order.route.startPhaseMileage, 0);
    let {
      intersectPolygon, intersectRegion, intersectPolygonType = null, intersectPolygonNeighborhood = null,
      distanceWithPark = null,
      distanceWithRegionPath = null,
      distanceWithProhibitedArea = null,
      distanceWithForbiddenArea = null,
    } = stock.location;
    location.distanceWithForbiddenArea = distanceWithForbiddenArea;
    location.distanceWithProhibitedArea = distanceWithProhibitedArea;
    location.distanceWithPark = distanceWithPark;
    location.distanceWithRegionPath = distanceWithRegionPath;
    // 停车区外10m也算在停车区
    let inPark = judgement.isNotEmpty(distanceWithPark) && distanceWithPark >= -10;
    // 如果用户位置在停车区  也算在停车区
    let userIntersectPolygonType = null;
    if (userLocation.lngLat) {
      const userIntersectPolygon = yield OPPolygonController.findIntersect(userLocation.lngLat, {
        enable: true,
        type: { $ne: constants.OP_POLYGON_TYPE.巡检区 },
      });
      if (userIntersectPolygon) {
        userIntersectPolygonType = userIntersectPolygon.type;
        if (!inPark && userIntersectPolygon.type === constants.OP_POLYGON_TYPE.停车区) {
          intersectPolygonType = userIntersectPolygon.type;
          intersectPolygon = userIntersectPolygon._id;
          inPark = true;
        }
      }
    }
    // 是否坏订单
    const isBad = ODOrderController.isBad({ duration: duration.totalDuration, distance });
    // 计算费用
    const { rent, coupon, insurance, totalAmount, parkingRate, parkingRateContent } = yield ODOrderController.calculatePayInfo({
      user: order.user,
      calculateDistance,
      inPark,
      price: order.price,
      duration,
      isBad,
      isFreeTrip: order.isFreeTrip,
    });
    yield BKStockController.updateLatestUsedAt(order.stock);
    // 计算最小外包矩形
    const { minLng = 180, maxLng = -180, minLat = 90, maxLat = -90 } = order.mbr;
    let mbr = order.mbr;
    if (location.lngLat) {
      mbr = {
        minLng: Math.min(minLng, location.lngLat[0]),
        maxLng: Math.max(maxLng, location.lngLat[0]),
        minLat: Math.min(minLat, location.lngLat[1]),
        maxLat: Math.max(maxLat, location.lngLat[1]),
      };
    }

    const now = new Date();
    return yield ODOrder.findOneAndUpdate({
      _id: order._id,
      updatedAt: order.updatedAt,
    }, {
      $set: {
        isBad,
        boxDataSource: box.info.dataSource,
        'lease.endTime': endTime,
        'lease.totalDuration': totalDuration,
        'lease.dayDuration': dayDuration,
        'lease.nightDuration': nightDuration,
        'route.end': location,
        'route.endMileage': extra.mileageInAll,
        'route.distance': distance,
        'route.latestUpdatedDistanceAt': distance === order.route.distance ? order.route.latestUpdatedDistanceAt : now,
        'route.calculateDistance': calculateDistance,
        'route.endPhaseMileage': stock.record.phaseMileage,
        'route.phaseMileage': phaseMileage,
        'route.latestUpdatedPhaseMileageAt': phaseMileage === order.route.phaseMileage ? order.route.latestUpdatedPhaseMileageAt : now,
        'route.inPark': !!inPark,
        'route.intersectRegion': intersectRegion,
        'route.intersectPolygon': intersectPolygon,
        'route.intersectPolygonType': intersectPolygonType,
        'route.intersectPolygonNeighborhood': intersectPolygonNeighborhood,
        'route.userIntersectPolygonType': userIntersectPolygonType,
        'route.userCapture': userLocation.lngLat ? userLocation : user.location,
        'payInfo.rent': rent,
        'payInfo.parkingRate': parkingRate,
        'payInfo.parkingRateContent': parkingRateContent,
        'payInfo.coupon': coupon,
        'payInfo.insurance.amount': insurance.amount,
        'payInfo.totalAmount': totalAmount,
        highestSpeed: Math.max(order.highestSpeed || 0, stock.speed),
        averageSpeed: totalDuration === 0 ? 0 : distance * 0.06 / totalDuration,
        mbr,
        // ppk,
        // pph,
        highestDeltaDistance,
        highestDeltaTime,
      },
    }, { new: true });
  }

  static *snap(id, userLocation, parkingLot) {
    yield shark.sendSync({
      c: 'order/order/snap',
      params: {
        id,
        parkingLot,
      },
    });
    return yield this.findByIdAndCheckExists(id);
    // let order = yield this.findByIdAndCheckExists(id);
    // if (order.state !== constants.OD_ORDER_STATE.租用中) throw new Error('您的行程已经结束，请在行程列表查看', {
    //   code: 'controller.odOrder.orderHasFinished',
    //   order: order._id,
    //   region: order.region,
    //   description: '行程已结束'
    // });
    //  更新快照
    // const stock = yield BKStockController.findByIdAndGetAddress(order.stock);
    // const location = {
    //   address: stock.location.address,
    //   lngLat: stock.location.lngLat,
    // };
    // const extra = {
    //   mileageInAll: stock.record.mileageInAll,
    // };
    // const snappedOrder = yield ODOrderController.updateSnap(order.box, { location, extra, userLocation });
    // return snappedOrder || order;
  }

  *finish(id, state = constants.OD_ORDER_STATE.已完成, { operator, operateLocation, autoLock = true } = {}) {
    const forceFinish = [
      constants.OD_ORDER_STATE.后台结束订单,
      constants.OD_ORDER_STATE.系统结束订单,
    ].includes(state);
    yield ODOrderController.snap(id, operateLocation);

    // 锁定订单数据，保证后续计算使用的数据是安全的  2018-01-13 12:29:59
    let order = yield this.T(ODOrder).findById(id);
    if (order.state !== constants.OD_ORDER_STATE.租用中) return order;
    const isFreeTrip = order.isFreeTrip;

    const now = new Date();
    const userData = yield ACUserController.findByIdAndCheckExists(order.user);
    const stockData = yield BKStockController.findByIdAndCheckExists(order.stock);
    const outsideRegion = !order.route.intersectRegion;
    const insideProhibitedArea = order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
    // 判断是否在禁停区/禁行区内  如果结束类型为7 则可以在禁停区结束  不在缓冲区内，也不准结束
    const insideForbiddenArea = !order.route.inPark && order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 && (
      state !== constants.OD_ORDER_STATE.禁停区结束 || stockData.location.distanceWithForbiddenArea < -5
    );

    // TODO: 根据运营模式
    const region = OPRegionController.Model.findById(order.region).select('operationPattern');

    if (state === constants.OD_ORDER_STATE.超时结束) {
      // 自动结束订单
    } else if (state === constants.OD_ORDER_STATE.长时无移动结束) {
      //
    } else {

      if (!forceFinish) { // 如果不是强制结束订单，则判断停车地点是否合理
        // 判断是否在大区内
        const device = IoT.at(order.box);
        if (outsideRegion && !isFreeTrip) {
          device.playOutsideRegionSound();
          throw new Error('请将车辆推到服务区（红线范围）内停车！', {
            code: 'controller.odOrder.stockOutsideRegion',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在服务区外',
          });
        }

        // 判断是否在禁行区内
        if (insideProhibitedArea && !isFreeTrip) {
          device.playInsideProhibitedAreaSound();
          throw new Error('当前车辆在禁行区，为了方便他人使用，请将车辆推出禁行区再结束行程！', {
            code: 'controller.odOrder.stockInProhibitedArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁行区',
          });
        }

        // 坏订单不用判断是否在禁停区
        if (insideForbiddenArea && !order.isBad) {
          device.playInsideForbiddenAreaSound();
          throw new Error('当前车辆在居民小区，为方便其他人使用，请将车辆骑出小区再结束行程！', {
            code: 'controller.odOrder.stockInForbiddenArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁停区',
          });
        }

        // 正常区域是否可停
        if (!order.route.end.parkingLot) {
          if (region.operationPattern === constants.OP_REGION_PATTERN.不可停) {
            throw new Error('当前车辆不在停车区，请将车辆骑行到停车区再结束行程！', {
              code: 'controller.odOrder.stockNotInParkingLot',
              order: order._id,
              region: order.region,
              location: order.route.end,
              description: '车辆不在停车',
            });
          }
        }
        if (order.isBad) {
          state = constants.OD_ORDER_STATE.异常结束;
        } else {
          // 正常骑行+1分
          yield new ACCreditController(this.transaction).create(Object.assign({
            user: order.user,
            order: order._id,
          }, constants.AC_CREDIT_RECORD_INFO.正常骑行));
        }
      }
    }

    if (!order.isBad) {
      // 使用优惠券
      if (order.payInfo.coupon.ref) {
        yield new ACCouponController(this.transaction).use(order.payInfo.coupon.ref, {
          type: constants.AC_COUPON_TYPE.租金抵扣券,
          actualDiscount: order.payInfo.coupon.actualDiscount,
        });
      }
    }

    // 最终结束订单车辆在禁停禁行区或者围栏外，扣信用分。如果状态是禁停区结束或坏订单，可以不判断禁停区 TODO: 禁停区暂时不算违停
    if (!order.isBad && (outsideRegion || insideProhibitedArea)) {
      yield new ACCreditController(this.transaction).create(Object.assign({
        user: order.user,
        order: order._id,
      }, constants.AC_CREDIT_RECORD_INFO.违停));
    }

    yield BKStockController.updateLatestIllegalOrderAt(order.stock, order.isBad || order.route.distance <= 10);

    let rentBill;
    let insuranceBill;
    let dispatchBill;
    // 如果是宝驾订单，不进行结算
    if (!order.baojia.isBaojia) {
      // 生成结算账单
      const fnBalanceBillController = new FNBalanceBillController(this.transaction);
      // 租金账单
      if (order.payInfo.rent.finalTotal > 0) {
        rentBill = yield fnBalanceBillController.createRent({
          user: order.user,
          order: order._id,
          amount: order.payInfo.rent.finalTotal,
        });
      }
      if (order.payInfo.insurance.amount > 0) {
        insuranceBill = yield fnBalanceBillController.createInsurance({
          user: order.user,
          order: order._id,
          amount: order.payInfo.insurance.amount,
        });
      }
      // 调度费账单
      if (order.payInfo.dispatchCost > 0) {
        dispatchBill = yield fnBalanceBillController.createDispatch({
          user: order.user,
          order: order._id,
          amount: order.payInfo.dispatchCost,
        });
      }
      // 解冻押金
      yield new ACWalletController(this.transaction).unfreezeDeposit(order.user);
    }
    // 将车辆解锁
    yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.空闲, {
      operator,
      operateLocation,
      opReturnBack: {
        check: 1,
        order: order._id,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        orderState: state,
        totalAmount: order.payInfo.totalAmount,
        duration: order.lease.totalDuration,
        distance: order.route.distance,
        outsideRegion: !order.route.intersectRegion,
        insideProhibitedArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区,
        insideForbiddenArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区,
        insidePark: order.route.inPark,
        location: stockData.location,
      },
    });

    try {
      // 更新用户里程
      yield new ACUserController(this.transaction).updateMileage(order.user, order.route.calculateDistance);
      // 用户体验记录更新
      const RCUserExperienceController = require('../record/RCUserExperienceController');
      RCUserExperienceController.finish({
        order: order._id,
        actualTotal: order.payInfo.rent.actualTotal,
        forceFinish,
        isBad: order.isBad,
        isFreeTrip: order.isFreeTrip,
        isOnline: stockData.isOnline,
      }).catch(error => errorHandler(error, 'RC_USER_EXPERIENCE_FINISH_ERROR'));

    } catch (error) {
      //
    }
    const RCStockPointController = require('../record/RCStockPointController');
    const routePath = yield RCStockPointController.findPath(order.box, order.lease);
    // 千米点密度
    const ppk = order.route.distance === 0 ? 0 : routePath.length / order.route.distance * 1000;
    // 小时点密度
    const pph = order.lease.totalDuration === 0 ? 0 : routePath.length / order.lease.totalDuration * 60;

    let points = routePath.map(point => point.gps.lngLat);
    let ts = routePath.map(point => point.time);

    if (points.length < 2) {
      points = [order.route.start.lngLat, ...points, order.route.end.lngLat];
      ts = [order.lease.startTime, ...ts, order.lease.endTime];
    }
    // 完成订单
    order = yield this.T(ODOrder).findByIdAndUpdate(order._id, {
      $set: {
        state,
        'payInfo.rentBill': rentBill && rentBill._id,
        'payInfo.insuranceBill': insuranceBill && insuranceBill._id,
        'payInfo.dispatchBill': dispatchBill && dispatchBill._id,
        finishedAt: now,
        ppk,
        pph,
        endVoltage: stockData.battery.voltage,
        'route.path': {
          type: 'LineString',
          coordinates: points,
          ts,
        },
        accOn: stockData.accOn,
      },
    }, { new: true });

    if (autoLock) {
      // 控制车辆停止设防
      IoT.at(order.box, {
        operator,
        operateLocation,
        stock: order.stock,
      }).tryLock().catch(error => IoT.emit('error', error, 'SEND_COMMAND'));
    }

    asyncTask(function *() {
      const SSAbnormalOrderInDayController = require('../statistic/SSAbnormalOrderInDayController');
      if (!(state === 1 && (order.isFreeTrip || outsideRegion || insideProhibitedArea || insideForbiddenArea))) {
        yield SSAbnormalOrderInDayController.trigger({ state, stock: stockData, user: order.user });
      }
    }, error => errorHandler(error, 'ORDER_FINISH'));

    setTimeout(_ => {
      shark.send({
        c: 'order/order/afterFinished',
        params: { id },
      });
    }, 5000);

    // 1天内给五人产生了坏订单 自动添加损坏 设置待拖回任务
    // if (order.isBad) {
    //   const ordersInDay = yield ODOrderController.Model.find({
    //     stock: order.stock,
    //     createdAt: { $gte: '1 day'.before(now), $lt: now },
    //     'route.intersectRegion': { $exists: true },
    //     'route.intersectPolygon': { $ne: constants.OP_POLYGON_TYPE.禁行区 },
    //   }).select('user isBad route').sort({ _id: -1 });
    //   const affectUsers = [];
    //   let affectCount = 0;
    //   let shouldSetStockDamage = false;
    //   ordersInDay.forEach(item => {
    //     if (item.isBad && item.route.end.distanceWithRegionPath < 200) {
    //       if (!affectUsers.includes(item.user)) {
    //         affectCount += 1;
    //         affectUsers.push(item.user);
    //         if (affectCount === 5) shouldSetStockDamage = true;
    //       }
    //     } else {
    //       affectCount = 0;
    //     }
    //   });
    //
    //   if (shouldSetStockDamage) {
    //     yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.待拖回, {
    //       operator: '1',
    //       operateLocation: stockData.location,
    //       opApplyReturnBack: {
    //         check: 1,
    //         order: order._id,
    //       },
    //     });
    //
    //     yield new BKDamageController(this.transaction).create({ stock: stockData._id, description: '一天内坏订单影响人数超五人', state: constants.BK_STATE.损坏不可租, submitter: '1' }, { operator: '1', operationLocation: stockData.location });
    //   }
    // }

    return order;
  }

  *newFinish(id, state = constants.OD_ORDER_STATE.已完成, { operator, operateLocation, autoLock = true } = {}, parkingLot) {
    const forceFinish = [
      constants.OD_ORDER_STATE.后台结束订单,
      constants.OD_ORDER_STATE.系统结束订单,
    ].includes(state);
    yield ODOrderController.snap(id, operateLocation, parkingLot);

    // 锁定订单数据，保证后续计算使用的数据是安全的  2018-01-13 12:29:59
    let order = yield this.T(ODOrder).findById(id);
    if (order.state !== constants.OD_ORDER_STATE.租用中) return order;
    // 是免单车
    const isFreeTrip = order.isFreeTrip;
    const now = new Date();
    const userData = yield ACUserController.findByIdAndCheckExists(order.user);
    const stockData = yield BKStockController.findByIdAndCheckExists(order.stock);
    const outsideRegion = !order.route.intersectRegion;
    const insideProhibitedArea = order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
    // 判断是否在禁停区/禁行区内  如果结束类型为7 则可以在禁停区结束  不在缓冲区内，也不准结束
    const insideForbiddenArea = !order.route.inPark && order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 && stockData.location.distanceWithForbiddenArea < -5;

    const region = OPRegionController.Model.findById(order.region).select('operationPattern');

    if (state === constants.OD_ORDER_STATE.超时结束) {
      // 自动结束订单
    } else if (state === constants.OD_ORDER_STATE.长时无移动结束) {
      //
    } else {

      if (!forceFinish) { // 如果不是强制结束订单，则判断停车地点是否合理
        // 判断是否在大区内
        const device = IoT.at(order.box);
        if (outsideRegion && !isFreeTrip) {
          device.playOutsideRegionSound();
          throw new Error('请将车辆推到服务区（红线范围）内停车！', {
            code: 'controller.odOrder.stockOutsideRegion',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在服务区外',
          });
        }

        // 判断是否在禁行区内
        if (insideProhibitedArea && !isFreeTrip) {
          device.playInsideProhibitedAreaSound();
          throw new Error('当前车辆在禁行区，为了方便他人使用，请将车辆推出禁行区再结束行程！', {
            code: 'controller.odOrder.stockInProhibitedArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁行区',
          });
        }

        // 坏订单不用判断是否在禁停区
        if (insideForbiddenArea && !order.isBad) {
          device.playInsideForbiddenAreaSound();
          throw new Error('当前车辆在居民小区，为方便其他人使用，请将车辆骑出小区再结束行程！', {
            code: 'controller.odOrder.stockInForbiddenArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁停区',
          });
        }

        // 正常区域是否可停
        if (!order.route.end.parkingLot && !order.isBad) {
          if (region.operationPattern === constants.OP_REGION_PATTERN.不可停) {
            throw new Error('当前车辆不在停车区，请将车辆骑行到停车区再结束行程！', {
              code: 'controller.odOrder.stockNotInParkingLot',
              order: order._id,
              region: order.region,
              location: order.route.end,
              description: '车辆不在停车区',
            });
          }
        }
        if (order.isBad) {
          state = constants.OD_ORDER_STATE.异常结束;
        } else {
          // 正常骑行+1分
          yield new ACCreditController(this.transaction).create(Object.assign({
            user: order.user,
            order: order._id,
          }, constants.AC_CREDIT_RECORD_INFO.正常骑行));
        }
      }
    }

    if (!order.isBad) {
      // 使用优惠券
      if (order.payInfo.coupon.ref) {
        yield new ACCouponController(this.transaction).use(order.payInfo.coupon.ref, {
          type: constants.AC_COUPON_TYPE.租金抵扣券,
          actualDiscount: order.payInfo.coupon.actualDiscount,
        });
      }
    }

    // 最终结束订单车辆在禁停禁行区或者围栏外，扣信用分。如果状态是禁停区结束或坏订单，可以不判断禁停区 TODO: 禁停区暂时不算违停
    if (!order.isBad && (outsideRegion || insideProhibitedArea)) {
      yield new ACCreditController(this.transaction).create(Object.assign({
        user: order.user,
        order: order._id,
      }, constants.AC_CREDIT_RECORD_INFO.违停));
    }

    yield BKStockController.updateLatestIllegalOrderAt(order.stock, order.isBad || order.route.distance <= 10);

    let rentBill;
    let insuranceBill;
    let dispatchBill;
    // 如果是宝驾订单，不进行结算
    if (!order.baojia.isBaojia) {
      // 生成结算账单
      const fnBalanceBillController = new FNBalanceBillController(this.transaction);
      // 租金账单
      if (order.payInfo.rent.finalTotal > 0) {
        rentBill = yield fnBalanceBillController.createRent({
          user: order.user,
          order: order._id,
          amount: order.payInfo.rent.finalTotal,
        });
      }
      if (order.payInfo.insurance.amount > 0) {
        insuranceBill = yield fnBalanceBillController.createInsurance({
          user: order.user,
          order: order._id,
          amount: order.payInfo.insurance.amount,
        });
      }
      // 调度费账单
      if (order.payInfo.dispatchCost > 0) {
        dispatchBill = yield fnBalanceBillController.createDispatch({
          user: order.user,
          order: order._id,
          amount: order.payInfo.dispatchCost,
        });
      }

      // 解冻押金
      yield new ACWalletController(this.transaction).unfreezeDeposit(order.user);
    }
    // 将车辆解锁

    yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.空闲, {
      operator,
      operateLocation,
      opReturnBack: {
        check: 1,
        order: order._id,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        orderState: state,
        totalAmount: order.payInfo.totalAmount,
        duration: order.lease.totalDuration,
        distance: order.route.distance,
        outsideRegion: !order.route.intersectRegion,
        insideProhibitedArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区,
        insideForbiddenArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区,
        insidePark: order.route.inPark,
        location: stockData.location,
      },
    });

    try {
      // 更新用户里程
      yield new ACUserController(this.transaction).updateMileage(order.user, order.route.calculateDistance);
      // 用户体验记录更新
      const RCUserExperienceController = require('../record/RCUserExperienceController');
      RCUserExperienceController.finish({
        order: order._id,
        actualTotal: order.payInfo.rent.actualTotal,
        forceFinish,
        isBad: order.isBad,
        isFreeTrip: order.isFreeTrip,
        isOnline: stockData.isOnline,
      }).catch(error => errorHandler(error, 'RC_USER_EXPERIENCE_FINISH_ERROR'));

    } catch (error) {
      //
    }
    let points = [[0, 0], [1, 1]];
    let ts = [];
    let ppk = 0;
    let pph = 0;
    if (process.env.NODE_ENV === 'production') {
      const RCStockPointController = require('../record/RCStockPointController');
      const routePath = yield RCStockPointController.findPath(order.box, order.lease);
      // 千米点密度;
      ppk = order.route.distance === 0 ? 0 : routePath.length / order.route.distance * 1000;
      // 小时点密度;
      pph = order.lease.totalDuration === 0 ? 0 : routePath.length / order.lease.totalDuration * 60;

      points = routePath.map(point => point.gps.lngLat);
      ts = routePath.map(point => point.time);
    }
    if (points.length < 2) {
      points = [order.route.start.lngLat, ...points, order.route.end.lngLat];
      ts = [order.lease.startTime, ...ts, order.lease.endTime];
    }
    // 锁车状态下 可直接结束订单
    const lock = order.lock;
    if (lock.isLocked) {
      lock.isLocked = false;
      const index = lock.times.length - 1;
      const now = Date.now();
      lock.times[index].end = now;
      lock.times[index].lease = parseInt((now - new Date(lock.times[index].start).getTime()) / 60000);
    }
    // 完成订单
    order = yield this.T(ODOrder).findByIdAndUpdate(order._id, {
      $set: {
        state,
        'payInfo.rentBill': rentBill && rentBill._id,
        'payInfo.insuranceBill': insuranceBill && insuranceBill._id,
        'payInfo.dispatchBill': dispatchBill && dispatchBill._id,
        finishedAt: now,
        ppk,
        pph,
        endVoltage: stockData.battery.voltage,
        'route.path': {
          type: 'LineString',
          coordinates: points,
          ts,
        },
        accOn: stockData.accOn,
        lock,
      },
    }, { new: true });
    if (autoLock) {
      // 控制车辆停止设防
      IoT.at(order.box, {
        operator,
        operateLocation,
        stock: order.stock,
      }).tryLock().catch(error => IoT.emit('error', error, 'SEND_COMMAND'));
    }

    asyncTask(function *() {
      const SSAbnormalOrderInDayController = require('../statistic/SSAbnormalOrderInDayController');
      if (!(state === 1 && (order.isFreeTrip || outsideRegion || insideProhibitedArea || insideForbiddenArea))) {
        yield SSAbnormalOrderInDayController.trigger({ state, stock: stockData, user: order.user });
      }
    }, error => errorHandler(error, 'ORDER_FINISH'));

    setTimeout(_ => {
      shark.send({
        c: 'order/order/afterFinished',
        params: { id },
      });
    }, 5000);

    // 1天内给五人产生了坏订单 自动添加损坏 设置待拖回任务
    // 2018年5月9日 tc修改为连续12笔订单即设置拖回
    if (order.isBad) {
      const ordersInDay = yield ODOrderController.Model.find({
        stock: order.stock,
        createdAt: { $gte: '1 day'.before(now), $lt: now },
        'route.intersectRegion': { $exists: true },
        'route.intersectPolygon': { $ne: constants.OP_POLYGON_TYPE.禁行区 },
      }).select('user isBad route').sort({ _id: -1 }).limit(12);
      let shouldSetStockDamage = false;

      if (ordersInDay.length === 12) {
        shouldSetStockDamage = ordersInDay.every(order => order.isBad);
      }
      // const affectUsers = [];
      // let affectCount = 0;
      // let shouldSetStockDamage = false;
      // ordersInDay.forEach(item => {
      //   if (item.isBad && item.route.end.distanceWithRegionPath < 200) {
      //     if (!affectUsers.includes(item.user)) {
      //       affectCount += 1;
      //       affectUsers.push(item.user);
      //       if (affectCount === 12) shouldSetStockDamage = true;
      //     }
      //   } else {
      //     affectCount = 0;
      //   }
      // });

      if (shouldSetStockDamage) {
        yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.待拖回, {
          operator: '1',
          operateLocation: stockData.location,
          opApplyReturnBack: {
            check: 1,
            order: order._id,
          },
        });

        yield new BKDamageController(this.transaction).create({ stock: stockData._id, description: '连续产生12笔坏订单', state: constants.BK_STATE.损坏不可租, submitter: '1' }, { operator: '1', operationLocation: stockData.location });
      }
    }

    return order;
  }

  *bmFinish(id, state = constants.OD_ORDER_STATE.已完成, { operator, operateLocation, autoLock = true } = {}, parkingLot) {
    const forceFinish = [
      constants.OD_ORDER_STATE.后台结束订单,
      constants.OD_ORDER_STATE.系统结束订单,
    ].includes(state);
    yield ODOrderController.snap(id, operateLocation, parkingLot);

    // 锁定订单数据，保证后续计算使用的数据是安全的  2018-01-13 12:29:59
    let order = yield this.T(ODOrder).findById(id);
    if (order.state !== constants.OD_ORDER_STATE.租用中) return order;

    // 是免单车
    const isFreeTrip = order.isFreeTrip;
    const now = new Date();
    const userData = yield ACUserController.findByIdAndCheckExists(order.user);
    const stockData = yield BKStockController.findByIdAndCheckExists(order.stock);
    const outsideRegion = !order.route.intersectRegion;
    const insideProhibitedArea = order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
    // 判断是否在禁停区/禁行区内  如果结束类型为7 则可以在禁停区结束  不在缓冲区内，也不准结束
    const insideForbiddenArea = !order.route.inPark && order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 && stockData.location.distanceWithForbiddenArea < -5;

    const region = OPRegionController.Model.findById(order.region).select('operationPattern');

    if (state === constants.OD_ORDER_STATE.超时结束) {
      // 自动结束订单
    } else if (state === constants.OD_ORDER_STATE.长时无移动结束) {
      //
    } else {

      if (!forceFinish) { // 如果不是强制结束订单，则判断停车地点是否合理
        // 判断是否在大区内
        const device = IoT.at(order.box);
        if (outsideRegion && !isFreeTrip) {
          device.playOutsideRegionSound();
          throw new Error('请将车辆推到服务区（红线范围）内停车！', {
            code: 'controller.odOrder.stockOutsideRegion',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在服务区外',
          });
        }

        // 判断是否在禁行区内
        if (insideProhibitedArea && !isFreeTrip) {
          device.playInsideProhibitedAreaSound();
          throw new Error('当前车辆在禁行区，为了方便他人使用，请将车辆推出禁行区再结束行程！', {
            code: 'controller.odOrder.stockInProhibitedArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁行区',
          });
        }

        // 坏订单不用判断是否在禁停区
        if (insideForbiddenArea && !order.isBad) {
          device.playInsideForbiddenAreaSound();
          throw new Error('当前车辆在居民小区，为方便其他人使用，请将车辆骑出小区再结束行程！', {
            code: 'controller.odOrder.stockInForbiddenArea',
            order: order._id,
            region: order.region,
            location: order.route.end,
            description: '车辆在禁停区',
          });
        }

        // 正常区域是否可停
        if (!order.route.end.parkingLot && !order.isBad) {
          if (region.operationPattern === constants.OP_REGION_PATTERN.不可停) {
            throw new Error('当前车辆不在停车区，请将车辆骑行到停车区再结束行程！', {
              code: 'controller.odOrder.stockNotInParkingLot',
              order: order._id,
              region: order.region,
              location: order.route.end,
              description: '车辆不在停车区',
            });
          }
        }
        if (order.isBad) {
          state = constants.OD_ORDER_STATE.异常结束;
        } else {
          // 正常骑行+1分
          yield new ACCreditController(this.transaction).create(Object.assign({
            user: order.user,
            order: order._id,
          }, constants.AC_CREDIT_RECORD_INFO.正常骑行));
        }
      }
    }

    if (!order.isBad) {
      // 使用优惠券
      if (order.payInfo.coupon.ref) {
        yield new ACCouponController(this.transaction).use(order.payInfo.coupon.ref, {
          type: constants.AC_COUPON_TYPE.租金抵扣券,
          actualDiscount: order.payInfo.coupon.actualDiscount,
        });
      }
    }

    // 最终结束订单车辆在禁停禁行区或者围栏外，扣信用分。如果状态是禁停区结束或坏订单，可以不判断禁停区 TODO: 禁停区暂时不算违停
    if (!order.isBad && (outsideRegion || insideProhibitedArea)) {
      yield new ACCreditController(this.transaction).create(Object.assign({
        user: order.user,
        order: order._id,
      }, constants.AC_CREDIT_RECORD_INFO.违停));
    }

    yield BKStockController.updateLatestIllegalOrderAt(order.stock, order.isBad || order.route.distance <= 10);

    let rentBill;
    let insuranceBill;
    let dispatchBill;
    // 如果是宝驾订单，不进行结算
    if (!order.baojia.isBaojia) {
      // 生成结算账单
      const fnBalanceBillController = new FNBalanceBillController(this.transaction);
      // 租金账单
      if (order.payInfo.rent.finalTotal > 0) {
        rentBill = yield fnBalanceBillController.createRent({
          user: order.user,
          order: order._id,
          amount: order.payInfo.rent.finalTotal,
        });
      }
      if (order.payInfo.insurance.amount > 0) {
        insuranceBill = yield fnBalanceBillController.createInsurance({
          user: order.user,
          order: order._id,
          amount: order.payInfo.insurance.amount,
        });
      }
      // 调度费账单
      if (order.payInfo.dispatchCost > 0) {
        dispatchBill = yield fnBalanceBillController.createDispatch({
          user: order.user,
          order: order._id,
          amount: order.payInfo.dispatchCost,
        });
      }

      // 解冻押金
      yield new ACWalletController(this.transaction).unfreezeDeposit(order.user);
    }
    // 将车辆解锁

    yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.空闲, {
      operator,
      operateLocation,
      opReturnBack: {
        check: 1,
        order: order._id,
        user: {
          id: userData._id,
          tel: userData.auth.tel,
          name: userData.cert.name,
        },
        orderState: state,
        totalAmount: order.payInfo.totalAmount,
        duration: order.lease.totalDuration,
        distance: order.route.distance,
        outsideRegion: !order.route.intersectRegion,
        insideProhibitedArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区,
        insideForbiddenArea: order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区,
        insidePark: order.route.inPark,
        location: stockData.location,
      },
    });

    try {
      // 更新用户里程
      yield new ACUserController(this.transaction).updateMileage(order.user, order.route.calculateDistance);
      // 用户体验记录更新
      const RCUserExperienceController = require('../record/RCUserExperienceController');
      RCUserExperienceController.finish({
        order: order._id,
        actualTotal: order.payInfo.rent.actualTotal,
        forceFinish,
        isBad: order.isBad,
        isFreeTrip: order.isFreeTrip,
        isOnline: stockData.isOnline,
      }).catch(error => errorHandler(error, 'RC_USER_EXPERIENCE_FINISH_ERROR'));

    } catch (error) {
      //
    }
    let points = [[0, 0], [1, 1]];
    let ts = [];
    let ppk = 0;
    let pph = 0;
    if (process.env.NODE_ENV === 'production') {
      const RCStockPointController = require('../record/RCStockPointController');
      const routePath = yield RCStockPointController.findPath(order.box, order.lease);
      // 千米点密度;
      ppk = order.route.distance === 0 ? 0 : routePath.length / order.route.distance * 1000;
      // 小时点密度;
      pph = order.lease.totalDuration === 0 ? 0 : routePath.length / order.lease.totalDuration * 60;

      points = routePath.map(point => point.gps.lngLat);
      ts = routePath.map(point => point.time);
    }
    if (points.length < 2) {
      points = [order.route.start.lngLat, ...points, order.route.end.lngLat];
      ts = [order.lease.startTime, ...ts, order.lease.endTime];
    }
    // 锁车状态下 可直接结束订单
    const lock = order.lock;
    if (lock.isLocked) {
      lock.isLocked = false;
      const index = lock.times.length - 1;
      const now = Date.now();
      lock.times[index].end = now;
      lock.times[index].lease = parseInt((now - new Date(lock.times[index].start).getTime()) / 60000);
    }

    // 增加订单结束时的定位地址
    let address;
    if (!order.route.end.address && order.route.end.lngLat) {
      address = yield amap.findAddressByLocation(order.route.end.lngLat);
    }

    // 完成订单
    order = yield this.T(ODOrder).findByIdAndUpdate(order._id, {
      $set: {
        state,
        'payInfo.rentBill': rentBill && rentBill._id,
        'payInfo.insuranceBill': insuranceBill && insuranceBill._id,
        'payInfo.dispatchBill': dispatchBill && dispatchBill._id,
        finishedAt: now,
        ppk,
        pph,
        endVoltage: stockData.battery.voltage,
        'route.path': {
          type: 'LineString',
          coordinates: points,
          ts,
        },
        accOn: stockData.accOn,
        lock,
        'route.end.address': address || '',
      },
    }, { new: true });
    if (autoLock) {
      // 控制车辆停止设防
      IoT.at(order.box, {
        operator,
        operateLocation,
        stock: order.stock,
      }).tryLock().catch(error => IoT.emit('error', error, 'SEND_COMMAND'));
    }

    asyncTask(function *() {
      const SSAbnormalOrderInDayController = require('../statistic/SSAbnormalOrderInDayController');
      if (!(state === 1 && (order.isFreeTrip || outsideRegion || insideProhibitedArea || insideForbiddenArea))) {
        yield SSAbnormalOrderInDayController.trigger({ state, stock: stockData, user: order.user });
      }
    }, error => errorHandler(error, 'ORDER_FINISH'));

    setTimeout(_ => {
      shark.send({
        c: 'order/order/afterFinished',
        params: { id },
      });
    }, 5000);

    // 1天内给五人产生了坏订单 自动添加损坏 设置待拖回任务
    // 2018年5月9日 tc修改为连续12笔订单即设置拖回
    if (order.isBad) {
      const ordersInDay = yield ODOrderController.Model.find({
        stock: order.stock,
        createdAt: { $gte: '1 day'.before(now), $lt: now },
        'route.intersectRegion': { $exists: true },
        'route.intersectPolygon': { $ne: constants.OP_POLYGON_TYPE.禁行区 },
      }).select('user isBad route').sort({ _id: -1 }).limit(12);
      let shouldSetStockDamage = false;

      if (ordersInDay.length === 12) {
        shouldSetStockDamage = ordersInDay.every(order => order.isBad);
      }
      // const affectUsers = [];
      // let affectCount = 0;
      // let shouldSetStockDamage = false;
      // ordersInDay.forEach(item => {
      //   if (item.isBad && item.route.end.distanceWithRegionPath < 200) {
      //     if (!affectUsers.includes(item.user)) {
      //       affectCount += 1;
      //       affectUsers.push(item.user);
      //       if (affectCount === 12) shouldSetStockDamage = true;
      //     }
      //   } else {
      //     affectCount = 0;
      //   }
      // });

      if (shouldSetStockDamage) {
        yield new BKStockController(this.transaction).updateLocate(order.stock, constants.BK_LOCATE.待拖回, {
          operator: '1',
          operateLocation: stockData.location,
          opApplyReturnBack: {
            check: 1,
            order: order._id,
          },
        });

        yield new BKDamageController(this.transaction).create({ stock: stockData._id, description: '连续产生12笔坏订单', state: constants.BK_STATE.损坏不可租, submitter: '1' }, { operator: '1', operationLocation: stockData.location });
      }
    }

    return order;
  }

  *share(id, channel) {
    const order = yield this.findByIdAndCheckExists(id);
    if (order.state === constants.OD_ORDER_STATE.租用中) {
      throw new Error('该行程正在进行中');
    }
    if (order.sharedAt) {
      throw new Error('该行程已经分享过啦');
    }
    yield new RCShareController(this.transaction).create({
      user: order.user,
      type: constants.RC_SHARE_TYPE.分享订单,
      channel,
    });
    return yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        sharedAt: new Date(),
      },
    }, { new: true });
  }

  *comment(id, { rank, content, tags }) {
    const order = yield this.findByIdAndCheckExists(id);
    if (order.state === constants.OD_ORDER_STATE.租用中) {
      throw new Error('该行程正在进行中');
    }
    if (order.comment.commentedAt) throw new Error('该行程已经评论过啦');
    // yield new ACCouponController(this.transaction).issueCommentOrder(order.user);
    return yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        comment: {
          rank,
          commentedAt: new Date(),
          content,
          tags,
        },
      },
    }, { new: true });
  }

  static *countInTwoDaysByStock(stock) {
    return yield ODOrder.count({
      stock,
      createdAt: { $gte: '2 days'.before(new Date()) },
    });
  }

  *free(id, { reason, processor }) {
    const order = yield this.findByIdAndCheckExists(id);
    if (order.baojia.isBaojia) throw new Error('宝驾订单无法免单');
    if (order.free.isFree) throw new Error('该订单已经免单');
    if ([constants.OD_ORDER_STATE.租用中, constants.OD_ORDER_STATE.异常结束].includes(order.state)) {
      throw new Error('租用中和异常结束的订单不能免单');
    }
    if (order.payInfo.totalAmount === 0) throw new Error('该订单未产生付款，无需免单');
    const freeBill = yield new FNBalanceBillController(this.transaction).createFree({
      user: order.user,
      order: id,
      amount: order.payInfo.totalAmount,
    });

    const result = yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        free: {
          isFree: true,
          processor,
          processedAt: new Date(),
          reason,
        },
        'payInfo.freeDiscount': order.payInfo.totalAmount,
        'payInfo.totalAmount': 0,
        'payInfo.freeBill': freeBill._id,
      },
    }, { new: true });

    // 订单免单进入消息通知
    RCMessageSystemController.orderFreeNotify({ id, user: order.user }).catch(error => {
      //
    });
    return result;
  }

  *partFree(id, { reason, processor, amount }) {
    const order = yield this.findByIdAndCheckExists(id);
    if (order.baojia.isBaojia) throw new Error('宝驾订单无法免单');
    if (order.free.isFree) throw new Error('该订单已经免单');
    if ([constants.OD_ORDER_STATE.租用中].includes(order.state)) {
      throw new Error('租用中的订单不能免单');
    }
    const bill = yield FNBalanceBillController.Model.findById(order.payInfo.rentBill);
    if (!bill) throw new Error('该订单未产生账单,无需免单');
    if (amount > bill.amount) throw new Error('免单金额最大为实际租金金额(免调度费另行操作)');
    if (order.payInfo.totalAmount === 0) throw new Error('该订单未产生付款，无需免单');
    amount = Math.min(amount, order.payInfo.totalAmount);
    const freeBill = yield new FNBalanceBillController(this.transaction).createFree({
      user: order.user,
      order: id,
      amount,
    });
    const result = yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        free: {
          isFree: true,
          processor,
          processedAt: new Date(),
          reason,
        },
        'payInfo.freeDiscount': amount,
        'payInfo.totalAmount': order.payInfo.totalAmount - amount,
        'payInfo.freeBill': freeBill._id,
      },
    }, { new: true });

    // 订单免单进入消息通知
    RCMessageSystemController.orderFreeNotify({ id, user: order.user }).catch(error => {
      //
    });
    return result;
  }

  *freeForDispatchCost(id, { reason, processor }) {
    const order = yield ODOrderController.findByIdAndCheckExists(id);
    if (order.baojia.isBaojia) throw new Error('宝驾订单无法免单');
    if (order.freeDispatch.isFree) throw new Error('该订单已经免过调度费');
    if ([constants.OD_ORDER_STATE.租用中].includes(order.state)) {
      throw new Error('租用中的订单不能免单');
    }
    if (order.payInfo.totalAmount === 0) throw new Error('该订单未产生付款，无需免单');
    if (order.payInfo.freeDispatchBill) throw new Error('该订单已经免过调度费');
    if (order.payInfo.dispatchBill) {
      const amount = Math.min(order.payInfo.dispatchCost, order.payInfo.totalAmount);
      const freeBill = yield new FNBalanceBillController(this.transaction).createFreeForDispatchCost({
        user: order.user,
        order: id,
        amount,
      });
      return yield this.T(ODOrder).findByIdAndUpdate(id, {
        $set: {
          freeDispatch: {
            processor,
            processedAt: new Date(),
            reason,
            isFreeDispatch: true,
          },
          'payInfo.freeDispatchDiscount': amount,
          'payInfo.totalAmount': order.payInfo.totalAmount - amount,
          'payInfo.freeDispatchBill': freeBill._id,
        },
      }, { new: true });
    } else throw new Error('未生成调度费账单,无需免调度费');
  }

  *shoot(id, { photo, lngLat, address, description }, { operator, operateLocation }) {
    const order = yield ODOrderController.findByIdAndCheckExists(id);
    if (order.shootAfterFinished.shootAt) throw new Error('该订单已经上传过停车照了');
    if (order.state === constants.OD_ORDER_STATE.租用中) {
      // 车辆租用中，并且在禁停区。 有可能是禁停区不正确导致用户无法正常结束订单，则以上报位置来结束订单
      throw new Error('订单当前在租用中');
      // yield this.finish(order._id, order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 ? constants.OD_ORDER_STATE.禁停区结束 : constants.OD_ORDER_STATE.已完成, {
      //   operator,
      //   operateLocation,
      // });
    } else {
      // yield new ACCouponController(this.transaction).issueShootAfterFinished(order.user);
    }
    return yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        shootAfterFinished: {
          photo,
          lngLat,
          address,
          description,
          shootAt: new Date(),
        },
      },
    }, { new: true });
  }

  static *findRouteEndNear({ center, radius, limit }) {
    const orders = yield ODOrder.find().near('route.end.lngLat', {
      center,
      spherical: true,
      maxDistance: radius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).limit(limit).select('route.end');
    return orders.map(order => order.route.end.lngLat);
  }

  static *findRouteStartNear({ center, radius, limit }) {
    const orders = yield ODOrder.find().near('route.start.lngLat', {
      center,
      spherical: true,
      maxDistance: radius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).limit(limit).select('route.start');
    return orders.map(order => order.route.start.lngLat);
  }

  static *findByBaojiaIdAndCheckExists(baojiaId) {
    const order = yield ODOrder.findOne({ 'baojia.id': baojiaId });
    if (!order) throw new Error('订单不存在');
    return order;
  }

  static checkLocationAddressType(order) {
    let locationAddressType = 1;
    let locationAddressMsg = '骑行区还车，正常计费';
    if (!order.route.intersectRegion) {
      locationAddressType = 2;
      locationAddressMsg = '服务区外，无法还车';
    } else if (order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区) {
      locationAddressType = 4;
      locationAddressMsg = '禁行区内，无法还车';
    } else if (order.route.inPark) {
      locationAddressType = 3;
      locationAddressMsg = '停车区内还车，半价计费';
    } else if (order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区) {
      locationAddressType = 5;
      locationAddressMsg = '禁停区内，无法还车';
    }
    return {
      locationAddressType,
      locationAddressMsg,
    };
  }

  static *transformBaojiaOrder(order) {
    const { locationAddressType, locationAddressMsg } = this.checkLocationAddressType(order);

    let orderStatus = 0;
    if (order.state !== constants.OD_ORDER_STATE.租用中) orderStatus = 1;

    const details = [{
      name: `时间计费：${(order.payInfo.rent.timeRent.actualUnit || 0).toCNY()}/分×${order.lease.totalDuration}分`,
      amount: order.payInfo.rent.timeRent.actualTotal,
    }, {
      name: `里程计费：${(order.payInfo.rent.mileageRent.actualUnit || 0).toCNY()}/km×${order.route.calculateDistance}km`,
      amount: order.payInfo.rent.mileageRent.discountTotal,
    }];
    if (order.payInfo.dispatchCost) {
      details.push({
        name: '调度费',
        amount: order.payInfo.dispatchCost,
      });
    }
    if (order.payInfo.coupon.actualDiscount) {
      details.push({
        name: '优惠券抵扣',
        amount: -order.payInfo.coupon.actualDiscount,
      });
    }
    details.push({
      name: '保险',
      amount: order.payInfo.insurance.amount,
    });
    if (order.payInfo.freeDiscount) {
      details.push({
        name: '免单',
        amount: -order.payInfo.freeDiscount,
      });
    }

    const parks = yield OPPolygonController.searchNear(order.route.end.lngLat, {
      type: constants.OP_POLYGON_TYPE.停车区,
      enable: true,
    });

    return {
      orderNo: order.baojia.id,
      allMile: order.route.calculateDistance,
      lng: order.route.end.lngLat[0],
      lat: order.route.end.lngLat[1],
      locationAddressType,
      locationAddressMsg,
      orderStatus,
      totalFee: order.payInfo.totalAmount,
      timestamp: order.lease.endTime.unix,
      details,
      isLock: false,
      stationList: parks.map(park => {
        return OPPolygonController.transformBaojia(park);
      }),
    };
  }

  *payBaojiaOrder(id, { amount, paidAt }) {
    return yield this.T(ODOrder).findByIdAndUpdate(id, {
      $set: {
        'baojia.paid': true,
        'baojia.amount': amount,
        'baojia.paidAt': paidAt,
      },
    }, { new: true });
  }

  static checkParking(order, stock) {
    let status;
    let info = {};
    let clickType;
    let outsideRegion = !order.route.intersectRegion;
    let insideProhibitedArea = order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
    // 判断是否在禁停区/禁行区内  如果结束类型为7 则可以在禁停区结束  不在缓冲区内，也不准结束
    let insideForbiddenArea = !order.route.inPark && order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 && (
      stock && stock.location.distanceWithForbiddenArea < -5
    );
    // 停车区; 新停车区按照parkingLot判断 旧的按照inPark
    let isInParkingLot = order.region.parkingPattern === constants.OP_REGION_PARKING_PATTERN.新停车区 ? !!order.route.end.parkingLot : order.route.inPark;
    // 免单车

    // 0 不可停 1 其他区域 收费停车  2 可停
    const isFree = order.isFreeTrip;
    if (isInParkingLot && !outsideRegion) {
      status = 1;
      info = { bubbleContent: '停车区内', buttonContent: '结束行程', alertTitle: '提示', alertContent: '当前在停车区内,是否结束行程?', buttons: [{ label: '取消', uri: '' }, { label: '结束', uri: 'app|finishOrder' }] };
      clickType = constants.RC_ORDER_FINISH_CLICK.停车区内;
    } else {
      if (outsideRegion) {
        if (isFree) {
          status = 1;
          info = { bubbleContent: '服务区外', buttonContent: '结束行程', alertTitle: '提示', alertContent: '是否结束行程?', buttons: [{ label: '取消', uri: '' }, { label: '结束', uri: 'app|finishOrder' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.免单车围栏外;
        } else {
          status = 0;
          info = { bubbleContent: '服务区外，禁止骑行', buttonContent: '服务区外，禁止骑行', linkTitle: '服务区说明', link: 'https://blog.mangoebike.com/2017/07/21/围栏说明/' };
          clickType = constants.RC_ORDER_FINISH_CLICK.正常车围栏外;
        }
      } else if (insideProhibitedArea) {
        if (isFree) {
          status = 1;
          info = { bubbleContent: '禁行区内', buttonContent: '结束行程', alertTitle: '提示', alertContent: '是否结束行程?', buttons: [{ label: '取消', uri: '' }, { label: '结束', uri: 'app|finishOrder' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.免单车禁行区内;
        } else {
          status = 0;
          info = { bubbleContent: '禁行区内，禁止骑行', buttonContent: '禁行区内，禁止骑行', linkTitle: '禁行区说明', link: 'https://blog.mangoebike.com/2017/07/21/禁行区说明/' };
          clickType = constants.RC_ORDER_FINISH_CLICK.正常车禁行区内;
        }
      } else if (insideForbiddenArea) {
        status = 0;
        info = { bubbleContent: '禁停区内，不可停', buttonContent: '禁停区内，禁止停车', linkTitle: '禁停区说明', link: 'https://blog.mangoebike.com/2017/07/21/禁停区说明/' };
        clickType = constants.RC_ORDER_FINISH_CLICK.禁停区;
      } else {
        if (order.region.operationPattern === constants.OP_REGION_PATTERN.不可停) {
          status = 0;
          info = { bubbleContent: '停车区外,不可停', buttonContent: '请停到停车区内', linkTitle: '停车区说明', link: 'https://blog.mangoebike.com/2018/03/25/区内停车/' };
          clickType = constants.RC_ORDER_FINISH_CLICK.停车区外;
        } else {
          status = 1;
          info = (order.payInfo.dispatchCost > 0 && !order.isBad)
            ? { bubbleContent: '停车区外停车额外收费', buttonContent: '停车区外停车额外收费', alertTitle: '提示', alertContent: `当前在停车区外，停车需支付额外调度费用${(order.payInfo.dispatchCost / 100).toFixed(0)}元。确定结束订单？`, buttons: [{ label: '收费说明', uri: 'web|https://blog.mangoebike.com/2018/03/22/额外收费/' }, { label: '结束', uri: 'app|finishOrder' }, { label: '取消', uri: '' }] }
            : { bubbleContent: '停车区外', buttonContent: '结束行程', alertTitle: '提示', alertContent: `当前在停车区外,是否结束行程`, buttons: [{ label: '取消', uri: '' }, { label: '结束', uri: 'app|finishOrder' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.额外收费;
        }
      }
    }
    return {
      status,
      info,
      clickType,
    };
  }

  static newCheckParking(order, stock) {
    let status;
    let info = {};
    let clickType;
    let outsideRegion = !order.route.intersectRegion;
    let insideProhibitedArea = order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区;
    // 判断是否在禁停区/禁行区内  如果结束类型为7 则可以在禁停区结束  不在缓冲区内，也不准结束
    let insideForbiddenArea = !order.route.inPark && order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区 && stock.location.distanceWithForbiddenArea < -5;
    // 停车区; 新停车区按照parkingLot判断 旧的按照inPark
    let isInParkingLot = order.region.parkingPattern === constants.OP_REGION_PARKING_PATTERN.新停车区 ? !!order.route.end.parkingLot : order.route.inPark;
    // 免单车

    // 0 不可停 1 其他区域 收费停车  2 可停
    const isFree = order.isFreeTrip;

    if (outsideRegion) {
      if (isFree) {
        status = 1;
        info = { bubbleContent: '服务区外，禁止骑行', alertTitle: '当前在服务区外', alertContent: '请将车辆推回服务区内，停放到路边停车区域', buttons: [{ label: '查看服务区范围', uri: 'app|checkRegion' }, { label: '结束行程', uri: 'app|finishOrder' }] };
        clickType = constants.RC_ORDER_FINISH_CLICK.免单车围栏外;
      } else {
        status = 1;
        info = { bubbleContent: '服务区外，禁止骑行', alertTitle: '当前在服务区外', alertContent: '车辆只能在服务范围内骑行，请将车辆推回服务区内，停放到路边停车区域', buttons: [{ label: '查看服务区范围', uri: 'app|checkRegion' }] };
        clickType = constants.RC_ORDER_FINISH_CLICK.正常车围栏外;
      }
    } else if (insideProhibitedArea) {
      if (isFree) {
        status = 1;
        info = { bubbleContent: '禁行区内，禁止骑行', alertTitle: '当前在禁行区内', alertContent: '请将车辆推出禁行区，停放到路边停车区域', buttons: [{ label: '查看禁行区范围', uri: 'app|checkProhibitedArea' }, { label: '结束', uri: 'app|finishOrder' }] };
        clickType = constants.RC_ORDER_FINISH_CLICK.免单车禁行区内;
      } else {
        status = 1;
        info = { bubbleContent: '禁行区内，禁止骑行', alertTitle: '当前在禁行区内', alertContent: '请将车辆推出禁行区，停放到路边停车区域', buttons: [{ label: '查看禁行区范围', uri: 'app|checkProhibitedArea' }] };
        clickType = constants.RC_ORDER_FINISH_CLICK.正常车禁行区内;
      }
    } else if (insideForbiddenArea) {
      status = 1;
      info = { bubbleContent: '禁停区内，禁止停车', alertTitle: '当前在禁停区内', alertContent: '为方便他人用车，请勿将车辆停到小区、单位大院等区域', buttons: [{ label: '查看临近停车区', uri: 'app|checkParkingLot' }] };
      clickType = constants.RC_ORDER_FINISH_CLICK.禁停区;
    } else {
      if (order.region.operationPattern === constants.OP_REGION_PATTERN.不可停) {
        status = 1;
        if (isInParkingLot) {
          info = { bubbleContent: '停车区内', buttonContent: '结束行程', alertTitle: '提示', alertContent: '当前在停车区内,是否结束行程?', buttons: [{ label: '结束', uri: 'app|finishOrder' }, { label: '取消', uri: '' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.停车区内;
        } else {
          info = { bubbleContent: '停车区外', alertTitle: '当前在停车区外', alertContent: '为保持街道整洁，请将车辆停到停车区内；请将车辆停到临近的停车区', buttons: [{ label: '查看临近停车区', uri: 'app|checkParkingLot' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.停车区外;
        }
      } else {
        status = 1;
        if (isInParkingLot) {
          info = { bubbleContent: '停车区内', buttonContent: '结束行程', alertTitle: '提示', alertContent: '当前在停车区内,是否结束行程?', buttons: [{ label: '结束', uri: 'app|finishOrder' }, { label: '取消', uri: '' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.停车区内;
        } else {
          info = (order.payInfo.dispatchCost > 0 && !order.isBad)
            ? { bubbleContent: '停车区外', alertTitle: '当前在停车区外', alertContent: `为维护良好的停车秩序，停车区外停车将额外收取${(order.payInfo.dispatchCost / 100).toFixed(0)}元调度费，建议您将车辆停到临近的停车区`, buttons: [{ label: '查看临近停车区', uri: 'app|checkParkingLot' }, { label: '支付调度费并结束', uri: 'app|finishOrder' }] }
            : { bubbleContent: '停车区外', alertTitle: '当前在停车区外', alertContent: `为保持街道整洁，建议您将车辆停到临近的停车区`, buttons: [{ label: '查看临近停车区', uri: 'app|checkParkingLot' }, { label: '结束', uri: 'app|finishOrder' }] };
          clickType = constants.RC_ORDER_FINISH_CLICK.额外收费;
        }
      }
    }
    return {
      status,
      info,
      clickType,
    };
  }

  *grantCoupon({ order, name, amount, granter, count, validateDay }) {
    for (let i = 0; i < count; i += 1) {
      yield new ACCouponController(this.transaction).create({
        name,
        user: order.user,
        amount,
        type: constants.AC_COUPON_TYPE.租金抵扣券,
        validDuration: validateDay,
        isSystem: false,
        granter,
      });
    }
    yield this.T(ODOrder).findByIdAndUpdate(order._id, {
      $set: {
        grantCoupon: true,
      },
    });
  }

}

ODOrderController.Model = ODOrder;
module.exports = ODOrderController;
