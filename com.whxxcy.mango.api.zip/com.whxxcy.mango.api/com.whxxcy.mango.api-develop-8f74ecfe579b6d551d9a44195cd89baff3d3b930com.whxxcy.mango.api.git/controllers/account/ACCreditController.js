const ACCredit = require('../../models/account/ac_credit');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const ACUserController = require('./ACUserController');
const RCMessageSystemController = require('../record/RCMessageSystemController');
const Error = require('errrr');

class ACCreditController extends Controller {
  *create({ user, name, type, point, order }) {
    if (type === constants.AC_CREDIT_RECORD_TYPE.加分) {
      yield new ACUserController(this.transaction).increaseCredit(user, point);
    } else {
      yield new ACUserController(this.transaction).decreaseCredit(user, point);
      // 信用减分消息通知
      RCMessageSystemController.creditDecreaseNotify({ user, order }).catch(error => {
        //
      });
    }
    return yield this.T(ACCredit).create({
      _id: yield ACCredit.genId(),
      user,
      order,
      name,
      type,
      point,
    });
  }

  static * findByIdAndCheckExists (id) {
    const credit = yield ACCredit.findById(id);
    if (!credit) throw new Error('记录不存在');
    return credit;
  }

  * findByIdAndCheckExists (id) {
    const credit = yield this.T(ACCredit).findById(id);
    if (!credit) throw new Error('记录不存在');
    return credit;
  }

  * appeal (id) {
    const credit = yield this.findByIdAndCheckExists(id);
    if (credit.type !== constants.AC_CREDIT_RECORD_TYPE.扣分) {
      throw new Error('只有扣分记录可以申诉！');
    }
    if (credit.appeal.appealed) throw new Error('该条记录已经申诉过！');
    return yield this.T(ACCredit).findByIdAndUpdate(id, {
      $set: {
        'appeal.appealed': true,
        'appeal.appealedAt': new Date(),
      }
    }, { new: true });
  }

  * pass (id) {
    const credit = yield this.findByIdAndCheckExists(id);
    if (!credit.appeal.appealed) throw new Error('该记录未申诉');
    if (credit.appeal.passedAt) throw new Error('该申诉记录已经通过');
    if (credit.appeal.rejectedAt) throw new Error('该申诉记录已经驳回');
    yield new ACUserController(this.transaction).increaseCredit(credit.user, credit.point);
    return yield this.T(ACCredit).findByIdAndUpdate(id, {
      $set: {
        'appeal.result': constants.OP_CREDIT_APPEAL_RESULT.通过,
        'appeal.passedAt': new Date(),
      }
    }, { new: true });
  }

  * reject (id, rejectReason) {
    const credit = yield this.findByIdAndCheckExists(id);
    if (!credit.appeal.appealed) throw new Error('该记录未申诉');
    if (credit.appeal.passedAt) throw new Error('该申诉记录已经通过');
    if (credit.appeal.rejectedAt) throw new Error('该申诉记录已经驳回');
    return yield this.T(ACCredit).findByIdAndUpdate(id, {
      $set: {
        'appeal.result': constants.OP_CREDIT_APPEAL_RESULT.驳回,
        'appeal.rejectedAt': new Date(),
        'appeal.rejectReason': rejectReason,
      }
    }, { new: true });
  }
}

ACCreditController.Model = ACCredit;
module.exports = ACCreditController;
