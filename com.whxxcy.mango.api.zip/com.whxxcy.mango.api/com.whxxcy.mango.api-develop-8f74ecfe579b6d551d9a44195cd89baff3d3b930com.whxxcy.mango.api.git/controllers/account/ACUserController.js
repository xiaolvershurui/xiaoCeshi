const ACUser = require('../../models/account/ac_user');
const Controller = require('../Controller');
const utils = require('xx-utils');
const Error = require('errrr');
const constants = require('../../settings/constants');
const { idCardVerify } = require('../../services/xinyan');
// const idCardVerify = require('../../services/aliOpenAPI/idCardVerify');
const ACWalletController = require('./ACWalletController');
const ACCouponController = require('./ACCouponController');
const RCInviteController = require('../record/RCInviteController');
const RCUserOpController = require('../record/RCUserOpController');
const { crypto } = require('xx-utils');
const settings = require('../../settings');
const token = require('../../middlewares/jwt').token;

class ACUserController extends Controller {

  static *findByTel(tel) {
    return ACUser.findOne({ 'auth.tel': tel });
  }

  static *findByName(name) {
    return ACUser.find({ 'cert.name': name }).limit(0);
  }

  static *findByCert(certNo, certType) {
    return ACUser.findOne({
      'cert.certNo': certNo,
      'cert.certType': certType,
      'auth.primaryUser': { $exists: false },
      destroyed: { $ne: true },
    });
  }

  *create(tel, { fromBaojia = false } = {}) {
    // throw new Error('账户注册服务暂停，请明日再试！');
    if (yield ACUserController.findByTel(tel)) {
      throw new Error('该手机号已经被注册，请更换其他手机号注册！');
    }
    const user = {
      _id: yield ACUser.genId(),
      auth: { tel, fromBaojia },
      invite: {
        code: parseInt(tel).toString(36).toUpperCase(),
      },
      profile: {},
      cert: {},
    };
    yield new ACWalletController(this.transaction).create(user._id);
    return yield this.T(ACUser).create(user);
  }

  *createSubUser(id, tel) {
    if (!(/^00/).test(tel)) throw new Error('子账号必须是00开头的号码');
    if (yield ACUserController.findByTel(tel)) throw new Error('该号码已被注册');
    const primaryUser = yield ACUserController.findByIdAndCheckExists(id);
    if (primaryUser.auth.primaryUser) throw new Error('不能给子账号添加子账号');
    if (!primaryUser.cert.hasVerified) throw new Error('主账号必须先通过实名认证');
    const userId = yield ACUser.genId();
    yield new ACWalletController(this.transaction).create(userId);
    return yield this.T(ACUser).create({
      _id: userId,
      auth: {
        tel,
        primaryUser: id,
        verifyTel: primaryUser.auth.tel,
      },
      invite: {
        code: parseInt(tel).toString(36).toUpperCase(),
      },
      profile: primaryUser.profile,
      cert: primaryUser.cert,
    });
  }

  static *findByIdAndCheckExists(id) {
    const user = yield ACUser.findById(id);
    if (!user) throw new Error('用户不存在，请联系管理员！');
    return user;
  }

  *findByIdAndCheckExists(id) {
    const user = yield this.T(ACUser).findById(id);
    if (!user) throw new Error('用户不存在，请联系管理员！');
    return user;
  }

  *bindWxOpenId(id, wxOpenId) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $set: {
        'auth.wxOpenId': wxOpenId,
      },
    }, { new: true });
  }

  *bindAlipayOpenId(id, alipayOpenId) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $set: {
        'auth.alipayOpenId': alipayOpenId,
      },
    }, { new: true });
  }

  *addRole(id, role) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $addToSet: {
        'auth.roles': role,
      },
    }, { new: true });
  }

  *removeRole(id, role) {
    yield token.destroyMany({ id });
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $pull: {
        'auth.roles': role,
      },
    }, { new: true });
  }

  static *addPermission(id, permission) {
    return yield ACUser.findByIdAndUpdate(id, {
      $addToSet: {
        'auth.permissions': permission,
      },
    }, { new: true });
  }

  static *removePermission(id, permission) {
    yield token.destroyMany({ id });
    return yield ACUser.findByIdAndUpdate(id, {
      $pull: {
        'auth.permissions': permission,
      },
    }, { new: true });
  }

  // 设置/取消管理员权限
  *setAdminRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, 'admin');
    } else {
      return yield this.addRole(id, 'admin');
    }
  }

  // 设置/取消城市经理权限
  *setManagerRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, 'manager');
    } else {
      return yield this.addRole(id, 'manager');
    }
  }

  // 设置/取消客服权限
  *setCustomerServiceRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, '客户服务');
    } else {
      return yield this.addRole(id, '客户服务');
    }
  }

  // 设置/取消数据采集权限
  *setDataCollectorRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, '数据采集');
    } else {
      return yield this.addRole(id, '数据采集');
    }
  }

  // 设置/取消线上运营权限
  *setDataOnlineOperatorRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, '线上运营');
    } else {
      return yield this.addRole(id, '线上运营');
    }
  }

  // 设置/取消仓库管理员权限
  *setStoreRole(id, unset) {
    if (unset) {
      return yield this.removeRole(id, '仓库管理');
    } else {
      return yield this.addRole(id, '仓库管理');
    }
  }

  static *updateProfile(id, profile) {
    const data = {};
    Object.keys(profile).forEach(key => (data[`profile.${key}`] = profile[key]));
    return yield ACUser.findByIdAndUpdate(id, {
      $set: data,
    }, { new: true });
  }

  static *updateInviteCode(id, code) {
    const user = yield ACUserController.findByIdAndCheckExists(id);
    if (user.invite.codeHasChanged) throw new Error('您已经修改过邀请码，无法再次修改！');
    // 屏蔽所有长度≤4的邀请码，作为活动奖励来使用
    if (code.length <= 4) throw new Error('该邀请码已被占用，请更换一个再试！');
    if (yield ACUser.findOne({ 'invite.code': code })) throw new Error('该邀请码已被占用，请更换一个再试！');
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        'invite.code': code,
        'invite.codeHasChanged': true,
      },
    }, { new: true });
  }

  *updateInvitedBy(id, code) {
    const account = yield this.findByIdAndCheckExists(id);
    if(!account.cert.hasVerified) throw new Error('请先进行实名认证');
    if (account.invite.invitedBy) throw new Error('已经填写过邀请码！');
    const inviteUser = yield ACUser.findOne({ 'invite.code': code });
    if (!inviteUser) throw new Error('无效的邀请码，请查实后重试！');
    if (inviteUser._id === id) throw new Error('不能使用自己的邀请码！');
    // 各发5张2元优惠券
    yield new RCInviteController(this.transaction).create({ user: inviteUser._id, invitedUser: id });
    yield new ACCouponController(this.transaction).issueInvite(inviteUser._id);
    yield new ACCouponController(this.transaction).issueInvite(id);
    // 给邀请人加信用分
    const ACCreditController = require('./ACCreditController');
    yield new ACCreditController(this.transaction).create(Object.assign({
      user: inviteUser._id,
    }, constants.AC_CREDIT_RECORD_INFO.邀请注册));
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $set: {
        'invite.invitedBy': inviteUser._id,
      },
    }, { new: true });
  }

  *updateMileage(id, mileage) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $inc: {
        'achievement.mileage': mileage,
      },
    }, { new: true });
  }

  *resetCertTry(id) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $set: {
        'cert.triedAt': [],
      },
    }, { new: true });
  }

  *pushCertTry(id) {
    let user = yield this.findByIdAndCheckExists(id);
    if (user.cert.hasVerified) throw new Error('已经通过实名认证！');
    const firstTry = user.cert.triedAt[0];
    if (firstTry && 'today'.beginning.is.over(firstTry)) {
      user = yield this.resetCertTry(id);
    }
    if (user.cert.triedAt.length >= constants.AC_CERT_TRY_TIMES_PER_DAY) {
      throw new Error(`今日已经尝试认证${constants.AC_CERT_TRY_TIMES_PER_DAY}次，请明日再试`);
    }
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $push: {
        'cert.triedAt': new Date(),
      },
    }, { new: true });
  }

  static *setRealNameAuth(id, { certNo, certType, certPic, name, noCheck = false }, isSelf) {
    let user = yield ACUserController.findByCert(certNo, certType);
    if (user) {
      if (isSelf) throw new Error(`该证件已由尾号[${user.auth.tel.slice(-4)}]的手机号认证，若需要对原账号进行注销，请联系客服。`);
      else throw new Error(`非常抱歉，你当前账号预留的身份信息与芒果电单车预留的身份信息不一致。如需继续使用，请致电芒果客服：400-023-8906`);
    }
    user = yield ACUserController.findByIdAndCheckExists(id);
    if (certType !== constants.AC_CERT_TYPE.身份证) {
      throw new Error('暂不支持除中国大陆身份证外的证件类型');
    }
    const { city = '未知', birth, gender } = utils.transform.parseIdCardNo(certNo);
    if (utils.judgement.isEmpty(city) || !utils.judgement.isDate(birth) || utils.judgement.isEmpty(gender)) {
      throw new Error('请输入合法的身份证号');
    }
    if (process.env.NODE_ENV === 'production' && !noCheck) {
      yield idCardVerify({ certNo, name, tel: user.auth.tel, uid: user._id });
    }
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        cert: {
          hasVerified: true,
          triedAt: [],
          verifiedAt: new Date(),
          certType,
          certNo,
          certPic,
          certInfo: {
            hometown: city,
            birthday: birth,
            gender,
          },
          name,
        },
      },
    }, { new: true });
  }

  static *resetRealNameAuth(id) {
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        cert: {
          hasVerified: false,
          triedAt: [],
        },
      },
    }, { new: true });
  }

  *increaseCredit(id, point) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $inc: {
        credit: point,
      },
    }, { new: true });
  }

  *decreaseCredit(id, point) {
    return yield this.T(ACUser).findByIdAndUpdate(id, {
      $inc: {
        credit: -point,
      },
    }, { new: true });
  }

  // 设置密码后可以用密码登陆
  static *setPassword(id, password) {
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        'auth.password': crypto.aes256(id, settings.passwordEncryptionIV).encode(crypto.md5(password)),
      },
    });
  }

  // 取消密码设置后不能再使用密码登陆
  static *unsetPassword(id) {
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        'auth.password': null,
      },
    });
  }

  // 检验密码是否正确
  static *checkPassword(id, md5Password) {
    const user = yield this.findByIdAndCheckExists(id);
    if (!user.auth.password) throw new Error('该账号不支持密码登陆，请联系管理员');
    if (crypto.aes256(id, settings.passwordEncryptionIV).decode(user.auth.password) !== md5Password) {
      throw new Error('密码不正确');
    }
  }

  // 更新位置快照
  static *updateLocation(id, location) {
    return yield ACUser.findByIdAndUpdate(id, {
      $set: {
        location,
      },
    }, { new: true });
  }

  static *destroy(id, operator) {
    yield token.destroyMany({ id });
    yield ACUser.findByIdAndUpdate(id, {
      destroyed: true,
    }, { new: true });
    const acOperator = yield ACUserController.findByIdAndCheckExists(operator);
    const acUser = yield ACUserController.findByIdAndCheckExists(id);
    yield RCUserOpController.Model.create({
      user: acUser._id,
      userTel: acUser.auth && acUser.auth.tel,
      type: constants.RC_USER_OP.注销账号,
      operator: acOperator._id,
      operatorTel: acOperator.auth && acOperator.auth.tel,
      operatedAt: new Date(),
    });
    return yield ACUser.findById(id);
  }

  static *cancelDestroy(id) {
    const user = yield this.findByIdAndCheckExists(id);
    if (user.cert.certNo) {
      if (yield ACUserController.findByCert(user.cert.certNo, user.cert.certType)) throw new Error('认证信息已被重新使用，无法从注销中恢复。');
    }
    return yield ACUser.findByIdAndUpdate(id, {
      destroyed: false,
    }, { new: true });
  }

  *updateIsReceivedCoupon(user) {
    yield this.T(ACUser).findByIdAndUpdate(user, {
      $set: {
        'invite.isReceivedCoupon': true,
      },
    });
  }

  *updateInvite(invitedBy, user) {
    yield new RCInviteController(this.transaction).create({
      user: invitedBy,
      invitedUser: user,
    });
    yield new ACUserController(this.transaction).updateIsReceivedCoupon(user);
    user = yield ACUserController.findByIdAndCheckExists(user);
    if (user.cert && user.cert.hasVerified) {
      yield new ACUserController(this.transaction).sendCoupon(invitedBy, user._id)
    }
  }

  *sendCoupon(invitedBy, user) {
    for (let item of [invitedBy, user]) {
      for (let i = 0; i < 5; i++) {
        yield new ACCouponController(this.transaction).create({
          name: '邀请好友',
          user: item,
          amount: 200,
          validDuration: 7,
          isSystem: true,
          granter: '1',
          isGetByShare: true,
        });
      }
    }
  }
}

ACUserController.Model = ACUser;
module.exports = ACUserController;
