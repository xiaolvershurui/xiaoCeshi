const ACCoupon = require('../../models/account/ac_coupon');
const Controller = require('../Controller');
const constants = require('../../settings/constants');
const RCMessageSystemController = require('../record/RCMessageSystemController');
const Error = require('errrr');

class ACCouponController extends Controller {
  *create({ name, user, type, amount, validDuration, isSystem, granter, isGetByShare }) {
    if (amount <= 0) throw new Error('金额必须大于0元');
    const result = yield this.T(ACCoupon).create({
      _id: yield ACCoupon.genId(),
      name,
      user,
      amount,
      expires: `${validDuration - 1} days`.after('today'.ending),
      type,
      granter,
      isSystem,
      isGetByShare,
    });
    // 优惠券到账通知
    RCMessageSystemController.couponNotify({ id: result._id, user }).catch(error => {
      //
    });
    return result;
  }

  static *create({ name, user, type, amount, validDuration, granter, isSystem }) {
    if (amount <= 0) throw new Error('金额必须大于0元');
    const result = yield ACCoupon.create({
      _id: yield ACCoupon.genId(),
      name,
      user,
      amount,
      expires: `${validDuration - 1} days`.after('today'.ending),
      type,
      granter,
      isSystem,
    });
    // 优惠券到账通知
    RCMessageSystemController.couponNotify({ id: result._id, user }).catch(error => {
      //
    });
    return result;

  }

  static *issueByUser(user, { name = '赔付补偿', amount, type = constants.AC_COUPON_TYPE.租金抵扣券, validDuration = 7, granter, isSystem = false }) {
    const ACUserController = require('../account/ACUserController');
    yield ACUserController.findByIdAndCheckExists(user);
    return yield this.create({
      name,
      user,
      type,
      amount,
      validDuration,
      granter,
      isSystem,
    });
  }

  static *issueByConfig(user, { count, amount, name, type, validDuration }) {
    for (let i = 0; i < count; i += 1) {
      yield this.create({
        name,
        user,
        type,
        validDuration,
        amount,
        isSystem: true,
      });
    }
  }

  *issueByConfig(user, { count, amount, name, type, validDuration }) {
    for (let i = 0; i < count; i += 1) {
      yield this.create({
        name,
        user,
        type,
        validDuration,
        amount,
        isSystem: true,
      });
    }
  }

  *issueInvite(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.invite);
  }

  *issueShareApp(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.shareApp);
  }

  *issueShareOrder(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.shareOrder);
  }

  *issueCommentOrder(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.commentOrder);
  }

  *issueShootAfterFinished(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.shootAfterFinished);
  }

  static *issueScanFailed(user) {
    yield this.issueByConfig(user, constants.AC_COUPON_INFO.scanFailed);
  }

  static *findAllAvailable(user) {
    return yield ACCoupon.find({
      state: constants.AC_COUPON_STATE.可使用,
      user,
      expires: { $gte: new Date() },
    }).sort({ expires: 1, _id: -1 });
  }

  static *findValid({ amount, user, type }) {
    const query = {
      state: constants.AC_COUPON_STATE.可使用,
      type,
      user,
      expires: { $gte: new Date() },
    };
    let coupon = yield ACCoupon.findOne(Object.assign({
      amount: { $gte: amount },
    }, query)).sort({ amount: 1, expires: 1 });
    if (!coupon) {
      coupon = yield ACCoupon.findOne(Object.assign({
        amount: { $lt: amount },
      }, query)).sort({ amount: -1, expires: 1 });
    }
    return coupon;
  }

  static *findByIdAndCheckExists(id) {
    const coupon = yield ACCoupon.findById(id);
    if (!coupon) throw new Error('优惠券不存在');
    return coupon;
  }

  *findByIdAndCheckExists(id) {
    const coupon = yield this.T(ACCoupon).findById(id);
    if (!coupon) throw new Error('优惠券不存在');
    return coupon;
  }

  static *checkExpires() {
    return yield ACCoupon.update({
      state: constants.AC_COUPON_STATE.可使用,
      expires: { $lt: new Date() },
    }, {
      $set: {
        state: constants.AC_COUPON_STATE.已过期,
      },
    }, { multi: true });
  }

  *use(id, { type, actualDiscount }) {
    const coupon = yield this.findByIdAndCheckExists(id);
    const { expires, state } = coupon;
    if (state !== constants.AC_COUPON_STATE.可使用) throw new Error('该优惠券不可用');
    const now = new Date();
    if (now.is.over(expires)) {
      throw new Error('该优惠券已过期');
    }
    if (coupon.type !== type) throw new Error('优惠券类型不正确');
    return yield this.T(ACCoupon).findByIdAndUpdate(id, {
      $set: {
        state: constants.AC_COUPON_STATE.已使用,
        usedAt: now,
        actualDiscount,
      },
    }, { new: true });
  }

  *reset(id) {
    return yield this.T(ACCoupon).findOneAndUpdate({
      state: constants.AC_COUPON_STATE.已使用,
      expires: { $gte: new Date() },
      _id: id,
    }, {
      $set: {
        state: constants.AC_COUPON_STATE.可使用,
        usedAt: null,
      },
    }, { new: true });
  }
}

ACCouponController.Model = ACCoupon;
module.exports = ACCouponController;
