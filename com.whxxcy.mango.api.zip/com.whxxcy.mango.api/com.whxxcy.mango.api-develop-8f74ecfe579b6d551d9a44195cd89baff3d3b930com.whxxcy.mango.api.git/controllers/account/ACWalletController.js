const ACWallet = require('../../models/account/ac_wallet');
const FNFinanceBill = require('../../models/finance/fn_balance_bill');
const ODOrder = require('../../models/order/od_order');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class ACWalletController extends Controller {
  *create(user) {
    return yield this.T(ACWallet).create({
      _id: user,
      user,
    });
  }

  static *findByUserAndCheckExists(user) {
    let wallet = yield ACWallet.findById(user);
    if (!wallet) throw new Error('钱包不存在，请联系管理员');
    return wallet;
  }

  static *getExtraFinanceInfo(user) {
    let fnFinanceBill = yield FNFinanceBill.aggregate([{
      $match: {
        signal: {
          // 充值, 余额退款, 撤销余额退款
          $in: [constants.FN_BALANCE_BILL_SIGNAL.充值, constants.FN_BALANCE_BILL_SIGNAL.充值退款, constants.FN_BALANCE_BILL_SIGNAL.撤销退款],
        },
        user,
      },
    }, {
      $group: {
        _id: '$signal',
        total: { $sum: '$amount' },
      },
    }, {
      $project: {
        _id: 0,
        type: '$_id',
        amount: '$total',
      },
    }]).read('secondary');
    // 订单消费
    let totalAmount = yield ODOrder.aggregate([
      {
        $match: {
          user,
          'baojia.isBaojia': {
            $ne: true,
          },
          state: {
            $ne: constants.OD_ORDER_STATE.租用中,
          },
        },
      }, {
        $group: {
          _id: '',
          total: { $sum: '$payInfo.totalAmount' },
        },
      }, {
        $project: {
          _id: 0,
          type: '$_id',
          amount: '$total',
        },
      },
    ]).read('secondary');
    fnFinanceBill = fnFinanceBill.reduce((memo, item) => {
      memo[item.type] = item.amount;
      return memo;
    }, {});
    totalAmount = totalAmount[0] ? totalAmount[0].amount : 0;
    return Object.assign(fnFinanceBill, { consume: totalAmount });
  }

  *findByUserAndCheckExists(user) {
    const wallet = yield this.T(ACWallet).findById(user);
    if (!wallet) throw new Error('钱包不存在，请联系管理员');
    return wallet;
  }

  *increaseBalance(user, amount) {
    yield this.findByUserAndCheckExists(user);
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $inc: { balance: amount },
    }, { new: true });
  }

  *decreaseBalance(user, amount) {
    yield this.findByUserAndCheckExists(user);
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $inc: { balance: -amount },
    }, { new: true });
  }

  *payDeposit(user, { amount, ticket }) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (wallet.deposit.paid) throw new Error('已经缴纳过押金');
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      throw new Error('押金正在退款中，请等待退款完成再进行缴纳');
    }
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.未缴纳) {
      throw new Error('当前不能进行押金缴纳');
    }
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        deposit: {
          paid: true,
          amount,
          state: constants.FN_DEPOSIT_REFUND_STATE.可退款,
          ticket,
        },
      },
    }, { new: true });
  }

  *freezeDeposit(user) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (!wallet.deposit.paid) throw new Error('还未缴纳押金');
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.可退款) {
      throw new Error('当前不能冻结押金');
    }
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.冻结中,
      },
    }, { new: true });
  }

  *unfreezeDeposit(user) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (!wallet.deposit.paid) throw new Error('还未缴纳押金');
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.可退款,
      },
    }, { new: true });
  }

  *applyRefund(user, refundReason = '') {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (!wallet.deposit.paid) throw new Error('还未缴纳押金');
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.可退款) {
      throw new Error('押金当前不能申请退款');
    }
    if (wallet.balance < 0) throw new Error('请先缴清欠款！');
    const FNTicketController = require('../../controllers/finance/FNTicketController');
    const newWallet = yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.退款中,
        'deposit.paid': false,
        'deposit.amount': 0,
      },
    }, { new: true });
    // 钱包中确认退款，在申请后即可退
    yield new FNTicketController(this.transaction).applyRefund(wallet.deposit.ticket, {
      willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date()),
    }, { reason: refundReason });
    return newWallet;
  }

  *applyRefundV2(user, refundReason, refundReasonExtra) {
    const wallet = yield this.findByUserAndCheckExists(user);
    const FNTicketController = require('../../controllers/finance/FNTicketController');
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.可退款) {
      if (!wallet.deposit.paid) throw new Error('还未缴纳押金');
      if (wallet.balance < 0) throw new Error('请先缴清欠款！');
      yield this.T(ACWallet).findByIdAndUpdate(user, {
        $set: {
          'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.退款中,
          'deposit.paid': false,
          'deposit.amount': 0,
        },
      }, { new: true });
      // 钱包中确认退款，在申请后即可退
      yield new FNTicketController(this.transaction).applyRefund(wallet.deposit.ticket, {
        willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date()),
      }, { reason: refundReason, refundReasonExtra });
    } else if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      yield new FNTicketController(this.transaction).updateRefundReason(wallet.deposit.ticket, {
        willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date()),
        reason: refundReason,
        refundReasonExtra,
      });
    }
    return yield ACWallet.findById(user).populate({
      model: FNTicketController.Model,
      path: 'deposit.ticket',
      select: 'state apiChannel finishedAt',
    });
  }

  *applyRefundForTimeOut({ user, reason, refundReasonExtra, account, type, name }) {
    const wallet = yield this.findByUserAndCheckExists(user);
    const FNTicketController = require('../../controllers/finance/FNTicketController');
    if (wallet.balance < 0) throw new Error('请先缴清欠款！');
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      yield new FNTicketController(this.transaction).updateRefundReason(wallet.deposit.ticket, {
        willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date()),
        reason,
        refundReasonExtra,
        account,
        type,
        name,
      });
    } else if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.可退款) {
      yield this.T(ACWallet).findByIdAndUpdate(user, {
        $set: {
          'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.退款中,
          'deposit.paid': false,
          'deposit.amount': 0,
        },
      }, { new: true });
      const FNTicketController = require('../../controllers/finance/FNTicketController');
      // 钱包中确认退款，在申请后即可退
      yield new FNTicketController(this.transaction).applyRefund(wallet.deposit.ticket, {
        willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date()),
      }, {
        reason,
        refundReasonExtra,
        account,
        type,
        name,
      });
    }

    return ACWallet.findById(user).populate({
      model: FNTicketController.Model,
      path: 'deposit.ticket',
      select: 'state apiChannel finishedAt refund',
    });
  }

  *cancelRefund(user) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      throw new Error('还未申请退款，无法撤销');
    }
    const FNTicketController = require('../../controllers/finance/FNTicketController');
    const fnTicketController = new FNTicketController(this.transaction);
    const ticket = yield fnTicketController.findRefundingByUser(user);
    if (!ticket) {
      throw new Error('退款申请已经提交到支付渠道，无法撤销');
    }
    yield fnTicketController.cancelRefund(ticket._id);
    return yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        deposit: {
          paid: true,
          amount: ticket.amount,
          state: constants.FN_DEPOSIT_REFUND_STATE.可退款,
          ticket: ticket._id,
        },
      },
    }, { new: true });
  }

  *cancelRefundV2(user) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (wallet.deposit.state !== constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      throw new Error('还未申请退款，无法撤销');
    }
    const FNTicketController = require('../../controllers/finance/FNTicketController');
    const fnTicketController = new FNTicketController(this.transaction);
    const ticket = yield fnTicketController.findRefundingByUser(user);
    if (!ticket) {
      throw new Error('退款申请已经提交到支付渠道，无法撤销');
    }
    yield fnTicketController.cancelRefund(ticket._id);
    yield this.T(ACWallet).findByIdAndUpdate(user, {
      $set: {
        deposit: {
          paid: true,
          amount: ticket.amount,
          state: constants.FN_DEPOSIT_REFUND_STATE.可退款,
          ticket: ticket._id,
        },
      },
    }, { new: true });
    return ACWallet.findById(user).populate({
      model: FNTicketController.Model,
      path: 'deposit.ticket',
      select: 'state apiChannel finishedAt refund',
    });
  }

  *confirmRefund(user) {
    const wallet = yield this.findByUserAndCheckExists(user);
    if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
      return yield this.T(ACWallet).findByIdAndUpdate(user, {
        $set: {
          'deposit.state': constants.FN_DEPOSIT_REFUND_STATE.未缴纳,
          'deposit.ticket': null,
        },
      }, { new: true });
    }
  }

  static getClientShowState(wallet) {
    let state;
    const isMoreThan3Month = (wallet.deposit.ticket && ([constants.FN_TICKET_STATE.已支付, constants.FN_TICKET_STATE.退款中].includes(wallet.deposit.ticket.state)) &&
      (wallet.deposit.ticket.channel === constants.FN_TICKET_PAYMENT_API_CHANNEL.支付宝) &&
      (Date.now() - (new Date(wallet.deposit.ticket.finishedAt.getTime())) > 90 * 24 * 3600 * 1000));
    if (wallet.deposit.ticket && wallet.deposit.ticket.state === constants.FN_TICKET_STATE.退款失败) {
      state = constants.AC_WALLET_CLIENT_SHOW_STATE.退款失败;
    } else {
      if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.退款中) {
        if (wallet.deposit.ticket.state === constants.FN_TICKET_STATE.退款已确认) {
          state = constants.AC_WALLET_CLIENT_SHOW_STATE.退款中不可撤销;
        } else {
          state = constants.AC_WALLET_CLIENT_SHOW_STATE.退款中可撤销;
        }
      } else {
        if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.未缴纳) {
          state = constants.AC_WALLET_CLIENT_SHOW_STATE.未交纳;
        } else if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.可退款) {
          state = constants.AC_WALLET_CLIENT_SHOW_STATE.可自动退款;
          if (isMoreThan3Month) {
            state = constants.AC_WALLET_CLIENT_SHOW_STATE.需手动退款;
          }
        } else if (wallet.deposit.state === constants.FN_DEPOSIT_REFUND_STATE.冻结中) {
          state = constants.AC_WALLET_CLIENT_SHOW_STATE.冻结中;
        }
      }
    }
    return state;
  }
}

ACWalletController.Model = ACWallet;

module.exports = ACWalletController;
