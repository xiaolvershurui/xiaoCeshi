const ACOperator = require('../../models/account/ac_operator');
const ACUserController = require('./ACUserController');
const OPRegionController = require('../operation/OPRegionController');
const OPPolygonController = require('../operation/OPPolygonController');
const RCOperatorCaptureController = require('../record/RCOperatorCaptureController');
const OPInspectionOrderController = require('../operation/OPInspectionOrderController');
const OPRideOrderController = require('../operation/OPRideOrderController');
const Controller = require('../Controller');
const Error = require('errrr');
const constants = require('../../settings/constants');

class ACOperatorController extends Controller {
  static *findByIdAndCheckExists(id) {
    const operator = yield ACOperator.findById(id);
    if (!operator) throw new Error('运营人员不存在');
    return operator;
  }

  static get role() {
    return 'operator';
  }

  static *create(user) {
    if (yield ACOperator.findOne({ user })) throw new Error('已经存在该运营人员');
    // 创建账户
    return yield ACOperator.create({
      _id: yield ACOperator.genId(),
      user,
    });
  }

  *toggleEnable(id, enable) {
    const operator = yield ACOperatorController.findByIdAndCheckExists(id);
    if (enable) {
      const user = yield ACUserController.findByIdAndCheckExists(operator.user);
      if (!user.cert.hasVerified) throw new Error('该用户还未实名认证，无法启用运营账户！');
      yield new ACUserController(this.transaction).addRole(operator.user, ACOperatorController.role);
    } else {
      yield ACOperatorController.toggleWorking(id, false);
      yield new ACUserController(this.transaction).removeRole(operator.user, ACOperatorController.role);
    }
    return yield this.T(ACOperator).findByIdAndUpdate(id, {
      $set: {
        enable,
      },
    }, { new: true });
  }

  static *updateWorkEmail(id, workEmail) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        workEmail,
      },
    }, { new: true });
  }

  static *updateLocation(user, { lngLat, address }) {
    return yield ACOperator.findOneAndUpdate({ user }, {
      $set: {
        location: {
          lngLat,
          address,
          snappedAt: new Date(),
        },
      },
    }, { new: true });
  }

  *addRegion(id, region) {
    const operator = yield ACOperatorController.findByIdAndCheckExists(id);
    // 添加为大区管理员
    yield new OPRegionController(this.transaction).addManager(region, operator.user);
    // 添加可视大区
    return yield this.T(ACOperator).findByIdAndUpdate(id, {
      $addToSet: {
        regions: region,
      },
    }, { new: true });
  }

  *removeRegion(id, region) {
    const operator = yield ACOperatorController.findByIdAndCheckExists(id);
    // 删除大区管理
    yield ACOperatorController.toggleWorking(id, false);
    yield new OPRegionController(this.transaction).removeManager(region, operator.user);
    return yield this.T(ACOperator).findByIdAndUpdate(id, {
      $pull: {
        regions: region,
      },
    }, { new: true });
  }

  static *countTasks(operators) {
    const workingOperators = operators.filter(operator => operator.isWorking);
    const BKStockController = require('../ebike/BKStockController');
    const result = [];
    /*eslint-disable*/
    const taskResult = yield BKStockController.Model.mapReduce({
      query: {
        inspector: { $in: workingOperators.map(operator => operator.user._id) },
      },
      scope: {
        constants: {
          BK_TASK_GROUP: constants.BK_TASK_GROUP,
          BK_TASK_TYPE: constants.BK_TASK_TYPE,
          BK_STOCK_HANDLE_TASK: constants.BK_STOCK_HANDLE_TASK,
          BK_STOCK_HANDLE_TYPE: constants.BK_STOCK_HANDLE_TYPE,
        },
      },
      map: function() {
        var data = {
          拖回: 0,
          换电: 0,
        };
        var key = 0;
        var codes = this.taskList.map(task => task.code);
        if (this.taskGroup === constants.BK_TASK_GROUP.无法租赁组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.低电) > -1)
            key = constants.BK_TASK_TYPE.低电;
          else if (codes.indexOf(constants.BK_TASK_TYPE.围栏外非免单) > -1)
            key = constants.BK_TASK_TYPE.围栏外非免单;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.低压换电组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.低压预警) > -1)
            key = constants.BK_TASK_TYPE.低压预警;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.未巡检组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.四天未巡检) > -1)
            key = constants.BK_TASK_TYPE.四天未巡检;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.困难换电任务组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.困难换电) > -1)
            key = constants.BK_TASK_TYPE.困难换电;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.高压换电组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.高压预警) > -1)
            key = constants.BK_TASK_TYPE.高压预警;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.拖车组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.待拖回) > -1)
            key = constants.BK_TASK_TYPE.待拖回;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.丢失风险组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.一天内真离线) > -1)
            key = constants.BK_TASK_TYPE.一天内真离线;
          else if (codes.indexOf(constants.BK_TASK_TYPE.一天内离线扫码车) > -1)
            key = constants.BK_TASK_TYPE.一天内离线扫码车;
          else if (codes.indexOf(constants.BK_TASK_TYPE.一天内无定位扫码车) > -1)
            key = constants.BK_TASK_TYPE.一天内无定位扫码车;
          else if (codes.indexOf(constants.BK_TASK_TYPE.一天内疑似离线) > -1)
            key = constants.BK_TASK_TYPE.一天内疑似离线;
          else if (codes.indexOf(constants.BK_TASK_TYPE.一天内丢失扫码车) > -1)
            key = constants.BK_TASK_TYPE.一天内丢失扫码车;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.断电任务组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.被盗断电) > -1)
            key = constants.BK_TASK_TYPE.被盗断电;
          else if (codes.indexOf(constants.BK_TASK_TYPE.零电) > -1)
            key = constants.BK_TASK_TYPE.零电;
          else if (codes.indexOf(constants.BK_TASK_TYPE.零电断电) > -1)
            key = constants.BK_TASK_TYPE.零电断电;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.无定位组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.无定位) > -1)
            key = constants.BK_TASK_TYPE.无定位;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.司机难寻组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.司机未找到) > -1)
            key = constants.BK_TASK_TYPE.司机未找到;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.丢失高风险组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.超一天真离线) > -1)
            key = constants.BK_TASK_TYPE.超一天真离线;
          else if (codes.indexOf(constants.BK_TASK_TYPE.超一天离线扫码车) > -1)
            key = constants.BK_TASK_TYPE.超一天离线扫码车;
          else if (codes.indexOf(constants.BK_TASK_TYPE.超一天无定位扫码车) > -1)
            key = constants.BK_TASK_TYPE.超一天无定位扫码车;
          else if (codes.indexOf(constants.BK_TASK_TYPE.超一天疑似离线) > -1)
            key = constants.BK_TASK_TYPE.超一天疑似离线;
          else if (codes.indexOf(constants.BK_TASK_TYPE.超一天丢失扫码车) > -1)
            key = constants.BK_TASK_TYPE.超一天丢失扫码车;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.白班难寻组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.白班未找到) > -1)
            key = constants.BK_TASK_TYPE.白班未找到;
        } else if (this.taskGroup === constants.BK_TASK_GROUP.高手难寻组) {
          if (codes.indexOf(constants.BK_TASK_TYPE.高手未找到) > -1)
            key = constants.BK_TASK_TYPE.高手未找到;
        }
        data.换电 += (constants.BK_STOCK_HANDLE_TASK[key] && constants.BK_STOCK_HANDLE_TASK[key][constants.BK_STOCK_HANDLE_TYPE.换电]) || 0;
        data.拖回 += (constants.BK_STOCK_HANDLE_TASK[key] && constants.BK_STOCK_HANDLE_TASK[key][constants.BK_STOCK_HANDLE_TYPE.拖回]) || 0;
        emit(this.inspector, data);
      },
      reduce: function(key, values) {
        return values.reduce(function(memo, value) {
          memo.换电 += value.换电;
          memo.拖回 += value.拖回;
          return memo;
        }, {
          换电: 0,
          拖回: 0,
        });
      },
      readPreference: 'secondary',
    });
    const ret = {};
    taskResult.forEach(item => {
      ret[item._id] = item.value;
    });
    for (let operator of operators) {
      if (!operator.isWorking) {
        result.push(operator);
      } else {
        const t = operator.toJSON();
        t.taskCount = yield BKStockController.Model.count({ inspector: operator.user });
        t.dispatchTaskCount = yield BKStockController.Model.count({
          inspector: operator.user,
          'taskList.code': constants.BK_TASK_TYPE.调度待处理,
        });
        if (t.user) {
          t.back = ret[t.user._id] && ret[t.user._id].拖回 || 0;
          t.changePower = ret[t.user._id] && ret[t.user._id].换电 || 0;
        }
        result.push(t);
      }
    }
    return result;
  }

  static *findAllInWorking(regions, isAdmin) {
    const query = {
      regions: { $in: regions },
    };
    if (!isAdmin) {
      query.isWorking = true;
    }
    return yield this.countTasks(yield ACOperator.find(query).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    }));
  }

  static *findIsNotWorking({ regions, query }) {
    query = {
      'auth.tel': { $in: query.tels },
    };
    const users = yield ACUserController.Model.find(query);
    const finalQuery = {
      isWorking: false,
      regions: { $in: regions },
      user: {
        $in: users.map(user => user._id),
      },
    };
    return yield ACOperatorController.Model.find(finalQuery).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    });
  }

  static *findByIdAndPopulate(id) {
    return yield ACOperator.findById(id).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name',
    }).populate({
      path: 'regions',
      model: OPRegionController.Model,
      select: 'name city',
    }).populate({
      path: 'inspectionAreas',
      model: OPPolygonController.Model,
      select: 'name type',
    });
  }

  static *findByUserAndPopulate(user) {
    return yield ACOperator.findOne({ user }).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name profile.avator',
    }).populate({
      path: 'regions',
      model: OPRegionController.Model,
      select: 'name city',
    }).populate({
      path: 'inspectionAreas',
      model: OPPolygonController.Model,
      select: 'name type',
    });
  }

  static *findByUserAndPopulateBatteries(user) {
    const BKBatteryController = require('../ebike/BKBatteryController');
    return yield ACOperator.findOne({ user }).select('batteryBag.batteries').populate({
      path: 'batteryBag.batteries',
      model: BKBatteryController.Model,
      select: 'QRCode mark',
    });
  }

  static *toggleWorking(id, isWorking, lngLat) {
    const acOperator = yield this.findByIdAndCheckExists(id);
    if (acOperator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机) {
      const inspectionOrder = yield OPInspectionOrderController.Model.findOne({
        'user.id': acOperator.user,
        state: {
          $in: [constants.OP_INSPECTION_ORDER_STATE.派单中, constants.OP_INSPECTION_ORDER_STATE.暂停派单],
        },
      });
      if (inspectionOrder) throw new Error('有派单中或暂停派单中巡检订单，请结束订单后重试');
    }
    if (acOperator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行) {
      const riderOrder = yield OPRideOrderController.Model.findOne({
        'user.id': acOperator.user,
        state: constants.OP_RIDER_ORDER_STATE.派单中,
      });
      if (riderOrder) throw new Error('有派单中骑手订单，请结束订单后重试');
    }

    const operator = yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        isWorking,
      },
    }, { new: true });
    const BKStockController = require('../ebike/BKStockController');
    if (isWorking) {
      yield BKStockController.findNoInspectorAndDistribute(operator.regions, lngLat);
    } else {
      yield BKStockController.releaseInspectorByInspector(operator.user);
    }
    return operator;
  }

  static *forceCheckIn(id) {
    let operator = yield this.findByIdAndCheckExists(id);
    // if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机 && operator.checkStatus !== constants.AC_DRIVER_STATUS.已审核)
    //   throw new Error('该司机还未通过审核');
    if (operator.isWorking) throw new Error('该人员已经上线');
    const colors = (yield ACOperatorController.Model.find({ color: { $exists: true } }).select('color')).map(operator => operator.color);
    let randomColors = constants.AC_OPERATOR_COLOR.filter(value => {
      return !colors.includes(value);
    });
    if (randomColors.length === 0) {
      randomColors = constants.AC_OPERATOR_COLOR;
    }
    operator = yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        isWorking: true,
        enableOffDuty: false,
        lastCheckInAt: new Date(),
        color: randomColors[parseInt(Math.random() * randomColors.length)],
      },
    }, { new: true });
    const RCCheckInController = require('../record/RCCheckInController');
    yield RCCheckInController.forceCheckIn(operator);
    const BKStockController = require('../ebike/BKStockController');
    if (operator.location.lngLat) {
      yield BKStockController.findNoInspectorAndDistribute(operator.regions, operator.location.lngLat);
    }
    return operator;
  }

  static *kickOff(id) {
    let operator = yield this.findByIdAndCheckExists(id);
    if (!operator.isWorking) throw new Error('该人员已经下线');
    const { wrongCount, missCount, wrongStock } = operator;
    operator = yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        isWorking: false,
        enableOffDuty: false,
        inspectionAreas: [],
        wrongCount: 0,
        missCount: 0,
        wrongStock: [],
      },
      $unset: {
        color: 1,
      },
    }, { new: true });
    const RCCheckInController = require('../record/RCCheckInController');
    yield RCCheckInController.kickOff(operator, wrongCount, missCount, wrongStock);
    const BKStockController = require('../ebike/BKStockController');
    yield BKStockController.releaseInspectorByInspector(operator.user);
    return operator;
  }

  // 骑手自行下班
  *kickOff(id) {
    let operator = yield this.findByIdAndCheckExists(id);
    if (!operator.isWorking) throw new Error('该人员已经下线');
    const { wrongCount, missCount, wrongStock } = operator;
    operator = yield this.T(ACOperator).findByIdAndUpdate(id, {
      $set: {
        isWorking: false,
        enableOffDuty: false,
        inspectionAreas: [],
        wrongCount: 0,
        missCount: 0,
        wrongStock: [],
      },
      $unset: {
        color: 1,
      },
    }, { new: true });

    const RCCheckInController = require('../record/RCCheckInController');
    yield RCCheckInController.kickOff(operator, wrongCount, missCount, wrongStock);
    // const BKStockController = require('../ebike/BKStockController');
    // yield BKStockController.releaseInspectorByInspector(operator.user);
    return operator;
  }

  static *addInspectionArea(id, inspectionArea) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $addToSet: {
        inspectionAreas: inspectionArea,
      },
    }, { new: true });
  }

  static *removeInspectionArea(id, inspectionArea) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $pull: {
        inspectionAreas: inspectionArea,
      },
    }, { new: true });
  }

  static *findNearestInspector({ lngLat, region, taskGroup, inspectionArea }) {
    const query = {
      regions: region,
      isWorking: true,
      enable: true,
      acceptTaskGroups: taskGroup,
    };
    if (inspectionArea) query.inspectionAreas = inspectionArea;
    return yield ACOperator.findOne(query).near('location.lngLat', {
      center: lngLat,
      spherical: true,
      maxDistance: constants.INSPECTOR_SEARCH_RADIUS / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).populate({
      path: 'user',
      model: ACUserController.Model,
    });
  }

  static *findAvailableInspector(region) {
    return yield this.countTasks(yield ACOperator.find({
      regions: region,
      isWorking: true,
      enable: true,
    }).populate({
      path: 'user',
      model: ACUserController.Model,
    }));
  }

  static *findLatestPath(user) {
    const RCCheckInController = require('../record/RCCheckInController');
    const { checkIn, checkOut } = yield RCCheckInController.findLatestCheckByUser(user);
    const captures = yield RCOperatorCaptureController.findLatestPathByUser(user, {
      startTime: checkIn && checkIn.checkedAt,
      endTime: checkOut && checkOut.checkedAt,
    });
    return captures.map(point => point.lngLat).filter(p => p);
  }

  static *searchNear(center, query, searchRadius = constants.INSPECTOR_SEARCH_RADIUS_ADMIN) {
    return yield ACOperator.find(query).near('location.lngLat', {
      center,
      spherical: true,
      maxDistance: searchRadius / constants.EARTH_RADIUS,
      distanceMultiplier: constants.EARTH_RADIUS,
    }).populate({
      path: 'user',
      model: ACUserController.Model,
    });
  }

  static *addAcceptTaskGroup(id, taskGroup) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $addToSet: {
        acceptTaskGroups: taskGroup,
      },
    }, { new: true });
  }

  static *addAcceptTaskGroups(id, taskGroups) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        acceptTaskGroups: taskGroups,
      },
    }, { new: true });
  }

  static *removeAcceptTaskGroup(id, taskGroup) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $pull: {
        acceptTaskGroups: taskGroup,
      },
    });
  }

  static *removeAcceptTaskGroups(id) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        acceptTaskGroups: [],
      },
    });
  }

  static *updateBatteryBag(id, batteryBag) {
    return yield ACOperator.findByIdAndUpdate(id, {
      $set: {
        batteryBag,
      },
    });
  }

  static *findUnFinishedTasks(id) {
    const BKStockController = require('../ebike/BKStockController');
    const stocks = yield BKStockController.Model.find({
      inspector: id,
      locate: {
        $ne: constants.BK_LOCATE.调度
      }
    }).select('taskList number.custom locate');
    if (!stocks.length) {
      return { finishAllTasks: true };
    }

    // 17 个紧急任务
    const urgencyTask = [
      constants.BK_TASK_TYPE.待拖回,
      constants.BK_TASK_TYPE.超一天真离线,
      constants.BK_TASK_TYPE.超一天疑似离线,
      constants.BK_TASK_TYPE.超一天离线扫码车,
      constants.BK_TASK_TYPE.超一天无定位扫码车,
      constants.BK_TASK_TYPE.超一天丢失扫码车,
      constants.BK_TASK_TYPE.一天内真离线,
      constants.BK_TASK_TYPE.一天内疑似离线,
      constants.BK_TASK_TYPE.一天内离线扫码车,
      constants.BK_TASK_TYPE.一天内无定位扫码车,
      constants.BK_TASK_TYPE.一天内丢失扫码车,
      constants.BK_TASK_TYPE.无定位,
      constants.BK_TASK_TYPE.零电断电,
      constants.BK_TASK_TYPE.被盗断电,
      constants.BK_TASK_TYPE.低电,
      constants.BK_TASK_TYPE.围栏外非免单,
      constants.BK_TASK_TYPE.高压离线,
    ];

    const unFinishedUrgencyTask = stocks.reduce((memo, stock) => {
      urgencyTask.forEach(task => {
        const t = stock.taskList.search({ code: task });
        const s = memo.stocks.find(i => i.id === stock._id);
        if (t && ((t.code === constants.BK_TASK_TYPE.高压离线 && (Date.now() - new Date(t.issuedAt).getTime() > 2 * 60 * 60 * 1000)) || t.code !== constants.BK_TASK_TYPE.高压离线)) {
          if (!s) {
            memo.stocks.push({
              id: stock._id,
              urgentTask: [{ code: t.code, issuedAt: t.issuedAt }],
              isDeduct: true,
            });
          } else {
            s.urgentTask.push({ code: t.code, issuedAt: t.issuedAt });
          }
          memo.tasks.push(t.code);
        }
      });
      return memo;
    }, {
      tasks: [],
      stocks: [],
    });

    if (unFinishedUrgencyTask.stocks.length) {
      return {
        unFinishedUrgencyTask,
      };
    }
    if (!unFinishedUrgencyTask.length) {
      const tasks = stocks.reduce((memo, item) => {
        memo.push(...item.taskList);
        return memo;
      }, []).map(item => item.code);
      return { unFinishedNotUrgencyTask: tasks.length };
    }
  }

  *releaseInspectionAreas (id){
    yield this.T(ACOperator).findByIdAndUpdate(id, {
      $set: {
        inspectionAreas: []
      }
    })
  }

  *backToStation(inspectionOrder, id, type ) {
    const { unFinishedUrgencyTask } = yield ACOperatorController.findUnFinishedTasks(id);

    if (unFinishedUrgencyTask) {
      const amount = unFinishedUrgencyTask.stocks.reduce(memo => {
        memo += constants.OP_INSPECTION_ORDER_DEDUCT_AMOUNT;
        return memo;
      }, 0);
      yield new OPInspectionOrderController(this.transaction).recordUnInspectionStocks(inspectionOrder._id, unFinishedUrgencyTask.stocks);
      yield new OPInspectionOrderController(this.transaction).calculateUrgentTaskDeductAmount(inspectionOrder._id, amount);
    }
    // 记录回仓时间
    yield new OPInspectionOrderController(this.transaction).updateBackToStationTime(inspectionOrder._id);
    // 清空巡检区
    yield new ACOperatorController(this.transaction).releaseInspectionAreas(inspectionOrder.user.operator);
    const BKStockController = require('../ebike/BKStockController');

    const stockQuery = {};
    // 主动回仓不清除调度任务车辆，被动回仓(运营端下班时强制回仓)清除调度任务车辆
    if (type !== 'finishInspection') {
      stockQuery.locate = {
        $ne: constants.BK_LOCATE.调度
      }
    }
    const stocks = yield BKStockController.Model.find(Object.assign({
      inspector: id,
    }, stockQuery));

    if (stocks && stocks.length) {
      for (let stock of stocks) {
        yield BKStockController.releaseInspector(stock);
      }
    }
  }

  *calculateUrgentTaskBeforeFinishInspection(riderOrder, id, type ) {
    const { unFinishedUrgencyTask } = yield ACOperatorController.findUnFinishedTasks(id);

    if (unFinishedUrgencyTask) {
      const amount = unFinishedUrgencyTask.stocks.reduce(memo => {
        memo += constants.OP_INSPECTION_ORDER_DEDUCT_AMOUNT;
        return memo;
      }, 0);
      yield new OPRideOrderController(this.transaction).recordUnInspectionStocks(riderOrder._id, unFinishedUrgencyTask.stocks);
      yield new OPRideOrderController(this.transaction).calculateUrgentTaskDeductAmount(riderOrder._id, amount);
    }
    // 记录回仓时间
    // yield new OPInspectionOrderController(this.transaction).updateBackToStationTime(inspectionOrder._id);
    // 清空巡检区
    yield new ACOperatorController(this.transaction).releaseInspectionAreas(riderOrder.user.operator);
    const BKStockController = require('../ebike/BKStockController');

    const stockQuery = {};
    // 主动回仓不清除调度任务车辆，被动回仓(运营端下班时强制回仓)清除调度任务车辆
    if (type !== 'finishInspection') {
      stockQuery.locate = {
        $ne: constants.BK_LOCATE.调度
      }
    }
    const stocks = yield BKStockController.Model.find(Object.assign({
      inspector: id,
    }, stockQuery));

    if (stocks && stocks.length) {
      for (let stock of stocks) {
        yield BKStockController.releaseInspector(stock);
      }
    }
  }
}

ACOperatorController.Model = ACOperator;
module.exports = ACOperatorController;
