const ACVerify = require('../../models/account/ac_verify');
const ACUserController = require('./ACUserController');
const Controller = require('../Controller');
const utils = require('xx-utils');
const constants = require('../../settings/constants');
const captcha = require('svg-captcha');
const Error = require('errrr');

class ACVerifyController extends Controller {
  static * findByTel (tel) {
    const user = yield ACUserController.findByTel(tel);
    if (user && user.destroyed) throw new Error('该账号已注销，如有疑问请提交反馈。');
    return ACVerify.findOne({ tel });
  }

  static * findByTelAndType (tel, type) {
    const user = yield ACUserController.findByTel(tel);
    if (user && user.destroyed) throw new Error('该账号已注销，如有疑问请提交反馈。');
    return ACVerify.findOne({ tel, type });
  }

  static * create (tel, type) {
    const verify = yield this.findByTel(tel);
    let code = '0000';
    if (process.env.NODE_ENV === 'production' && tel !== '18888888888') code = utils.produce.nonceNumber(4)
    const now = new Date();
    if (!verify) {

      const data = {
        _id: yield ACVerify.genId(),
        tel,
        step: constants.AC_VERIFY_STEP.待验证短信验证码,
        code,
        resend: constants.AC_VERIFY_CODE_RESEND.after(now),
        expires: constants.AC_VERIFY_CODE_EXPIRES.after(now),
      };

      if (type === constants.AC_VERIFY_TYPE.更换手机号) {
        Object.assign(data, { type: constants.AC_VERIFY_TYPE.更换手机号 })
      }
      return yield ACVerify.create(data);
    } else if (verify.step === constants.AC_VERIFY_STEP.待验证图形验证码) {
      return yield ACVerify.findByIdAndUpdate(verify._id, {
        $set: {
          step: constants.AC_VERIFY_STEP.待验证短信验证码,
          code,
          resend: constants.AC_VERIFY_CODE_RESEND.after(now),
          expires: constants.AC_VERIFY_CODE_EXPIRES.after(now),
        },
      }, { new: true });
    } else throw new Error('获取验证码太频繁，请稍后再试！');
  }

  static * createCaptcha (tel) {
    const verify = yield this.findByTel(tel);
    const { data, text } = captcha.create({
      ignoreChars: '0oO1Iil',
      noise: 2,
      color: true,
    });
    if (!verify) {
      return yield ACVerify.create({
        _id: yield ACVerify.genId(),
        tel,
        step: constants.AC_VERIFY_STEP.待验证图形验证码,
        captcha: text,
        captchaSVG: data,
        expires: constants.AC_VERIFY_CODE_EXPIRES.after(new Date()),
      });
    } else {
      return yield ACVerify.findByIdAndUpdate(verify._id, {
        $set: {
          step: constants.AC_VERIFY_STEP.待验证图形验证码,
          captcha: text,
          captchaSVG: data,
          expires: constants.AC_VERIFY_CODE_EXPIRES.after(new Date()),
        },
      }, { new: true });
    }
  }

  static * updateResend (id) {
    return yield ACVerify.findByIdAndUpdate(id, {
      $set: {
        resend: constants.AC_VERIFY_CODE_RESEND.after(new Date()),
      },
    }, { new: true });
  }

  static * remove (id) {
    return yield ACVerify.findByIdAndRemove(id);
  }

  * remove (id) {
    return yield this.T(ACVerify).findByIdAndRemove(id);
  }
}

ACVerifyController.Model = ACVerify;

module.exports = ACVerifyController;
