const Controller = require('../Controller');
const GJRoad = require('../../models/geojson/gj_road');

class GJRoadController extends Controller {

}

GJRoadController.Model = GJRoad;
module.exports = GJRoadController;
