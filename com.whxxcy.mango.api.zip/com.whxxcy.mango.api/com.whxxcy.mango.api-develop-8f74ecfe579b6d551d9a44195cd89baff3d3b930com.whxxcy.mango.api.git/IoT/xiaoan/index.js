const EventEmitter = require('events');
const net = require('net');
const settings = require('./settings');
const constants = require('../../settings/constants');
const util = require('util');
const cmds = require('./cmds');
const actions = require('./actions');
const sounds = require('./sounds');
const coordtransform = require('coordtransform');
const amap = require('../../services/amap');
const { asyncTask, judgement } = require('xx-utils');
// const pubSubCenter = require('../pubSubCenter');
const logger = require('../../services/logger').xiaoan;
const co = require('co');

const amrUrlPrefix = 'http://mangoebike.oss-cn-shenzhen.aliyuncs.com/amrs/';

// const node = pubSubCenter.getNode();

const isLeftVersionGreater = (v1, v2) => {
  const [major1, minor1, patch1] = v1.split('.').map(t => parseInt(t));
  const [major2, minor2, patch2] = v2.split('.').map(t => parseInt(t));
  if (major1 > major2) return true;
  else if (major1 < major2) return false;
  else if (minor1 > minor2) return true;
  else if (minor1 < minor2) return false;
  else return patch1 > patch2;
};

class Xiaoan extends EventEmitter {
  constructor () {
    super();
    this._initServer();
    this._clients = {};
    this._context = {};
  }

  _initServer () {
    const server = require('net').createServer();
    server.on('listening', _ => {
      this.emit('listening', settings.port);
    });
    server.on('connection', this._onClientConnected.bind(this));
    server.on('close', _ => {
      this.emit('close');
      this.listen();
    });
    server.on('error', error => this.emit('server_error', error));
    this._server = server;
  }

  listen () {
    this._server.listen(settings.port);
  }

  _onClientDisconnected (client) {
    this.emit('disconnected', client.remoteAddress);
    if (client.imei && this._clients[client.imei] === client) {
      Reflect.deleteProperty(this._clients, client.imei);
      if (!this._clients[client.imei]) { // 没有连接上的该设备的连接，才认为掉线
        this.emit('data', {
          isOnline: false,
          dataSource: constants.BK_BOX_DATA_SOURCE.小安宝,
          deviceId: client.imei,
          time: new Date(),
          alarms: [constants.RC_ALARM_TYPE.设备下线]
        });
      }
    }
  }

  _onClientConnected (client) {
    this.emit('connected', client.remoteAddress);
    client.on('close', _ => this._onClientDisconnected(client));
    client.on('error', error => this.emit('client_error', error));
    client.sendPack = (body, pid = Xiaoan.pid, cmd = cmds.CMD_WILD) => {
      if (client.writable) {
        const bodyIsBuffer = Buffer.isBuffer(body);
        if (!bodyIsBuffer && util.isObject(body)) body = JSON.stringify(body);
        const length = body ? body.length : 0;
        const buffer = Buffer.alloc(6 + length);
        settings.head.copy(buffer, 0, 0);
        buffer.writeUInt8(cmd, 2);
        buffer.writeUInt8(pid, 3);
        buffer.writeUInt16BE(length, 4);
        if (bodyIsBuffer) {
          body.copy(buffer, 6, 0);
        } else {
          body && buffer.write(body, 6, length);
        }
        // console.log('send pack:', cmd, buffer.toString());
        client.write(buffer);
      }
    };
    client._buffer = new Buffer([]);
    client.on('data', rawData => {
      // 只要收到数据 就认为在线
      if (client.timer) clearTimeout(client.timer);
      client.timer = setTimeout(_ => {
        client.destroy();
      }, 310000);

      try {
        let buffer = Buffer.concat([client._buffer, rawData]);
        const headIndex = buffer.indexOf(settings.head);
        if (headIndex === -1) {
          client._buffer = new Buffer([]);
          return;
        }
        if (headIndex > 0) buffer = buffer.slice(headIndex);
        // node.publish('gps_raw_data', buffer.toString('hex'));
        // node.publish(`gps_raw_data_${client.deviceId}`, buffer.toString('hex'));

        while (buffer.length >= headIndex + 6) {
          const cmd = buffer.readUInt8(2);
          const pid = buffer.readUInt8(3);
          const length = buffer.readUInt16BE(4);
          const body = buffer.slice(6, 6 + length);
          if (body.length < length) return;
          buffer = buffer.slice(6 + length);
          this._parseData({ client, cmd, pid, body });
        }
        client._buffer = buffer;
      } catch (error) {
        this.emit('error', error, 'PARSE_DATA');
      }
    });

  }

  static get pid () {
    this._pid = judgement.isNotEmpty(this._pid) ? this._pid : -1;
    this._pid += 1;
    if (this._pid >= 255) this._pid = 0;
    return this._pid;
  }

  static get alarm () {
    return [
      null,
      null,
      null,
      constants.RC_ALARM_TYPE.震动警报,
      constants.RC_ALARM_TYPE.低电压警报,
      constants.RC_ALARM_TYPE.严重低电压警报,
      constants.RC_ALARM_TYPE.断电警报,
      null,
      null,
      null,
      constants.RC_ALARM_TYPE.仓锁关闭,
      constants.RC_ALARM_TYPE.电量恢复
    ];
  }

  static get dataSource () {
    return constants.BK_BOX_DATA_SOURCE.小安宝;
  }

  * _upgrade (client) {
    // 转网升级
    logger.info(client.deviceId, '开始升级');
    if (isLeftVersionGreater('3.0.15', client.appVersion)) { // 3.0.15 以下版本需要转网升级
      logger.info(client.deviceId, '转网到小安');
      yield this.changeServer(client.deviceId, { server: settings.xiaoanGate });
      logger.info(client.deviceId, '转网到小安成功');
      client.destroy();
    } else {
      // 远程升级
      logger.info(client.deviceId, '开始远程升级');
      const { success } = yield this.remoteUpgrade(client.deviceId);
      if (success) {
        logger.info(client.deviceId, '远程升级成功');
        client.destroy();
      } else {
        logger.info(client.deviceId, '远程升级失败');
        setTimeout(_ => {
          this.shutdown(client.deviceId);
        }, 60000);
      }
    }
  }

  * _upgradeSound (client, sound = []) {
    if (![sounds.欢迎语, sounds.靠近服务边界提示, sounds.驶出服务区提示, sounds.靠近禁行区提示, sounds.驶入禁行区提示, sounds.禁停区提示].every(s => sound.includes(s))) {
      logger.info(client.deviceId, '开始制定声音');
      yield (async _ => {
        if (!sound.includes(sounds.欢迎语)) await this.setSoundByIdx(client.deviceId, sounds.欢迎语);
        if (!sound.includes(sounds.靠近服务边界提示)) await this.setSoundByIdx(client.deviceId, sounds.靠近服务边界提示);
        if (!sound.includes(sounds.驶出服务区提示)) await this.setSoundByIdx(client.deviceId, sounds.驶出服务区提示);
        if (!sound.includes(sounds.靠近禁行区提示)) await this.setSoundByIdx(client.deviceId, sounds.靠近禁行区提示);
        if (!sound.includes(sounds.驶入禁行区提示)) await this.setSoundByIdx(client.deviceId, sounds.驶入禁行区提示);
        if (!sound.includes(sounds.禁停区提示)) await this.setSoundByIdx(client.deviceId, sounds.禁停区提示);
      })();
      logger.info(client.deviceId, '制定声音成功');
    }
  }

  _parseData ({ client, cmd, pid, body }) {
    // if (client.deviceId === '865067025303044') {
    // logger.error('received pack - cmd:', cmd, 'data length:', body.length, body.toString());
    // }
    const data = JSON.stringify({ cmd, pid, body });
    // node.publish(`gps_data_${client.deviceId}`, data);
    // node.publish('gps_data', body);
    return this.__parseData({ client, cmd, pid, body });
  }

  __parseData ({ client, cmd, pid, body }) {
    let time = new Date();
    const dataSource = Xiaoan.dataSource;
    const isOnline = true;
    const deviceId = client.deviceId;
    const deviceType = client.deviceType;
    const appVersion = client.appVersion;
    const alarms = [constants.RC_ALARM_TYPE.设备上线];
    const commonData = {
      success: true, time, dataSource, deviceId,
      alarms, isOnline, deviceType, appVersion, cmd, bin: body.toString('hex')
    };

    // 每次收到信息都强制转网
    this.changeServer(deviceId, {server: '120.25.135.178:4007'}).catch(_ => null);

    switch (cmd) {
      case cmds.CMD_LOGIN: { // 登陆
        const [pad, major, minor, patch, deviceType] = body;
        const imei = body.slice(5, 20).toString();
        const voltage = body[20];
        client.imei = imei;
        client.deviceId = imei;
        client.deviceType = deviceType;
        client.appVersion = `${major}.${minor}.${patch}`;
        client.sendPack(null, pid, cmd);
        if (this._clients[imei]) this._clients[imei].destroy();
        this._clients[imei] = client;
        this.emit('data', Object.assign(commonData, { deviceId: imei, deviceType, appVersion: client.appVersion, extra: { voltage } }));
        asyncTask(function * () {
          const { acc, lock } = yield this.getInfo(imei);
          if (isLeftVersionGreater(settings.latestVersion, client.appVersion)) {
            client.needUpgrade = true;
          } else if (process.env.NODE_ENV !== 'production') {
            // logger.info(imei, '转到远程');
            // yield this.changeServer(imei, { server: '120.77.89.97:84' });
            // return client.destroy();
          }
          // 判断是否是安全情况
          let isSafe = false;
          if (lock) { // 设防情况下
            if (process.env.NODE_ENV === 'production') {
              const hour = new Date().getHours();
              if (!((hour >= 6 && hour < 9) || (hour >= 17 && hour < 22))) { // 6-9 17-22 点间不进行危险操作
                isSafe = true;
              }
            } else {
              isSafe = true;
            }
          }

          // 如果没有转网到ip 则进行一次转网
          if (isSafe && client.needUpgrade) { // 需要升级？
            yield this._upgrade(client);
          } else if (!isLeftVersionGreater('3.0.20', client.appVersion)) {
            if (isSafe) {
              const { gateway } = yield this.queryGateway(imei);
              if (!(/^(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)(:[0-9]+)?$/).test(gateway)) {
                yield this._redirectToIP(client);
              }
            }
            const { sound } = yield this.querySound(imei);
            // 更新声音
            yield this._upgradeSound(client, sound);
          }
        }.bind(this)).catch(error => this.emit('error', error, 'LOGIN'));
        break;
      }
      case cmds.CMD_NEW_LOGIN: { // 登陆
        const [pad, major, minor, patch, deviceType] = body;
        const imei = body.slice(5, 20).toString();
        const imsi = body.slice(20, 35).toString();
        client.imei = imei;
        client.deviceId = imei;
        client.deviceType = deviceType;
        client.appVersion = `${major}.${minor}.${patch}`;
        const reply = Buffer.alloc(4);
        reply.writeUInt32BE(new Date().unix);
        client.sendPack(reply, pid, cmd);
        if (this._clients[imei]) this._clients[imei].destroy();
        this._clients[imei] = client;
        this.emit('data', Object.assign(commonData, {
          deviceId: imei, deviceType,
          appVersion: client.appVersion,
          sim: { imsi }
        }));
        asyncTask(function * () {
          const { acc, lock, extra } = yield this.getInfo(imei);
          // if(extra) {
          //   if (extra.voltage > 39) {
          //     yield this.setConfig(imei, { mode: 0 });
          //   } else {
          //     yield this.setConfig(imei, { mode: 1 });
          //   }
          // }

          if (isLeftVersionGreater(settings.latestVersion, client.appVersion)) {
            client.needUpgrade = true;
          } else if (process.env.NODE_ENV !== 'production') {
            // logger.info(imei, '转到远程');
            // yield this.changeServer(imei, { server: '120.77.89.97:84' });
            // return client.destroy();
          }
          // 判断是否是安全情况
          let isSafe = false;
          if (lock) { // 设防情况下
            if (process.env.NODE_ENV === 'production') {
              const hour = new Date().getHours();
              if (!((hour >= 6 && hour < 9) || (hour >= 17 && hour < 22))) { // 6-9 17-22 点间不进行危险操作
                isSafe = true;
              }
            } else {
              isSafe = true;
            }
          }

          if(isSafe) { // 转移车机到新网关
            yield this.changeServer(imei, {server: '120.25.135.178:4007'});
          }
          // 如果没有转网到ip 则进行一次转网
          if (isSafe && client.needUpgrade) { // 需要升级？
            yield this._upgrade(client);
          } else if (!isLeftVersionGreater('3.0.20', client.appVersion)) {
            if (isSafe) {
              const { gateway } = yield this.queryGateway(imei);
              if (!(/^(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)(:[0-9]+)?$/).test(gateway)) {
                yield this._redirectToIP(client);
              }
            }
            const { sound } = yield this.querySound(imei);
            // 更新声音
            yield this._upgradeSound(client, sound);
          }
        }.bind(this)).catch(error => this.emit('error', error, 'LOGIN'));
        break;
      }
      case cmds.CMD_PING: { // 心跳
        const [csq, voltage] = body;
        this.emit('data', Object.assign(commonData, {
          extra: {
            signal: Math.round(csq / 31 * 5),
            voltage
          }
        }));
        break;
      }
      case cmds.CMD_ALARM: {
        const [alarmCode] = body;
        const alarm = Xiaoan.alarm[alarmCode];
        alarms.push(alarm);
        if (alarm) {
          this.emit('data', Object.assign(commonData, { alarms }));
        }
        client.sendPack(null, pid, cmd);
        break;
      }
      case cmds.CMD_SIM_INFO: {
        const ccid = body.slice(0, 20).toString();
        const imsi = body.slice(20, 36).toString();
        this.emit('data', Object.assign(commonData, { sim: { ccid, imsi } }));
        client.sendPack(null, pid, cmd);
        break;
      }
      case cmds.CMD_STATUS: {
        const [defend, acc, wheelLock, batteryLock, powerLink] = `00000000${body[0].toString(2)}`.split('').reverse();
        asyncTask(function * () {
          const voltage = body.readUInt8(1);
          const signal = body.readUInt8(2);
          const gpsSignal = body.readDoubleLE(3);
          let location;
          if (body.length > 11) {
            const ts = body.readUInt32LE(11);
            if (ts > 0) {
              time = new Date(ts * 1e3);
              const lng = body.readFloatLE(15);
              const lat = body.readFloatLE(19);
              const speed = body[23];
              const course = body.readUInt16LE(24);
              const lngLat = coordtransform.wgs84togcj02(lng, lat);
              const address = yield amap.findAddressByLocation(lngLat);
              location = {
                lngLat,
                address,
                type: constants.BK_BOX_LOCATION_TYPE.卫星,
                speed: speed,
                direction: course,
              };
            }
          }
          this.emit('data', Object.assign(commonData, {
            acc: acc === '1',
            lock: defend === '1',
            wheelLock: wheelLock === '1',
            batteryLock: batteryLock === '0',
            powerUnlink: powerLink === '0',
            time,
            extra: {
              voltage,
              signal: Math.round(signal / 31 * 5),
              gpsSignal
            },
            location,
          }));
        }.bind(this), error => this.emit('error', error, 'STATUS'));
        break;
      }
      case cmds.CMD_NEW_STATUS: {
        const [defend, acc, wheelLock, batteryLock, powerLink, ecoMode, wheelRand] = `00000000${body[0].toString(2)}`.split('').reverse();
        asyncTask(function * () {
          const signal = body.readUInt8(1);
          const voltage = body.readUInt32BE(2);
          let location;
          if (body.length > 6) {
            const ts = body.readUInt32BE(6);
            if (ts > 0) {
              time = new Date(ts * 1e3);
              const lng = body.readFloatLE(10);
              const lat = body.readFloatLE(14);
              const speed = body[18];
              const course = body.readUInt16BE(19);
              const lngLat = coordtransform.wgs84togcj02(lng, lat);
              const address = '';
              // const address = yield amap.findAddressByLocation(lngLat);
              location = {
                lngLat,
                address,
                type: constants.BK_BOX_LOCATION_TYPE.卫星,
                speed: speed,
                direction: course,
              };
            }
          }
          this.emit('data', Object.assign(commonData, {
            acc: acc === '1',
            lock: defend === '1',
            wheelLock: wheelLock === '1',
            batteryLock: batteryLock === '0',
            powerUnlink: powerLink === '0',
            ecoMode: ecoMode === '1',
            wheelRand: wheelRand === '1',
            time,
            extra: {
              voltage: voltage / 1e3,
              signal: Math.round(signal / 31 * 5),
            },
            location,
          }));
        }.bind(this), error => this.emit('error', error, 'NEW_STATUS'));
        break;
      }
      case cmds.CMD_WILD: {
        commonData.bin = body.toString();
        const context = this._context[deviceId] && this._context[deviceId][pid];
        if (context) {
          const { timer, command, resolve } = context;
          clearTimeout(timer);
          body = JSON.parse(body);
          if (body.code === 0) {
            let emit = true;
            asyncTask(function * () {
              const pack = {};
              switch (command.c) {
                case actions.设置防御状态: {
                  if (command.param.defend === 0) {
                    pack.lock = false;
                  } else {
                    pack.lock = true;
                    pack.acc = false;
                  }
                  break;
                }
                case actions.远程启动: {
                  if (command.param.acc === 0) {
                    pack.acc = false;
                  } else {
                    pack.acc = true;
                    pack.lock = false;
                  }
                  break;
                }
                case actions.获取设备状态信息: {
                  if (!body.result) {
                    return resolve(Object.assign(commonData, { success: false }));
                  }
                  const { defend, acc, voltage, voltageMv, gsm, gpsSignal, wheelLock, seatLock, gps } = body.result;
                  if (gps) {
                    const lngLat = coordtransform.wgs84togcj02(gps.lng, gps.lat);
                    // const address = yield amap.findAddressByLocation(lngLat);
                    const address = '';
                    pack.location = {
                      lngLat,
                      address,
                      type: constants.BK_BOX_LOCATION_TYPE.卫星,
                      speed: gps.speed,
                      direction: gps.course,
                    };
                    pack.time = new Date(gps.timestamp * 1e3);
                  }
                  pack.lock = defend === 1;
                  pack.acc = acc === 1;
                  pack.extra = {
                    voltage: judgement.isNotEmpty(voltageMv) ? voltageMv / 1e3 : voltage,
                    signal: Math.round(gsm / 31 * 5)
                  };
                  pack.wheelLock = wheelLock === 1;
                  pack.batteryLock = seatLock === 0;
                  break;
                }
                case actions.开启后座锁: {
                  pack.batteryLock = false;
                  break;
                }
                case actions.查询网关: {
                  pack.gateway = body.result.server;
                  emit = false;
                  break;
                }
                case actions.查询语音: {
                  pack.sound = body.result.aud;
                  emit = false;
                  break;
                }
                case actions.查询设备内部参数:
                case actions.设置设备内部参数: {
                  emit = false;
                  break;
                }
                default:
              }
              const data = Object.assign(commonData, pack);
              if (emit) this.emit('data', data);
              resolve(data);
              Reflect.deleteProperty(this._context[deviceId], pid);
            }.bind(this), error => this.emit('error', error, 'WILD'));
          } else {
            resolve(Object.assign(commonData, { success: false }));
          }
        }
        break;
      }
      default:
    }
  }

  _initContext (deviceId) {
    if (!this._context[deviceId]) this._context[deviceId] = {};
  }

  _sendCommand (deviceId, cmd) {
    return new Promise((resolve, reject) => {
      const client = this._clients[deviceId];
      if (!client || !client.writable) return resolve({
        isOnline: false,
        success: false,
        dataSource: Xiaoan.dataSource,
        deviceId,
        time: new Date(),
        alarms: [constants.RC_ALARM_TYPE.设备下线]
      });
      this._initContext(deviceId);
      const pid = Xiaoan.pid;
      this._context[deviceId][pid] = {
        resolve,
        command: cmd,
        timer: setTimeout(_ => {
          Reflect.deleteProperty(this._context[deviceId], pid);
          resolve({ isOnline: true, success: false, dataSource: Xiaoan.dataSource, time: new Date(), deviceId });
        }, settings.timeout),
      };
      client.sendPack(cmd, pid);
    });
  }

  async lock (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.设置防御状态, param: { defend: 1 } });
  }

  async unlock (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.设置防御状态, param: { defend: 0 } });
  }

  async start (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.远程启动, param: { acc: 1 } });
  }

  async stop (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.远程启动, param: { acc: 0 } });
  }

  async welcome (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.播放语音, param: { idx: sounds.欢迎语 } });
  }

  async shutdown (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.重启 });
  }

  async getInfo (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.获取设备状态信息 });
  }

  async playSound (deviceId, { idx } = {}) {
    return await this._sendCommand(deviceId, { c: actions.播放语音, param: { idx } });
  }

  async setSound (deviceId, { idx, url } = {}) {
    return await this._sendCommand(deviceId, { c: actions.语音定制, param: { idx, url } });
  }

  async setSoundByIdx (deviceId, idx) {
    return await this.setSound(deviceId, { idx, url: `${amrUrlPrefix}${idx}.amr` });
  }

  async unlockBattery (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.开启后座锁 });
  }

  async changeServer (deviceId, { server } = {}) {
    return await this._sendCommand(deviceId, { c: actions.转网, param: { server } });
  }

  async remoteUpgrade (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.远程升级 });
  }

  async queryGateway (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.查询网关 });
  }

  kick (deviceId) {
    const client = this._clients[deviceId];
    if (client) client.destroy();
    return { success: true };
  }

  async querySound (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.查询语音 });
  }

  async setConfig (deviceId, param) {
    return await this._sendCommand(deviceId, { c: actions.设置设备内部参数, param });
  }

  async getConfig (deviceId) {
    return await this._sendCommand(deviceId, { c: actions.查询设备内部参数 });
  }
}

module.exports = Xiaoan;
