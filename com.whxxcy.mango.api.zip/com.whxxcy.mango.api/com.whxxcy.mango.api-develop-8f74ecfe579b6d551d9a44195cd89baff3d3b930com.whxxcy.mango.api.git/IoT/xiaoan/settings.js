module.exports = {
  port: 9085,
  timeout: 30000,
  head: Buffer.from([0xaa, 0x55]),
  xiaoanGate: 'mangguo.xiaoantech.com:9880',
  ipGate: process.env.NODE_ENV === 'production' ? '120.77.89.97:84' : '112.74.132.53:9085',
  latestVersion: '3.0.30'
};