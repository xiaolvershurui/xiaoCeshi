const net = require('net');

net.connect('120.77.89.97:84');