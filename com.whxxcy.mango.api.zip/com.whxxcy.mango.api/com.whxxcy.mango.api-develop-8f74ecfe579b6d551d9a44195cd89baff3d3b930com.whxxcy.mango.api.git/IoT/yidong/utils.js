const encodeFlag = buf => {
  buf = buf.reduce((memo, value) => {
    if (value === 0x7e) {
      memo.push(0x7d, 0x02);
    } else if (value === 0x7d) {
      memo.push(0x7d, 0x01);
    } else {
      memo.push(value);
    }
    return memo;
  }, []);
  buf.push(0x7e);
  buf.unshift(0x7e);
  return new Buffer(buf);
};

const decodeFlag = buf => {
  if (buf[0] !== 0x7e || buf[buf.length - 1] !== 0x7e) throw new Error('Flag Error');
  buf = buf.slice(1, -1);
  return new Buffer(buf.reduce((memo, value) => {
    if (value === 0x02 && memo[memo.length - 1] === 0x7d) {
      memo.pop();
      memo.push(0x7e);
    } else if (value === 0x01 && memo[memo.length - 1] === 0x7d) {
      memo.pop();
      memo.push(0x7d);
    } else {
      memo.push(value);
    }
    return memo;
  }, []));
};

module.exports.pack = ({ headers = [], params = [] }) => {
  params = params.join(',');
  // const checksum = check(Buffer.from(params));
  let buf = Buffer.from([headers, params, ''].join(','));
  return encodeFlag(buf);
};

module.exports.unpack = buf => {
  buf = decodeFlag(buf);
  // const expectChecksum = buf[buf.length - 1];
  const params = buf.slice(0, -1).toString().split(',');
  const headers = params.splice(0, 2);
  // const checksum = check(Buffer.from(params.join(',')));
  // console.log(expectChecksum, checksum);
  return {
    headers: [parseInt(headers[0]), parseInt(headers[1])],
    params
  };
};

module.exports.mIds = {
  终端通用应答: 0x0001,
  平台通用应答: 0x8001,
  终端心跳: 0x0002,
  终端鉴权: 0x0102,
  鉴权应答: 0x8102,
  终端控制: 0x8805,
  终端控制应答: 0x0805,
  查询终端属性: 0x8107,
  查询终端属性应答: 0x0107,
  下发终端升级包: 0x8108,
  终端升级结果通知: 0x0108,
  位置信息汇报: 0x0200,
  位置信息查询: 0x8201,
  位置信息应答: 0x0201,
  位置信息批量上传: 0x0202,
  位置跟踪控制: 0x8202,
  AGPS查询: 0x0210,
  AGPS应答: 0x8210,
  电话回拨: 0x8400,
  设置通讯录: 0x0401,
  设置圆形区域: 0x8600,
  设置通用工作配置项: 0x8609,
  蓝牙匹配: 0x8806,
  蓝牙匹配应答: 0x0806,
  查询附近RFID: 0x8807,
  查询附近RFID应答: 0x0807
};

module.exports.commands = {
  关机: 1,
  重置: 2,
  设防: 3,
  撤防: 4,
  无钥匙启动: 5,
  寻车: 6,
  静音: 7,
  遥控器配对: 8
};

module.exports.events = {
  位移警报: 1,
  断电警报: 2,
  震动警报: 3,
  超速警报: 4,
  非法开门警报: 5,
  进入围栏: 6,
  离开围栏: 7,
  SOS: 8,
  紧急减速: 9,
  侧翻: 10,
  低电报警: 11
};

module.exports.responseResult = {
  成功: 0,
  失败: 1,
  消息有误: 2,
  不支持: 3,
  报警处理确认: 4
};
