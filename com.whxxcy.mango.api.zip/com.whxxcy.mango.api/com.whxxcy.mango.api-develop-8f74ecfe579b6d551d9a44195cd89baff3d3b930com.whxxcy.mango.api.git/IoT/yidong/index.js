const EventEmitter = require('events');
const net = require('net');
const settings = require('./settings');
const utils = require('./utils');
const amap = require('../../services/amap');
const { asyncTask } = require('xx-utils');
const ublox = require('../ublox');
const constants = require('../../settings/constants');
const coordtransform = require('coordtransform');

class ZhanHua extends EventEmitter {
  constructor () {
    super();
    this._initServer();
    this._clients = {};
    this._context = {};
    this._pid = 0;
  }

  static _loginConfirm (imei, deviceType, appVersion, pId) {
    const now = new Date();
    const tz = -new Date().getTimezoneOffset() / 60;
    let { code, timezone, serverTime, redirect, host, port, upgrade, dnkURL } = {
      code: 0,
      timezone: tz > 0 ? `+${tz}` : `-${tz}`,
      serverTime: `${now.format('yyyyMMddhhmmss')}${now.getDay()}`,
      redirect: 0,
      host: '',
      port: '',
      upgrade: 0,
      dnkURL: ''
    };
    if (settings.redirect[imei]) {
      const red = settings.redirect[imei];
      host = red.host;
      port = red.port;
      redirect = 1;
    }
    if (settings.upgrade[deviceType] && settings.upgrade[deviceType].version > appVersion) {
      upgrade = 1;
      dnkURL = settings.upgrade[deviceType].dnkURL;
    }
    return utils.pack({
      headers: [utils.mIds.鉴权应答, pId],
      params: [code, timezone, serverTime, redirect, host, port, upgrade, dnkURL]
    });
  }

  static _settings ({
    workMode, heartInterval, speedyLimit, speedyDuration, alarmType, alarmPhone,
    phoneCallDevice, smsDevice, micSensitivity, g2Sleep, g2KeepOnline, reportGPS,
    reportIntervalS, reportIntervalM, remoteControlSwitch,
  }) {
    return utils.pack({
      headers: [utils.mIds.设置通用工作配置项, this.pId],
      params: [
        workMode, heartInterval, speedyLimit, speedyDuration, alarmType, alarmPhone,
        phoneCallDevice, smsDevice, micSensitivity, g2Sleep, g2KeepOnline, reportGPS,
        reportIntervalS, reportIntervalM, remoteControlSwitch,
      ]
    });
  }

  static get pId () {
    this._pid += 1;
    if (this._pid >= 255) this._pid = 0;
    return this._pid;
  }

  static _command (command) {
    return utils.pack({
      headers: [utils.mIds.终端控制, this.pId],
      params: [command]
    });
  }

  static _snap () {
    return utils.pack({
      headers: [utils.mIds.位置信息查询, this.pId],
    });
  }

  static * _parseGPS (type, detail, deviceId, lng, alt, speed, direction) {
    const result = {};
    if (type === 3) {
      const lngLat = yield amap.BSLocationByCell({ imei: deviceId, cell: detail });
      if (lngLat) {
        const address = yield amap.findAddressByLocation(lngLat);
        result.lngLat = lngLat;
        result.address = address;
      }
      result.type = constants.BK_BOX_LOCATION_TYPE.基站;
    } else if (type === 1) {
      const lngLat = coordtransform.wgs84togcj02(parseInt(lng) / 1e6, parseInt(detail) / 1e6);
      const address = yield amap.findAddressByLocation(lngLat);
      result.lngLat = lngLat;
      result.address = address;
      result.type = constants.BK_BOX_LOCATION_TYPE.卫星;
    }
    result.speed = speed;
    result.alt = parseInt(alt) / 1e6 || null;
    result.direction = parseInt(direction) / 1e6 || null;
    return result;
  }

  static _parseAlarm ({ acc, lock, event, battery, movement, silent }) {
    const alarms = [];
    if (event === 1) {
      alarms.add(constants.RC_ALARM_TYPE.位移警报);
    } else if (event === 2) {
      alarms.add(constants.RC_ALARM_TYPE.断电警报);
    } else if (event === 3) {
      alarms.add(constants.RC_ALARM_TYPE.震动警报);
    }
    if (lock && acc) alarms.add(constants.RC_ALARM_TYPE.震动警报);
    // if (battery < 50) alarms.add(constants.RC_ALARM_TYPE.断电警报);
    if (movement) alarms.add(constants.RC_ALARM_TYPE.移动警报);
    if (silent) alarms.add(constants.RC_ALARM_TYPE.静音警报);
    alarms.push(constants.RC_ALARM_TYPE.设备上线);
    return alarms;
  }

  * _processLocationInfo (client, params) {
    const { deviceId, appVersion, deviceType } = client;
    const [
      time, battery, signal, tcard, speed,
      mileageOfDay, timeOfDay, locked, silent,
      movement, acc, event, data, type, detail, lng, alt, gpsSpeed, direction
    ] = params;
    const info = {
      deviceId,
      time: new Date(parseInt(time * 1000)),
      battery: parseInt(battery),
      signal: parseInt(signal),
      tcard,
      speed: parseInt(speed) / 1e6,
      mileageOfDay: parseInt(mileageOfDay),
      timeOfDay: parseInt(parseInt(timeOfDay) / 60),
      movement: movement !== '1',
      locked: locked === '1',
      silent: silent === '1',
      acc: acc === '1',
      event: event && parseInt(event),
      data,
      type: parseInt(type),
      detail,
    };
    if (info.time.is.over('5 minutes'.after(new Date()))) info.time = new Date();
    const result = {
      isOnline: true,
      success: true,
      dataSource: constants.BK_BOX_DATA_SOURCE.一动,
      deviceId,
      deviceType,
      appVersion,
      time: info.time,
      acc: info.acc,
      lock: info.locked,
      extra: {
        mileageOfDay: info.mileageOfDay,
        timeOfDay: info.timeOfDay,
        battery: info.battery,
        signal: info.signal
      },
      location: yield ZhanHua._parseGPS(info.type, detail, deviceId, lng, alt, info.speed, direction),
      alarms: ZhanHua._parseAlarm({
        acc: info.acc,
        lock: info.locked,
        event: info.event,
        battery: info.battery,
        movement: info.movement,
        silent: info.silent
      })
    };
    this.emit('data', result);
    return result;
  }

  static _ack (mId, pId, result) {
    return utils.pack({
      headers: [utils.mIds.平台通用应答, pId],
      params: [mId, result]
    });
  }

  _onClientConnected (client) {
    this.emit('connected', client.remoteAddress);
    client.on('close', _ => {
      this.emit('disconnected', client.remoteAddress);
      if (client.imei && this._clients[client.imei] === client) {
        Reflect.deleteProperty(this._clients, client.imei);
        this.emit('client_logout', client);
        if (!this._clients[client.imei]) { // 没有连接上的该设备的连接，才认为掉线
          this.emit('data', {
            isOnline: false,
            dataSource: constants.BK_BOX_DATA_SOURCE.一动,
            deviceId: client.imei,
            time: new Date(),
            alarms: [constants.RC_ALARM_TYPE.设备下线]
          });
        }
      }
    });
    client.on('error', error => this.emit('error', error));
    client._buffer = new Buffer([]);
    const sliceData = (rawData, cb) => {
      let buffer = Buffer.concat([client._buffer, rawData]);
      if (buffer[buffer.length - 1] === 0x7e) {
        client._buffer = new Buffer([]);
        while (buffer.length > 0) {
          const endIndex = buffer.indexOf(0x7e, 1) + 1;
          cb(buffer.slice(0, endIndex));
          buffer = buffer.slice(endIndex);
        }
      } else {
        client._buffer = buffer;
      }
    };
    client.on('data', rawData => {
      try {
        sliceData(rawData, data => {
          const { headers, params } = utils.unpack(data);
          const [mId, pId] = headers;
          try {
            // 只要收到数据 就认为在线
            if (client.timer) clearTimeout(client.timer);
            client.timer = setTimeout(_ => {
              client.destroy();
            }, 310000);
            // 根据消息ID来做不同处理
            switch (mId) {
              case utils.mIds.终端鉴权: {
                const [imei, imsi, deviceType, appVersion] = params;
                client.imei = imei;
                client.imsi = imsi;
                client.deviceId = imei;
                client.deviceType = deviceType;
                client.appVersion = appVersion;
                ZhanHua._sendPack(client, ZhanHua._loginConfirm(imei, deviceType, appVersion, pId));
                if (this._clients[imei]) this._clients[imei].destroy();
                this._clients[imei] = client;
                this.emit('client_login', client);
                this.emit('data', {
                  isOnline: true,
                  dataSource: constants.BK_BOX_DATA_SOURCE.一动,
                  deviceId: client.imei,
                  time: new Date(),
                  alarms: [constants.RC_ALARM_TYPE.设备上线]
                });
                break;
              }
              case utils.mIds.终端心跳: {
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              case utils.mIds.AGPS查询: {
                const [mcc, mnc, lac, cellid] = params;
                asyncTask(function * () {
                  let { lngLat, accuracy } = yield amap.BSLocation({ imei: client.imei, bts: [mcc, mnc, lac, cellid, ''].join(',') });
                  if (lngLat) {
                    lngLat = coordtransform.gcj02towgs84(lngLat[0], lngLat[1]);
                    const agpsBuf = yield ublox(lngLat, accuracy);
                    const agpsHex = agpsBuf.toString('hex');
                    if (!agpsHex) {
                      const error = new Error('解析AGPS错误');
                      error.code = 1;
                      throw error;
                    }
                    client.write(utils.pack({
                      headers: [utils.mIds.AGPS应答, pId],
                      params: [0, (lngLat[0] * 1e6).toFixed(0), (lngLat[1] * 1e6).toFixed(0), accuracy, agpsHex]
                    }));
                  } else {
                    const error = new Error('解析基站错误');
                    error.code = 2;
                    throw error;
                  }
                }, error => {
                  this.emit('error', error);
                  client.write(utils.pack({
                    headers: [utils.mIds.AGPS应答, pId],
                    params: [error.code || 1]
                  }));
                });
                break;
              }
              case utils.mIds.位置信息汇报: {
                asyncTask(function * () {
                  yield this._processLocationInfo(client, params);
                }.bind(this), error => this.emit('error', error));
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              case utils.mIds.位置信息批量上传: {
                const [count] = params.splice(0, 1);
                asyncTask(function * () {
                  for (let i = 0; i < count; i += 1) {
                    yield this._processLocationInfo(client, params.splice(0, 19));
                  }
                }.bind(this), error => this.emit('error', error));
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              case utils.mIds.位置信息应答: {
                if (this._context[client.imei]) {
                  const snap = this._context[client.imei].snaps.shift();
                  if (snap) {
                    asyncTask(function * () {
                      snap.resolve(yield this._processLocationInfo(client, params));
                      clearTimeout(snap.timer);
                    }.bind(this), error => this.emit('error', error));
                  }
                }
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              case utils.mIds.终端通用应答: {
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              case utils.mIds.终端控制应答: {
                const [result] = params;
                if (this._context[client.imei]) {
                  const command = this._context[client.imei].commands.shift();
                  if (command) {
                    clearTimeout(command.timer);
                    if (result === '0') {
                      const pack = {
                        isOnline: true,
                        success: true,
                        dataSource: constants.BK_BOX_DATA_SOURCE.一动,
                        deviceId: client.imei,
                        time: new Date(),
                      };
                      command.resolve(pack);
                      this.emit('data', Object.assign(pack, command.successPack));
                    } else {
                      command.resolve({
                        isOnline: true,
                        success: false,
                        dataSource: constants.BK_BOX_DATA_SOURCE.一动,
                        deviceId: client.imei
                      });
                    }
                  }
                }
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
                break;
              }
              default:
                ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.成功));
            }
          } catch (error) {
            ZhanHua._sendPack(client, ZhanHua._ack(mId, pId, utils.responseResult.失败));
            throw error;
          }
        });
      } catch (error) {
        this.emit('error', error);
      }
    });
  }

  _initServer () {
    const server = require('net').createServer();
    server.on('listening', _ => {
      this.emit('listening', settings.localPort);
    });
    server.on('connection', this._onClientConnected.bind(this));
    server.on('close', _ => {
      this.emit('close');
      this.listen();
    });
    server.on('error', error => this.emit('error', error));
    this._server = server;
  }

  listen () {
    this._server.listen(settings.localPort);
  }

  _initContext (deviceId) {
    if (!this._context[deviceId]) this._context[deviceId] = {
      commands: [],
      snaps: [],
    };
  }

  _sendCommand ({ deviceId, command }, successPack) {
    return new Promise((resolve, reject) => {
      const client = this._clients[deviceId];
      if (!client || !client.writable) return resolve({
        isOnline: false,
        success: false,
        dataSource: constants.BK_BOX_DATA_SOURCE.一动,
        deviceId,
        time: new Date(),
        alarms: [constants.RC_ALARM_TYPE.设备下线]
      });
      this._initContext(deviceId);
      const context = {
        resolve,
        successPack,
        timer: setTimeout(_ => {
          this._context[deviceId].commands.splice(this._context[deviceId].commands.indexOf(context), 1);
          resolve({ isOnline: true, success: false, dataSource: constants.BK_BOX_DATA_SOURCE.一动, time: new Date(), deviceId });
        }, settings.timeout)
      };
      this._context[deviceId].commands.push(context);
      ZhanHua._sendPack(client, ZhanHua._command(command));
    });
  }

  async lock (deviceId) {
    return await this._sendCommand({ deviceId, command: utils.commands.设防 }, {
      acc: false,
      lock: true,
    });
  }

  async unlock (deviceId) {
    return await this._sendCommand({ deviceId, command: utils.commands.撤防 }, {
      acc: false,
      lock: false
    });
  }

  async start (deviceId) {
    return this._sendCommand({ deviceId, command: utils.commands.无钥匙启动 }, {
      acc: true,
      lock: false
    });
  }

  async stop (deviceId) {
    return await this.unlock(deviceId);
  }

  welcome (deviceId) {
    return this._sendCommand({ deviceId, command: utils.commands.寻车 });
  }

  shutdown (deviceId) {
    return this._sendCommand({ deviceId, command: utils.commands.关机 });
  }

  reset (deviceId) {
    return this._sendCommand({ deviceId, command: utils.commands.重置 });
  }

  getInfo (deviceId) {
    return new Promise((resolve, reject) => {
      const client = this._clients[deviceId];
      if (!client || !client.writable) return resolve({
        isOnline: false,
        success: false,
        dataSource: constants.BK_BOX_DATA_SOURCE.一动,
        deviceId,
        time: new Date(),
        alarms: [constants.RC_ALARM_TYPE.设备下线]
      });
      this._initContext(deviceId);
      const context = {
        resolve,
        timer: setTimeout(_ => {
          this._context[deviceId].snaps.splice(this._context[deviceId].snaps.indexOf(context), 1);
          reject(new Error('请求超时'));
        }, settings.timeout)
      };
      this._context[deviceId].snaps.push(context);
      ZhanHua._sendPack(client, ZhanHua._snap());
    });
  }

  static _sendPack (client, pack) {
    if (client && client.writable) {
      client.write(pack);
    }
  }

  kick (deviceId) {
    const client = this._clients[deviceId];
    if (client) client.destroy();
    return { success: true };
  }

}

module.exports = ZhanHua;