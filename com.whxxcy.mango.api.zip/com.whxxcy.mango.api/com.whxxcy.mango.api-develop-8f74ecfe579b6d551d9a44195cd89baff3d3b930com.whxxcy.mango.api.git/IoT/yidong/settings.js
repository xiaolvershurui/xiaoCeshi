const isPro = process.env.NODE_ENV === 'production';
const fs = require('fs');
const path = require('path');

module.exports = {
  localPort: 9086,
  timeout: 30000,
  redirect: {},
  upgrade: {
    // 'Q007_046_00': {
    //   version: '000.001.010',
    //   dnkURL: 'https://mangoebike.com/dnks/Q007_046(000.001.010).dnk'
    // }
  }
};

const setRedirection = (devices, host, port) => {
  devices.forEach(imei => {
    module.exports.redirect[imei] = { host, port }
  });
};

if (isPro) {
  setRedirection([
    '358482040758532',
  ], '112.74.132.53', 9086);
}