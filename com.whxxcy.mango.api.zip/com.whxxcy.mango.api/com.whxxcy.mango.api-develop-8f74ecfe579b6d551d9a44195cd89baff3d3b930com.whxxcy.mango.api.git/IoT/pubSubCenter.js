const Redis = require('ioredis');
const isPro = process.env.NODE_ENV === 'production';
const isLocal = process.env.LOCAL_REDIS === '1';

const config = (_ => {
  if (isPro) {
    return {
      host: 'r-wz9923af4b4d3914.redis.rds.aliyuncs.com',
      port: 6379,
      password: 'Xxcy987412365',
    };
  } else if (isLocal) {
    return {
      host: 'hi.mangoebike.cc',
      port: 6379,
      password: 'mango987412365'
    };
  } else {
    return {
      host: 'localhost',
      port: 6379,
      password: 'mango987412365'
    };
  }
})();

module.exports.getNode = _ => {
  return new Redis(config);
};

const Bayonet = require('bayonet');
const bayonet = new Bayonet({
  host: 'r-wz9923af4b4d3914.redis.rds.aliyuncs.com',
  port: 6379,
  sshHost: '112.74.132.53',
  sshUser: 'root',
  sshPassword: '@xxcy987412365'
});
module.exports.getNodeRemote = async _ => {
  const { host, port } = await bayonet.connect();
  return new Redis({
    host,
    port,
    // password: 'Xxcy987412365'
    password: 'mango987412365'
  });
};
