const EventEmitter = require('events');
const logger = require('../services/logger').IoT;
const loggerYidong = require('../services/logger').yidong;
const loggerXiaoan = require('../services/logger').xiaoan;
const Yidong = require('./yidong');
const Xiaoan = require('./xiaoan');
// const pubSubCenter = require('./pubSubCenter');
const uuid = require('node-uuid');
const constants = require('../settings/constants');
const { asyncTask, judgement } = require('xx-utils');
const RCStockOpController = require('../controllers/record/RCStockOpController');
const co = require('co');
const os = require('os');
const errorHandler = require('../services/errorHandler');
const isDev = process.env.NODE_ENV !== 'production';
const Error = require('errrr');
const shark = require('../services/shark').iot;

/*eslint-disable*/
class IoT extends EventEmitter {

  constructor () {
    super();
    this.on('error', (error, tag = 'UNKNOWN') => {
      errorHandler(error, `IoT:${tag}`);
    });
    this._context = {};
    this._registeredDevices = [];
    this._devices = {};
  }

  _initYidong () {
    const yidong = new Yidong();
    yidong.on('listening', port => loggerYidong.info('server started! Listening on port', port));
    yidong.on('error', error => this.emit('error', _ => _));
    yidong.on('data', data => this.emit('data', data));
    yidong.listen();
    this._yidong = yidong;
  }

  _initXiaoan () {
    const xiaoan = new Xiaoan();
    xiaoan.on('listening', port => loggerXiaoan.info('server started! Listening on port', port));
    xiaoan.on('close', _ => loggerXiaoan.warn('Server closed! Try reconnect.'));
    xiaoan.on('error', (error, tag) => this.emit('error', error, tag));
    xiaoan.on('server_error', error => _ => _);
    xiaoan.on('client_error', error => _ => _);
    xiaoan.on('data', data => this.emit('data', data));
    xiaoan.listen();
    this._xiaoan = xiaoan;
  }

  _registerDevice (deviceId, dataSource) {
    // 单节点连接数超过200，则不再接受连接
    if (this._registeredDevices.length >= 200) {
      return this._use(dataSource).kick(deviceId);
    }
    if (this._registeredDevices.includes(deviceId)) return;
    // this.subscriber.subscribe(deviceId, err => {
    //   if (err) return this.emit('error', err, 'SUBSCRIBE');
    //   logger.info(`Register device success with id ${deviceId}`);
    //   this._registeredDevices.add(deviceId);
    //   const now = new Date();
    //   this._devices[deviceId] = {
    //     ds: dataSource,
    //     time: now,
    //     dc: 0,
    //     rc: 0,
    //     snap: now,
    //     hostname: os.hostname(),
    //   };
    // });
    this._publish('device_registered', { deviceId, nId: this.nId });
  }

  _unregisterDevice (deviceId) {
    if (!this._registeredDevices.includes(deviceId)) return;
    // this.subscriber.unsubscribe(deviceId, err => {
    //   if (err) return this.emit('error', err, 'UNSUBSCRIBE');
    //   logger.info(`Unregister device success with id ${deviceId}`);
    //   this._registeredDevices.remove(deviceId);
    //   Reflect.deleteProperty(this._devices, deviceId);
    // });
    this._publish('device_unregistered', { deviceId, nId: this.nId });
  }

  init () {
    this._initNode().then(_ => {
      logger.info('Initial node success!');
      this._initYidong();
      this._initXiaoan();
      this._initailized = true;
    });
  }

  _publish (topic, data) {
    // this.publisher.publish(topic, JSON.stringify(data));
  }

  _updateDeviceStatus (data) {
    const { deviceId } = data;
    if (!this._devices[deviceId]) return;
    this._devices[deviceId].dc += 1;
    this._devices[deviceId].snap = new Date();
  }

  async _initNode () {
    // const publisher = pubSubCenter.getNode();
    // const subscriber = pubSubCenter.getNode();
    // const publisher = pubSubCenter.getNode();
    // const subscriber = pubSubCenter.getNode();
    const nId = uuid.v4();
    // 上报数据 统一上报入口
    this.on('data', data => {
      const registered = this._registeredDevices.includes(data.deviceId);
      if (data.isOnline && !registered) { // 在线未注册则进行注册
        this._registerDevice(data.deviceId, data.dataSource);
      } else if (!data.isOnline && registered) { // 不在线已注册则进行注销
        this._unregisterDevice(data.deviceId);
      }
      // 在线已注册直接上报报文
      const BKBoxController = require('../controllers/ebike/BKBoxController');
      asyncTask(function * () {
        yield BKBoxController.updateRealTimeInfoNew(Object.assign({ nodeId: nId }, data));
      }, error => this.emit('error', error, 'UPDATE_INFO'));
      this._updateDeviceStatus(data);
    });
    // 注册节点
    // 订阅其他节点的设备注册消息
    // 订阅全局询问、节点询问消息
    // subscriber.subscribe(nId, 'ask', `ask_${nId}`, err => {
    //   if (err) return this.emit('error', err, 'SUBSCRIBE');
    //   logger.info(`Register node success with id ${nId}`);
    // });
    // 监听消息
    // subscriber.on('message', (topic, message) => {
    //   message = JSON.parse(message);
    //   if (topic === nId) {
    //     this._onNodeMessage(message);
    //   } else if (topic === 'ask') {
    //     this._onQuestionGlobal(message);
    //   } else if (topic === `ask_${nId}`) {
    //     this._onQuestionNode(message);
    //   } else {
    //     this._onDeviceCommand(topic, message);
    //   }
    // });
    this.nId = nId;
    // this.subscriber = subscriber;
    // this.publisher = publisher;
  }

  _onDeviceRegistered ({ deviceId, nId }) {
    // 监听到其他节点设备注册的消息
    if (nId === this.nId) return;
    this._unregisterDevice(deviceId);
  }

  _onNodeMessage ({ qId, result = {}, error, type }) {
    // 获取到下发指令请求反馈、询问反馈
    const context = this._context[qId];
    if (!context) return;
    switch (type) {
      case 'accepted':
        clearTimeout(context.timer);
        break;
      case 'failed':
        context.reject(new Error(error));
        Reflect.deleteProperty(this._context, qId);
        break;
      case 'succeeded':
        context.resolve(result);
        Reflect.deleteProperty(this._context, qId);
        break;
      case 'pending':
        context.chunks.push(result);
        break;
      default:
    }
  }

  _onQuestionGlobal ({ qId, question, nId }) {
    // 全局询问，向上下文中推入结果即可
    const reply = { qId, type: 'pending', result: { nId: this.nId, code: constants.IOT_QUESTION_ERROR_CODE.成功 } };
    switch (question) {
      case 'ping':
      case 'registered_count': {
        reply.result.count = this._registeredDevices.length;
        reply.result.hostname = os.hostname();
        break;
      }
      default:
        reply.result.code = constants.IOT_QUESTION_ERROR_CODE.不支持的指令;
    }
    this._publish(nId, reply);
  }

  _onQuestionNode ({ qId, question, nId }) {
    // 节点询问
    this._publish(nId, { qId, type: 'accepted' });
    const reply = { qId, type: 'succeeded', result: { nId: this.nId, code: constants.IOT_QUESTION_ERROR_CODE.成功 } };
    switch (question) {
      case 'ping':
      case 'registered_count': {
        reply.result.count = this._registeredDevices.length;
        reply.result.devices = this._devices;
        reply.result.hostname = os.hostname();
        break;
      }
      default:
        reply.result.code = constants.IOT_QUESTION_ERROR_CODE.不支持的指令;
    }
    this._publish(nId, reply);
  }

  _onDeviceCommand (deviceId, { ds, command, params, nId, qId }) {
    // 获取到下发指令请求 这里不能用context来处理请求，因为可能不在一个进程中！！！
    this._publish(nId, { qId, type: 'accepted' });

    if (command === 'status') {
      return this._publish(nId, { qId, type: 'succeeded', result: this._devices[deviceId] });
    } else if (this._devices[deviceId]) {
      this._devices[deviceId].rc += 1;
    }
    if (judgement.isEmpty(ds) && this._devices[deviceId]) {
      ds = this._devices[deviceId].ds;
    }
    if (judgement.isEmpty(ds)) return this._publish(nId, { qId, type: 'failed', error: 'Cannot confirm `dataSource`' });
    if (!this._use(ds)[command]) return this._publish(nId, { qId, type: 'failed', error: `Command ${command} of dataSource ${ds} is not supported.` });
    (async _ => {
      const result = await this._use(ds)[command](deviceId, params);
      this._publish(nId, { qId, type: 'succeeded', result });
    })().catch(error => {
      this._publish(nId, { qId, type: 'failed', error: error.message });
    });
  }

  _genRequest (fn, timeoutFn, timeout) {
    const qId = uuid.v4();
    return new Promise((resolve, reject) => {
      this._context[qId] = {
        resolve,
        reject,
        chunks: [],
        timer: setTimeout(_ => {
          timeoutFn(resolve, reject, this._context[qId]);
          Reflect.deleteProperty(this._context, qId);
        }, timeout),
      };
      fn(qId);
    });
  }

  async question (ask, params) {
    // if (!this._initailized) throw new Error('GPS service has not been initialized!');
    // return await this._genRequest(qId => {
    //   this._publish('ask', { qId: qId, nId: this.nId, question: ask, params });
    // }, (resolve, reject, context) => {
    //   resolve(context.chunks);
    // }, 4000);
    return await shark.sendSync({
      c: 'ask',
      params: {
        question: ask,
        params,
      },
    });
  }

  async questionNode (nId, ask, params) {
    // if (!this._initailized) throw new Error('GPS service has not been initialized!');
    // return await this._genRequest(qId => {
    //   this._publish(`ask_${nId}`, { qId: qId, nId: this.nId, question: ask, params });
    // }, resolve => {
    //   resolve({
    //     code: constants.IOT_QUESTION_ERROR_CODE.请求超时,
    //   });
    // }, 1000);
    return await shark.sendSync({
      c: 'ask',
      params: {
        nId,
        question: ask,
        params,
      },
    });
  }

  _use (dataSource) {
    if (!this._initailized) throw new Error('GPS service has not been initialized!');
    const box = [
      null,
      null,
      this._yidong,
      this._xiaoan,
    ][dataSource];
    if (!box) throw new Error(`不再支持本数据源协议 dataSource:${dataSource}`);
    return {
      lock: box.lock && box.lock.bind(box),
      unlock: box.unlock && box.unlock.bind(box),
      start: box.start && box.start.bind(box),
      stop: box.stop && box.stop.bind(box),
      welcome: box.welcome && box.welcome.bind(box),
      getInfo: box.getInfo && box.getInfo.bind(box),
      reboot: box.shutdown && box.shutdown.bind(box),
      shutdown: box.shutdown && box.shutdown.bind(box),
      reset: box.reset && box.reset.bind(box),
      playSound: box.playSound && box.playSound.bind(box),
      unlockBattery: box.unlockBattery && box.unlockBattery.bind(box),
      changeServer: box.changeServer && box.changeServer.bind(box),
      remoteUpgrade: box.remoteUpgrade && box.remoteUpgrade.bind(box),
      setSound: box.setSound && box.setSound.bind(box),
      kick: box.kick && box.kick.bind(box),
      queryGateway: box.queryGateway && box.queryGateway.bind(box),
      setConfig: box.setConfig && box.setConfig.bind(box),
    };
  }

  async sendCommand (deviceId, dataSource, command, param) {

    try {
      return await shark.sendSync({
        c: 'sendCommand',
        params: {
          deviceId,
          command,
          params: param,
        },
      });
    } catch (err) {
      return {
        isOnline: false,
        success: false,
      };
    }

    // if (!this._initailized) throw new Error('GPS service has not been initialized!');
    // return await this._genRequest(qId => {
    //   this._publish(deviceId, { ds: dataSource, command, params: param, nId: this.nId, qId: qId });
    // }, resolve => {
    //   const result = {
    //     isOnline: false,
    //     success: false,
    //     dataSource,
    //     deviceId,
    //     time: new Date(),
    //     alarms: [constants.RC_ALARM_TYPE.设备下线],
    //     nId: this.nId
    //   };
    //   resolve(result);
    //   this.emit('data', result);
    // }, 2000);
  }

  async sendCommandWithoutDataSource (deviceId, command, param) {
    return await this.sendCommand(deviceId, null, command, param);
  }

  at (deviceId, { stock, operator, operateLocation } = {}) {
    return {
      lock: async _ => {
        const result = await this.sendCommandWithoutDataSource(deviceId, 'lock');
        if (stock && result.success) {
          await co(function * () {
            yield RCStockOpController.opLockOn({
              stock,
              operator,
              operateLocation,
            });
          });
        }
        return result;
      },
      unlock: async _ => {
        const result = await this.sendCommandWithoutDataSource(deviceId, 'unlock');
        if (stock && result.success) {
          await co(function * () {
            yield RCStockOpController.opLockOff({
              stock,
              operator,
              operateLocation,
            });
          });
        }
        return result;
      },
      start: async _ => {
        const result = await this.sendCommandWithoutDataSource(deviceId, 'start');
        if (stock && result.success) {
          await co(function * () {
            yield RCStockOpController.opAccOn({
              stock,
              operator,
              operateLocation,
            });
          });
        }
        return result;
      },
      stop: async _ => {
        const result = await this.sendCommandWithoutDataSource(deviceId, 'stop');
        if (stock && result.success) {
          await co(function * () {
            yield RCStockOpController.opAccOff({
              stock,
              operator,
              operateLocation,
            });
          });
        }
        return result;
      },
      stopAsync: _ => {
        (async _ => {
          const result = await this.sendCommandWithoutDataSource(deviceId, 'stop');
          if (stock && result.success) {
            await co(function * () {
              yield RCStockOpController.opAccOff({
                stock,
                operator,
                operateLocation,
              });
            });
          }
        })();
      },
      unlockAsync: _ => {
        (async _ => {
          const result = await this.sendCommandWithoutDataSource(deviceId, 'unlock');
          if (stock && result.success) {
            await co(function * () {
              yield RCStockOpController.opLockOff({
                stock,
                operator,
                operateLocation,
              });
            });
          }
        })();
      },
      lockAsync: _ => {
        (async _ => {
          const result = await this.sendCommandWithoutDataSource(deviceId, 'lock');
          if (stock && result.success) {
            await co(function * () {
              yield RCStockOpController.opLockOn({
                stock,
                operator,
                operateLocation,
              });
            });
          }
        })();
      },
      startAsync: _ => {
        (async _ => {
          const result = await this.sendCommandWithoutDataSource(deviceId, 'start');
          if (stock && result.success) {
            await co(function * () {
              yield RCStockOpController.opAccOn({
                stock,
                operator,
                operateLocation,
              });
            });
          }
        })();
      },
      welcome: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'welcome');
      },
      getInfo: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'getInfo');
      },
      shutdown: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'reboot');
      },
      reset: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'reset');
      },
      tryLock: async _ => {
        // 控制车辆停止设防
        let triedTimes = 0;
        const lock = async _ => {
          if (triedTimes > 3) return { success: false };
          triedTimes += 1;
          try {
            // 如果有操作人，则认为是用户手动锁车，不判断速度，直接锁车
            if (!operator) {
              // 获取实时信息
              const data = await this.sendCommandWithoutDataSource(deviceId, 'getInfo');
              const { location = {} } = data;
              if (!data.success) throw new Error('failed');
              // 车辆在行驶，不能直接锁车
              if (location.speed > 6) throw new Error('Not still');
            }
            const { isOnline, success } = await this.sendCommandWithoutDataSource(deviceId, 'lock');
            if (!success) throw new Error('failed');
            if (stock) {
              await co(function * () {
                yield RCStockOpController.opLockOn({
                  stock,
                  operator,
                  operateLocation,
                });
              });
            }
            return { success: true };
          } catch (err) {
            return lock();
          }
        };
        return await lock();
      },
      tryStart: async _ => {
        // 控制车辆启动
        let triedTimes = 0;
        const start = async _ => {
          if (triedTimes > 3) return { success: false };
          triedTimes += 1;
          try {
            const { isOnline, success } = await this.sendCommandWithoutDataSource(deviceId, 'start');
            if (!success) throw new Error('failed');
            if (stock) {
              await co(function * () {
                yield RCStockOpController.opAccOn({
                  stock,
                  operator,
                  operateLocation,
                });
              });
            }
            return { success: true };
          } catch (err) {
            return start();
          }
        };
        return await start();
      },
      playSound: async param => {
        return await this.sendCommandWithoutDataSource(deviceId, 'playSound', param);
      },
      unlockBattery: async _ => {
        const result = await this.sendCommandWithoutDataSource(deviceId, 'unlock');
        if (result.success) {
          const result = await this.sendCommandWithoutDataSource(deviceId, 'unlockBattery');
          if (stock && result.success) {
            await co(function * () {
              yield RCStockOpController.opUnlockBattery({
                stock,
                operator,
                operateLocation,
              });
            });
          }
          return result;
        } else return result;
      },
      changeServer: async param => {
        return await this.sendCommandWithoutDataSource(deviceId, 'changeServer', param);
      },
      playOutsideRegionSound: _ => {
        (async _ => {
          await this.sendCommandWithoutDataSource(deviceId, 'playSound', { idx: constants.BK_BOX_SOUND.驶出服务区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playInsideProhibitedAreaSound: _ => {
        (async _ => {
          await this.sendCommandWithoutDataSource(deviceId, 'playSound', { idx: constants.BK_BOX_SOUND.驶入禁行区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playInsideForbiddenAreaSound: _ => {
        (async _ => {
          await this.sendCommandWithoutDataSource(deviceId, 'playSound', { idx: constants.BK_BOX_SOUND.禁停区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playSoundAsync: sound => {
        (async _ => {
          await this.sendCommandWithoutDataSource(deviceId, 'playSound', { idx: sound });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      remoteUpgrade: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'remoteUpgrade');
      },
      setSound: async param => {
        return await this.sendCommandWithoutDataSource(deviceId, 'setSound', param);
      },
      kick: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'kick');
      },
      status: async _ => {
        return await this.sendCommandWithoutDataSource(deviceId, 'status');
      },
      setConfig: async config => {
        return await this.sendCommandWithoutDataSource(deviceId, 'setConfig', config);
      },
      setEcoMode: async ecoMode => {
        return await this.sendCommandWithoutDataSource(deviceId, 'setConfig', { mode: ecoMode ? 1 : 0, freq_eco: 3600 });
      },
    };
  }

  use (dataSource, {
    stock,
    operator,
    operateLocation,
  } = {}) {
    return {
      lock: function * (deviceId) {
        const { isOnline, success } = yield this.sendCommand(deviceId, dataSource, 'lock');
        if (stock && success) {
          yield RCStockOpController.opLockOn({
            stock,
            operator,
            operateLocation,
          });
        }
        return { isOnline, success };
      }.bind(this),
      unlock: function * (deviceId) {
        const { isOnline, success } = yield this.sendCommand(deviceId, dataSource, 'unlock');
        if (stock && success) {
          yield RCStockOpController.opLockOff({
            stock,
            operator,
            operateLocation,
          });
        }
        return { isOnline, success };
      }.bind(this),
      start: function * (deviceId) {
        const { isOnline, success } = yield this.sendCommand(deviceId, dataSource, 'start');
        if (stock && success) {
          yield RCStockOpController.opAccOn({
            stock,
            operator,
            operateLocation,
          });
        }
        return { isOnline, success };
      }.bind(this),
      stop: function * (deviceId) {
        const { isOnline, success } = yield this.sendCommand(deviceId, dataSource, 'stop');
        if (stock && success) {
          yield RCStockOpController.opAccOff({
            stock,
            operator,
            operateLocation,
          });
        }
        return { isOnline, success };
      }.bind(this),
      welcome: function * (deviceId) {
        return yield this.sendCommand(deviceId, dataSource, 'welcome');
      }.bind(this),
      getInfo: function * (deviceId) {
        return yield this.sendCommand(deviceId, dataSource, 'getInfo');
      }.bind(this),
      shutdown: function * (deviceId) {
        return yield this.sendCommand(deviceId, dataSource, 'shutdown');
      }.bind(this),
      reset: function * (deviceId) {
        return yield this.sendCommand(deviceId, dataSource, 'reset');
      }.bind(this),
      tryLock: async deviceId => {
        // 控制车辆停止设防
        let triedTimes = 0;
        const lock = async _ => {
          if (triedTimes > 3) return { success: false };
          triedTimes += 1;
          try {
            // 如果有操作人，则认为是用户手动锁车，不判断速度，直接锁车
            if (!operator) {
              // 获取实时信息
              const data = await this.sendCommand(deviceId, dataSource, 'getInfo');
              const { location = {} } = data;
              if (!data.success) throw new Error('failed');
              // 车辆在行驶，不能直接锁车
              if (location.speed > 6) throw new Error('Not still');
            }
            const { isOnline, success } = await this.sendCommand(deviceId, dataSource, 'lock');
            if (!success) throw new Error('failed');
            if (stock) {
              await co(function * () {
                yield RCStockOpController.opLockOn({
                  stock,
                  operator,
                  operateLocation,
                });
              });
            }
            return { success: true };
          } catch (err) {
            return lock();
          }
        };
        return await lock();
      },
      tryStart: async deviceId => {
        // 控制车辆启动
        let triedTimes = 0;
        const start = async _ => {
          if (triedTimes > 3) return { success: false };
          triedTimes += 1;
          try {
            const { isOnline, success } = await this.sendCommand(deviceId, dataSource, 'start');
            if (!success) throw new Error('failed');
            if (stock) {
              await co(function * () {
                yield RCStockOpController.opAccOn({
                  stock,
                  operator,
                  operateLocation,
                });
              });
            }
            return { success: true };
          } catch (err) {
            return start();
          }
        };
        return await start();
      },
      playSound: function * (deviceId, param) {
        return yield this.sendCommand(deviceId, dataSource, 'playSound', param);
      }.bind(this),
      unlockBattery: function * (deviceId) {
        const { isOnline, success } = yield this.sendCommand(deviceId, dataSource, 'unlock');
        if (success) {
          yield this.sendCommand(deviceId, dataSource, 'unlockBattery');
        }
        if (stock && success) {
          yield RCStockOpController.opUnlockBattery({
            stock,
            operator,
            operateLocation,
          });
        }
        return { isOnline, success };
      }.bind(this),
      changeServer: function * (deviceId, param) {
        return yield this.sendCommand(deviceId, dataSource, 'changeServer', param);
      }.bind(this),
      playOutsideRegionSound: deviceId => {
        (async _ => {
          await this.sendCommand(deviceId, dataSource, 'playSound', { idx: constants.BK_BOX_SOUND.驶出服务区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playInsideProhibitedAreaSound: deviceId => {
        (async _ => {
          await this.sendCommand(deviceId, dataSource, 'playSound', { idx: constants.BK_BOX_SOUND.驶入禁行区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playInsideForbiddenAreaSound: deviceId => {
        (async _ => {
          await this.sendCommand(deviceId, dataSource, 'playSound', { idx: constants.BK_BOX_SOUND.禁停区提示 });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      playSoundAsync: (deviceId, sound) => {
        (async _ => {
          await this.sendCommand(deviceId, dataSource, 'playSound', { idx: sound });
        })().catch(error => this.emit('error', error, 'SEND_COMMAND'));
      },
      remoteUpgrade: function * (deviceId) {
        return yield this.sendCommand(deviceId, dataSource, 'remoteUpgrade');
      }.bind(this),
      setSound: function * (deviceId, param) {
        return yield this.sendCommand(deviceId, dataSource, 'setSound', param);
      }.bind(this),
      kick: async deviceId => {
        return await this.sendCommand(deviceId, dataSource, 'kick');
      },
      queryGateway: async deviceId => {
        return await this.sendCommand(deviceId, dataSource, 'queryGateway');
      },
    };
  }

}

module.exports = new IoT();
