const axios = require('axios');

const request = axios.create();
request.interceptors.response.use(response => response.data);

module.exports = function * (lngLat, pacc) {
  const stream = yield request({
    url: 'http://online-live1.services.u-blox.com/GetOnlineData.ashx',
    responseType: 'stream',
    params: {
      token: 'xgbVijB9RkuvJ69o0ueMJg',
      lon: lngLat[0],
      lat: lngLat[1],
      pacc,
      format: 'aid',
      gnss: 'gps',
      datatype: 'pos,eph,alm,aux',
      filteronpos: ''
    }
  });
  return yield new Promise((resolve, reject) => {
    let buf = new Buffer([]);
    stream.on('data', chunk => {
      buf = Buffer.concat([buf, chunk])
    });
    stream.on('end', _ => {
      resolve(buf);
    });
  });
};