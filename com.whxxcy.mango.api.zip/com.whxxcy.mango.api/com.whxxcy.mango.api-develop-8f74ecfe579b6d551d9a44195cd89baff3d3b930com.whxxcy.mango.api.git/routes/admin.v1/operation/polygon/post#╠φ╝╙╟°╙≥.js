const OPPolygonController = require('../../../../controllers/operation/OPPolygonController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');
const validators = require('../../../../settings/validators');

module.exports = [['admin.op.polygon.post'], {
  type: 'json',
  body: {
    enable: Joi.boolean().description('启用状态').error(new Error('启用状态设置错误')),
    name: Joi.string().description('区域名称').error(new Error('请填写区域名称')),
    type: Joi.number().default(constants.OP_POLYGON_TYPE.无类型).valid(constants.OP_POLYGON_TYPE_ENUMS).description('区域类型').error(new Error('请选择区域类型')),
    neighborhood: Joi.number().default(constants.OP_POLYGON_NEIGHBORHOOD.无类型).valid(constants.OP_POLYGON_NEIGHBORHOOD_ENUMS).description('区域社区类型').error(new Error('社区类型不正确')),
    city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('所在城市').error(new Error('请填写城市名称')),
    area: Joi.string().required().description('所在行政区').error(new Error('请填写行政区')),
    address: Joi.string().empty('').description('街道地址'),
    lngLat: validators.location.required().description('经纬度').error(new Error('请选择经纬度')),
    path: Joi.array().required().description('区域围栏').error(new Error('请选择围栏')),
    directionLine: Joi.array().empty('').description('区域方向线')
  }
}, function * ({ body }) {
  const { id } = this.state.user;
  const polygon = yield OPPolygonController.create(Object.assign({
    creator: id,
  }, body));
  return yield OPPolygonController.Model.findById(polygon._id).setOptions({
    readPreference: 'primary'
  }).populate({
    path: 'creator',
    model: ACUserController.Model
  });
}];