const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const validators = require('../../../../../settings/validators');
const constants = require('../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.op.polygon.getMany'], {
  query: {
    query: Joi.object().description('搜索条件'),
    center: validators.location.required().description('搜索中心点').error(new Error('搜索中心不正确')),
    radius: Joi.number().default(constants.POLYGON_SEARCH_RADIUS_ADMIN).min(0).description('搜索半径')
  }
}, function * ({ query }) {
  const finalQuery = Object.assign({}, query.query, { isCleaned: false });
  return yield OPPolygonController.searchNear(query.center, finalQuery, query.radius);
}];
