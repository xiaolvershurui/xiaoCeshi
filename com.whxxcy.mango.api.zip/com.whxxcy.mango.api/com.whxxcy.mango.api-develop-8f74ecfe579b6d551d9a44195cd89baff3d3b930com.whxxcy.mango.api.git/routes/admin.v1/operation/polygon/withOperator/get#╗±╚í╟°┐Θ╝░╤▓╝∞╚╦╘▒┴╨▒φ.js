const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const constants = require('../../../../../settings/constants');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.op.polygon.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数').error(new Error('查询条数不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法'))
  }
}, function * ({ query }) {
  const finalQuery = Object.assign({}, { type: constants.OP_POLYGON_TYPE.巡检区 }, { isCleaned: false });
  const polygons = yield OPPolygonController.Model.find(finalQuery).skip(query.skip).limit(query.limit).sort(query.sort).select('name')
  const operators = yield ACOperatorController.Model.find({isWorking: true});
}];