const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.op.polygon.get'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  }
}, function * ({ params }) {
  return yield OPPolygonController.findByIdAndCheckExists(params.id);
}];