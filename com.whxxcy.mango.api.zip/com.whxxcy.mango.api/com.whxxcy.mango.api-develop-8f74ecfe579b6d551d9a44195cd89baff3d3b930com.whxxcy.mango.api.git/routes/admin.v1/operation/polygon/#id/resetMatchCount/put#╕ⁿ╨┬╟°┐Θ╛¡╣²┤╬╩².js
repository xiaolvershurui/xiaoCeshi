const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['区块审核'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
}, function * ({ params }) {
  return yield OPPolygonController.update(params.id, { matchCount: 0 });
}];