const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../settings/constants');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().empty('').description('启用状态').error(new Error('启用状态设置错误')),
    name: Joi.string().empty('').description('区域名称').error(new Error('请填写区域名称')),
    type: Joi.number().empty('').description('区域类型').error(new Error('请选择区域类型')),
    neighborhood: Joi.number().empty('').description('区域社区类型').error(new Error('社区类型不正确')),
    location: Joi.object({
      city: Joi.string().description('所在城市').error(new Error('请填写城市名称')),
      area: Joi.string().description('所在行政区').error(new Error('请填写行政区')),
      address: Joi.string().description('街道地址'),
      lngLat: validators.location.description('经纬度').error(new Error('请选择经纬度')),
    }).empty(''),
    path: Joi.array().empty('').description('区域围栏').error(new Error('请选择围栏')),
    directionLine: Joi.array().empty('').description('区域方向线'),
    extraPoints: Joi.array().empty('').description('额外点'),
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.update(params.id, body);
}];