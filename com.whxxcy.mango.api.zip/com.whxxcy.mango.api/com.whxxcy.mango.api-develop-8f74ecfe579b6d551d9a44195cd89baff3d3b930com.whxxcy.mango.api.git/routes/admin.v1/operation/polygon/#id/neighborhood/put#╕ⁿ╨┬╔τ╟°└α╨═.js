const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    neighborhood: Joi.number().default(constants.OP_POLYGON_NEIGHBORHOOD.无类型).valid(constants.OP_POLYGON_NEIGHBORHOOD_ENUMS).description('区域社区类型').error(new Error('请选择社区类型')),
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.updateNeighborhood(params.id, body.neighborhood);
}];