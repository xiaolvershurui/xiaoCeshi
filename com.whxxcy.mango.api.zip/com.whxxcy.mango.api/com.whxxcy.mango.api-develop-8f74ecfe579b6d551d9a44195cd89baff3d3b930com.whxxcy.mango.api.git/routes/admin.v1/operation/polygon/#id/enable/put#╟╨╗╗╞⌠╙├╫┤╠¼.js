const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('启用状态').error(new Error('启用状态设置错误'))
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.updateEnable(params.id, body.enable);
}];