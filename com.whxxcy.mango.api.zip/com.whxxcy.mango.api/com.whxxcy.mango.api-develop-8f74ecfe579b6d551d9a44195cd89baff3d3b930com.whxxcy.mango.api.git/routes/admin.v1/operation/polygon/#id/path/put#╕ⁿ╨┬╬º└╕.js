const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    path: Joi.array().required().description('区域围栏').error(new Error('请选择围栏'))
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.updatePath(params.id, body.path);
}];