const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    location: Joi.object({
      city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('所在城市').error(new Error('请填写城市名称')),
      area: Joi.string().required().description('所在行政区').error(new Error('请填写行政区')),
      address: Joi.string().empty('').description('街道地址'),
      lngLat: validators.location.required().description('经纬度').error(new Error('请选择经纬度')),
    })
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.updateLocation(params.id, body.location);
}];