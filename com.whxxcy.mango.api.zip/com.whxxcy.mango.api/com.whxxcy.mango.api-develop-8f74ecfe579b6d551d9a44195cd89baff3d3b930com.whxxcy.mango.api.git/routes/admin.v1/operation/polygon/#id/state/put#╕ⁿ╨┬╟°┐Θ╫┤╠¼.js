const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['区块审核'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    state: Joi.number().required().valid(constants.OP_POLYGON_STATE_ENUMS).description('区块状态').error(new Error('状态设置错误')),
    proposedChanges: Joi.string().empty('').description('修改建议'),
    reworkReasons: Joi.array().items(Joi.number().valid(constants.OP_POLYGON_REWORK_REASON_ENUMS)).required().description('返工原因列表')
  }
}, function * ({ params, body }) {
  const { id } = this.state.user;
  return yield OPPolygonController.updateState(params.id, body, id);
}];