const OPPolygonController = require('../../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('区域ID').error(new Error('区域ID不正确'))
  },
  type: 'json',
  body: {
    type: Joi.number().default(constants.OP_POLYGON_TYPE.无类型).valid(constants.OP_POLYGON_TYPE_ENUMS).description('区域类型').error(new Error('请选择区域类型')),
  }
}, function * ({ params, body }) {
  return yield OPPolygonController.updateType(params.id, body.type);
}];