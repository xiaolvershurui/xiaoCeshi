const OPReportedAbuseController = require('../../../../../controllers/operation/OPReportedAbuseController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.op.reported_abuse.get'], {
  params: {
    id: validators.id.required().description('举报记录编号').error(new Error('举报记录编号不合法'))
  }
}, function * ({params}) {
  const reportedAbuse = yield OPReportedAbuseController.Model.findById(params.id).populate({
    path: 'reporter',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'processor',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  });
  if(!reportedAbuse) throw new Error('不存在该举报记录');
  return reportedAbuse;
}];