const OPRegionController = require('../../../../controllers/operation/OPRegionController');

module.exports = [['admin.op.region.getMany'], {

}, function * () {
  return yield OPRegionController.Model.find().sort({ enable: -1 });
}];
