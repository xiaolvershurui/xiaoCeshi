const OPRegionController = require('../../../../controllers/operation/OPRegionController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');

module.exports = [['admin.op.region.post'], {
  type: 'json',
  body: {
    name: Joi.string().required().description('大区名称').error(new Error('请填写大区名称')),
    city: Joi.string().valid(constants.ST_CITIES_ENUMS).required().description('大区所在城市').error(new Error('请填写城市名称')),
    path: Joi.array().required().description('大区围栏').error(new Error('请选择围栏'))
  }
}, function * ({ body }) {
  return yield OPRegionController.create(body);
}];