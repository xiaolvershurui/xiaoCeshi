const OPRegionController = require('../../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');
const Core = require('../../../../../../services/shark/core');

module.exports = [['admin.op.region.put'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确')),
  },
  type: 'json',
  body: {
    path: Joi.array().required().description('大区围栏').error(new Error('请选择围栏')),
    coordinateSystem: Joi.string().default('gcj02'),
  },
}, function *({ params, body }) {
  yield Core.sendSync({
    c: 'operation/region/updatePath.a.1',
    params: {
      id: params.id,
      coordinates: body.path,
      coordinateSystem: body.coordinateSystem,
    },
  });
  return yield OPRegionController.findByIdAndCheckExists(params.id);
}];
