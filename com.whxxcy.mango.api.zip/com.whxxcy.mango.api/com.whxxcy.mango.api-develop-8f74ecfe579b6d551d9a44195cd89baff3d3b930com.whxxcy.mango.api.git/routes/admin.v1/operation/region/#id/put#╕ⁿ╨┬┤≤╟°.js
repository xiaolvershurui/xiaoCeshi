const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../settings/validators');
const constants = require('../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.op.region.put'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  },
  type: 'json',
  body: {
    city: Joi.string().valid(constants.ST_CITIES_ENUMS).description('大区城市').error(new Error('大区城市不正确')),
    enable: Joi.boolean().description('启用状态').error(new Error('启用状态设置错误')),
    name: Joi.string().description('大区名称').error(new Error('大区名称不正确')),
    path: Joi.array().description('大区围栏').error(new Error('请选择围栏'))
  }
}, function * ({ params, body }) {
  return yield OPRegionController.update(params.id, body);
}];