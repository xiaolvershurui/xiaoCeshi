const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.op.region.get'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  }
}, function * ({ params }) {
  return yield OPRegionController.findByIdAndCheckExists(params.id);
}];