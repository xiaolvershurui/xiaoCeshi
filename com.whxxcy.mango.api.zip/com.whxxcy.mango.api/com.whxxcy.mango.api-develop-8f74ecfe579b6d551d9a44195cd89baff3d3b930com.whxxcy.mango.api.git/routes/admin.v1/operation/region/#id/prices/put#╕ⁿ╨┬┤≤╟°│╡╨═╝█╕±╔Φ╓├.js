const OPRegionController = require('../../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.op.region.put'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  },
  type: 'json',
  body: {
    level: Joi.number().required().valid(constants.OP_STYLE_LEVEL_ENUMS).description('需要修改的车型等级').error(new Error('车型等级不正确')),
    price: Joi.object({
      timeUnit: validators.amount.required().description('时间单价 元/分钟').error(new Error('时间单价不合法')),
      mileageUnit: validators.amount.required().description('里程单价 元/公里').error(new Error('里程单价不合法')),
      floorCost: validators.amount.required().description('最低消费 元').error(new Error('最低消费价格不合法')),
      enableInsurance: Joi.boolean().required().description('是否开通保险服务').error(new Error('是否开通保险服务不合法')),
      insurance: validators.amount.required().description('保费 元').error(new Error('保费价格不合法')),
      parkingRate: Joi.number().min(0).max(1).required().description('停车区停车折扣率').error(new Error('停车区折扣率不合法')),
      dayCeilingCost: validators.amount.required().description('日封顶 元').error(new Error('日封顶价格不合法')),
      nightCeilingCost: validators.amount.required().description('夜封顶 元').error(new Error('夜封顶价格不合法'))
    }).unknown()
  }
}, function * ({ params, body }) {
  return yield OPRegionController.updatePrice(params.id, body);
}];