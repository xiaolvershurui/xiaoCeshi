const OPRegionController = require('../../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.op.region.put'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('启用状态').error(new Error('启用状态设置错误'))
  }
}, function * ({ params, body }) {
  return yield OPRegionController.updateEnable(params.id, body.enable);
}];