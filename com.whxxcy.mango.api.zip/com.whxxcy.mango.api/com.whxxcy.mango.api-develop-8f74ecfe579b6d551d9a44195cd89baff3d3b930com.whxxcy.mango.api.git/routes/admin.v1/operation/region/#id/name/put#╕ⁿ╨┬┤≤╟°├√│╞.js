const OPRegionController = require('../../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.op.region.put'], {
  params: {
    id: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  },
  type: 'json',
  body: {
    name: Joi.string().required().description('大区名称').error(new Error('大区名称不正确'))
  }
}, function * ({ params, body }) {
  return yield OPRegionController.updateName(params.id, body.name);
}];