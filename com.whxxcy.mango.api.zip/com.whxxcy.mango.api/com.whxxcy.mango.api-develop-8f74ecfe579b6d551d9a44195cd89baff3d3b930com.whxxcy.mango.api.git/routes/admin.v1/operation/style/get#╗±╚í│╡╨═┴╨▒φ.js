const OPStyleController = require('../../../../controllers/operation/OPStyleController');

module.exports = [['admin.op.style.getMany'], {

}, function * () {
  return yield OPStyleController.Model.find();
}];