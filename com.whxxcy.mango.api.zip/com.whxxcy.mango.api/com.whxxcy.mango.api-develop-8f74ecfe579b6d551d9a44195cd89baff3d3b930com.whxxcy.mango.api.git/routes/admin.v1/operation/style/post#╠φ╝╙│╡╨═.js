const OPStyleController = require('../../../../controllers/operation/OPStyleController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');

module.exports = [['admin.op.style.post'], {
  type: 'json',
  body: {
    name: Joi.string().required().description('车型名称').error(new Error('请填写车型名称')),
    number: Joi.string().required().description('车型编号').error(new Error('请填写车型编号')),
    thumbnail: Joi.string().required().description('车型缩略图').error(new Error('请上传缩略图')),
    level: Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS).required().description('车型等级').error(new Error('请选择车型等级')),
    maxMileage: Joi.number().required().description('最大续航里程').error(new Error('请填写最大续航里程，单位km')),
    ratedVoltage: Joi.number().required().description('电池额定电压').error(new Error('请填写电池额定电压，单位V'))
  }
}, function * ({ body }) {
  return yield OPStyleController.create(body);
}];