const OPStyleController = require('../../../../../../controllers/operation/OPStyleController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.op.style.put'], {
  params: {
    id: validators.id.required().description('车型ID').error(new Error('车型ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('启用状态').error(new Error('启用状态设置错误'))
  }
}, function * ({ params, body }) {
  return yield OPStyleController.update(params.id, body);
}];