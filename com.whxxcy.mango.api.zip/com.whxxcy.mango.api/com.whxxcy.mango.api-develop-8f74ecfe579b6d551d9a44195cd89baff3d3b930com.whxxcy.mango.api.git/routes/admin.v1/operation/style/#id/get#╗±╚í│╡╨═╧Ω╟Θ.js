const OPStyleController = require('../../../../../controllers/operation/OPStyleController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.op.style.get'], {
  params: {
    id: validators.id.required().description('车型ID').error(new Error('车型ID不正确'))
  }
}, function * ({ params }) {
  return yield OPStyleController.findByIdAndCheckExists(params.id);
}];