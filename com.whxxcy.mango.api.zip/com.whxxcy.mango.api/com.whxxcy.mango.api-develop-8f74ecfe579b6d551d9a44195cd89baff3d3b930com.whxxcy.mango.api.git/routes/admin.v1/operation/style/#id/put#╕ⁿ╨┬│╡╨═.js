const OPStyleController = require('../../../../../controllers/operation/OPStyleController');
const validators = require('../../../../../settings/validators');
const Joi = require('joi');
const constants = require('../../../../../settings/constants');

module.exports = [['admin.op.style.put'], {
  params: {
    id: validators.id.required().description('车型ID').error(new Error('车型ID不正确'))
  },
  type: 'json',
  body: {
    name: Joi.string().description('车型名称').error(new Error('请填写车型名称')),
    number: Joi.string().description('车型编号').error(new Error('请填写车型编号')),
    thumbnail: Joi.string().description('车型缩略图').error(new Error('请上传缩略图')),
    level: Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS).description('车型等级').error(new Error('请选择车型等级')),
    maxMileage: Joi.number().description('最大续航里程').error(new Error('请填写最大续航里程，单位km')),
    ratedVoltage: Joi.number().description('电池额定电压').error(new Error('请填写电池额定电压，单位V'))
  }
}, function * ({ params, body }) {
  return yield OPStyleController.update(params.id, body);
}];