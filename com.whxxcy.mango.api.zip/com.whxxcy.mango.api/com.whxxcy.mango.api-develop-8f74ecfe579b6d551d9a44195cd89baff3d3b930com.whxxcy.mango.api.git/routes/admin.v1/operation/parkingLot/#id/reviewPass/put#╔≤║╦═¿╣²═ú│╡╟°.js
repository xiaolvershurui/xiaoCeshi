const Joi = require('joi');
const validators = require('../../../../../../settings/validators');
const Core = require('../../../../../../services/core/shark');

module.exports = [['admin.op.polygon.put'], {
  params: {
    id: validators.id.required().description('停车区ID').error(new Error('停车区ID不正确')),
  },
  type: 'json',
  body: {
    reviewRemark: Joi.string().allow(null).description('通过备注'),
  },
}, function *({ params, body }) {
  return yield Core.sendSync({
    c: 'operation/parkingLot/reviewPass.a.1',
    params: {
      parkingLotId: params.id,
      userId: this.state.user.id,
      reviewRemark: body.reviewRemark,
    },
  });
}];
