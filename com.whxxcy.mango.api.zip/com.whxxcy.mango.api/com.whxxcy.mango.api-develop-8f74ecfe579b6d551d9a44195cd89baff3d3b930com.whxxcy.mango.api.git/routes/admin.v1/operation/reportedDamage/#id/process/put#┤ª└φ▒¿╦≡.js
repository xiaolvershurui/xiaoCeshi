const OPReportedDamageController = require('../../../../../../controllers/operation/OPReportedDamageController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.op.reported_damage.put'], {
  type: 'json',
  params: {
    id: validators.id.required().description('报损记录编号').error(new Error('报损记录编号不合法'))
  },
  body: {
    result: Joi.number().required().description('处理结果').error(new Error('处理结果不合法')),
    remark: Joi.string().required().description('处理结果备注').error(new Error('处理结果备注不合法'))
  }
}, function * ({params, body}) {
  const {id} = this.state.user;
  return yield this.transaction.try(function * () {
    return yield new OPReportedDamageController(this).process(params.id, Object.assign({}, {processor: id}, body));
  })
}];