const OPReportedDamageController = require('../../../../../controllers/operation/OPReportedDamageController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.op.reported_damage.get'], {
  params: {
    id: validators.id.required().description('报损记录编号').error(new Error('报损记录编号不合法'))
  }
}, function * ({params}) {
  const reportedDamage = yield OPReportedDamageController.Model.findById(params.id).populate({
    path: 'reporter',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'processor',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  });
  if (!reportedDamage) throw new Error('不存在该报损记录');
  return reportedDamage;
}];