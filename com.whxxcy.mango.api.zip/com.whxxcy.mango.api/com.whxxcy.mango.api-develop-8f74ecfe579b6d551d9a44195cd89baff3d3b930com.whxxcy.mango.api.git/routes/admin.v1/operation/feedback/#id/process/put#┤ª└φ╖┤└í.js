const OPFeedbackController = require('../../../../../../controllers/operation/OPFeedbackController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.op.feedback.put'], {
  type: 'json',
  params: {
    id: validators.id.required().description('反馈记录编号').error(new Error('反馈记录编号不合法'))
  },
  body: {
    result: Joi.string().required().description('内部备注信息').error(new Error('备注信息不合法')),
    reply: Joi.string().required().description('回复用户内容').error(new Error('回复内容不合法'))
  }
}, function * ({params, body}) {
  const {id} = this.state.user;
  return yield OPFeedbackController.process(params.id, Object.assign({}, {processor: id}, body));
}];