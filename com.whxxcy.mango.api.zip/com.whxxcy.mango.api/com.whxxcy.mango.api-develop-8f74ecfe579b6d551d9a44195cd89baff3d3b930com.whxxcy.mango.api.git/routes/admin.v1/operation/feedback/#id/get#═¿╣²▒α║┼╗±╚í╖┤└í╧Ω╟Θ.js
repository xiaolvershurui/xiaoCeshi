const OPFeedbackController = require('../../../../../controllers/operation/OPFeedbackController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.op.feedback.get'], {
  params: {
    id: validators.id.required().description('反馈记录编号').error(new Error('反馈记录编号不合法'))
  }
}, function * ({params}) {
  const feedback = yield OPFeedbackController.Model.findById(params.id).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'processor',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  });
  if(!feedback) throw new Error('不存在该反馈记录');
  return feedback;
}];