const OPCreditAppealController = require('../../../../../../controllers/operation/OPCreditAppealController');
const ACUserController = require('../../../../../../controllers/account/ACUserController');
const ACCreditController = require('../../../../../../controllers/account/ACCreditController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');
const Joi = require('joi');

module.exports = [['admin.op.credit_appeal.put'], {
  type: 'json',
  params: {
    id: validators.id.required().description('申述记录编号').error(new Error('申述记录编号不合法'))
  },
  body: {
    passRemark: Joi.string().required().description('通过备注').error(new Error('通过备注不合法'))
  }
}, function * ({params, body}) {
  const {id} = this.state.user;
  return yield this.transaction.try(function * () {
    return yield new OPCreditAppealController(this).pass(params.id, Object.assign({}, {processor: id}, body));
  })
}];