const OPCreditAppealController = require('../../../../../controllers/operation/OPCreditAppealController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const ACCreditController = require('../../../../../controllers/account/ACCreditController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.op.credit_appeal.get'], {
  params: {
    id: validators.id.required().description('申述记录编号').error(new Error('申述记录编号不合法'))
  }
}, function * ({params}) {
  const creditAppeal = yield OPCreditAppealController.Model.findById(params.id).populate({
    path: 'processor',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'credit',
    model: ACCreditController.Model,
    select: 'name type point'
  });
  if(!creditAppeal) throw new Error('不存在该申诉记录');
  return creditAppeal;
}];