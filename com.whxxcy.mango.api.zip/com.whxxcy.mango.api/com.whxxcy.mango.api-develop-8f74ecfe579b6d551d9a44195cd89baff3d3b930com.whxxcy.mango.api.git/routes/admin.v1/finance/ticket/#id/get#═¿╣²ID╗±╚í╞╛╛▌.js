const FNTicketController = require('../../../../../controllers/finance/FNTicketController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.fn.ticket.get'], {
  params: {
    id: validators.id.required().description('支付凭据id').error(new Error('id错误'))
  }
}, function * ({ params }) {
  return FNTicketController.Model.findById(params.id).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'refund.processor',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  });
}];