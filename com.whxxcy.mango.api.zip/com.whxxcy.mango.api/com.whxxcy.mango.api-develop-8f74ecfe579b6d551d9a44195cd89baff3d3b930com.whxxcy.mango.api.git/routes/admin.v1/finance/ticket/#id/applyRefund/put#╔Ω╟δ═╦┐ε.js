const FNTicketController = require('../../../../../../controllers/finance/FNTicketController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const ACWalletController = require('../../../../../../controllers/account/ACWalletController');

module.exports = [['admin.fn.ticket.put'], {
  params: {
    id: validators.id.required().description('支付凭据id').error(new Error('id错误'))
  }
}, function * ({ params }) {
  const ticket = yield FNTicketController.findByIdAndCheckExists(params.id);
  if (ticket.type === constants.FN_TICKET_TYPE.支付押金) {
    yield this.transaction.try(function * () {
      yield new ACWalletController(this).applyRefund(ticket.user);
    });
  } else {
    yield this.transaction.try(function * () {
      return yield new FNTicketController(this).applyRefund(params.id, {
        willProcessAt: constants.FN_TICKET_REFUND_DELAY.after(new Date())
      });
    });
  }
  return FNTicketController.findByIdAndPopulate(params.id);
}];