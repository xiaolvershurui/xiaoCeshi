const FNTicketController = require('../../../../../../controllers/finance/FNTicketController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.fn.ticket.put'], {
  params: {
    id: validators.id.required().description('支付凭据id').error(new Error('id错误'))
  }
}, function * ({ params }) {
  const { id } = this.state.user;
  yield this.transaction.try(function * () {
    return yield new FNTicketController(this).confirmRefund(params.id, id);
  });
  return FNTicketController.findByIdAndPopulate(params.id);
}];