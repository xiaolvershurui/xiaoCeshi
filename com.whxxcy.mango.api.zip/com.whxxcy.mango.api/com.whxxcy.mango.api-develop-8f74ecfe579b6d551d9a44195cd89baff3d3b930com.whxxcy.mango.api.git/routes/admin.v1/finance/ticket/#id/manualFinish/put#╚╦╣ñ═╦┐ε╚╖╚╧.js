const FNTicketController = require('../../../../../../controllers/finance/FNTicketController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.fn.ticket.put'], {
  params: {
    id: validators.id.required().description('支付凭据id').error(new Error('id错误'))
  },
  type: 'json',
  body: {
    tradeNo: Joi.string().required().description('转账流水号').error(new Error('请输入转账流水号'))
  }
}, function * ({ params, body }) {
  const { id } = this.state.user;
  yield this.transaction.try(function * () {
    return yield new FNTicketController(this).finishRefund(params.id, {
      processor: id,
      tradeNo: body.tradeNo
    });
  });
  return FNTicketController.findByIdAndPopulate(params.id);
}];