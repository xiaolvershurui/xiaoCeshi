const FNBalanceBillController = require('../../../../controllers/finance/FNBalanceBillController');
const FNTicketController = require('../../../../controllers/finance/FNTicketController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const constants = require('../../../../settings/constants');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.fn.balance_bill.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数').error(new Error('查询条数不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法'))
  }
}, function * ({ query }) {
  return {
    items: yield FNBalanceBillController.Model.find(query.query).skip(query.skip).limit(query.limit).sort(query.sort).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'auth.tel cert.name'
    }).populate({
      path: 'ticket',
      model: FNTicketController.Model
    }),
    count: yield FNBalanceBillController.Model.count(query.query)
  };
}];