const FNBalanceBillController = require('../../../../../controllers/finance/FNBalanceBillController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const ODOrderController = require('../../../../../controllers/order/ODOrderController');
const Joi = require('joi');

module.exports = [['admin.fn.balance_bill.get'], {
  params: {
    id: Joi.string().required().description('车损号').error(new Error('车损号不正确')),
  }
}, function * ({ params }) {
  return yield FNBalanceBillController.Model.findById(params.id).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  });
}];