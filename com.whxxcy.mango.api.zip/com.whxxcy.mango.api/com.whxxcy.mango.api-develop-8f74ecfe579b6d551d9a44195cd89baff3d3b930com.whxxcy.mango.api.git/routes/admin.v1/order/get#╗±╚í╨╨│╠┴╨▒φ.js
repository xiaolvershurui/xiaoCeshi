const ODOrderController = require('../../../controllers/order/ODOrderController');
const RCStockPointController = require('../../../controllers/record/RCStockPointController');
const OPRegionController = require('../../../controllers/operation/OPRegionController');
const OPStyleController = require('../../../controllers/operation/OPStyleController');
const BKStockController = require('../../../controllers/ebike/BKStockController');
const ACUserController = require('../../../controllers/account/ACUserController');
const constants = require('../../../settings/constants');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.od.order.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数').error(new Error('查询条数不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法')),
  },
}, function *({ query }) {
  const maxCount = 5000 * constants.PAGE_SIZE;
  query.skip = Math.min(query.skip, maxCount);
  const items = yield ODOrderController.Model.find(query.query).skip(query.skip).limit(query.limit).sort(query.sort).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name',
  }).populate({
    path: 'region',
    model: OPRegionController.Model,
    select: 'name',
  }).populate({
    path: 'style',
    model: OPStyleController.Model,
    select: 'name',
  }).populate({
    path: 'stock',
    model: BKStockController.Model,
    select: 'number speed outsideRegion insideForbiddenArea insideProhibitedArea noGpsLocation',
  });
  const pathsByOrder = {};
  for (let item of items) {
    if (item.route.path) {
      pathsByOrder[item._id] = item.route.path.coordinates;
    } else {
      let points = [];
      // 持续时间三小时内才查点数据
      if (new Date(item.lease.endTime).getTime() - new Date(item.lease.startTime).getTime() < 3 * 60 * 60 * 1000) {
        points = yield RCStockPointController.findPath(item.box, item.lease);
      }
      pathsByOrder[item._id] = points.map(point => point.gps && point.gps.lngLat);
    }
  }
  return {
    items,
    pathsByOrder,
    count: Math.min(yield ODOrderController.Model.count(query.query), maxCount),
  };
}];
