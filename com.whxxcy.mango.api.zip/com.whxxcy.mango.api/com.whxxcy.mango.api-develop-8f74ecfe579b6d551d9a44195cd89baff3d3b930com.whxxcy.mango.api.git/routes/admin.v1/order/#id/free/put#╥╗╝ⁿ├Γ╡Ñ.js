const ODOrderController = require('../../../../../controllers/order/ODOrderController');
const OPStyleController = require('../../../../../controllers/operation/OPStyleController');
const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');
const constants = require('../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.od.order.put'], {
  type: 'json',
  params: {
    id: validators.id.required().description('订单号').error(new Error('订单号错误'))
  },
  body: {
    reason: Joi.string().required().description('免单理由').error(new Error('免单理由不合法')),
    amount: Joi.number().required().description('免单金额').error(new Error('免单金额不合法')),
  }
}, function * ({ params, body }) {
  const { id } = this.state.user;
  yield this.transaction.try(function * () {
    yield new ODOrderController(this).partFree(params.id, { reason: body.reason, processor: id, amount: body.amount });
  });
  return yield ODOrderController.Model.findById(params.id).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'region',
    model: OPRegionController.Model,
    select: 'name'
  }).populate({
    path: 'style',
    model: OPStyleController.Model,
    select: 'name'
  }).populate({
    path: 'stock',
    model: BKStockController.Model,
    select: 'number'
  });
}];