const ODOrderController = require('../../../../../controllers/order/ODOrderController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');
const Joi = require('joi');
const constants = require('../../../../../settings/constants');
const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const OPStyleController = require('../../../../../controllers/operation/OPStyleController');
const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const transaction = require('../../../../../services/transaction');
const RCBackgroundFinishOrderOp = require('../../../../../models/record/rc_background_finish_order_op');

module.exports = [['admin.od.order.put'], {
  type: 'json',
  body: {
    reason: Joi.number().description('原因')
  },
  params: {
    id: validators.id.required().description('订单号').error(new Error('订单号错误'))
  }
}, function *({params, body}) {
  const {id} = this.state.user;
  const {lngLat, address} = this.state.deviceInfo;
  (async () => {
    if (!body) {
      body = {};
    }
    await RCBackgroundFinishOrderOp.create({
      orderId: params.id,
      date: new Date((new Date()).setHours(0, 0, 0, 0)),
      operator: id,
      reason: body.reason || 0,
    });
  })();
  yield this.transaction.try(function *() {
    return yield new ODOrderController(this).newFinish(params.id, constants.OD_ORDER_STATE.后台结束订单, {
      operator: id,
      operateLocation: {lngLat, address}
    });
  });
  return yield ODOrderController.Model.findById(params.id).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).populate({
    path: 'region',
    model: OPRegionController.Model,
    select: 'name'
  }).populate({
    path: 'style',
    model: OPStyleController.Model,
    select: 'name'
  }).populate({
    path: 'stock',
    model: BKStockController.Model,
    select: 'number'
  });
}];
