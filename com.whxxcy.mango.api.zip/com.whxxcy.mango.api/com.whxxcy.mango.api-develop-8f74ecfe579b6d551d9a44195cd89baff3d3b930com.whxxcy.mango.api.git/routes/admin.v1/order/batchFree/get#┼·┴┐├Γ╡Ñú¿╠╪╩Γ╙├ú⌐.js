const ODOrderController = require('../../../../controllers/order/ODOrderController');
const OPStyleController = require('../../../../controllers/operation/OPStyleController');
const OPRegionController = require('../../../../controllers/operation/OPRegionController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const BKStockController = require('../../../../controllers/ebike/BKStockController');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');
const transaction = require('../../../../services/transaction');

const orders = [];

module.exports = [['admin'], {}, function * () {

  const errors = [];

  for (let order of orders) {
    try {
      yield transaction().try(function * () {
        yield new ODOrderController(this).freeForDispatchCost(order, { reason: '停车区定位错误', processor: "1" });
      });
    } catch (error) {
      errors.push({
        id: order,
        error: error.message,
      });
    }
  }

  return errors;

}];
