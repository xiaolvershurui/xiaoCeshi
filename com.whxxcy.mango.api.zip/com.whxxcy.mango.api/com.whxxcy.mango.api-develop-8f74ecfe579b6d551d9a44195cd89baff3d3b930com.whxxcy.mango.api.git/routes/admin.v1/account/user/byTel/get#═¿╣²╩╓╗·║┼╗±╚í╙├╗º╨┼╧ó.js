const ACUserController = require('../../../../../controllers/account/ACUserController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.ac.user.getMany'], {
  query: {
    tel: validators.tel.required().description('手机号').error(new Error('请输入合法的手机号'))
  }
}, function * ({ query }) {
  const user = yield ACUserController.findByTel(query.tel);
  if(!user) throw new Error('账户不存在');
  return user;
}];