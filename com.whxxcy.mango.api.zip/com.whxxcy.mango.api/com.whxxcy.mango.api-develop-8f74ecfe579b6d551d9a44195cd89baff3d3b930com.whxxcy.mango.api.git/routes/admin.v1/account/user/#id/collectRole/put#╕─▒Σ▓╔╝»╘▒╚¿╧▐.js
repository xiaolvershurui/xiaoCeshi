const ACUserController = require('../../../../../../controllers/account/ACUserController');
const Joi = require('joi');
const validator = require('../../../../../../settings/validators');

module.exports = [['admin'], {
  type: 'json',
  params: {
    id: validator.id.required().description('用户编号').error(new Error('用户编号不合法'))
  },
  body: {
    unset: Joi.boolean().required().description('添加或删除').error(new Error('添加参数不合法'))
  }
}, function * ({params, body}) {
  return yield this.transaction.try(function * () {
    return yield new ACUserController(this).setDataCollectorRole(params.id, body.unset);
  })
}];