const ACUserController = require('../../../../../controllers/account/ACUserController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.user.get'], {
  params: {
    id: validators.id.required().description('账户ID').error(new Error('账户ID不正确'))
  }
}, function * ({ params }) {
  return yield ACUserController.findByIdAndCheckExists(params.id);
}];