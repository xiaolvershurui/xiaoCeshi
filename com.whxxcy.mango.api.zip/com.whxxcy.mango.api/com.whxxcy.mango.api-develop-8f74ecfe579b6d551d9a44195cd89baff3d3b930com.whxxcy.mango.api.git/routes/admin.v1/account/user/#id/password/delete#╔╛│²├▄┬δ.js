const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.ac.user.put'], {
  params: {
    id: validators.id.required().description('主账号ID').error(new Error('主账号ID错误')),
  },
}, function * ({ params }) {
  return yield ACUserController.unsetPassword(params.id);
}];