const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin'], {
  params: {
    id: validators.id.required().description('主账号ID').error(new Error('主账号ID错误')),
  },
  type: 'json',
  body: {
    tel: validators.tel.required().description('子账号').error(new Error('子账号不正确'))
  }
}, function * ({ params, body }) {
  return yield this.transaction.try(function * () {
    return yield new ACUserController(this).createSubUser(params.id, body.tel);
  });
}];