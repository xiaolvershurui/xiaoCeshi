const ACUserController = require('../../../../../../controllers/account/ACUserController');
const Joi = require('joi');
const validator = require('../../../../../../settings/validators');

module.exports = [['admin'], {
  params: {
    id: validator.id.required().description('用户编号').error(new Error('用户编号不合法'))
  },
  query: {
    permission: Joi.string().required().description('权限').error(new Error('请填写权限'))
  }
}, function * ({ query, params }) {
  return yield ACUserController.removePermission(params.id, query.permission);
}];