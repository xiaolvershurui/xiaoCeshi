const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.ac.user.put'], {
  params: {
    id: validators.id.required().description('账户编号').error(new Error('账户编号错误')),
  },
}, function * ({ params }) {
  return yield ACUserController.resetRealNameAuth(params.id);
}];