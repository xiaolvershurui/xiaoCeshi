const ACUserController = require('../../../../../../controllers/account/ACUserController');
const Joi = require('joi');
const validator = require('../../../../../../settings/validators');

module.exports = [['admin'], {
  type: 'json',
  params: {
    id: validator.id.required().description('用户编号').error(new Error('用户编号不合法'))
  },
  body: {
    permission: Joi.string().required().description('权限').error(new Error('请填写权限'))
  }
}, function * ({ body, params }) {
  return yield ACUserController.addPermission(params.id, body.permission);
}];