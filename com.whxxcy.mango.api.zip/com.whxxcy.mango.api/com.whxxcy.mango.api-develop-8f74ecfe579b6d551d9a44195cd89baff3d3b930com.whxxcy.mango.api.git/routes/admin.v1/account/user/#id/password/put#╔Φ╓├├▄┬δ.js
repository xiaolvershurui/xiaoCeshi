const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.ac.user.put'], {
  params: {
    id: validators.id.required().description('主账号ID').error(new Error('主账号ID错误')),
  },
  type: 'json',
  body: {
    password: Joi.string().min(6).max(64).required().description('未加密的密码').error(new Error('密码为长度6-64位的字符串'))
  }
}, function * ({ params, body }) {
  return yield ACUserController.setPassword(params.id, body.password);
}];