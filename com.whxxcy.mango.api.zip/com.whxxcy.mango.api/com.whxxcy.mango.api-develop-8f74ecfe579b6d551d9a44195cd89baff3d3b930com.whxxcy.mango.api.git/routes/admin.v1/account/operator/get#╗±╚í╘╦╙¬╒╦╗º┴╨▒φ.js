const ACOperatorController = require('../../../../controllers/account/ACOperatorController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const BKStockController = require('../../../../controllers/ebike/BKStockController');
const OPPolygonController = require('../../../../controllers/operation/OPPolygonController');
const OPRegionController = require('../../../../controllers/operation/OPRegionController');
const STInspectionPriceController = require('../../../../controllers/setting/STInspectionPriceController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');

module.exports = [['admin.ac.operator.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    limit: Joi.number().min(0).default(constants.PAGE_SIZE).description('查询条数').error(new Error('查询条数不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法')),
  },
}, function *({ query }) {
  if (query.query.region) Reflect.deleteProperty(query.query, 'region');
  const finalQuery = {
    $and: [],
    enable: true,
  };
  const q = Object.assign({}, query.query);
  if (q.name) {
    const users = yield ACUserController.Model.find({ 'cert.name': q.name });
    Reflect.deleteProperty(q, 'name');
    finalQuery.$and.push({
      user: { $in: users.map(user => user._id) },
    });
  }
  finalQuery.$and.push(q);
  const taskCount = {};
  (yield BKStockController.Model.aggregate().read('secondary')
    .match({ inspector: { $exists: true } })
    .project({ inspector: '$inspector' })
    .group({
      _id: '$inspector',
      count: { $sum: 1 },
    })).forEach(item => {
    taskCount[item._id] = item.count;
  });
  return {
    items: yield ACOperatorController.countTasks(yield ACOperatorController.Model.find(finalQuery).skip(query.skip).limit(query.limit).sort(query.sort).populate({
      path: 'user',
      model: ACUserController.Model,
      select: 'cert.name auth.tel',
    }).populate({
      path: 'regions',
      model: OPRegionController.Model,
      select: 'name city',
    }).populate({
      path: 'inspectionAreas',
      model: OPPolygonController.Model,
      select: 'name type',
    }).populate({
      path: 'inspectionPrice',
      model: STInspectionPriceController.Model,
      select: 'name',
    })),
    count: yield ACOperatorController.Model.count(finalQuery),
    taskCount,
  };
}];
