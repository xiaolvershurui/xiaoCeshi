const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.operator.getMany'], {
  query: {
    user: validators.id.required().description('用户ID').error(new Error('用户ID不正确'))
  }
}, function * ({ query }) {
  return yield ACOperatorController.findByUserAndPopulate(query.user);
}];