const ACOperatorController = require('../../../../controllers/account/ACOperatorController');
const validators = require('../../../../settings/validators');

module.exports = [['admin.ac.operator.post'], {
  type: 'json',
  body: {
    user: validators.id.required().description('账户ID').error(new Error('账户ID不正确')),
  }
}, function * ({ body }) {
  const operator = yield ACOperatorController.create(body.user);
  return yield ACOperatorController.findByIdAndPopulate(operator._id);
}];