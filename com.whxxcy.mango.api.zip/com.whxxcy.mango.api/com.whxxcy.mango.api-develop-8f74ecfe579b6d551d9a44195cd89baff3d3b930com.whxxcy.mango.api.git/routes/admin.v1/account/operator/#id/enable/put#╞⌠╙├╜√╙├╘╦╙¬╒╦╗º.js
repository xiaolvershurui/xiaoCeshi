const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const Errrr = require('errrr');

module.exports = [['运营组长', 'admin'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('是否启用').error(new Error('启用状态设置错误'))
  }
}, function * ({ params, body }) {
  const operator = yield ACOperatorController.findByIdAndCheckExists(params.id);
  if (operator.isWorking) throw new Errrr('该运营人员正在上班，无法禁用');
  yield this.transaction.try(function * () {
    yield new ACOperatorController(this).toggleEnable(params.id, body.enable);
  });
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];
