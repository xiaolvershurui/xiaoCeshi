const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  type: 'json',
  body: {
    region: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  }
}, function * ({ params, body }) {
  yield this.transaction.try(function * () {
    yield new ACOperatorController(this).addRegion(params.id, body.region);
  });
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];