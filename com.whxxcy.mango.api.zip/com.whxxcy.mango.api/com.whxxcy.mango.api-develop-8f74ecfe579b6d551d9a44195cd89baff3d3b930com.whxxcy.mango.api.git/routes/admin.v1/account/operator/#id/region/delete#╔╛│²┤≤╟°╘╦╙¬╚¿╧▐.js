const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  query: {
    region: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  }
}, function * ({ params, query }) {
  yield this.transaction.try(function * () {
    yield new ACOperatorController(this).removeRegion(params.id, query.region);
  });
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];