const ACCouponController = require('../../../../../controllers/account/ACCouponController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.coupon.getMany'], {
  query: {
    user: validators.id.required().description('用户ID').error(new Error('用户ID不正确'))
  }
}, function * ({ query }) {
  return yield ACCouponController.findAllAvailable(query.user);
}];