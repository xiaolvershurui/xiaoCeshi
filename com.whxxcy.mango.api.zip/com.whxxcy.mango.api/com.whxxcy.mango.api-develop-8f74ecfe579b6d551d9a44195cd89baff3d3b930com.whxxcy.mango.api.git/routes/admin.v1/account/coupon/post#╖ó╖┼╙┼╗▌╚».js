const ACCouponController = require('../../../../controllers/account/ACCouponController');
const validators = require('../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.ac.coupon.post'], {
  type: 'json',
  body: {
    user: validators.id.required().description('用户ID').error(new Error('用户ID不正确')),
    name: Joi.string().empty('').description('优惠券名称').error(new Error('优惠券名称不正确')),
    amount: validators.amount.required().description('优惠券面额').error(new Error('优惠券面额不正确')),
    count: Joi.number().required().min(1).default(1).description('优惠券数量').error(new Error('优惠券数量不正确')),
    validDuration: Joi.number().required().min(7).default(7).description('有效期天数').error(new Error('有效期天数不合法'))
  }
}, function * ({ body }) {
  for (let i = 0; i < body.count; i += 1) {
    yield ACCouponController.issueByUser(body.user, {
      name: body.name,
      amount: body.amount,
      validDuration: body.validDuration,
      granter: this.state.user.id,
      isSystem: false
    });
  }
}];