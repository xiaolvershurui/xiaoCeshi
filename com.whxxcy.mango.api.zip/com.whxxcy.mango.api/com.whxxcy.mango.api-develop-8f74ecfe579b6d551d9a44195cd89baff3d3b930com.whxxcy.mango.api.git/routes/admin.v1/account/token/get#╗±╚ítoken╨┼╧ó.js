const { permissions, roles } = require('../../../../settings/rbacRules');
const OPBatteryStationController = require('../../../../controllers/operation/OPBatteryStationController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const ACOperatorController = require('../../../../controllers/account/ACOperatorController');
const constants = require('../../../../settings/constants');


module.exports = [['client'], {}, function * () {
  const info = this.state.user;
  const user = yield ACUserController.Model.findById(info.id).select('cert.name');
  const station = yield OPBatteryStationController.Model.findById(info.stationId).select('name');
  user && (info.userName = user.cert.name);
  station && (info.stationName = station.name);
  const userRoles = info.roles || [];
  const userPermissions = info.permissions || [];
  const ret = Object.assign({}, info, userRoles.reduce((memo, role) => {
    permissions[role] && permissions[role].forEach(memo.permissions.add.bind(memo.permissions));
    roles[role] && roles[role].forEach(memo.roles.add.bind(memo.roles));
    return memo;
  }, { permissions: userPermissions, roles: [] }));
  const endpoint = this.get('endpoint');
  if (endpoint === 'op') {
    const operator = yield ACOperatorController.Model.findOne({ user: info.id }).select('inspectionType');
    const tables = [
      { key: 0, value: '任务' },
      { key: 1, value: '电池' },
      { key: 5, value: '账户' },
    ];
    if (ret.permissions.includes('tracer')) tables.push({ key: 2, value: '追踪' });
    if (ret.roles.includes('公关')) tables.push({ key: 3, value: '扣押' });
    if (ret.roles.includes('线上运营') || (ret.roles.includes('operator') && operator && operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行)) {
      tables.push({ key: 4, value: '摆车' });
    }
    ret.tables = tables.sort((a, b) => a.key - b.key);
  }
  return ret;
}];
