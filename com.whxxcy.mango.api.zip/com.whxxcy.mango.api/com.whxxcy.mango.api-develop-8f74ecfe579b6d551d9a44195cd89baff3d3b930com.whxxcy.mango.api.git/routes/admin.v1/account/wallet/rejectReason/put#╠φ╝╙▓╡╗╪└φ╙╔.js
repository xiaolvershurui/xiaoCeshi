const FNTicketController = require('../../../../../controllers/finance/FNTicketController');
const Joi = require('joi');
const constants = require('../../../../../settings/constants');
const Error = require('errrr');

module.exports = [['client'], {
  type: 'json',
  body: {
    id: Joi.string().description('ticketId'),
    rejectReason: Joi.string().empty('').description('驳回理由'),
  },
}, function *({ body }) {
  const { id, rejectReason }=body;
  let ticket = yield FNTicketController.Model.findOne({_id:id});
  if(ticket){
    if(ticket.state === constants.FN_TICKET_STATE.退款失败 ) {
        return yield FNTicketController.addRejectReason(id, rejectReason);
    } else {
      throw new Error('用户退款未失败，添加驳回理由失败');
    }
  } else {
    throw new Error('此记录不存在');
  }
}];
