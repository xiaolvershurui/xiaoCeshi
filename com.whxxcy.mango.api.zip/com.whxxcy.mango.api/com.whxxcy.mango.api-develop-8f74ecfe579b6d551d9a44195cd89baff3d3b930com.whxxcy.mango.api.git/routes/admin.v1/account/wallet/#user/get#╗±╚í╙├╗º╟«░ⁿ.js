const ACWalletController = require('../../../../../controllers/account/ACWalletController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.wallet.get'], {
  params: {
    user: validators.id.description('用户ID').required().error(new Error('用户ID不正确'))
  }
}, function * ({ params }) {
  return yield ACWalletController.findByUserAndCheckExists(params.user);
}];