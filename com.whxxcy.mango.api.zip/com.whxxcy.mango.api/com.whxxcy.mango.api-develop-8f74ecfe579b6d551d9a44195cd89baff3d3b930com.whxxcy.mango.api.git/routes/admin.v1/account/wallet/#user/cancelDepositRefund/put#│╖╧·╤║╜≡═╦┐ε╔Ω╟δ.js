const ACWalletController = require('../../../../../../controllers/account/ACWalletController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.ac.wallet.put'], {
  params: {
    user: validators.id.required().description('用户ID').error(new Error('用户ID错误'))
  }
}, function * ({ params }) {
  const { user } = params;
  return yield this.transaction.try(function * () {
    return yield new ACWalletController(this).cancelRefund(user);
  });
}];