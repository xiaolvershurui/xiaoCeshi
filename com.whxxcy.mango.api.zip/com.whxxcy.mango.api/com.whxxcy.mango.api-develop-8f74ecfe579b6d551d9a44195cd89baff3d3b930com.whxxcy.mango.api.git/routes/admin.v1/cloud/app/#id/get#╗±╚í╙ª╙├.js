const CLDeveloperController = require('../../../../../controllers/cloud/CLDeveloperController');
const CLAppController = require('../../../../../controllers/cloud/CLAppController');
const constants = require('../../../../../settings/constants');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.cl.app.getMany'], {
  params: {
    id: validators.id.description('应用ID').required().error(new Error('id不正确'))
  },
}, function * ({ params }) {
  return yield CLAppController.Model.findById(params.id).populate({
    model: CLDeveloperController.Model,
    path: 'developer'
  });
}];