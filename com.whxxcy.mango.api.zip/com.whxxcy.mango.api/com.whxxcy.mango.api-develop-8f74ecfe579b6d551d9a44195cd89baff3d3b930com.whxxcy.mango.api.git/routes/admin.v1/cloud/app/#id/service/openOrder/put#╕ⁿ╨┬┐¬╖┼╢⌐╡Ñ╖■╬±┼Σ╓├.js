const CLAppController = require('../../../../../../../controllers/cloud/CLAppController');
const Joi = require('joi');
const validators = require('../../../../../../../settings/validators');

module.exports = [['admin.cl.app.put'], {
  params: {
    id: validators.id.description('应用ID').required().error(new Error('id不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().description('是否启用').error(new Error('状态不合法')),
    regions: Joi.array().items(Joi.string()).description('开放大区列表').error(new Error('开放大区列表设置错误'))
  }
}, function * ({ params, body }) {
  return yield CLAppController.updateOpenOrderService(params.id, body);
}];