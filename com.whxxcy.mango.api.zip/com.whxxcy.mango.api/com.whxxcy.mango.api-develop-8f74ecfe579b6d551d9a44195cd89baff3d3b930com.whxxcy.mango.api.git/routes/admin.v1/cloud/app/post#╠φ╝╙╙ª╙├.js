const CLAppController = require('../../../../controllers/cloud/CLAppController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.cl.app.post'], {
  type: 'json',
  body: {
    developer: validators.id.description('开发者ID').error(new Error('开发者ID不合法')),
    name: Joi.string().required().description('应用名称').error(new Error('请填写应用名称')),
    authMethod: Joi.number().valid(constants.CL_APP_AUTH_METHOD_ENUMS).description(`鉴权方式`)
  }
}, function * ({ body }) {
  return yield CLAppController.create(body);
}];