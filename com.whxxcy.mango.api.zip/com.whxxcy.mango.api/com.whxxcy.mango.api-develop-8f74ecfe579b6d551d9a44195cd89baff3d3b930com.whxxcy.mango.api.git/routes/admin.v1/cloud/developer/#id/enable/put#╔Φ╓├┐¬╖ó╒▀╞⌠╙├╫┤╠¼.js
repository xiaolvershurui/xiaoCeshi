const CLDeveloperController = require('../../../../../../controllers/cloud/CLDeveloperController');
const Joi = require('joi');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.cl.developer.put'], {
  params: {
    id: validators.id.description('开发者ID').required().error(new Error('id不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('是否启用').error(new Error('状态不合法'))
  }
}, function * ({ params, body }) {
  return yield this.transaction.try(function * () {
    return yield new CLDeveloperController(this).toggleEnable(params.id, body.enable);
  });
}];