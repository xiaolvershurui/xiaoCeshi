const CLDeveloperController = require('../../../../../controllers/cloud/CLDeveloperController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const constants = require('../../../../../settings/constants');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.cl.developer.get'], {
  params: {
    id: validators.id.description('开发者ID').required().error(new Error('id不正确'))
  },
}, function * ({ params }) {
  return yield CLDeveloperController.Model.findById(params.id).populate({
    model: ACUserController.Model,
    path: 'user'
  });
}];