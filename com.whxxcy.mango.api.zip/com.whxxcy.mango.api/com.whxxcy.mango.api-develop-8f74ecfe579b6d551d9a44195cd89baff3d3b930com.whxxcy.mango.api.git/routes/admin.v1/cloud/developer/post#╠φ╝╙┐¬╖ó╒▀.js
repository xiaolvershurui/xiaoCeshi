const CLDeveloperController = require('../../../../controllers/cloud/CLDeveloperController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const validators = require('../../../../settings/validators');
const Error = require('errrr');
const Joi = require('joi');

module.exports = [['admin.cl.developer.post'], {
  type: 'json',
  body: {
    tel: validators.tel.required().description('用户手机号').error(new Error('手机号不合法')),
    name: Joi.string().required().description('主体名称').error(new Error('')),
    contact: Joi.object({
      important: Joi.object({
        name: Joi.string().required().description('联系人姓名').error(new Error('请填写联系人姓名')),
        tel: validators.tel.required().description('联系人手机号').error(new Error('请填写联系人手机号')),
        email: Joi.string().email().required().description('联系人邮箱').error(new Error('请填写联系人邮箱'))
      }).description('关键联系人')
    }).description('联系方式')
  }
}, function * ({ body }) {
  const user = yield ACUserController.findByTel(body.tel);
  if (!user) throw new Error('账户不存在');
  return yield this.transaction.try(function * () {
    return yield new CLDeveloperController(this).create({ user: user._id, name: body.name, contact: body.contact });
  });
}];