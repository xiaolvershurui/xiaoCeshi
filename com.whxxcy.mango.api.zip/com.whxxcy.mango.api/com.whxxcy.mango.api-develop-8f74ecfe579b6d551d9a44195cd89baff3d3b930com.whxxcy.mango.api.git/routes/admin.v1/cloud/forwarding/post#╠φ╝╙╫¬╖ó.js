const CLForwardingController = require('../../../../controllers/cloud/CLForwardingController');
const BKStockController = require('../../../../controllers/ebike/BKStockController');
const CLAppController = require('../../../../controllers/cloud/CLAppController');
const validators = require('../../../../settings/validators');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.cl.forwarding.post'], {
  type: 'json',
  body: {
    stock: validators.id.empty('').description('库存ID').error(new Error('库存ID不正确')),
    number: Joi.string().empty('').description('自定义车牌号').error(new Error('自定义车牌号错误')),
    deviceId: validators.id.empty('').description('设备号').error(new Error('设备号不正确')),
    app: validators.id.empty('').description('应用ID').error(new Error('应用ID不正确'))
  }
}, function * ({ body }) {
  let { stock, number, deviceId, app } = body;
  if (stock) {
    yield BKStockController.findByIdAndCheckExists(stock);
  } else if (number) {
    const stockData = yield BKStockController.Model.findOne({ 'number.custom': number });
    if (!stockData) throw new Error('车牌号未使用');
    stock = stockData._id;
  } else if (deviceId) {
    const result = yield BKStockController.findBoxByBoxId(deviceId);
    if (!result) throw new Error('设备未使用');
    stock = result.stock._id;
  } else throw new Error('请输入车辆唯一标识');
  yield CLAppController.findByIdAndCheckExists(app);
  const forwarding = yield CLForwardingController.create({ stock, app });
  return CLForwardingController.Model.findById(forwarding._id).populate({
    model: BKStockController.Model,
    path: 'stock'
  });
}];