const CLForwardingController = require('../../../../controllers/cloud/CLForwardingController');
const BKStockController = require('../../../../controllers/ebike/BKStockController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');

module.exports = [['admin.cl.forwarding.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    limit: Joi.number().min(1).default(constants.PAGE_SIZE).description('查询条数').error(new Error('查询条数不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法'))
  }
}, function * ({ query }) {
  const items = yield CLForwardingController.Model.find(query.query).sort(query.sort).skip(query.skip).limit(query.limit).populate({
    model: BKStockController.Model,
    path: 'stock'
  });
  return {
    items,
    count: yield CLForwardingController.Model.count(query.query)
  };
}];