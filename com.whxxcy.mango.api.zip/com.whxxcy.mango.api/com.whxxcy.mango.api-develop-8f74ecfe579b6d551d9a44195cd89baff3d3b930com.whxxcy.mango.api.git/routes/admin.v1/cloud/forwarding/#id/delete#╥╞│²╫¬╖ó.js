const CLForwardingController = require('../../../../../controllers/cloud/CLForwardingController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.cl.forwarding.remove'], {
  params: {
    id: validators.id.required().description('转发id').error(new Error('转发ID错误'))
  }
}, function * ({ params }) {
  return yield CLForwardingController.remove(params.id);
}];