const BKBoxController = require('../../../../controllers/ebike/BKBoxController');
const Joi = require('joi');
const constants = require('../../../../settings/constants');

module.exports = [['admin.bk.box.post'], {
  type: 'json',
  body: {
    deviceId: Joi.string().required().description('设备号').error(new Error('设备号不正确')),
    model: Joi.string().empty('').description('型号').error(new Error('设备型号不正确')),
    voltageRange: Joi.string().empty('').description('电压范围').error(new Error('电压范围不正确')),
    sn: Joi.string().empty('').description('SN码').error(new Error('SN码不正确')),
    dataSource: Joi.number().valid(constants.BK_BOX_DATA_SOURCE_ENUMS).required().description('数据源 0 一动 1 比德文').error(new Error('数据源不正确')),
    activateExpires: Joi.date().empty('').description('最后激活时间').error(new Error('最后激活时间不正确')),
    activatedAt: Joi.date().empty('').description('激活时间').error(new Error('激活时间不正确')),
    number: Joi.string().empty('').description('SIM卡号').error(new Error('SIM卡号不正确'))
  }
}, function * ({ body }) {
  return yield BKBoxController.create(body);
}];