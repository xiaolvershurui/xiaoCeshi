const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const BKBoxController = require('../../../../../../controllers/ebike/BKBoxController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const Error = require('errrr');
const IoT = require('../../../../../../IoT');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.bk.box.put'], {
  params: {
    id: validators.id.required().description('设备ID').error(new Error('设备ID不正确'))
  },
  type: 'json',
  body: {
    command: Joi.number().valid([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])
      .description('0 启动  1 设防  2 播放寻车声 3 刷新状态 4 关闭电门 5 撤防 6 获取实时信息 7 关机 8 重置 9 播放声音 10 开启电池仓锁 11 转网 12 远程升级 13 设置语音 14 设置参数').error(new Error('指令不合法')),
    dataSource: Joi.number().default(constants.BK_BOX_DATA_SOURCE.小安宝).description('盒子数据源'),
    param: Joi.any(),
  }
}, function * ({ body, params }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;

  const stock = yield BKStockController.Model.findOne({ box: params.id });

  const device = IoT.at(params.id, {
    stock: stock && stock._id,
    operator: id,
    operateLocation: { lngLat, address }
  });

  switch (body.command) {
    case 0:
      return yield device.start();
    case 1:
      return yield device.lock();
    case 2:
      return yield device.welcome();
    case 3: {
      return yield BKBoxController.forceUpdate(params.id, {
        operator: id,
        operateLocation: { lngLat, address }
      });
    }
    case 4:
      return yield device.stop();
    case 5:
      return yield device.unlock();
    case 6:
      return yield device.getInfo();
    case 7:
      return yield device.shutdown();
    case 8:
      return yield device.reset();
    case 9:
      return yield device.playSound(body.param);
    case 10:
      return yield device.unlockBattery();
    case 11:
      return yield device.changeServer(body.param);
    case 12:
      return yield device.remoteUpgrade();
    case 13:
      return yield device.setSound(body.param);
    case 14:
      return yield device.setConfig(body.param);
    default:
  }
}];