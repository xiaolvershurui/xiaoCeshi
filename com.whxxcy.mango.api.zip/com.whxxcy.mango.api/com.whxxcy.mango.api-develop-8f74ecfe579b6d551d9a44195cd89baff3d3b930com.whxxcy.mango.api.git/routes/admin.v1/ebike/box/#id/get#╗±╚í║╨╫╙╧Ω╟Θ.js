const BKBoxController = require('../../../../../controllers/ebike/BKBoxController');
const Joi = require('joi');

module.exports = [['admin.bk.box.get'], {
  params: {
    id: Joi.string().required().description('设备号').error(new Error('设备号不正确')),
  }
}, function * ({ params }) {
  return yield BKBoxController.findByIdAndCheckExists(params.id);
}];