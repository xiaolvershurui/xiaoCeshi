const BKBoxController = require('../../../../../../controllers/ebike/BKBoxController');

module.exports = [['admin.bk.box.put'], {

}, function * () {
  // TODO: 未实现
}];