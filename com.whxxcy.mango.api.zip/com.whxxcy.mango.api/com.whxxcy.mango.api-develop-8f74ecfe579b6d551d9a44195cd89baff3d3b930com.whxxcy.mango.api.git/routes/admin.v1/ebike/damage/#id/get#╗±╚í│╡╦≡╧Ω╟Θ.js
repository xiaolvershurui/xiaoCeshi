const BKDamageController = require('../../../../../controllers/ebike/BKDamageController');
const Joi = require('joi');

module.exports = [['admin.bk.damage.get'], {
  params: {
    id: Joi.string().required().description('车损号').error(new Error('车损号不正确')),
  }
}, function * ({ params }) {
  return yield BKDamageController.findByIdAndCheckExists(params.id);
}];