const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.bk.stock.get'], {
  query: {
    number: Joi.string().length(9).required().description('定制车牌号').error(new Error('车牌号应当是9位的数字'))
  }
}, function * ({ query }) {
  const { regionIds } = this.state.user;
  let stock = yield BKStockController.Model.findOne({
    'number.custom': query.number,
    region: { $in: regionIds }
  }).populate({
    path: 'location.intersectPolygon',
    model: OPPolygonController.Model
  }).populate({
    path: 'location.intersectRegion',
    model: OPRegionController.Model
  });
  if (!stock) throw new Error('车辆不存在或无权限');
  stock = stock.toJSON();
  stock.taskList = stock.taskList.map(task => task.code);
  stock.invalidReasons = stock.invalidReasons.map(reason => reason.code);
  return stock;
}];