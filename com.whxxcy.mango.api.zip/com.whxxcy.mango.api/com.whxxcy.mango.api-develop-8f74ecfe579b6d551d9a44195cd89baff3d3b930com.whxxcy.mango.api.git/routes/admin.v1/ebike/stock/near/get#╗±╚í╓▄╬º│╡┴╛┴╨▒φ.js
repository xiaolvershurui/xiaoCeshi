const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const BKBoxController = require('../../../../../controllers/ebike/BKBoxController');
const OPInspectionTaskController = require('../../../../../controllers/operation/OPInspectionTaskController');
const validators = require('../../../../../settings/validators');
const constants = require('../../../../../settings/constants');
const RCScanQRController = require('../../../../../controllers/record/RCScanQRController');

module.exports = [['admin.bk.stock.getMany'], {
  query: {
    region: validators.id.empty('').description('大区ID，可不填').error(new Error('大区ID不正确')),
    center: validators.location.required().description('搜索中心点').error(new Error('搜索中心不正确'))
  }
}, function * ({ query }) {
  const { regionIds } = this.state.user;
  const finalQuery = {
    $and: [{
      region: { $in: [...regionIds, null] }
    }]
  };
  if (query.region) finalQuery.$and.push({ region: query.region });
  const items = yield BKStockController.searchNear(query.center, finalQuery, constants.STOCK_SEARCH_RADIUS_ADMIN);
  const boxById = {};
  const stateById = {};
  const latestSuspiciousById = {};
  for (let item of items) {
    boxById[item._id] = yield BKBoxController.Model.findById(item.box);
    stateById[item._id] = yield OPInspectionTaskController.integrateUnprocessedByStock(item._id);
    latestSuspiciousById[item._id] = yield RCScanQRController.findLatestSuspicious(item._id);
  }
  return {
    items: items.map(item => {
      item = item.toJSON();
      item.taskList = item.taskList.map(task => task.code);
      item.invalidReasons = item.invalidReasons.map(reason => reason.code);
      return item;
    }),
    count: items.length,
    boxById,
    stateById,
    latestSuspiciousById
  };
}];