const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    style: validators.id.required().description('车型ID').error(new Error('车型ID不正确'))
  }
}, function * ({ body, params }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  return yield BKStockController.updateStyle(params.id, body.style, {
    operator: id,
    operateLocation: { lngLat, address }
  });
}];