const BKStockController = require('../../../../../controllers/ebike/BKStockController');
const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.bk.stock.get'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  }
}, function * ({ params }) {
  const { regionIds } = this.state.user;
  let stock = yield BKStockController.Model.findOne({
    _id: params.id,
    region: { $in: regionIds }
  }).populate({
    path: 'location.intersectPolygon',
    model: OPPolygonController.Model
  }).populate({
    path: 'location.intersectRegion',
    model: OPRegionController.Model
  });
  if (!stock) throw new Error('车辆不存在或无权限');
  stock = stock.toJSON();
  stock.taskList = stock.taskList.map(task => task.code);
  stock.invalidReasons = stock.invalidReasons.map(reason => reason.code);
  return stock;
}];