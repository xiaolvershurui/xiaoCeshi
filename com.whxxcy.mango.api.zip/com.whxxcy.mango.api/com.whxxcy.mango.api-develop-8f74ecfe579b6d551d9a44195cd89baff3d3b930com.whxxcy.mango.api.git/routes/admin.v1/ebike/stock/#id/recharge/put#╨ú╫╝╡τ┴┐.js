const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    power: Joi.number().min(0).max(1).description('电量值').error(new Error('请输入正确的电量值'))
  }
}, function * ({ body, params }) {
  const { regionIds, id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  const stock = yield BKStockController.Model.findOne({
    _id: params.id,
    region: { $in: regionIds }
  });
  if (!stock) throw new Error('车辆不存在或无权限');
  return yield BKStockController.updateRechargeInfo(params.id, body.power, {
    operator: id,
    operateLocation: { lngLat, address }
  });
}];