const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    enable: Joi.boolean().required().description('启用状态').error(new Error('启用状态不正确'))
  }
}, function * ({ body, params }) {
  const { regionIds, id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  const stock = yield BKStockController.Model.findOne({
    _id: params.id,
    region: { $in: regionIds }
  });
  if (!stock) throw new Error('车辆不存在或无权限');
  return yield BKStockController.updateEnable(params.id, body.enable, {
    operator: id,
    operateLocation: { lngLat, address }
  });
}];