const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const BKBatteryController = require('../../../../../../controllers/ebike/BKBatteryController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确')),
  },
  type: 'json',
  body: {
    region: validators.id.empty('').description('大区ID').error(new Error('请选择正确的大区')),
    station: validators.id.empty('').description('仓库ID').error(new Error('请选择正确的仓库')),
  },
}, function *({ body, params }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  const stock = yield BKStockController.findByIdAndCheckExists(params.id);
  if (body.station) {
    yield BKStockController.updateStation(params.id, body.station);
    if (stock.battery.id) {
      yield BKBatteryController.updateStation({ id: stock.battery.id, station: body.station, operator: id });
    }
  }

  const bkStock = yield BKStockController.updateRegion(params.id, body.region, {
    operator: id,
    operateLocation: { lngLat, address },
  });
  if (stock.battery.id) {
    yield BKBatteryController.updateRegion({ id: stock.battery.id, region: body.region, operator: id });
  }
  return bkStock
}];
