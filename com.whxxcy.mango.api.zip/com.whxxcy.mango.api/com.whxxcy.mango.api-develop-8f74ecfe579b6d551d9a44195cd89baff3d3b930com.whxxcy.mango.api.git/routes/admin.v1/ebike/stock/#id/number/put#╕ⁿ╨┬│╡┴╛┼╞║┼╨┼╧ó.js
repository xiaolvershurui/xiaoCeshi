const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    number: Joi.object({
      temp: Joi.string().empty('').description('临时车牌号').error(new Error('临时车牌号不正确')),
      license: Joi.string().empty('').description('交管局车牌号').error(new Error('交管局车牌号不正确')),
      custom: Joi.string().empty('').length(9).description('自定义车牌号').error(new Error('自定义车牌号应当是9位的数字')),
      vin: Joi.string().required().description('车架号').error(new Error('请填写车架号')),
    })
  }
}, function * ({ body, params }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  // return yield BKStockController.updateNumber(params.id, body.number, {
  //   operator: id,
  //   operateLocation: { lngLat, address }
  // });
  return yield this.transaction.try(function*() {
    return yield new BKStockController(this).updateNumber(params.id, body.number, {
      operator: id,
      operateLocation: { lngLat, address }
    })
  })
}];
