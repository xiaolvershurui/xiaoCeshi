const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    box: Joi.string().empty('').description('盒子设备号').error(new Error('盒子设备号不正确'))
  }
}, function * ({ body, params }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  return yield BKStockController.updateBox(params.id, body.box, {
    operator: id,
    operateLocation: { lngLat, address }
  });
}];