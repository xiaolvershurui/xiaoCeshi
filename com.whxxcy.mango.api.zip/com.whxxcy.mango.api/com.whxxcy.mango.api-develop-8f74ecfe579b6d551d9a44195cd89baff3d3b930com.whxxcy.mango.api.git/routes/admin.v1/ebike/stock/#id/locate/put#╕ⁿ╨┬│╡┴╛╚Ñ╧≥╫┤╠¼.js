const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const constants = require('../../../../../../settings/constants');
const Error = require('errrr');

module.exports = [['admin.bk.stock.put'], {
  params: {
    id: validators.id.required().description('车辆ID').error(new Error('车辆ID不正确'))
  },
  type: 'json',
  body: {
    locate: Joi.number().valid(constants.BK_LOCATE_ENUMS).required().description('车辆去向').error(new Error('车辆去向不正确'))
  }
}, function * ({ body, params }) {
  if (body.locate === constants.BK_LOCATE.扣押) throw new Error('设置扣押功能已禁用，请在扣押点监控页面设置扣押');
  const { regionIds, id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  const stock = yield BKStockController.Model.findOne({
    _id: params.id,
    region: { $in: regionIds }
  });
  if (!stock) throw new Error('车辆不存在或无权限');
  if ([constants.BK_LOCATE.在租, constants.BK_LOCATE.预约].includes(stock.locate)) {
    throw new Error('车辆在租或被预约，无法调整去向。');
  }
  return yield BKStockController.updateLocate(params.id, body.locate, {
    operator: id,
    operateLocation: { lngLat, address },
  });
}];