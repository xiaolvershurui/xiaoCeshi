const BKStockController = require('../../../../controllers/ebike/BKStockController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.bk.stock.post'], {
  type: 'json',
  body: {
    number: Joi.object({
      temp: Joi.string().empty('').description('临时车牌号').error(new Error('临时车牌号不正确')),
      custom: Joi.string().empty('').length(9).description('自定义车牌号').error(new Error('自定义车牌号应当是9位的数字')),
      license: Joi.string().empty('').description('交管局车牌号').error(new Error('交管局车牌号不正确')),
      vin: Joi.string().required().description('车架号').error(new Error('请填写车架号')),
    }),
    region: validators.id.empty('').description('大区ID').error(new Error('大区ID不正确')),
    style: validators.id.required().description('车型ID').error(new Error('请选择车型')),
    box: Joi.string().empty('').description('盒子ID').error(new Error('盒子ID不正确'))
  }
}, function * ({ body }) {
  const { id } = this.state.user;
  const { lngLat, address } = this.state.deviceInfo;
  return yield BKStockController.create(body, {
    operator: id,
    operateLocation: { lngLat, address }
  });
}];