const RCStockPointController = require('../../../../../controllers/record/RCStockPointController');
const Joi = require('joi');
const constants = require('../.././../../../settings/constants');

module.exports = [['admin.rc.stock_point.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
    skip: Joi.number().min(0).default(0).description('跳过条数').error(new Error('跳过条数不合法'))
  }
}, function * ({query}) {
  return yield RCStockPointController.Model.find(query.query).skip(query.skip).sort(query.sort).distinct('stock');
}];