const RCStockPointController = require('../../../../../controllers/record/RCStockPointController');
const Joi = require('joi');

module.exports = [['admin.rc.stock_point.getMany'], {
  query: {
    box: Joi.string().required().description('盒子ID').error(new Error('请输入盒子ID'))
  }
}, function * ({ query }) {
  const points = yield RCStockPointController.findLatestPath(query.box, 100);
  return points.map(point => point.gps.lngLat);
}];