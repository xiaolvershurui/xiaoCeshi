const STEventController = require('../../../../controllers/setting/STEventController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.st.event.post'], {
  type: 'json',
  body: {
    life: Joi.object({
      start: Joi.date().required().description('启用时间').error(new Error('启用时间不正确')),
      end: Joi.date().required().description('结束时间').error(new Error('启用时间不正确')),
    }).required().error(new Error('请填写生命周期')),
    title: Joi.string().required().description('标题').error(new Error('请填写标题')),
    description: Joi.string().required().description('描述').error(new Error('请填写描述')),
    image: Joi.string().required().description('活动图片').error(new Error('请上传活动图片')),
    link: Joi.string().empty('').description('链接'),
    rule: Joi.object({
      discountRent: Joi.object({
        enable: Joi.boolean().default(false).description('是否启用').error(new Error('是否启用设置错误')),
        cutRate: Joi.number().min(0).max(1).empty('').description('折扣率').error(new Error('折扣率错误')),
      }).description('租金折扣规则'),
      cutRent: Joi.object({
        enable: Joi.boolean().default(false).description('是否启用').error(new Error('是否启用设置错误')),
        amount: validators.amount.description('抵扣面额'),
        validAmount: validators.amount.description('起用金额')
      }).description('租金抵扣规则'),
      freeRent: Joi.object({
        enable: Joi.boolean().default(false).description('是否启用').error(new Error('是否启用设置错误')),
      }).description('免费租车规则'),
      freeInsurance: Joi.object({
        enable: Joi.boolean().default(false).description('是否启用').error(new Error('是否启用设置错误')),
      }).description('免费保险规则')
    }),
    validRegions: Joi.array().items(validators.id).description('可用大区列表').error(new Error('可用大区列表不正确')),
    validStyleLevels: Joi.array().items(Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS)).description('可用车型等级列表').error(new Error('可用车型等级列表不正确'))
  }
}, function * ({ body }) {
  return yield STEventController.create(body);
}];