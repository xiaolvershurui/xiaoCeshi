const STConfigController = require('../../../../controllers/setting/STConfigController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.st.config.post'], {
  type: 'json',
  body: {
    platforms: Joi.array().items(Joi.string().valid(constants.ST_CONFIG_PLATFORM_ENUMS)).description('可用平台').error(new Error('可用平台错误')),
    iOSLowestVersion: Joi.string().empty('').description('iOS平台可见最低版本').error(new Error('iOS平台可见最低版本错误')),
    androidLowestVersion: Joi.string().empty('').description('安卓可见最低版本').error(new Error('安卓可见最低版本错误')),
    key: Joi.string().required().description('配置键').error(new Error('配置键错误')),
    valueType: Joi.string().valid(constants.ST_CONFIG_VALUE_TYPE_ENUMS).required().description('配置值类型').error(new Error('配置值类型错误')),
    value: Joi.any().description('配置值'),
    description: Joi.string().empty('').description('配置描述').error(new Error('配置描述错误'))
  }
}, function * ({ body }) {
  return yield STConfigController.create(body);
}];