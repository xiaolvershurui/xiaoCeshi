const STCouponCodeController = require('../../../../../../controllers/setting/STCouponCodeController');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin.st.coupon_code.put'], {
  params: {
    id: validators.id.required().description('id')
  },
  type: 'json',
  body: {
    enable: Joi.boolean().description('启用状态')
  }
}, function * ({ body, params }) {
  return yield STCouponCodeController.toggleEnable(params.id, body.enable);
}];