const STCouponCodeController = require('../../../../controllers/setting/STCouponCodeController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.st.coupon_code.post'], {
  type: 'json',
  body: {
    life: Joi.object({
      start: Joi.date().required().description('开始兑换时间').error(new Error('开始兑换时间不正确')),
      end: Joi.date().required().description('结束兑换时间').error(new Error('结束兑换时间不正确')),
    }).required().error(new Error('请填写生命周期')),
    code: Joi.string().required().description('兑换码').error(new Error('兑换码不合法')),
    tels: Joi.array().items(validators.tel).description('可兑换的手机号列表').error(new Error('手机号列表不合法')),
    totalTimes: Joi.number().min(1).default(1).description('可兑换次数').error(new Error('可兑换次数不正确')),
    type: Joi.number().valid(constants.AC_COUPON_TYPE_ENUMS).description('优惠券类型').error(new Error('优惠券类型不正确')),
    name: Joi.string().required().description('优惠券名称').error(new Error('请填写优惠券名称')),
    amount: Joi.number().min(0).required().description('优惠券面额').error(new Error('优惠券面额不正确')),
    validDuration: Joi.number().min(1).required().description('优惠券有效期天数').error(new Error('优惠券有效期天数不正确')),
    validRegions: Joi.array().items(validators.id).description('优惠券可用大区列表').error(new Error('可用大区列表不正确')),
    validStyleLevels: Joi.array().items(Joi.number().valid(constants.OP_STYLE_LEVEL_ENUMS)).description('可用车型等级列表').error(new Error('可用车型等级列表不正确'))
  }
}, function * ({ body }) {
  return yield STCouponCodeController.create(body);
}];