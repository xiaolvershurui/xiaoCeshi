const STLaunchController = require('../../../../controllers/setting/STLaunchController');
const Joi = require('joi');
const validators = require('../../../../settings/validators');
const constants = require('../../../../settings/constants');

module.exports = [['admin.st.launch.post'], {
  type: 'json',
  body: {
    life: Joi.object({
      start: Joi.date().required().description('启用时间').error(new Error('启用时间不正确')),
      end: Joi.date().required().description('结束时间').error(new Error('结束时间不正确')),
    }).required().error(new Error('请填写生命周期')),
    name: Joi.string().required().description('名称').error(new Error('请填写名称')),
    image: Joi.string().required().description('图片').error(new Error('请上传图片')),
    link: Joi.string().empty('').description('链接'),
    validCities: Joi.array().items(Joi.string()).description('可用城市列表').error(new Error('可用城市列表不正确')),
    queue: Joi.number().default(0).description('排序权重')
  }
}, function * ({ body }) {
  return yield STLaunchController.create(body);
}];