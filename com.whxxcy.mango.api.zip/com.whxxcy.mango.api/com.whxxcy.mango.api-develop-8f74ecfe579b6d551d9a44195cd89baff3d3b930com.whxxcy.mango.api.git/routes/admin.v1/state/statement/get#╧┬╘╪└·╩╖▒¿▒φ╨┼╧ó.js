const RCStockAlarmController = require('../../../../controllers/record/RCStockAlarmController');
const RCLoginController = require('../../../../controllers/record/RCLoginController');
const ODOrderController = require('../../../../controllers/order/ODOrderController');
const FNBalanceBillController = require('../../../../controllers/finance/FNBalanceBillController');
const FNDepositBillController = require('../../../../controllers/finance/FNDepositBillController');
const FNTicketController = require('../../../../controllers/finance/FNTicketController');
const BKStockController = require('../../../../controllers/ebike/BKStockController');
const OPRegionController = require('../../../../controllers/operation/OPRegionController');
const ODReservationController = require('../../../../controllers/order/ODReservationController');
const RCNotificationController = require('../../../../controllers/record/RCNotificationController');
const ACUserController = require('../../../../controllers/account/ACUserController');
const ACCreditController = require('../../../../controllers/account/ACCreditController');
const ACWalletController = require('../../../../controllers/account/ACWalletController');
const OPCreditAppealController = require('../../../../controllers/operation/OPCreditAppealController');
const OPFeedbackController = require('../../../../controllers/operation/OPFeedbackController');
const OPReportedAbuseController = require('../../../../controllers/operation/OPReportedAbuseController');
const OPReportedDamageController = require('../../../../controllers/operation/OPReportedDamageController');
const SSStockInDayController = require('../../../../controllers/statistic/SSStockInDayController');
const constants = require('../../../../settings/constants');
const Joi = require('joi');
const amap = require('../../../../services/amap/index');

module.exports = [['admin'], {
  query: {
    type: Joi.number().required().description('报表类型').error(new Error('报表类型不正确')),
    startTime: Joi.date().required().description('开始时间').error(new Error('开始时间不正确')),
    endTime: Joi.date().required().description('结束时间').error(new Error('结束时间不正确'))
  }
}, function * ({query}) {
  let start;
  let end;
  let result = [];
  const duration = Math.ceil((query.endTime.getTime() - query.startTime.getTime()) / (24 * 3600 * 1000));
  const endDay = Math.ceil((new Date('today'.beginning).getTime() - query.endTime.getTime()) / (24 * 3600 * 1000));
  const type = query.type;
  const regions = yield OPRegionController.Model.find({enable: true});
  switch (type) {
    case 1:
      result.push(['日期', '登陆用户数', '1天留存', '2天留存', '3天留存', '4天留存', '5天留存', '6天留存', '7天留存', '30天留存', '90天留存', '360天留存']);
      break;
    case 2:
      result.push(['日期', '老用户下单数', '新增付费用户数', '下单一次', '下单两次', '下单三次', '下单四次', '下单五次及以上', '下单老用户数', '下单新用户数']);
      break;
    case 3:
      result.push(['日期', '注册量', '实名认证人数', '充押金人数', '下单人数', '北京注册量', '北京实名认证数', '北京充押金人数', '北京下单人数', '绵阳注册量', '绵阳实名认证数', '绵阳充押金人数', '绵阳下单人数']);
      break;
    case 4:
      result.push(['日期', '驶出围栏', '20分钟结束订单', '实际总禁停区数量', '20分钟结束且在禁停区数量', '报错后禁停区数量', '禁停纠正', '禁行区数量', '禁行区纠正']);
      break;
    case 5:
      result.push(['日期'], ['大区'], ['投放车辆数'], ['可用车辆数'], ['平均可用时长'], ['使用车辆数'], ['车辆使用率'], ['车辆使用次数'], ['车辆总计收入(租金+保险)'], ['单车日均收入'], ['日期', '地区', '车辆', '次数', '租金', '可用时长', '扫码错误次数', '订单时长', '用户报损次数']);
      for (let i = 0; i < regions.length; i += 1) {
        for (let k = endDay + duration; k > endDay - 1; k -= 1) {
          if (k === 1) {
            start = '1 day'.before('today'.beginning);
            end = '1 day'.before('today'.ending);
          } else {
            start = `${k} days`.before('today'.beginning);
            end = `${k} days`.before('today'.ending)
          }
          const dateQuery = {
            $gte: start,
            $lt: end
          };
          const orders = yield ODOrderController.Model.find({
            finishedAt: dateQuery,
            region: regions[i]._id
          });
          const existsStocks = [];
          const useStocks = {};
          const allStocks = yield BKStockController.Model.find({
            region: regions[i]._id
          });
          for (let i = 0; i < allStocks.length; i += 1) {
            const stock = allStocks[i];
            const scanErrorCount = yield RCNotificationController.Model.count({
              createdAt: dateQuery,
              'data.query.number': stock.number.custom
            });
            const stockInDay = yield SSStockInDayController.Model.findOne({
              stock: stock._id,
              createdAt: dateQuery
            });
            useStocks[stock.number.custom] = {
              rent: 0,
              useCount: 0,
              validTime: (stockInDay && ((stockInDay.validTime + stockInDay.usingTime) / 60).toFixed(2)) || 0,
              scanErrorCount: scanErrorCount,
              orderTime: 0,
              damageCount: yield OPReportedDamageController.Model.count({createdAt: dateQuery, bike: stock._id})
            }
          }
          let totalRent = 0;
          const rentBills = yield FNBalanceBillController.Model.find({
            createdAt: dateQuery,
            signal: {$in: [constants.FN_BALANCE_BILL_SIGNAL.支付订单租金, constants.FN_BALANCE_BILL_SIGNAL.订单免单, constants.FN_BALANCE_BILL_SIGNAL.支付订单保险]}
          }).populate({
            path: 'order',
            model: ODOrderController.Model,
            select: 'region'
          });
          rentBills.forEach(rentBill => {
            if (rentBill.order.region === regions[i]._id) {
              totalRent += (rentBill.signal === constants.FN_BALANCE_BILL_SIGNAL.订单免单) ? -rentBill.amount : rentBill.amount;
            }
          });

          orders.forEach(order => {
            if (!existsStocks.includes(order.stockNo)) {
              existsStocks.push(order.stockNo);
            }
            useStocks[order.stockNo].rent += order.payInfo.totalAmount;
            useStocks[order.stockNo].useCount += 1;
            useStocks[order.stockNo].orderTime = order.lease.totalDuration;
          });
          let enableUseTime = 0;
          const enableUseStocks = yield SSStockInDayController.Model.find({
            createdAt: dateQuery,
            region: regions[i]._id,
            $or: [{usingTime: {$gt: 0}}, {validTime: {$gt: 0}}]
          });
          enableUseStocks.forEach(ss => {
            enableUseTime += ss.validTime + ss.usingTime;
          });
          result[0].push(start.format('yyyy-MM-dd'));
          result[1].push(regions[i].name);
          result[3].push(enableUseStocks.length);
          result[4].push(`${(enableUseTime / enableUseStocks.length / 60).toFixed(2)}H`);
          result[5].push(existsStocks.length);
          result[6].push((existsStocks.length / enableUseStocks.length).toFixed(2));
          result[7].push(orders.length);
          result[8].push(totalRent / 100);
          result[9].push((totalRent / enableUseStocks.length / 100).toFixed(2));
          const ret = Object.keys(useStocks).map(useStock => {
            return [start.format('yyyy-MM-dd'), regions[i].name, useStock, useStocks[useStock].useCount, useStocks[useStock].rent / 100, useStocks[useStock].validTime, useStocks[useStock].scanErrorCount, useStocks[useStock].orderTime, useStocks[useStock].damageCount];
          });
          result.push(...ret);
        }
      }
      break;
    case 6:
      result.push(['日期', '充值笔数', '充值金额', '充值均值', '微信充值', '支付宝充值', '消费笔数', '消费金额', '消费均值', '当日余额池沉淀', '累计余额池沉淀']);
      break;
    case 7:
      //租金
      result.push(['日期'], ['大区'], ['预约车辆数'], ['预约下单数'], ['预约转化率'], ['下单总数'], ['完成订单数'], ['完成订单租金总额'], ['完成订单优惠券使用总额'], ['完成订单保险总额'], ['订单均价(元)'], ['订单均使用时长(分)'], ['订单均行驶里程(km)'], ['每小时下单']);
      for (let i = 0; i < regions.length; i += 1) {
        result.push([regions[i].name]);
        for (let k = endDay + duration; k > endDay - 1; k -= 1) {
          if (k === 1) {
            start = '1 day'.before('today'.beginning);
            end = '1 day'.before('today'.ending);
          } else {
            start = `${k} days`.before('today'.beginning);
            end = `${k} days`.before('today'.ending)
          }
          const dateQuery = {
            $gte: start,
            $lt: end
          };
          //所有租金 保险消费
          let totalAmount = {};
          let totalInsurance = {};
          const rentBills = yield FNBalanceBillController.Model.find({
            createdAt: dateQuery,
            signal: {$in: [constants.FN_BALANCE_BILL_SIGNAL.支付订单租金, constants.FN_BALANCE_BILL_SIGNAL.订单免单]}
          }).populate({
            path: 'order',
            model: ODOrderController.Model,
            select: 'region'
          });
          const insuranceBills = yield FNBalanceBillController.Model.find({
            createdAt: dateQuery,
            signal: constants.FN_BALANCE_BILL_SIGNAL.支付订单保险
          }).populate({
            path: 'order',
            model: ODOrderController.Model,
            select: 'region'
          });
          rentBills.forEach(rentBill => {
            const amount = (rentBill.signal === constants.FN_BALANCE_BILL_SIGNAL.支付订单租金) ? rentBill.amount : -rentBill.amount;
            totalAmount[rentBill.order.region] = totalAmount[rentBill.order.region] ? (totalAmount[rentBill.order.region] + amount) : amount;
          });
          insuranceBills.forEach(insuranceBill => {
            totalInsurance[insuranceBill.order.region] = totalInsurance[insuranceBill.order.region] ? (totalInsurance[insuranceBill.order.region] + insuranceBill.amount) : insuranceBill.amount;
          });

          //预约车辆数
          const reservationCount = yield ODReservationController.Model.count({
            region: regions[i]._id,
            createdAt: dateQuery
          });
          //预约下单数
          const reservationOrderCount = yield ODOrderController.Model.count({
            region: regions[i]._id,
            createdAt: dateQuery,
            reservation: {$exists: true}
          });
          //下单总数
          const totalCount = yield ODOrderController.Model.count({
            region: regions[i]._id,
            finishedAt: dateQuery
          });
          //完成总数
          const finishOrders = yield ODOrderController.Model.find({
            region: regions[i]._id,
            isBad: false,
            finishedAt: dateQuery,
            state: {$ne: constants.OD_ORDER_STATE.异常结束}
          });
          let totalTime = 0;
          let totalDistance = 0;
          const orderDistribute = Array(24).fill(0);
          finishOrders.forEach(order => {
            totalTime += order.lease.totalDuration;
            totalDistance += order.route.distance;
            const hour = order.createdAt.getHours();
            orderDistribute[hour] += 1;
          });
          result[0].push(start.format('yyyy-MM-dd'));
          result[1].push(regions[i].name);
          result[2].push(reservationCount);
          result[3].push(reservationOrderCount);
          result[4].push(`${(reservationOrderCount / reservationCount * 100).toFixed(2)}%`);
          result[5].push(totalCount);
          result[6].push(finishOrders.length);
          result[7].push(totalAmount[regions[i]._id] / 100);
          result[8].push(finishOrders.length * 2);
          result[9].push(totalInsurance[regions[i]._id] / 100);
          result[10].push((totalAmount[regions[i]._id] / finishOrders.length / 100).toFixed(2));
          result[11].push((totalTime / finishOrders.length).toFixed(2));
          result[12].push((totalDistance / finishOrders.length / 1000).toFixed(2));
          orderDistribute.unshift(start.format('yyyy-MM-dd'));
          result.push(orderDistribute);
        }
      }
      break;
    case 8:
      result.push(['日期', '新充值押金笔数', '新充值押金数额', '提交提现押金笔数', '提交提现押金金额', '执行打款笔数', '执行打款数额', '提现中押金笔数', '提现中押金金额', '未提交提现押金池累计沉淀笔数', '押金池沉淀金额', '押金池笔数', '押金池金额', '累计支付押金人数', '累计退款押金人数']);
      break;
    case 9:
      result.push(['日期', '图片', '姓名', '手机号', '理由', '名称', '类型', '分值', '申诉时间', '处理状态', '结果', '处理人', '处理时间', '备注']);
      break;
    case 10:
      result.push(['日期', '图片', '姓名', '手机号', '内容', '状态', '反馈时间', '处理结果', '回复用户', '处理人', '处理时间']);
      break;
    case 11:
      result.push(['日期', '图片', '车辆编号', '类型', '姓名', '手机号', '上报地点', '用户地点', '描述', '状态', '上报时间', '处理人', '处理结果', '处理备注', '处理时间']);
      break;
    case 12:
      result.push(['日期', '图片', '车辆编号', '问题类型', '姓名', '手机号', '描述', '用户定位', '损坏信息', '状态', '上报时间', '处理人', '处理结果', '处理备注', '处理时间']);
      break;
    case 13:
      break;
    default:
      break;
  }
  for (let k = endDay + duration; k > endDay - 1; k -= 1) {
    if (k === 1) {
      start = '1 day'.before('today'.beginning);
      end = '1 day'.before('today'.ending);
    } else {
      start = `${k} days`.before('today'.beginning);
      end = `${k} days`.before('today'.ending)
    }
    const dateQuery = {
      $gte: start,
      $lt: end
    };
    //用户活跃度
    if (type === 1) {
      const loginRecords = yield RCLoginController.Model.find({
        createdAt: dateQuery,
      });
      const count = Array(10).fill(0);
      const existLoginRecords = [];
      for (let i = 0; i < loginRecords.length; i += 1) {
        const login = loginRecords[i];
        //去重
        if (!existLoginRecords.includes(login.user)) {
          existLoginRecords.push(login.user);
          //找到最老的一条登陆记录
          const oldLogin = yield RCLoginController.Model.findOne({
            createdAt: {$lt: start},
            user: login.user
          }).sort({_id: 1});
          if (oldLogin) {
            const interval = Math.ceil((login.createdAt.getTime() - oldLogin.createdAt.getTime()) / (24 * 3600 * 1000));
            if (interval === 1) {
              count[0] += 1;
            } else if (interval === 2) {
              count[1] += 1;
            } else if (interval === 3) {
              count[2] += 1;
            } else if (interval === 4) {
              count[3] += 1;
            } else if (interval === 5) {
              count[4] += 1;
            } else if (interval === 6) {
              count[5] += 1;
            } else if (interval >= 7 && interval < 30) {
              count[6] += 1;
            } else if (interval >= 30 && interval < 90) {
              count[7] += 1;
            } else if (interval >= 90 && interval < 360) {
              count[8] += 1;
            } else if (interval >= 360) {
              count[9] += 1;
            }
          }
        }
      }
      count.unshift(existLoginRecords.length);
      count.unshift(start.format('yyyy-MM-dd'));
      result.push(count);
    }
    //付费用户活跃度
    if (type === 2) {
      const orders = yield ODOrderController.Model.find({
        finishedAt: dateQuery,
      });
      let existUsers = [];
      let oldUser = 0;
      let newUser = 0;
      const count2 = new Array(7).fill(0);
      for (let i = 0; i < orders.length; i += 1) {
        const order = orders[i];
        const orderCount = yield ODOrderController.Model.count({
          _id: {$ne: order._id},
          user: order.user,
          isBad: false,
          finishedAt: {$gt: start}
        });
        orderCount === 0 ? count2[1] += 1 : count2[0] += 1;
        if (!existUsers.includes(order.user)) {
          existUsers.push(order.user);
          if (orderCount === 0) {
            newUser += 1;
          } else {
            oldUser += 1;
          }
        }

        switch (orderCount) {
          case 0:
            count2[2] += 1;
            break;
          case 1:
            count2[3] += 1;
            break;
          case 2:
            count2[4] += 1;
            break;
          case 3:
            count2[5] += 1;
            break;
          default:
            count2[6] += 1;
            break;
        }
      }
      count2.push(oldUser, newUser);
      count2.unshift(start.format('yyyy-MM-dd'));
      result.push(count2);
    }
    // 新用户增长
    if (type === 3) {
      const users = yield ACUserController.Model.find({
        createdAt: dateQuery,
      });
      let certCount = 0;
      let depositCount = 0;
      let orderCount = 0;
      const area = {
        '绵阳市': ['绵阳市', 0, 0, 0, 0],
        '北京市': ['北京市', 0, 0, 0, 0]
      };
      for (let i = 0; i < users.length; i += 1) {
        const user = users[i];
        const login = yield RCLoginController.Model.findOne({user: user._id});
        let city = '无';
        if (login && login.lngLat) {
          city = yield amap.findCityByLocation(login.lngLat)
        }
        if (['北京市', '绵阳市'].includes(city)) {
          area[city] = area[city] || [city, 1, 0, 0, 0];
          area[city][1] += 1;
          if (user.cert.hasVerified) {
            certCount += 1;
            area[city][2] += 1;
          }
          if (yield FNDepositBillController.Model.findOne({
              createdAt: dateQuery,
              type: constants.FN_DEPOSIT_BILL_TYPE.支付押金,
              user: user._id
            })) {
            depositCount += 1;
            area[city][3] += 1;
          }
          if (yield ODOrderController.Model.findOne({
              finishedAt: dateQuery,
              user: user._id
            })) {
            orderCount += 1;
            area[city][4] += 1;
          }
        }
      }
      result.push([start.format('yyyy-MM-dd'), users.length, certCount, depositCount, orderCount, area['北京市'][1], area['北京市'][2], area['北京市'][3], area['北京市'][4], area['绵阳市'][1], area['绵阳市'][2], area['绵阳市'][3], area['绵阳市'][4]])
    }
    // 系统规则
    if (type === 4) {
      const forbiddenParts = yield RCNotificationController.Model.find({
        createdAt: dateQuery,
        $or: [{'data.errorCode': {$in: ['controller.odOrder.stockInForbiddenArea', 'controller.odOrder.stockInProhibitedArea']}}, {'data.errorExtra.code': {$in: ['controller.odOrder.stockInForbiddenArea', 'controller.odOrder.stockInProhibitedArea']}}]
      });
      const existOrders = [];
      let forbiddenPartCount = 0;
      let noWalkCount = 0;
      let correctPartCount = 0;
      let correctWalkCount = 0;
      //遍历所有报错信息
      for (let j = 0; j < forbiddenParts.length; j += 1) {
        const forbiddenPart = forbiddenParts[j];
        const order = yield ODOrderController.Model.findById(forbiddenPart.data.errorExtra.order);
        //每个订单只算一次
        if (!existOrders.includes(order.id)) {
          existOrders.push(order.id);
          if (forbiddenPart.data.errorCode === 'controller.odOrder.stockInForbiddenArea' || (forbiddenPart.data.errorExtra && forbiddenPart.data.errorExtra.description) === 'controller.odOrder.stockInForbiddenArea') {
            if (order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁停区) {
              forbiddenPartCount += 1;
            } else {
              correctPartCount += 1;
            }
          } else {
            if (order.route.intersectPolygonType === constants.OP_POLYGON_TYPE.禁行区) {
              noWalkCount += 1;
            } else {
              correctWalkCount += 1;
            }
          }

        }
      }
      //超过20分钟结果订单
      const finishOrder = yield ODOrderController.Model.count({
        finishedAt: dateQuery,
        state: constants.OD_ORDER_STATE.长时无移动结束
      });
      //超过20分钟结束且在禁停区订单
      const wrongFinishOrder = yield ODOrderController.Model.count({
        finishedAt: dateQuery,
        state: constants.OD_ORDER_STATE.长时无移动结束,
        'route.intersectPolygonType': constants.OP_POLYGON_TYPE.禁停区
      });
      //实际总共禁停区数量
      const wrongFinalFinishOrder = yield ODOrderController.Model.count({
        finishedAt: dateQuery,
        'route.intersectPolygonType': constants.OP_POLYGON_TYPE.禁停区
      });
      //每天骑出围栏数量
      let actualCount = 0;
      const existOrder = [];
      (yield RCStockAlarmController.Model.find({
        createdAt: dateQuery,
        type: constants.RC_ALARM_TYPE.驶出围栏
      })).forEach(alarm => {
        if (!existOrder.includes(alarm.order)) {
          existOrder.push(alarm.order);
          actualCount += 1;
        }
      });
      result.push([start.format('yyyy-MM-dd'), actualCount, finishOrder, wrongFinalFinishOrder, wrongFinishOrder, forbiddenPartCount, correctPartCount, noWalkCount, correctWalkCount]);
    }
    //充值
    if (type === 6) {
      const rechargeBills = yield FNBalanceBillController.Model.find({
        createdAt: dateQuery,
        signal: constants.FN_BALANCE_BILL_SIGNAL.充值
      });
      let rechargeAmount = 0;
      let alipayCount = 0;
      let wxpayCount = 0;
      for (let i = 0; i < rechargeBills.length; i += 1) {
        rechargeAmount += rechargeBills[i].amount;
        const ticket = yield FNTicketController.Model.findById(rechargeBills[i].ticket);
        if (ticket.channel === 'alipay') {
          alipayCount += 1;
        } else if (ticket.channel === 'wx') {
          wxpayCount += 1;
        }
      }
      const costBills = yield FNBalanceBillController.Model.find({
        createdAt: dateQuery,
        signal: {$in: [constants.FN_BALANCE_BILL_SIGNAL.支付订单保险, constants.FN_BALANCE_BILL_SIGNAL.支付订单租金]},
      });
      let costAmount = 0;
      costBills.forEach(costBill => {
        costAmount += costBill.amount;
      });
      //总余额沉淀
      let totalBalanceAmount = 0;
      const wallets = yield ACWalletController.Model.find({balance: {$gt: 0}});
      wallets.forEach(wallet => {
        totalBalanceAmount += wallet.balance;
      });
      result.push([start.format('yyyy-MM-dd'), rechargeBills.length, rechargeAmount / 100, (rechargeAmount / rechargeBills.length / 100).toFixed(2), `${(alipayCount / rechargeBills.length * 100).toFixed(2)}%`, `${(wxpayCount / rechargeBills.length * 100).toFixed(2)}%`, costBills.length, costAmount / 100, (costAmount / costBills.length / 100).toFixed(2), (rechargeAmount - costAmount) / 100, totalBalanceAmount / 100]);
    }
    //押金关联
    if (type === 8) {
      //当日新增支付押金账单笔数
      const newDepositCount = yield FNDepositBillController.Model.count({
        createdAt: dateQuery,
        type: constants.FN_DEPOSIT_BILL_TYPE.支付押金
      });
      //当日申请提现笔数
      const refundDepositCount = yield FNTicketController.Model.count({
        type: constants.FN_TICKET_TYPE.支付押金,
        state: {$nin: [constants.FN_TICKET_STATE.已取消, constants.FN_TICKET_STATE.待支付]},
        'refund.appliedAt': dateQuery
      });
      //当日押金执行打款笔数
      const finishRefundCount = yield FNTicketController.Model.count({
        'refund.finishedAt': dateQuery,
        finishedAt: {$lt: end},
        type: constants.FN_TICKET_TYPE.支付押金
      });
      //提现中累计押金笔数
      const refundCount = yield FNTicketController.Model.count({
        type: constants.FN_TICKET_TYPE.支付押金,
        state: {$nin: [constants.FN_TICKET_STATE.已取消, constants.FN_TICKET_STATE.待支付]},
        'refund.appliedAt': {$lt: end},
        'refund.finishedAt': {$not: {$lte: end}}
      });
      //未提交提现押金笔数
      const unRefundCount = yield FNTicketController.Model.count({
        type: constants.FN_TICKET_TYPE.支付押金,
        state: {$nin: [constants.FN_TICKET_STATE.已取消, constants.FN_TICKET_STATE.待支付]},
        createdAt: {$lt: end},
        'refund.appliedAt': {$not: {$lte: end}}
      });
      //当日押金池笔数(未提交+退款中)
      // const totalRefundCount = yield FNTicketController.Model.count({
      //   type: constants.FN_TICKET_TYPE.支付押金,
      //   finishedAt: {$lt: end},
      //   'refund.finishedAt': {$not: {$lte: end}}
      // });
      // ticket时间脏了 账单脏数据已纠正 直接用累计支付 - 累计退还
      //累计支付押金人数
      const payCount = yield FNDepositBillController.Model.count({
        type: constants.FN_DEPOSIT_BILL_TYPE.支付押金,
        createdAt: {$lt: end}
      });
      //累计退还押金人数
      const payBackCount = yield FNDepositBillController.Model.count({
        type: constants.FN_DEPOSIT_BILL_TYPE.退还押金,
        createdAt: {$lt: end}
      });
      result.push([
        start.format('yyyy-MM-dd'),
        newDepositCount,
        newDepositCount * 299,
        refundDepositCount,
        refundDepositCount * 299,
        finishRefundCount,
        finishRefundCount * 299,
        refundCount,
        refundCount * 299,
        unRefundCount,
        unRefundCount * 299,
        payCount - payBackCount,
        (payCount - payBackCount) * 299,
        payCount,
        payBackCount]);
    }
    //信用申诉
    if (type === 9) {
      const typeMap = Object.keys(constants.AC_CREDIT_RECORD_TYPE);
      const stateMap = Object.keys(constants.OP_CREDIT_APPEAL_STATE);
      const resultMap = Object.keys(constants.OP_CREDIT_APPEAL_RESULT);
      result = result.concat((yield OPCreditAppealController.Model.find({
        createdAt: dateQuery
      }).populate({
        path: 'credit',
        model: ACCreditController.Model,
        select: 'name point type'
      }).populate({
        path: 'user',
        model: ACUserController.Model,
        select: 'cert.name auth.tel'
      }).populate({
        path: 'processor',
        model: ACUserController.Model,
        select: 'cert.name'
      })).map(creditAppeal => {
        return [
          start.format('yyyy-MM-dd'),
          creditAppeal.photos[0],
          creditAppeal.user.cert.name,
          creditAppeal.user.auth.tel,
          creditAppeal.reason,
          creditAppeal.credit.name,
          typeMap[creditAppeal.credit.type],
          creditAppeal.credit.point,
          creditAppeal.appealedAt.format('hh:mm:ss'),
          stateMap[creditAppeal.state],
          resultMap[creditAppeal.result],
          creditAppeal.processor && creditAppeal.processor.cert.name,
          (creditAppeal.passedAt && creditAppeal.passedAt.format('hh:mm:ss')) || (creditAppeal.rejectedAt && creditAppeal.rejectedAt.format('hh:mm:ss')),
          creditAppeal.passRemark || creditAppeal.rejectReason
        ]
      }));
    }
    //用户反馈
    if (type === 10) {
      const stateMap = Object.keys(constants.OP_REPORT_STATE);
      result = result.concat((yield OPFeedbackController.Model.find({
        createdAt: dateQuery
      }).populate({
        path: 'user',
        model: ACUserController.Model,
        select: 'cert.name auth.tel'
      }).populate({
        path: 'processor',
        model: ACUserController.Model,
        select: 'cert.name auth.tel'
      }).sort({_id: 1})).map(feedback => {
        return [
          start.format('yyyy-MM-dd'),
          feedback.photos[0],
          feedback.user.cert.name,
          feedback.user.auth.tel,
          feedback.description,
          stateMap[feedback.state],
          feedback.createdAt.format('hh:mm:ss'),
          feedback.result,
          feedback.reply,
          feedback.processor && feedback.processor.cert.name,
          feedback.processedAt && feedback.processedAt.format('hh:mm:ss')
        ]
      }))
    }
    //用户举报
    if (type === 11) {
      const typeMap = Object.keys(constants.OP_REPORTED_ABUSE_TYPE);
      const state = yield OPReportedAbuseController.Model.aggregate([
        {
          $match: {
            createdAt: dateQuery
          }
        }, {
          $group: {
            _id: {type: '$type'},
            count: {$sum: 1}
          }
        }
      ]).read('secondary');
      result.push([start.format('yyyyMMdd')]);
      result = result.concat(state.map(item => {
        return [typeMap[item._id.type], item.count]
      }))
    }
    //车辆报损
    if (type === 12) {
      const typeMap = Object.keys(constants.OP_REPORTED_DAMAGES_TYPE);
      const state = yield OPReportedDamageController.Model.aggregate([
        {
          $match: {
            createdAt: dateQuery
          }
        },
        {
          $group: {
            _id: {type: '$type'},
            count: {$sum: 1}
          }
        }
      ]).read('secondary');
      result.push([start.format('yyyyMMdd')]);
      result = result.concat(state.map(item => {
        return [typeMap[item._id.type], item.count]
      }));
    }
  }
  const name = Object.keys(constants.STATEMENT_TYPE)[type - 1];
  yield RCNotificationController.createDataExport({
    emailTo: 'csh@m.8ddao.com',
    name: `${name}-${query.startTime.format('yyyyMMdd')}-${query.endTime.format('yyyyMMdd')}`,
    sender: this.state.user.id,
    data: result
  });
}];