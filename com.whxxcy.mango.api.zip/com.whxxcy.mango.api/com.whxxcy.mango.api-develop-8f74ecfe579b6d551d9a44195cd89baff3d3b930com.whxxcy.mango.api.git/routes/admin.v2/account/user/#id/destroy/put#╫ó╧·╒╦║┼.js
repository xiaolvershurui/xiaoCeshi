const ACUserController = require('../../../../../../controllers/account/ACUserController');
const ACWalletController = require('../../../../../../controllers/account/ACWalletController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.ac.user.put'], {
  params: {
    id: validators.id.required().description('账户id').error(new Error('请输入账户ID')),
  },
}, function *({ params }) {
  const operator = this.state.user.id;
  const wallet = yield ACWalletController.findByUserAndCheckExists(operator);
  if (!wallet || wallet.balance < 0) throw new Error('请先缴清欠款');
  return yield ACUserController.destroy(params.id, operator);
}];
