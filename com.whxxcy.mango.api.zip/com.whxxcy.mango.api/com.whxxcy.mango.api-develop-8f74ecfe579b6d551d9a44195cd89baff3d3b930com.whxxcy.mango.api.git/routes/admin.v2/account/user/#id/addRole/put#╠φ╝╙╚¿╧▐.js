const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');
const Joi = require('joi');
const Error = require('errrr');

module.exports = [['admin'], {
  type: 'json',
  params: {
    id: validators.id.empty('').description('用户ID')
  },
  body: {
    role: Joi.string().required().description('角色').error(new Error('角色不合法'))
  }
}, function * ({ params, body }) {
  const { roles } = this.state.user;
  const { role } = body;
  if (!roles.includes('super') && role === 'admin') throw new Error('只有超管能添加管理员哦');
  const user = yield ACUserController.findByIdAndCheckExists(params.id);
  return yield ACUserController.Model.findByIdAndUpdate(user._id, {
    $addToSet: {
      'auth.roles': role
    }
  }, { new: true })
}];