const ACUserController = require('../../../../../../controllers/account/ACUserController');
const validators = require('../../../../../../settings/validators');

module.exports = [['admin'], {
  params: {
    id: validators.id.required().description('账户id').error(new Error('请输入账户ID'))
  }
}, function * ({ params }) {
  return yield ACUserController.cancelDestroy(params.id);
}];