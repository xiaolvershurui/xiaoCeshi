const ACUserController = require('../../../../../controllers/account/ACUserController');
const ACWalletController = require('../../../../../controllers/account/ACWalletController');
const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.user.get'], {
  params: {
    id: validators.id.empty('').description('用户ID'),
  },
}, function * ({ params }) {
  const user = yield ACUserController.findByIdAndCheckExists(params.id);
  const wallet = yield ACWalletController.findByUserAndCheckExists(user._id);
  const financeInfo = yield ACWalletController.getExtraFinanceInfo(user._id);
  const operator = yield ACOperatorController.Model.findOne({ user: params.id });
  return {
    user,
    wallet,
    financeInfo,
    operator,
  };
}];
