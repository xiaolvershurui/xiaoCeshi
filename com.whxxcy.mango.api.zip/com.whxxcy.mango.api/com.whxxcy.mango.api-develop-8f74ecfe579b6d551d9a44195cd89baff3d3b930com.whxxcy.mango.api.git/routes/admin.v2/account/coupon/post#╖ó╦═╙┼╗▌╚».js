const Joi = require('joi');
const { crypto } = require('xx-utils');
const validators = require('../../../../settings/validators');
const ACUserController = require('../../../../controllers/account/ACUserController');
const ACCouponController = require('../../../../controllers/account/ACCouponController');
const RCInviteController = require('../../../../controllers/record/RCInviteController');
const ACVerifyController = require('../../../../controllers/account/ACVerifyController');
const Error = require('errrr');
const settings = require('../../../../settings/index');

module.exports = [['public'], {
  type: 'json',
  body: {
    invitedByTel: validators.id.required().description('邀请用户'),
    invitedUserTel: validators.tel.required().description('被邀请用户'),
    code: Joi.string().empty('').required().description('verify code'),
  },
}, function *({ body }) {
  let { invitedByTel, invitedUserTel, code } = body;

  const invitedBy = yield ACUserController.findByIdAndCheckExists(invitedByTel);

  if ((invitedBy.auth && invitedBy.auth.tel) === invitedUserTel) throw new Error('不能邀请自己');
  // step 1: judge verify code
  const verify = yield ACVerifyController.findByTel(invitedUserTel);
  if (!verify) throw new Error('请先获取验证码');

  if (verify.code !== code) throw new Error('验证码不正确');

  // check user existence
  yield this.transaction.try(function *() {
    let user = yield ACUserController.findByTel(invitedUserTel);
    if (!user) {
      user = yield new ACUserController(this).create(invitedUserTel);
    }
    if (user.invite && user.invite.isReceivedCoupon) throw new Error('您已经领取了优惠券');
    yield new ACUserController(this).updateInvite(invitedBy._id, user._id);
  });
}];
