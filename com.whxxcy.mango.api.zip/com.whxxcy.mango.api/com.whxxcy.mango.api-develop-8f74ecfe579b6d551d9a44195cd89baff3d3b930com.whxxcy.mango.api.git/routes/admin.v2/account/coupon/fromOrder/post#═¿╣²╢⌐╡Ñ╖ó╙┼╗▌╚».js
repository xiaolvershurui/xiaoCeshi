const ODOrderController = require('../../../../../controllers/order/ODOrderController');
const Joi = require('joi');

module.exports = [['admin.ac.coupon.post'], {
  type: 'json',
  body: {
    orderId: Joi.string().required().description('订单编号').error(new Error('订单编号不合法')),
    name: Joi.string().required().description('优惠券名称').error(new Error('优惠券名称不合法')),
    amount: Joi.number().min(0).required().description('优惠券金额').error(new Error('金额不合法')),
    count: Joi.number().min(0).required().description('优惠券数量').error(new Error('数量不合法')),
    validateDay: Joi.number().min(0).required().description('优惠券有效期').error(new Error('有效期不合法')),
  },
}, function * ({ body }) {
  const { orderId, name, amount, count, validateDay } = body;
  const order = yield ODOrderController.findByIdAndCheckExists(orderId);
  if (order.grantCoupon) throw new Error('该订单已经补偿过优惠券');
  const { id } = this.state.user;
  yield this.transaction.try(function * () {
    yield new ODOrderController(this).grantCoupon({ order, amount, name, granter: id, count, validateDay });
  });
}];
