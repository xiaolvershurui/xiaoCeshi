const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const OPInspectionOrderController = require('../../../../../../controllers/operation/OPInspectionOrderController');
const OPRideOrderController = require('../../../../../../controllers/operation/OPRideOrderController');
const shark = require('../../../../../../services/shark/business');
const Error = require('errrr');

module.exports = [['admin.op.inspection_order.put'], {
  params: {
    id: validators.id.required().description('运营人员 Id'),
  },
}, function *({ params }) {
  // const { id } = this.state.user;
  const operator = yield ACOperatorController.findByIdAndCheckExists(params.id);
  if (!operator) throw new Error(`运营人员不存在`);
  if (!operator.isWorking) throw new Error(`运营人员${operator._id}已下班`);

  // 司机下班
  if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.司机) {
    const inspectionOrder = yield OPInspectionOrderController.Model.findOne({
      'user.id': operator.user,
      state: {
        $in: [constants.OP_INSPECTION_ORDER_STATE.派单中, constants.OP_INSPECTION_ORDER_STATE.暂停派单],
      },
    });
    if (!inspectionOrder) throw new Error('没有派单中的巡检订单');

    if (!inspectionOrder.times.backToStationAt) {
      yield this.transaction.try(function *() {
        yield new ACOperatorController(this).backToStation(inspectionOrder, operator.user, 'finishInspection');
      });
    }

    yield shark.sendSync({
      c: 'account/operator/finishInspection',
      params: { id: params.id },
    }, {
      timeout: 60000,
    });

  } else if (operator.inspectionType === constants.AC_OPERATOR_INSPECTION_TYPE.骑行) {
    // 骑手下班
    const riderOrder = yield OPRideOrderController.Model.findOne({
      'user.id': operator.user,
      state: {
        $in: [constants.OP_RIDER_ORDER_STATE.派单中],
      },
    });
    if (!riderOrder) throw new Error('没有派单中的骑手订单');

    yield this.transaction.try(function *() {
      yield new ACOperatorController(this).backToStation(riderOrder, operator.user, 'finishInspection');
    });

    yield shark.sendSync({
      c: 'account/operator/finishRider',
      params: { id: params.id },
    }, {
      timeout: 60000,
    });
  } else {
    // TODO: 非司机和骑手，仅下班
    return yield ACOperatorController.Model.findByIdAndUpdate(params.id, {
      $set: {
        isWorking: false,
        enableOffDuty: false,
        wrongCount: 0,
        missCount: 0,
        wrongStock: [],
        'batteryBag.total': 0,
        'batteryBag.batteries': [],
        'batteryBag.available': 0,
        'batteryBag.unavailable': 0,
      },
      $unset: {
        color: 1,
      },
    });
  }
}];

