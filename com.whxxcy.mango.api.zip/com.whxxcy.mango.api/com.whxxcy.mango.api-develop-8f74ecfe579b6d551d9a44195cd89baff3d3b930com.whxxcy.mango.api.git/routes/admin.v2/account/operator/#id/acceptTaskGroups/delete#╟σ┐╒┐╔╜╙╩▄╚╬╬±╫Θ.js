const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
}, function * ({ params, query }) {
  yield ACOperatorController.removeAcceptTaskGroups(params.id, query.taskGroup);
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];