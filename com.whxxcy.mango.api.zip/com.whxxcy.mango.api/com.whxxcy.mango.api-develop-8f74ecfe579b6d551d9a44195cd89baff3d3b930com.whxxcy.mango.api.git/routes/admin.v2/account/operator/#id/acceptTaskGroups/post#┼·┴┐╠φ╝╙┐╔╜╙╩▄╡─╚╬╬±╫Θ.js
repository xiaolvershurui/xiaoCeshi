const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  type: 'json',
  body: {
    taskGroups: Joi.array().items(Joi.number().valid(constants.BK_TASK_GROUP_ENUMS)).description('任务组').error(new Error('选择的任务组不正确'))
  }
}, function * ({ params, body }) {
  yield ACOperatorController.addAcceptTaskGroups(params.id, body.taskGroups);
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];