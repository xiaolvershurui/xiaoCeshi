const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('巡检人员ID').error(new Error('请选择巡检人员'))
  }
}, function * ({ params }) {
  return yield ACOperatorController.forceCheckIn(params.id);
}];