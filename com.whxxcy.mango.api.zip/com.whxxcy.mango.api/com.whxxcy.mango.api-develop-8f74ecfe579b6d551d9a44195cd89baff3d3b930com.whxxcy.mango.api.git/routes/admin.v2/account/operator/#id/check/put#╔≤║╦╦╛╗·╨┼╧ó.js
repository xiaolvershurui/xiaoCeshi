const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.ac.operator.put'], {
  type: 'json',
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  body: {
    checkStatus: Joi.valid(constants.AC_DRIVER_STATUS_ENUMS).required().description('审核状态').error(new Error('审核状态不合法'))
  }
}, function * ({ params, body }) {
  return yield ACOperatorController.Model.findByIdAndUpdate(params.id, {
    $set: {
      checkStatus: body.checkStatus
    }
  }, { new: true });
}];