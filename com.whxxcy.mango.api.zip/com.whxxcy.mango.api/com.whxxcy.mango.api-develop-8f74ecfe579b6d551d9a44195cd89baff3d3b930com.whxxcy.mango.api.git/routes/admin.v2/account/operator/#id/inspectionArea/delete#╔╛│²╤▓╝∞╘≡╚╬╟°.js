const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const BKStockController = require('../../../../../../controllers/ebike/BKStockController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  query: {
    inspectionArea: validators.id.required().description('巡检责任区ID').error(new Error('请选择巡检责任区'))
  }
}, function * ({ params, query }) {
  const acOp = yield ACOperatorController.removeInspectionArea(params.id, query.inspectionArea);
  // 删除巡检区 同时释放掉不符合条件的任务
  yield BKStockController.releaseInvalidByInspector(acOp.user);
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];