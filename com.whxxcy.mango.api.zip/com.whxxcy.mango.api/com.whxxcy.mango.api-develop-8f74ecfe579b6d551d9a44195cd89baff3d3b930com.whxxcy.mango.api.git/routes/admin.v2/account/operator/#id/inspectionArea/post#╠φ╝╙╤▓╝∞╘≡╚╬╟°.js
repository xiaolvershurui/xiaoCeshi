const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  type: 'json',
  body: {
    inspectionArea: validators.id.required().description('巡检责任区ID').error(new Error('请选择巡检责任区'))
  }
}, function * ({ params, body }) {
  yield ACOperatorController.addInspectionArea(params.id, body.inspectionArea);
  return yield ACOperatorController.findByIdAndPopulate(params.id);
}];