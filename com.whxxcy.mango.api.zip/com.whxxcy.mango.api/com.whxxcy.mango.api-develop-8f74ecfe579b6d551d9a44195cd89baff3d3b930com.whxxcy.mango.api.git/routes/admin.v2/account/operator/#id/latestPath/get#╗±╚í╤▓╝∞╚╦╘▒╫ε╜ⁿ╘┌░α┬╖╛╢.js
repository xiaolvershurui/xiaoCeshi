const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.ac.operator.get'], {
  params: {
    id: validators.id.required().description('巡检人员ID').error(new Error('请选择巡检人员'))
  }
}, function * ({ params }) {
  const { regionIds } = this.state.user;
  const operator = yield ACOperatorController.Model.findOne({
    _id: params.id,
    regions: { $in: regionIds }
  });
  if (!operator) throw new Error('运营账户不存在或无权限');
  return yield ACOperatorController.findLatestPath(operator.user);
}];