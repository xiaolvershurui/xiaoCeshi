const ACOperatorController = require('../../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../../settings/validators');
const constants = require('../../../../../../settings/constants');
const Joi = require('joi');

module.exports = [['admin.ac.operator.put'], {
  params: {
    id: validators.id.required().description('运营ID').error(new Error('运营ID不正确'))
  },
  type: 'json',
  body: {
    doc: Joi.object().required().description('修改信息').error(new Error('修改信息不合法'))
  }
}, function * ({ params, body }) {
  return yield ACOperatorController.Model.findByIdAndUpdate(params.id, body.doc, { new: true });
}];