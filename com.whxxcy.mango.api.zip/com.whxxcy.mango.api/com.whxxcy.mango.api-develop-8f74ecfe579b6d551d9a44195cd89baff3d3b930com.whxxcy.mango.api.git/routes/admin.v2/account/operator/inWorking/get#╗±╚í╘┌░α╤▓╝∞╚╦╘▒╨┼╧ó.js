const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../settings/validators');

module.exports = [['admin.ac.operator.getMany'], {
  query: {
    region: validators.id.empty('').description('大区ID，可不填').error(new Error('大区ID不正确')),
  }
}, function * ({ query }) {
  let regions = this.state.user.regionIds;
  if (query.region) {
    regions = [query.region];
  }
  return yield ACOperatorController.findAllInWorking(regions, true);
}];