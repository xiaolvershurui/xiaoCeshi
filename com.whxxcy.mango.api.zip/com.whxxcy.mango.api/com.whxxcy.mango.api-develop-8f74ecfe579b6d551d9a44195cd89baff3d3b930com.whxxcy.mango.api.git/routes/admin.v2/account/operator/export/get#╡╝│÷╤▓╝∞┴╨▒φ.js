const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const OPRegionController = require('../../../../../controllers/operation/OPRegionController');
const OPPolygonController = require('../../../../../controllers/operation/OPPolygonController');
const Joi = require('joi');
const exporter = require('../../../../../services/dataTrasfer/exporter');
const constants = require('../../../../../settings/constants');
module.exports = [['admin.bk.stock.getMany'], {
  query: {
    query: Joi.object().description('查询条件').error(new Error('查询条件不合法')),
    skip: Joi.number().default(0).description('跳过数').error(new Error('跳过数目不合法')),
    sort: Joi.object().description('排序条件').error(new Error('排序条件')),
  }
}, function * ({ query }) {
  const { regionIds } = this.state.user;
  const finalQuery = {
    $and: [query.query, {
      region: { $in: [...regionIds, null] }
    }]
  };
  const items = yield ACOperatorController.countTasks(yield ACOperatorController.Model.find(finalQuery).skip(query.skip).limit(query.limit).sort(query.sort).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'cert.name auth.tel',
  }).populate({
    path: 'regions',
    model: OPRegionController.Model,
    select: 'name city'
  }).populate({
    path: 'inspectionAreas',
    model: OPPolygonController.Model,
    select: 'name type'
  }));
  this.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  return yield exporter(items, {
    ID: '_id',
    姓名: 'user.cert.name',
    任务数: 'taskCount',
    调度任务数: 'dispatchTaskCount',
    换电: 'changePower',
    拖回: 'back',
  }, `巡检列表-${new Date().toNanoString()}`);
}];