const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const validators = require('../../../../../settings/validators');
const Error = require('errrr');

module.exports = [['admin.ac.operator.getMany'], {
  query: {
    region: validators.id.required().description('大区ID').error(new Error('大区ID不正确'))
  }
}, function * ({ query }) {
  const { regionIds } = this.state.user;
  if (!regionIds.includes(query.region)) throw new Error('无大区权限');
  return yield ACOperatorController.findAvailableInspector(query.region);
}];