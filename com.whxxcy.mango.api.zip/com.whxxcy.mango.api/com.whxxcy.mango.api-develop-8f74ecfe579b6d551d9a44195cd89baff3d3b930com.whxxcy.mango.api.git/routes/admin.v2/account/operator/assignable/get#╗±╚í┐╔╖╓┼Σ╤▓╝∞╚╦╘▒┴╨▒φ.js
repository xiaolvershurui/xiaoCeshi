const ACOperatorController = require('../../../../../controllers/account/ACOperatorController');
const ACUserController = require('../../../../../controllers/account/ACUserController');
const OPBatteryStationController = require('../../../../../controllers/operation/OPBatteryStationController');
const Error = require('errrr');

module.exports = [['admin.ac.operator.getMany'], {}, function * () {
  const { stationId } = this.state.user;
  const station = yield OPBatteryStationController.findByIdAndCheckExists(stationId);
  return yield ACOperatorController.Model.find({
    regions: station.region,
    isWorking: true,
    enable: true
  }).populate({
    path: 'user',
    model: ACUserController.Model,
    select: 'auth.tel cert.name'
  }).select('isWorking user')
}];