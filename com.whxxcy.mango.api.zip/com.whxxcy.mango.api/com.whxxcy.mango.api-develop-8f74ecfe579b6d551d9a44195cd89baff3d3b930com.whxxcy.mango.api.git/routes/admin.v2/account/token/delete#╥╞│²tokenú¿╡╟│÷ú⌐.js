module.exports = [['public'], {}, function * () {
  yield this.Token.destroy();
}];
