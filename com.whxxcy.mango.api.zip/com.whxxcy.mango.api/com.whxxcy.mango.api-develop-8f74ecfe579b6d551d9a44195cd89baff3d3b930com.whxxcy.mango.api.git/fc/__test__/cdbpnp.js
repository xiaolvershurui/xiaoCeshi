/*eslint-disable*/

const fc = require('../');
const path = require('./path');

(async _ => {
  const result = await fc.exec(fc.functions.计算点到面记录, { path, point:  [
    116.4570457850843,
    39.87995622456473
  ]});
})().catch(console.error);
