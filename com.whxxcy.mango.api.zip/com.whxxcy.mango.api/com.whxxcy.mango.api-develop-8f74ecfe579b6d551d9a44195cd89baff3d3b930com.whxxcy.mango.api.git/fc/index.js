const FCClient = require('@alicloud/fc');
const client = module.exports = new FCClient('1898345410638071', {
  accessKeyID: 'wqIamDTjWjDNoef9',
  accessKeySecret: 'EDqGomWlqAVM1fmFemgoFeOfKJmqy1',
  region: 'cn-shanghai'
});
const serviceName = module.exports.serviceName = 'mangoebike';

module.exports.functions = {
  计算点到面记录: 'calculateDistanceBetweenPointAndPolygon'
};

module.exports.exec = async (func, params) => {
  const result = await client.invokeFunction(serviceName, func, JSON.stringify(params));
  if(result && result.errorMessage) {
    throw new Error(result.errorMessage);
  }
  return result;
};