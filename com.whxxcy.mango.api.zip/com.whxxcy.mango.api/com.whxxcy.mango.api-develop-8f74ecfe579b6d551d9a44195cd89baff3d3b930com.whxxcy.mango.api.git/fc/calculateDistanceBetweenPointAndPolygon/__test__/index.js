/*eslint-disable*/
const path = require('../../__test__/path');

const calc = require('../');

calc.handler(JSON.stringify({ path, point: [
  116.45699251653667,
  39.8799143705844
]}), null, console.log);