/*eslint-disable*/
const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');
const dirTraveler = require('dir-traveler');

const client = require('./');
const serviceName = client.serviceName;

// 压缩文件
const zipFolder = async folder => {
  return new Promise((resolve, reject) => {
    const zip = new JSZip();
    const files = dirTraveler(path.resolve(__dirname, folder));
    Object.keys(files).forEach(key => {
      zip.file(key, fs.readFileSync(files[key]));
    });
    zip.generateNodeStream({
      type: 'nodebuffer',
      streamFiles: true
    }).pipe(fs.createWriteStream(path.resolve(__dirname, `${folder}.zip`)))
      .on('finish', resolve)
      .on('error', reject);
  });
};

// 创建或更新函数
const upsertFunction = async (functionName, {
  memorySize = 128,
  runtime = 'nodejs4.4',
  description = '',
  handler = 'index.handler',
  timeout = 3
} = {}) => {
  if (!functionName) throw new Error('请指定函数名');
  const zipFileName = path.resolve(__dirname, `${functionName}.zip`);
  if (fs.existsSync(zipFileName)) {
    fs.unlinkSync(zipFileName);
  }
  // 压缩源码
  await zipFolder(functionName);
  const commonOptions = {
    description,
    handler,
    memorySize,
    runtime,
    timeout,
    code: {
      zipFile: fs.readFileSync(zipFileName, 'base64')
    }
  };
  // 查询函数是否存在
  try {
    await client.getFunction(serviceName, functionName);
    // 更新函数
    await client.updateFunction(serviceName, functionName, commonOptions);
    console.log(`Updated function [${functionName}]`);
  } catch (err) {
    // 创建函数
    await client.createFunction(serviceName, Object.assign({
      functionName
    }, commonOptions));
    console.log(`Created function [${functionName}]`);
  }
};

(async _ => {
  await upsertFunction('calculateDistanceBetweenPointAndPolygon');
})().catch(console.error);